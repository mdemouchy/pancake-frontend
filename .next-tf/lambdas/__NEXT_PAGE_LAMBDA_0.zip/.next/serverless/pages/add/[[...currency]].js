"use strict";
(() => {
var exports = {};
exports.id = 6619;
exports.ids = [6619];
exports.modules = {

/***/ 25116:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "unstable_getStaticParams": () => (/* binding */ unstable_getStaticParams),
/* harmony export */   "unstable_getStaticProps": () => (/* binding */ unstable_getStaticProps),
/* harmony export */   "unstable_getStaticPaths": () => (/* binding */ unstable_getStaticPaths),
/* harmony export */   "unstable_getServerProps": () => (/* binding */ unstable_getServerProps),
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "_app": () => (/* binding */ _app),
/* harmony export */   "renderReqToHTML": () => (/* binding */ renderReqToHTML),
/* harmony export */   "render": () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(70607);
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59450);
/* harmony import */ var private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97020);
/* harmony import */ var private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(73978);
/* harmony import */ var next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99436);

      
      
      
      

      
      const { processEnv } = __webpack_require__(85360)
      processEnv([{"path":".env.production","contents":"NEXT_PUBLIC_CHAIN_ID = \"1666700000\"\nNEXT_PUBLIC_GTAG = \"GTM-PXLD3XW\"\n\n# 10+ nodes balanced, US/EU\nNEXT_PUBLIC_NODE_1 = \"https://api.s0.b.hmny.io\"\n\n# 10+ nodes balanced, US/EU\nNEXT_PUBLIC_NODE_2 = \"https://api.s0.b.hmny.io\"\n\n# 10+ nodes balanced in each region, global\nNEXT_PUBLIC_NODE_3 = \"https://api.s0.b.hmny.io\"\n\n# Google Cloud Infrastructure Endpoint - Global\n#NEXT_PUBLIC_NODE_PRODUCTION = \"https://nodes.pancakeswap.com\"\n\nNEXT_PUBLIC_GRAPH_API_PROFILE = \"https://api.thegraph.com/subgraphs/name/pancakeswap/profile\"\nNEXT_PUBLIC_GRAPH_API_PREDICTION = \"https://api.thegraph.com/subgraphs/name/pancakeswap/prediction-v2\"\nNEXT_PUBLIC_GRAPH_API_LOTTERY = \"https://api.thegraph.com/subgraphs/name/pancakeswap/lottery\"\nNEXT_PUBLIC_GRAPH_API_NFT_MARKET = \"https://api.thegraph.com/subgraphs/name/pancakeswap/nft-market\"\n\nNEXT_PUBLIC_SNAPSHOT_BASE_URL = \"https://hub.snapshot.org\"\nNEXT_PUBLIC_SNAPSHOT_VOTING_API = \"https://voting-api.pancakeswap.info/api\"\n\nNEXT_PUBLIC_API_NFT = \"https://nft.pancakeswap.com/api/v1\"\nNEXT_PUBLIC_BIT_QUERY_ENDPOINT = \"https://graphql.bitquery.io\"\n"},{"path":".env","contents":"NEXT_PUBLIC_API_PROFILE = https://profile.pancakeswap.com"}])
    
      
      const runtimeConfig = {}
      ;

      const documentModule = __webpack_require__(85641)

      const appMod = __webpack_require__(12957)
      let App = appMod.default || appMod.then && appMod.then(mod => mod.default);

      const compMod = __webpack_require__(29527)

      const Component = compMod.default || compMod.then && compMod.then(mod => mod.default)
      /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Component);
      const getStaticProps = compMod['getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['getStaticProp' + 's'])
      const getStaticPaths = compMod['getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['getStaticPath' + 's'])
      const getServerSideProps = compMod['getServerSideProp' + 's'] || compMod.then && compMod.then(mod => mod['getServerSideProp' + 's'])

      // kept for detecting legacy exports
      const unstable_getStaticParams = compMod['unstable_getStaticParam' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticParam' + 's'])
      const unstable_getStaticProps = compMod['unstable_getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticProp' + 's'])
      const unstable_getStaticPaths = compMod['unstable_getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticPath' + 's'])
      const unstable_getServerProps = compMod['unstable_getServerProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getServerProp' + 's'])

      let config = compMod['confi' + 'g'] || (compMod.then && compMod.then(mod => mod['confi' + 'g'])) || {}
      const _app = App

      const combinedRewrites = Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)
        ? private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg
        : []

      if (!Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)) {
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.beforeFiles */ .Dg.beforeFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.afterFiles */ .Dg.afterFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.fallback */ .Dg.fallback)
      }

      const { renderReqToHTML, render } = (0,next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__/* .getPageHandler */ .u)({
        pageModule: compMod,
        pageComponent: Component,
        pageConfig: config,
        appModule: App,
        documentModule: documentModule,
        errorModule: __webpack_require__(54141),
        notFoundModule: __webpack_require__(59622),
        pageGetStaticProps: getStaticProps,
        pageGetStaticPaths: getStaticPaths,
        pageGetServerSideProps: getServerSideProps,

        assetPrefix: "",
        canonicalBase: "",
        generateEtags: true,
        poweredByHeader: true,

        runtimeConfig,
        buildManifest: private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__,
        reactLoadableManifest: private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__,

        rewrites: combinedRewrites,
        i18n: undefined,
        page: "/add/[[...currency]]",
        buildId: "bk7DdLVRVq-P98G1wWWjl",
        escapedBuildId: "bk7DdLVRVq\-P98G1wWWjl",
        basePath: "",
        pageIsDynamic: true,
        encodedPreviewProps: {previewModeId:"3b2a374a9cc8399f3636f3a5a38de72b",previewModeSigningKey:"1c36cb3b93f11355763ed0d7dcb8ff73adf6e5d62ec7fdc8f3c5ca1edd50b7b2",previewModeEncryptionKey:"601ee8797bc61c221f8a6883c44b005277ef8f2d433e035f7b94ee068979f9fa"}
      })
      
    

/***/ }),

/***/ 29527:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var views_AddLiquidity__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(78848);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([views_AddLiquidity__WEBPACK_IMPORTED_MODULE_0__]);
views_AddLiquidity__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (views_AddLiquidity__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);
const OLD_PATH_STRUCTURE = /^(0x[a-fA-F0-9]{40}|BNB)-(0x[a-fA-F0-9]{40}|BNB)$/;
const getStaticPaths = ()=>{
    return {
        paths: [
            {
                params: {
                    currency: []
                }
            }
        ],
        fallback: true
    };
};
const getStaticProps = async ({ params  })=>{
    const { currency =[]  } = params;
    const [currencyIdA, currencyIdB] = currency;
    const match = currencyIdA?.match(OLD_PATH_STRUCTURE);
    if (match?.length) {
        return {
            redirect: {
                statusCode: 301,
                destination: `/add/${match[1]}/${match[2]}`
            }
        };
    }
    if (currencyIdA && currencyIdB && currencyIdA.toLowerCase() === currencyIdB.toLowerCase()) {
        return {
            redirect: {
                statusCode: 303,
                destination: `/add/${currencyIdA}`
            }
        };
    }
    return {
        props: {}
    };
};

});

/***/ }),

/***/ 20081:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OY": () => (/* binding */ useMintState),
/* harmony export */   "OA": () => (/* binding */ useMintActionHandlers),
/* harmony export */   "Qw": () => (/* binding */ useDerivedMintInfo)
/* harmony export */ });
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(42877);
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(64011);
/* harmony import */ var hooks_usePairs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(84915);
/* harmony import */ var hooks_useTotalSupply__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(23552);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(99150);
/* harmony import */ var utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(53854);
/* harmony import */ var _swap_hooks__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(36717);
/* harmony import */ var _wallet_hooks__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(71900);
/* harmony import */ var _actions__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(60650);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks_usePairs__WEBPACK_IMPORTED_MODULE_4__, _swap_hooks__WEBPACK_IMPORTED_MODULE_8__, _wallet_hooks__WEBPACK_IMPORTED_MODULE_9__, hooks_useTotalSupply__WEBPACK_IMPORTED_MODULE_5__]);
([hooks_usePairs__WEBPACK_IMPORTED_MODULE_4__, _swap_hooks__WEBPACK_IMPORTED_MODULE_8__, _wallet_hooks__WEBPACK_IMPORTED_MODULE_9__, hooks_useTotalSupply__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);











const ZERO = _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(0);
function useMintState() {
    return (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useSelector)((state)=>state.mint
    );
}
function useMintActionHandlers(noLiquidity) {
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useDispatch)();
    const onFieldAInput = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((typedValue)=>{
        dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_10__/* .typeInput */ .LC)({
            field: _actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_A */ .gN.CURRENCY_A,
            typedValue,
            noLiquidity: noLiquidity === true
        }));
    }, [
        dispatch,
        noLiquidity
    ]);
    const onFieldBInput = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((typedValue)=>{
        dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_10__/* .typeInput */ .LC)({
            field: _actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_B */ .gN.CURRENCY_B,
            typedValue,
            noLiquidity: noLiquidity === true
        }));
    }, [
        dispatch,
        noLiquidity
    ]);
    return {
        onFieldAInput,
        onFieldBInput
    };
}
function useDerivedMintInfo(currencyA, currencyB) {
    const { account , chainId  } = (0,hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)();
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_6__/* .useTranslation */ .$G)();
    const { independentField , typedValue , otherTypedValue  } = useMintState();
    const dependentField = independentField === _actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_A */ .gN.CURRENCY_A ? _actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_B */ .gN.CURRENCY_B : _actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_A */ .gN.CURRENCY_A;
    // tokens
    const currencies = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>({
            [_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]: currencyA ?? undefined,
            [_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]: currencyB ?? undefined
        })
    , [
        currencyA,
        currencyB
    ]);
    // pair
    const [pairState, pair] = (0,hooks_usePairs__WEBPACK_IMPORTED_MODULE_4__/* .usePair */ .yX)(currencies[_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_A */ .gN.CURRENCY_A], currencies[_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]);
    const totalSupply = (0,hooks_useTotalSupply__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)(pair?.liquidityToken);
    const noLiquidity = pairState === hooks_usePairs__WEBPACK_IMPORTED_MODULE_4__/* .PairState.NOT_EXISTS */ ._G.NOT_EXISTS || Boolean(totalSupply && _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.equal(totalSupply.raw, ZERO));
    // balances
    const balances = (0,_wallet_hooks__WEBPACK_IMPORTED_MODULE_9__/* .useCurrencyBalances */ .K5)(account ?? undefined, [
        currencies[_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_A */ .gN.CURRENCY_A],
        currencies[_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_B */ .gN.CURRENCY_B], 
    ]);
    const currencyBalances = {
        [_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]: balances[0],
        [_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]: balances[1]
    };
    // amounts
    const independentAmount = (0,_swap_hooks__WEBPACK_IMPORTED_MODULE_8__/* .tryParseAmount */ .eo)(typedValue, currencies[independentField]);
    const dependentAmount = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        if (noLiquidity) {
            if (otherTypedValue && currencies[dependentField]) {
                return (0,_swap_hooks__WEBPACK_IMPORTED_MODULE_8__/* .tryParseAmount */ .eo)(otherTypedValue, currencies[dependentField]);
            }
            return undefined;
        }
        if (independentAmount) {
            // we wrap the currencies just to get the price in terms of the other token
            const wrappedIndependentAmount = (0,utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_7__/* .wrappedCurrencyAmount */ .N)(independentAmount, chainId);
            const [tokenA, tokenB] = [
                (0,utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_7__/* .wrappedCurrency */ .pu)(currencyA, chainId),
                (0,utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_7__/* .wrappedCurrency */ .pu)(currencyB, chainId)
            ];
            if (tokenA && tokenB && wrappedIndependentAmount && pair) {
                const dependentCurrency = dependentField === _actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_B */ .gN.CURRENCY_B ? currencyB : currencyA;
                const dependentTokenAmount = dependentField === _actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_B */ .gN.CURRENCY_B ? pair.priceOf(tokenA).quote(wrappedIndependentAmount) : pair.priceOf(tokenB).quote(wrappedIndependentAmount);
                return dependentCurrency === _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.ETHER ? _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.CurrencyAmount.ether(dependentTokenAmount.raw) : dependentTokenAmount;
            }
            return undefined;
        }
        return undefined;
    }, [
        noLiquidity,
        otherTypedValue,
        currencies,
        dependentField,
        independentAmount,
        currencyA,
        chainId,
        currencyB,
        pair
    ]);
    const parsedAmounts = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>({
            [_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]: independentField === _actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_A */ .gN.CURRENCY_A ? independentAmount : dependentAmount,
            [_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]: independentField === _actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_A */ .gN.CURRENCY_A ? dependentAmount : independentAmount
        })
    , [
        dependentAmount,
        independentAmount,
        independentField
    ]);
    const price = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        if (noLiquidity) {
            const { [_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]: currencyAAmount , [_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]: currencyBAmount  } = parsedAmounts;
            if (currencyAAmount && currencyBAmount) {
                return new _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.Price(currencyAAmount.currency, currencyBAmount.currency, currencyAAmount.raw, currencyBAmount.raw);
            }
            return undefined;
        }
        const wrappedCurrencyA = (0,utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_7__/* .wrappedCurrency */ .pu)(currencyA, chainId);
        return pair && wrappedCurrencyA ? pair.priceOf(wrappedCurrencyA) : undefined;
    }, [
        chainId,
        currencyA,
        noLiquidity,
        pair,
        parsedAmounts
    ]);
    // liquidity minted
    const liquidityMinted = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        const { [_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]: currencyAAmount , [_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]: currencyBAmount  } = parsedAmounts;
        const [tokenAmountA, tokenAmountB] = [
            (0,utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_7__/* .wrappedCurrencyAmount */ .N)(currencyAAmount, chainId),
            (0,utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_7__/* .wrappedCurrencyAmount */ .N)(currencyBAmount, chainId), 
        ];
        if (pair && totalSupply && tokenAmountA && tokenAmountB) {
            return pair.getLiquidityMinted(totalSupply, tokenAmountA, tokenAmountB);
        }
        return undefined;
    }, [
        parsedAmounts,
        chainId,
        pair,
        totalSupply
    ]);
    const poolTokenPercentage = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        if (liquidityMinted && totalSupply) {
            return new _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.Percent(liquidityMinted.raw, totalSupply.add(liquidityMinted).raw);
        }
        return undefined;
    }, [
        liquidityMinted,
        totalSupply
    ]);
    let error;
    if (!account) {
        error = t('Connect Wallet');
    }
    if (pairState === hooks_usePairs__WEBPACK_IMPORTED_MODULE_4__/* .PairState.INVALID */ ._G.INVALID) {
        error = error ?? t('Invalid pair');
    }
    if (!parsedAmounts[_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_A */ .gN.CURRENCY_A] || !parsedAmounts[_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]) {
        error = error ?? t('Enter an amount');
    }
    const { [_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]: currencyAAmount1 , [_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]: currencyBAmount1  } = parsedAmounts;
    if (currencyAAmount1 && currencyBalances?.[_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]?.lessThan(currencyAAmount1)) {
        error = t('Insufficient %symbol% balance', {
            symbol: currencies[_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]?.symbol
        });
    }
    if (currencyBAmount1 && currencyBalances?.[_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]?.lessThan(currencyBAmount1)) {
        error = t('Insufficient %symbol% balance', {
            symbol: currencies[_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]?.symbol
        });
    }
    return {
        dependentField,
        currencies,
        pair,
        pairState,
        currencyBalances,
        parsedAmounts,
        price,
        noLiquidity,
        liquidityMinted,
        poolTokenPercentage,
        error
    };
}

});

/***/ }),

/***/ 34900:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(99150);
/* harmony import */ var _components_Layout_Row__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(39475);
/* harmony import */ var _components_Logo__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(83356);
/* harmony import */ var _state_mint_actions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(60650);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Logo__WEBPACK_IMPORTED_MODULE_5__]);
_components_Logo__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];







function ConfirmAddModalBottom({ noLiquidity , price , currencies , parsedAmounts , poolTokenPercentage , onAdd  }) {
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_3__/* .useTranslation */ .$G)();
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layout_Row__WEBPACK_IMPORTED_MODULE_4__/* .RowBetween */ .m0, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        children: t('%asset% Deposited', {
                            asset: currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_6__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]?.symbol
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layout_Row__WEBPACK_IMPORTED_MODULE_4__/* .RowFixed */ .DA, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Logo__WEBPACK_IMPORTED_MODULE_5__/* .CurrencyLogo */ .Xw, {
                                currency: currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_6__/* .Field.CURRENCY_A */ .gN.CURRENCY_A],
                                style: {
                                    marginRight: '8px'
                                }
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                children: parsedAmounts[_state_mint_actions__WEBPACK_IMPORTED_MODULE_6__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]?.toSignificant(6)
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layout_Row__WEBPACK_IMPORTED_MODULE_4__/* .RowBetween */ .m0, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        children: t('%asset% Deposited', {
                            asset: currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_6__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]?.symbol
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layout_Row__WEBPACK_IMPORTED_MODULE_4__/* .RowFixed */ .DA, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Logo__WEBPACK_IMPORTED_MODULE_5__/* .CurrencyLogo */ .Xw, {
                                currency: currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_6__/* .Field.CURRENCY_B */ .gN.CURRENCY_B],
                                style: {
                                    marginRight: '8px'
                                }
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                children: parsedAmounts[_state_mint_actions__WEBPACK_IMPORTED_MODULE_6__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]?.toSignificant(6)
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layout_Row__WEBPACK_IMPORTED_MODULE_4__/* .RowBetween */ .m0, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        children: t('Rates')
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        children: `1 ${currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_6__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]?.symbol} = ${price?.toSignificant(4)} ${currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_6__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]?.symbol}`
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Layout_Row__WEBPACK_IMPORTED_MODULE_4__/* .RowBetween */ .m0, {
                style: {
                    justifyContent: 'flex-end'
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                    children: `1 ${currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_6__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]?.symbol} = ${price?.invert().toSignificant(4)} ${currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_6__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]?.symbol}`
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layout_Row__WEBPACK_IMPORTED_MODULE_4__/* .RowBetween */ .m0, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        children: [
                            t('Share of Pool'),
                            ":"
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        children: [
                            noLiquidity ? '100' : poolTokenPercentage?.toSignificant(4),
                            "%"
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                onClick: onAdd,
                mt: "20px",
                children: noLiquidity ? t('Create Pool & Supply') : t('Confirm Supply')
            })
        ]
    }));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ConfirmAddModalBottom);

});

/***/ }),

/***/ 89113:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(99150);
/* harmony import */ var _components_Layout_Column__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(41914);
/* harmony import */ var _components_Layout_Row__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(39475);
/* harmony import */ var _config_constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3862);
/* harmony import */ var _state_mint_actions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(60650);








function PoolPriceBar({ currencies , noLiquidity , poolTokenPercentage , price  }) {
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_3__/* .useTranslation */ .$G)();
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Layout_Column__WEBPACK_IMPORTED_MODULE_4__/* .AutoColumn */ .Tz, {
        gap: "md",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layout_Row__WEBPACK_IMPORTED_MODULE_5__/* .AutoRow */ .BA, {
            justify: "space-around",
            gap: "4px",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layout_Column__WEBPACK_IMPORTED_MODULE_4__/* .AutoColumn */ .Tz, {
                    justify: "center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                            children: price?.toSignificant(6) ?? '-'
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                            fontSize: "14px",
                            pt: 1,
                            children: t('%assetA% per %assetB%', {
                                assetA: currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_7__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]?.symbol ?? '',
                                assetB: currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_7__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]?.symbol ?? ''
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layout_Column__WEBPACK_IMPORTED_MODULE_4__/* .AutoColumn */ .Tz, {
                    justify: "center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                            children: price?.invert()?.toSignificant(6) ?? '-'
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                            fontSize: "14px",
                            pt: 1,
                            children: t('%assetA% per %assetB%', {
                                assetA: currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_7__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]?.symbol ?? '',
                                assetB: currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_7__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]?.symbol ?? ''
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layout_Column__WEBPACK_IMPORTED_MODULE_4__/* .AutoColumn */ .Tz, {
                    justify: "center",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                            children: [
                                noLiquidity && price ? '100' : (poolTokenPercentage?.lessThan(_config_constants__WEBPACK_IMPORTED_MODULE_6__/* .ONE_BIPS */ .IS) ? '<0.01' : poolTokenPercentage?.toFixed(2)) ?? '0',
                                "%"
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                            fontSize: "14px",
                            pt: 1,
                            children: t('Share of Pool')
                        })
                    ]
                })
            ]
        })
    }));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PoolPriceBar);


/***/ }),

/***/ 78848:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ AddLiquidity)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65757);
/* harmony import */ var _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(42877);
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var hooks_Trades__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(42649);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(99150);
/* harmony import */ var components_UnsupportedCurrencyFooter__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(49704);
/* harmony import */ var hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(64011);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _components_Card__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(36261);
/* harmony import */ var _components_Layout_Column__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(41914);
/* harmony import */ var _components_TransactionConfirmationModal__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(41228);
/* harmony import */ var _components_CurrencyInputPanel__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(71372);
/* harmony import */ var _components_Logo__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(83356);
/* harmony import */ var _components_App__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(85101);
/* harmony import */ var _components_PositionCard__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(86323);
/* harmony import */ var _components_Layout_Row__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(39475);
/* harmony import */ var _components_ConnectWalletButton__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(30621);
/* harmony import */ var _config_constants__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(3862);
/* harmony import */ var _hooks_usePairs__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(84915);
/* harmony import */ var _hooks_Tokens__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(86435);
/* harmony import */ var _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(69398);
/* harmony import */ var _hooks_useTransactionDeadline__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(81748);
/* harmony import */ var _state_mint_actions__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(60650);
/* harmony import */ var _state_mint_hooks__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(20081);
/* harmony import */ var _state_transactions_hooks__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(55892);
/* harmony import */ var _state_user_hooks__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(68605);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(38328);
/* harmony import */ var _utils_maxAmountSpend__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(45131);
/* harmony import */ var _utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(53854);
/* harmony import */ var _components_Loader_Dots__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(48468);
/* harmony import */ var _ConfirmAddModalBottom__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(34900);
/* harmony import */ var _utils_currencyId__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(28996);
/* harmony import */ var _PoolPriceBar__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(89113);
/* harmony import */ var _Page__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(49438);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([components_UnsupportedCurrencyFooter__WEBPACK_IMPORTED_MODULE_7__, _components_PositionCard__WEBPACK_IMPORTED_MODULE_17__, _hooks_usePairs__WEBPACK_IMPORTED_MODULE_21__, _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_23__, _components_CurrencyInputPanel__WEBPACK_IMPORTED_MODULE_14__, _components_App__WEBPACK_IMPORTED_MODULE_16__, _Page__WEBPACK_IMPORTED_MODULE_36__, hooks_Trades__WEBPACK_IMPORTED_MODULE_5__, _ConfirmAddModalBottom__WEBPACK_IMPORTED_MODULE_33__, _components_Logo__WEBPACK_IMPORTED_MODULE_15__, _state_user_hooks__WEBPACK_IMPORTED_MODULE_28__, _hooks_useTransactionDeadline__WEBPACK_IMPORTED_MODULE_24__, _state_mint_hooks__WEBPACK_IMPORTED_MODULE_26__, _hooks_Tokens__WEBPACK_IMPORTED_MODULE_22__]);
([components_UnsupportedCurrencyFooter__WEBPACK_IMPORTED_MODULE_7__, _components_PositionCard__WEBPACK_IMPORTED_MODULE_17__, _hooks_usePairs__WEBPACK_IMPORTED_MODULE_21__, _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_23__, _components_CurrencyInputPanel__WEBPACK_IMPORTED_MODULE_14__, _components_App__WEBPACK_IMPORTED_MODULE_16__, _Page__WEBPACK_IMPORTED_MODULE_36__, hooks_Trades__WEBPACK_IMPORTED_MODULE_5__, _ConfirmAddModalBottom__WEBPACK_IMPORTED_MODULE_33__, _components_Logo__WEBPACK_IMPORTED_MODULE_15__, _state_user_hooks__WEBPACK_IMPORTED_MODULE_28__, _hooks_useTransactionDeadline__WEBPACK_IMPORTED_MODULE_24__, _state_mint_hooks__WEBPACK_IMPORTED_MODULE_26__, _hooks_Tokens__WEBPACK_IMPORTED_MODULE_22__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);





































function AddLiquidity() {
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_10__.useRouter)();
    const [currencyIdA, currencyIdB] = router.query.currency || [];
    const { account , chainId , library  } = (0,hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_9__.useDispatch)();
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_6__/* .useTranslation */ .$G)();
    const gasPrice = (0,_state_user_hooks__WEBPACK_IMPORTED_MODULE_28__/* .useGasPrice */ .Fh)();
    const currencyA = (0,_hooks_Tokens__WEBPACK_IMPORTED_MODULE_22__/* .useCurrency */ .U8)(currencyIdA);
    const currencyB = (0,_hooks_Tokens__WEBPACK_IMPORTED_MODULE_22__/* .useCurrency */ .U8)(currencyIdB);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (!currencyIdA && !currencyIdB) {
            dispatch((0,_state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .resetMintState */ .dA)());
        }
    }, [
        dispatch,
        currencyIdA,
        currencyIdB
    ]);
    const oneCurrencyIsWETH = Boolean(chainId && (currencyA && (0,_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_3__.currencyEquals)(currencyA, _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_3__.WETH[chainId]) || currencyB && (0,_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_3__.currencyEquals)(currencyB, _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_3__.WETH[chainId])));
    const expertMode = (0,_state_user_hooks__WEBPACK_IMPORTED_MODULE_28__/* .useIsExpertMode */ .LO)();
    // mint state
    const { independentField , typedValue , otherTypedValue  } = (0,_state_mint_hooks__WEBPACK_IMPORTED_MODULE_26__/* .useMintState */ .OY)();
    const { dependentField , currencies , pair , pairState , currencyBalances , parsedAmounts , price , noLiquidity , liquidityMinted , poolTokenPercentage , error ,  } = (0,_state_mint_hooks__WEBPACK_IMPORTED_MODULE_26__/* .useDerivedMintInfo */ .Qw)(currencyA ?? undefined, currencyB ?? undefined);
    const { onFieldAInput , onFieldBInput  } = (0,_state_mint_hooks__WEBPACK_IMPORTED_MODULE_26__/* .useMintActionHandlers */ .OA)(noLiquidity);
    const isValid = !error;
    // modal and loading
    const { 0: attemptingTxn , 1: setAttemptingTxn  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false) // clicked confirm
    ;
    // txn values
    const deadline = (0,_hooks_useTransactionDeadline__WEBPACK_IMPORTED_MODULE_24__/* ["default"] */ .Z)() // custom from users settings
    ;
    const [allowedSlippage] = (0,_state_user_hooks__WEBPACK_IMPORTED_MODULE_28__/* .useUserSlippageTolerance */ .$2)() // custom from users
    ;
    const { 0: txHash , 1: setTxHash  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    // get formatted amounts
    const formattedAmounts = {
        [independentField]: typedValue,
        [dependentField]: noLiquidity ? otherTypedValue : parsedAmounts[dependentField]?.toSignificant(6) ?? ''
    };
    // get the max amounts user can add
    const maxAmounts = [
        _state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_A */ .gN.CURRENCY_A,
        _state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_B */ .gN.CURRENCY_B
    ].reduce((accumulator, field)=>{
        return {
            ...accumulator,
            [field]: (0,_utils_maxAmountSpend__WEBPACK_IMPORTED_MODULE_30__/* .maxAmountSpend */ .i)(currencyBalances[field])
        };
    }, {});
    const atMaxAmounts = [
        _state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_A */ .gN.CURRENCY_A,
        _state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_B */ .gN.CURRENCY_B
    ].reduce((accumulator, field)=>{
        return {
            ...accumulator,
            [field]: maxAmounts[field]?.equalTo(parsedAmounts[field] ?? '0')
        };
    }, {});
    // check whether the user has approved the router on the tokens
    const [approvalA, approveACallback] = (0,_hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_23__/* .useApproveCallback */ .qL)(parsedAmounts[_state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_A */ .gN.CURRENCY_A], _config_constants__WEBPACK_IMPORTED_MODULE_20__/* .ROUTER_ADDRESS */ .bR);
    const [approvalB, approveBCallback] = (0,_hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_23__/* .useApproveCallback */ .qL)(parsedAmounts[_state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_B */ .gN.CURRENCY_B], _config_constants__WEBPACK_IMPORTED_MODULE_20__/* .ROUTER_ADDRESS */ .bR);
    const addTransaction = (0,_state_transactions_hooks__WEBPACK_IMPORTED_MODULE_27__/* .useTransactionAdder */ .h7)();
    async function onAdd() {
        if (!chainId || !library || !account) return;
        const routerContract = (0,_utils__WEBPACK_IMPORTED_MODULE_29__/* .getRouterContract */ .iY)(chainId, library, account);
        const { [_state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]: parsedAmountA , [_state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]: parsedAmountB  } = parsedAmounts;
        if (!parsedAmountA || !parsedAmountB || !currencyA || !currencyB || !deadline) {
            return;
        }
        const amountsMin = {
            [_state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]: (0,_utils__WEBPACK_IMPORTED_MODULE_29__/* .calculateSlippageAmount */ .uc)(parsedAmountA, noLiquidity ? 0 : allowedSlippage)[0],
            [_state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]: (0,_utils__WEBPACK_IMPORTED_MODULE_29__/* .calculateSlippageAmount */ .uc)(parsedAmountB, noLiquidity ? 0 : allowedSlippage)[0]
        };
        let estimate;
        let method;
        let args;
        let value;
        if (currencyA === _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_3__.ETHER || currencyB === _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_3__.ETHER) {
            const tokenBIsETH = currencyB === _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_3__.ETHER;
            estimate = routerContract.estimateGas.addLiquidityETH;
            method = routerContract.addLiquidityETH;
            args = [
                (0,_utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_31__/* .wrappedCurrency */ .pu)(tokenBIsETH ? currencyA : currencyB, chainId)?.address ?? '',
                (tokenBIsETH ? parsedAmountA : parsedAmountB).raw.toString(),
                amountsMin[tokenBIsETH ? _state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_A */ .gN.CURRENCY_A : _state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_B */ .gN.CURRENCY_B].toString(),
                amountsMin[tokenBIsETH ? _state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_B */ .gN.CURRENCY_B : _state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_A */ .gN.CURRENCY_A].toString(),
                account,
                deadline.toHexString(), 
            ];
            value = _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_2__.BigNumber.from((tokenBIsETH ? parsedAmountB : parsedAmountA).raw.toString());
        } else {
            estimate = routerContract.estimateGas.addLiquidity;
            method = routerContract.addLiquidity;
            args = [
                (0,_utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_31__/* .wrappedCurrency */ .pu)(currencyA, chainId)?.address ?? '',
                (0,_utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_31__/* .wrappedCurrency */ .pu)(currencyB, chainId)?.address ?? '',
                parsedAmountA.raw.toString(),
                parsedAmountB.raw.toString(),
                amountsMin[_state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_A */ .gN.CURRENCY_A].toString(),
                amountsMin[_state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_B */ .gN.CURRENCY_B].toString(),
                account,
                deadline.toHexString(), 
            ];
            value = null;
        }
        setAttemptingTxn(true);
        await estimate(...args, value ? {
            value
        } : {}).then((estimatedGasLimit)=>method(...args, {
                ...value ? {
                    value
                } : {},
                gasLimit: (0,_utils__WEBPACK_IMPORTED_MODULE_29__/* .calculateGasMargin */ .yC)(estimatedGasLimit),
                gasPrice
            }).then((response)=>{
                setAttemptingTxn(false);
                addTransaction(response, {
                    summary: `Add ${parsedAmounts[_state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]?.toSignificant(3)} ${currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]?.symbol} and ${parsedAmounts[_state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]?.toSignificant(3)} ${currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]?.symbol}`
                });
                setTxHash(response.hash);
            })
        ).catch((err)=>{
            setAttemptingTxn(false);
            // we only care if the error is something _other_ than the user rejected the tx
            if (err?.code !== 4001) {
                console.error(err);
            }
        });
    }
    const modalHeader = ()=>{
        return noLiquidity ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Flex, {
            alignItems: "center",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                    fontSize: "48px",
                    marginRight: "10px",
                    children: `${currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]?.symbol}/${currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]?.symbol}`
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Logo__WEBPACK_IMPORTED_MODULE_15__/* .DoubleCurrencyLogo */ .ge, {
                    currency0: currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_A */ .gN.CURRENCY_A],
                    currency1: currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_B */ .gN.CURRENCY_B],
                    size: 30
                })
            ]
        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layout_Column__WEBPACK_IMPORTED_MODULE_12__/* .AutoColumn */ .Tz, {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Flex, {
                    alignItems: "center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                            fontSize: "48px",
                            marginRight: "10px",
                            children: liquidityMinted?.toSignificant(6)
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Logo__WEBPACK_IMPORTED_MODULE_15__/* .DoubleCurrencyLogo */ .ge, {
                            currency0: currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_A */ .gN.CURRENCY_A],
                            currency1: currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_B */ .gN.CURRENCY_B],
                            size: 30
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Layout_Row__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .ZP, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                        fontSize: "24px",
                        children: `${currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]?.symbol}/${currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]?.symbol} Pool Tokens`
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                    small: true,
                    textAlign: "left",
                    my: "24px",
                    children: t('Output is estimated. If the price changes by more than %slippage%% your transaction will revert.', {
                        slippage: allowedSlippage / 100
                    })
                })
            ]
        });
    };
    const modalBottom = ()=>{
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ConfirmAddModalBottom__WEBPACK_IMPORTED_MODULE_33__/* ["default"] */ .Z, {
            price: price,
            currencies: currencies,
            parsedAmounts: parsedAmounts,
            noLiquidity: noLiquidity,
            onAdd: onAdd,
            poolTokenPercentage: poolTokenPercentage
        }));
    };
    const pendingText = t('Supplying %amountA% %symbolA% and %amountB% %symbolB%', {
        amountA: parsedAmounts[_state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]?.toSignificant(6) ?? '',
        symbolA: currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]?.symbol ?? '',
        amountB: parsedAmounts[_state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]?.toSignificant(6) ?? '',
        symbolB: currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]?.symbol ?? ''
    });
    const handleCurrencyASelect = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((currencyA_)=>{
        const newCurrencyIdA = (0,_utils_currencyId__WEBPACK_IMPORTED_MODULE_34__/* .currencyId */ .H)(currencyA_);
        if (newCurrencyIdA === currencyIdB) {
            router.replace(`/add/${currencyIdB}/${currencyIdA}`, undefined, {
                shallow: true
            });
        } else if (currencyIdB) {
            router.replace(`/add/${newCurrencyIdA}/${currencyIdB}`, undefined, {
                shallow: true
            });
        } else {
            router.replace(`/add/${newCurrencyIdA}`, undefined, {
                shallow: true
            });
        }
    }, [
        currencyIdB,
        router,
        currencyIdA
    ]);
    const handleCurrencyBSelect = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((currencyB_)=>{
        const newCurrencyIdB = (0,_utils_currencyId__WEBPACK_IMPORTED_MODULE_34__/* .currencyId */ .H)(currencyB_);
        if (currencyIdA === newCurrencyIdB) {
            if (currencyIdB) {
                router.replace(`/add/${currencyIdB}/${newCurrencyIdB}`, undefined, {
                    shallow: true
                });
            } else {
                router.replace(`/add/${newCurrencyIdB}`, undefined, {
                    shallow: true
                });
            }
        } else {
            router.replace(`/add/${currencyIdA || 'BNB'}/${newCurrencyIdB}`, undefined, {
                shallow: true
            });
        }
    }, [
        currencyIdA,
        router,
        currencyIdB
    ]);
    const handleDismissConfirmation = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        // if there was a tx hash, we want to clear the input
        if (txHash) {
            onFieldAInput('');
        }
        setTxHash('');
    }, [
        onFieldAInput,
        txHash
    ]);
    const addIsUnsupported = (0,hooks_Trades__WEBPACK_IMPORTED_MODULE_5__/* .useIsTransactionUnsupported */ .mP)(currencies?.CURRENCY_A, currencies?.CURRENCY_B);
    const [onPresentAddLiquidityModal] = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.useModal)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_TransactionConfirmationModal__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .ZP, {
        title: noLiquidity ? t('You are creating a pool') : t('You will receive'),
        customOnDismiss: handleDismissConfirmation,
        attemptingTxn: attemptingTxn,
        hash: txHash,
        content: ()=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_TransactionConfirmationModal__WEBPACK_IMPORTED_MODULE_13__/* .ConfirmationModalContent */ .pM, {
                topContent: modalHeader,
                bottomContent: modalBottom
            })
        ,
        pendingText: pendingText,
        currencyToAdd: pair?.liquidityToken
    }), true, true, 'addLiquidityModal');
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Page__WEBPACK_IMPORTED_MODULE_36__/* ["default"] */ .Z, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_App__WEBPACK_IMPORTED_MODULE_16__/* .AppBody */ .j, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_App__WEBPACK_IMPORTED_MODULE_16__/* .AppHeader */ .t, {
                        title: t('Add Liquidity'),
                        subtitle: t('Add liquidity to receive LP tokens'),
                        helper: t('Liquidity providers earn a 0.17% trading fee on all trades made for that token pair, proportional to their share of the liquidity pool.'),
                        backTo: "/liquidity"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.CardBody, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layout_Column__WEBPACK_IMPORTED_MODULE_12__/* .AutoColumn */ .Tz, {
                            gap: "20px",
                            children: [
                                noLiquidity && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Layout_Column__WEBPACK_IMPORTED_MODULE_12__/* .ColumnCenter */ .lg, {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Message, {
                                        variant: "warning",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                                                    bold: true,
                                                    mb: "8px",
                                                    children: t('You are the first liquidity provider.')
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                                                    mb: "8px",
                                                    children: t('The ratio of tokens you add will set the price of this pool.')
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                                                    children: t('Once you are happy with the rate click supply to review.')
                                                })
                                            ]
                                        })
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_CurrencyInputPanel__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                                    value: formattedAmounts[_state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_A */ .gN.CURRENCY_A],
                                    onUserInput: onFieldAInput,
                                    onMax: ()=>{
                                        onFieldAInput(maxAmounts[_state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]?.toExact() ?? '');
                                    },
                                    onCurrencySelect: handleCurrencyASelect,
                                    showMaxButton: !atMaxAmounts[_state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_A */ .gN.CURRENCY_A],
                                    currency: currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_A */ .gN.CURRENCY_A],
                                    id: "add-liquidity-input-tokena",
                                    showCommonBases: true
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Layout_Column__WEBPACK_IMPORTED_MODULE_12__/* .ColumnCenter */ .lg, {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.AddIcon, {
                                        width: "16px"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_CurrencyInputPanel__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                                    value: formattedAmounts[_state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_B */ .gN.CURRENCY_B],
                                    onUserInput: onFieldBInput,
                                    onCurrencySelect: handleCurrencyBSelect,
                                    onMax: ()=>{
                                        onFieldBInput(maxAmounts[_state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]?.toExact() ?? '');
                                    },
                                    showMaxButton: !atMaxAmounts[_state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_B */ .gN.CURRENCY_B],
                                    currency: currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_B */ .gN.CURRENCY_B],
                                    id: "add-liquidity-input-tokenb",
                                    showCommonBases: true
                                }),
                                currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_A */ .gN.CURRENCY_A] && currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_B */ .gN.CURRENCY_B] && pairState !== _hooks_usePairs__WEBPACK_IMPORTED_MODULE_21__/* .PairState.INVALID */ ._G.INVALID && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Card__WEBPACK_IMPORTED_MODULE_11__/* .LightCard */ .hl, {
                                        padding: "0px",
                                        borderRadius: "20px",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Layout_Row__WEBPACK_IMPORTED_MODULE_18__/* .RowBetween */ .m0, {
                                                padding: "1rem",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                                                    fontSize: "14px",
                                                    children: noLiquidity ? t('Initial prices and pool share') : t('Prices and pool share')
                                                })
                                            }),
                                            ' ',
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Card__WEBPACK_IMPORTED_MODULE_11__/* .LightCard */ .hl, {
                                                padding: "1rem",
                                                borderRadius: "20px",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PoolPriceBar__WEBPACK_IMPORTED_MODULE_35__/* ["default"] */ .Z, {
                                                    currencies: currencies,
                                                    poolTokenPercentage: poolTokenPercentage,
                                                    noLiquidity: noLiquidity,
                                                    price: price
                                                })
                                            })
                                        ]
                                    })
                                }),
                                addIsUnsupported ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Button, {
                                    disabled: true,
                                    mb: "4px",
                                    children: t('Unsupported Asset')
                                }) : !account ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ConnectWalletButton__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z, {}) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layout_Column__WEBPACK_IMPORTED_MODULE_12__/* .AutoColumn */ .Tz, {
                                    gap: "md",
                                    children: [
                                        (approvalA === _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_23__/* .ApprovalState.NOT_APPROVED */ .UK.NOT_APPROVED || approvalA === _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_23__/* .ApprovalState.PENDING */ .UK.PENDING || approvalB === _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_23__/* .ApprovalState.NOT_APPROVED */ .UK.NOT_APPROVED || approvalB === _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_23__/* .ApprovalState.PENDING */ .UK.PENDING) && isValid && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layout_Row__WEBPACK_IMPORTED_MODULE_18__/* .RowBetween */ .m0, {
                                            children: [
                                                approvalA !== _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_23__/* .ApprovalState.APPROVED */ .UK.APPROVED && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Button, {
                                                    onClick: approveACallback,
                                                    disabled: approvalA === _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_23__/* .ApprovalState.PENDING */ .UK.PENDING,
                                                    width: approvalB !== _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_23__/* .ApprovalState.APPROVED */ .UK.APPROVED ? '48%' : '100%',
                                                    children: approvalA === _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_23__/* .ApprovalState.PENDING */ .UK.PENDING ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Loader_Dots__WEBPACK_IMPORTED_MODULE_32__/* ["default"] */ .Z, {
                                                        children: t('Enabling %asset%', {
                                                            asset: currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]?.symbol
                                                        })
                                                    }) : t('Enable %asset%', {
                                                        asset: currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]?.symbol
                                                    })
                                                }),
                                                approvalB !== _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_23__/* .ApprovalState.APPROVED */ .UK.APPROVED && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Button, {
                                                    onClick: approveBCallback,
                                                    disabled: approvalB === _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_23__/* .ApprovalState.PENDING */ .UK.PENDING,
                                                    width: approvalA !== _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_23__/* .ApprovalState.APPROVED */ .UK.APPROVED ? '48%' : '100%',
                                                    children: approvalB === _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_23__/* .ApprovalState.PENDING */ .UK.PENDING ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Loader_Dots__WEBPACK_IMPORTED_MODULE_32__/* ["default"] */ .Z, {
                                                        children: t('Enabling %asset%', {
                                                            asset: currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]?.symbol
                                                        })
                                                    }) : t('Enable %asset%', {
                                                        asset: currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]?.symbol
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Button, {
                                            variant: !isValid && !!parsedAmounts[_state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_A */ .gN.CURRENCY_A] && !!parsedAmounts[_state_mint_actions__WEBPACK_IMPORTED_MODULE_25__/* .Field.CURRENCY_B */ .gN.CURRENCY_B] ? 'danger' : 'primary',
                                            onClick: ()=>{
                                                if (expertMode) {
                                                    onAdd();
                                                } else {
                                                    onPresentAddLiquidityModal();
                                                }
                                            },
                                            disabled: !isValid || approvalA !== _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_23__/* .ApprovalState.APPROVED */ .UK.APPROVED || approvalB !== _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_23__/* .ApprovalState.APPROVED */ .UK.APPROVED,
                                            children: error ?? t('Supply')
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            }),
            !addIsUnsupported ? pair && !noLiquidity && pairState !== _hooks_usePairs__WEBPACK_IMPORTED_MODULE_21__/* .PairState.INVALID */ ._G.INVALID ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Layout_Column__WEBPACK_IMPORTED_MODULE_12__/* .AutoColumn */ .Tz, {
                style: {
                    minWidth: '20rem',
                    width: '100%',
                    maxWidth: '400px',
                    marginTop: '1rem'
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_PositionCard__WEBPACK_IMPORTED_MODULE_17__/* .MinimalPositionCard */ .W, {
                    showUnwrapped: oneCurrencyIsWETH,
                    pair: pair
                })
            }) : null : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_UnsupportedCurrencyFooter__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                currencies: [
                    currencies.CURRENCY_A,
                    currencies.CURRENCY_B
                ]
            })
        ]
    }));
};

});

/***/ }),

/***/ 68454:
/***/ ((module) => {

module.exports = require("@binance-chain/bsc-connector");

/***/ }),

/***/ 6187:
/***/ ((module) => {

module.exports = require("@ethersproject/abi");

/***/ }),

/***/ 51541:
/***/ ((module) => {

module.exports = require("@ethersproject/address");

/***/ }),

/***/ 65757:
/***/ ((module) => {

module.exports = require("@ethersproject/bignumber");

/***/ }),

/***/ 49935:
/***/ ((module) => {

module.exports = require("@ethersproject/bytes");

/***/ }),

/***/ 26644:
/***/ ((module) => {

module.exports = require("@ethersproject/constants");

/***/ }),

/***/ 12792:
/***/ ((module) => {

module.exports = require("@ethersproject/contracts");

/***/ }),

/***/ 40750:
/***/ ((module) => {

module.exports = require("@ethersproject/hash");

/***/ }),

/***/ 90399:
/***/ ((module) => {

module.exports = require("@ethersproject/providers");

/***/ }),

/***/ 49213:
/***/ ((module) => {

module.exports = require("@ethersproject/strings");

/***/ }),

/***/ 93138:
/***/ ((module) => {

module.exports = require("@ethersproject/units");

/***/ }),

/***/ 42877:
/***/ ((module) => {

module.exports = require("@mdemouchy/sdk");

/***/ }),

/***/ 85360:
/***/ ((module) => {

module.exports = require("@next/env");

/***/ }),

/***/ 2829:
/***/ ((module) => {

module.exports = require("@pancakeswap/uikit");

/***/ }),

/***/ 75184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 58097:
/***/ ((module) => {

module.exports = require("@sentry/nextjs");

/***/ }),

/***/ 15427:
/***/ ((module) => {

module.exports = require("@sentry/react");

/***/ }),

/***/ 7248:
/***/ ((module) => {

module.exports = require("@snapshot-labs/snapshot.js");

/***/ }),

/***/ 51554:
/***/ ((module) => {

module.exports = require("@uniswap/token-lists");

/***/ }),

/***/ 18054:
/***/ ((module) => {

module.exports = require("@web3-react/core");

/***/ }),

/***/ 76590:
/***/ ((module) => {

module.exports = require("@web3-react/injected-connector");

/***/ }),

/***/ 9795:
/***/ ((module) => {

module.exports = require("@web3-react/walletconnect-connector");

/***/ }),

/***/ 75888:
/***/ ((module) => {

module.exports = require("ajv");

/***/ }),

/***/ 34215:
/***/ ((module) => {

module.exports = require("bignumber.js");

/***/ }),

/***/ 10899:
/***/ ((module) => {

module.exports = require("bignumber.js/bignumber");

/***/ }),

/***/ 18729:
/***/ ((module) => {

module.exports = require("cids");

/***/ }),

/***/ 74146:
/***/ ((module) => {

module.exports = require("date-fns");

/***/ }),

/***/ 64175:
/***/ ((module) => {

module.exports = require("fast-json-stable-stringify");

/***/ }),

/***/ 5805:
/***/ ((module) => {

module.exports = require("graphql-request");

/***/ }),

/***/ 90221:
/***/ ((module) => {

module.exports = require("lodash/chunk");

/***/ }),

/***/ 38190:
/***/ ((module) => {

module.exports = require("lodash/flatMap");

/***/ }),

/***/ 58579:
/***/ ((module) => {

module.exports = require("lodash/flatten");

/***/ }),

/***/ 1712:
/***/ ((module) => {

module.exports = require("lodash/get");

/***/ }),

/***/ 89699:
/***/ ((module) => {

module.exports = require("lodash/isEmpty");

/***/ }),

/***/ 51546:
/***/ ((module) => {

module.exports = require("lodash/kebabCase");

/***/ }),

/***/ 63385:
/***/ ((module) => {

module.exports = require("lodash/keyBy");

/***/ }),

/***/ 11341:
/***/ ((module) => {

module.exports = require("lodash/maxBy");

/***/ }),

/***/ 61831:
/***/ ((module) => {

module.exports = require("lodash/merge");

/***/ }),

/***/ 49949:
/***/ ((module) => {

module.exports = require("lodash/orderBy");

/***/ }),

/***/ 64042:
/***/ ((module) => {

module.exports = require("lodash/range");

/***/ }),

/***/ 47657:
/***/ ((module) => {

module.exports = require("lodash/sample");

/***/ }),

/***/ 4354:
/***/ ((module) => {

module.exports = require("lodash/times");

/***/ }),

/***/ 18459:
/***/ ((module) => {

module.exports = require("lodash/uniq");

/***/ }),

/***/ 16677:
/***/ ((module) => {

module.exports = require("multicodec");

/***/ }),

/***/ 63735:
/***/ ((module) => {

module.exports = require("multihashes");

/***/ }),

/***/ 54426:
/***/ ((module) => {

module.exports = require("next/dist/compiled/chalk");

/***/ }),

/***/ 40252:
/***/ ((module) => {

module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 19371:
/***/ ((module) => {

module.exports = require("next/dist/compiled/node-fetch");

/***/ }),

/***/ 97999:
/***/ ((module) => {

module.exports = require("next/dist/compiled/path-to-regexp");

/***/ }),

/***/ 60600:
/***/ ((module) => {

module.exports = require("next/dist/server/accept-header.js");

/***/ }),

/***/ 18612:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils.js");

/***/ }),

/***/ 60562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 94140:
/***/ ((module) => {

module.exports = require("next/dist/server/get-page-files.js");

/***/ }),

/***/ 89716:
/***/ ((module) => {

module.exports = require("next/dist/server/htmlescape.js");

/***/ }),

/***/ 25071:
/***/ ((module) => {

module.exports = require("next/dist/server/render-result.js");

/***/ }),

/***/ 33100:
/***/ ((module) => {

module.exports = require("next/dist/server/render.js");

/***/ }),

/***/ 92779:
/***/ ((module) => {

module.exports = require("next/dist/server/request-meta.js");

/***/ }),

/***/ 79502:
/***/ ((module) => {

module.exports = require("next/dist/server/send-payload.js");

/***/ }),

/***/ 76368:
/***/ ((module) => {

module.exports = require("next/dist/server/utils.js");

/***/ }),

/***/ 56724:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 27664:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/escape-regexp.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 82374:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-locale-cookie.js");

/***/ }),

/***/ 34014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 78524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 95832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 78020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 29565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 64365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 95714:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-route-from-asset-path.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 91292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 25753:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-match.js");

/***/ }),

/***/ 99521:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/prepare-destination.js");

/***/ }),

/***/ 80979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 36052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 84226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 95566:
/***/ ((module) => {

module.exports = require("next/error");

/***/ }),

/***/ 40968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 71853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 4780:
/***/ ((module) => {

module.exports = require("next/script");

/***/ }),

/***/ 59819:
/***/ ((module) => {

module.exports = require("querystring");

/***/ }),

/***/ 16689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 84466:
/***/ ((module) => {

module.exports = require("react-transition-group");

/***/ }),

/***/ 80551:
/***/ ((module) => {

module.exports = require("react-window");

/***/ }),

/***/ 20997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 14161:
/***/ ((module) => {

module.exports = require("redux-persist");

/***/ }),

/***/ 61127:
/***/ ((module) => {

module.exports = require("redux-persist/integration/react");

/***/ }),

/***/ 98936:
/***/ ((module) => {

module.exports = require("redux-persist/lib/storage");

/***/ }),

/***/ 57518:
/***/ ((module) => {

module.exports = require("styled-components");

/***/ }),

/***/ 84269:
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ 15941:
/***/ ((module) => {

module.exports = import("swr");;

/***/ }),

/***/ 79847:
/***/ ((module) => {

module.exports = import("swr/immutable");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9635,2151,1228,6261,7010,570,2129,8269,1721,6323,7904,2920], () => (__webpack_exec__(25116)));
module.exports = __webpack_exports__;

})();
//# sourceMappingURL=[[...currency]].js.map