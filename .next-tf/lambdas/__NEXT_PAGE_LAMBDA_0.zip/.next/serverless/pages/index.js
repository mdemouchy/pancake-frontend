"use strict";
(() => {
var exports = {};
exports.id = 5405;
exports.ids = [5405];
exports.modules = {

/***/ 95683:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "unstable_getStaticParams": () => (/* binding */ unstable_getStaticParams),
/* harmony export */   "unstable_getStaticProps": () => (/* binding */ unstable_getStaticProps),
/* harmony export */   "unstable_getStaticPaths": () => (/* binding */ unstable_getStaticPaths),
/* harmony export */   "unstable_getServerProps": () => (/* binding */ unstable_getServerProps),
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "_app": () => (/* binding */ _app),
/* harmony export */   "renderReqToHTML": () => (/* binding */ renderReqToHTML),
/* harmony export */   "render": () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(70607);
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59450);
/* harmony import */ var private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97020);
/* harmony import */ var private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(73978);
/* harmony import */ var next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99436);

      
      
      
      

      
      const { processEnv } = __webpack_require__(85360)
      processEnv([{"path":".env.production","contents":"NEXT_PUBLIC_CHAIN_ID = \"1666700000\"\nNEXT_PUBLIC_GTAG = \"GTM-PXLD3XW\"\n\n# 10+ nodes balanced, US/EU\nNEXT_PUBLIC_NODE_1 = \"https://api.s0.b.hmny.io\"\n\n# 10+ nodes balanced, US/EU\nNEXT_PUBLIC_NODE_2 = \"https://api.s0.b.hmny.io\"\n\n# 10+ nodes balanced in each region, global\nNEXT_PUBLIC_NODE_3 = \"https://api.s0.b.hmny.io\"\n\n# Google Cloud Infrastructure Endpoint - Global\n#NEXT_PUBLIC_NODE_PRODUCTION = \"https://nodes.pancakeswap.com\"\n\nNEXT_PUBLIC_GRAPH_API_PROFILE = \"https://api.thegraph.com/subgraphs/name/pancakeswap/profile\"\nNEXT_PUBLIC_GRAPH_API_PREDICTION = \"https://api.thegraph.com/subgraphs/name/pancakeswap/prediction-v2\"\nNEXT_PUBLIC_GRAPH_API_LOTTERY = \"https://api.thegraph.com/subgraphs/name/pancakeswap/lottery\"\nNEXT_PUBLIC_GRAPH_API_NFT_MARKET = \"https://api.thegraph.com/subgraphs/name/pancakeswap/nft-market\"\n\nNEXT_PUBLIC_SNAPSHOT_BASE_URL = \"https://hub.snapshot.org\"\nNEXT_PUBLIC_SNAPSHOT_VOTING_API = \"https://voting-api.pancakeswap.info/api\"\n\nNEXT_PUBLIC_API_NFT = \"https://nft.pancakeswap.com/api/v1\"\nNEXT_PUBLIC_BIT_QUERY_ENDPOINT = \"https://graphql.bitquery.io\"\n"},{"path":".env","contents":"NEXT_PUBLIC_API_PROFILE = https://profile.pancakeswap.com"}])
    
      
      const runtimeConfig = {}
      ;

      const documentModule = __webpack_require__(85641)

      const appMod = __webpack_require__(12957)
      let App = appMod.default || appMod.then && appMod.then(mod => mod.default);

      const compMod = __webpack_require__(30441)

      const Component = compMod.default || compMod.then && compMod.then(mod => mod.default)
      /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Component);
      const getStaticProps = compMod['getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['getStaticProp' + 's'])
      const getStaticPaths = compMod['getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['getStaticPath' + 's'])
      const getServerSideProps = compMod['getServerSideProp' + 's'] || compMod.then && compMod.then(mod => mod['getServerSideProp' + 's'])

      // kept for detecting legacy exports
      const unstable_getStaticParams = compMod['unstable_getStaticParam' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticParam' + 's'])
      const unstable_getStaticProps = compMod['unstable_getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticProp' + 's'])
      const unstable_getStaticPaths = compMod['unstable_getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticPath' + 's'])
      const unstable_getServerProps = compMod['unstable_getServerProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getServerProp' + 's'])

      let config = compMod['confi' + 'g'] || (compMod.then && compMod.then(mod => mod['confi' + 'g'])) || {}
      const _app = App

      const combinedRewrites = Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)
        ? private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg
        : []

      if (!Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)) {
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.beforeFiles */ .Dg.beforeFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.afterFiles */ .Dg.afterFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.fallback */ .Dg.fallback)
      }

      const { renderReqToHTML, render } = (0,next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__/* .getPageHandler */ .u)({
        pageModule: compMod,
        pageComponent: Component,
        pageConfig: config,
        appModule: App,
        documentModule: documentModule,
        errorModule: __webpack_require__(54141),
        notFoundModule: __webpack_require__(59622),
        pageGetStaticProps: getStaticProps,
        pageGetStaticPaths: getStaticPaths,
        pageGetServerSideProps: getServerSideProps,

        assetPrefix: "",
        canonicalBase: "",
        generateEtags: true,
        poweredByHeader: true,

        runtimeConfig,
        buildManifest: private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__,
        reactLoadableManifest: private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__,

        rewrites: combinedRewrites,
        i18n: undefined,
        page: "/",
        buildId: "pA0qXx8N8yV4x51Q8eKRJ",
        escapedBuildId: "pA0qXx8N8yV4x51Q8eKRJ",
        basePath: "",
        pageIsDynamic: false,
        encodedPreviewProps: {previewModeId:"4be1d5f31f1c05ab7d94512e7c5324a6",previewModeSigningKey:"bc6aa2b2074ecf664cef37e2cf2b9a8c7f10e81a4e58b764ce70d78163ce2360",previewModeEncryptionKey:"620945a7ce3f1dee81153e4e394922ca059a150870ea548250af9ef14ef4d062"}
      })
      
    

/***/ }),

/***/ 2010:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "M": () => (/* binding */ useGetStats)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const useGetStats = ()=>{
    const { 0: data , 1: setData  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        const fetchData = async ()=>{
            try {
                const response = await fetch('https://openapi.debank.com/v1/protocol?id=bsc_pancakeswap');
                const responseData = await response.json();
                setData(responseData);
            } catch (error) {
                console.error('Unable to fetch data:', error);
            }
        };
        fetchData();
    }, [
        setData
    ]);
    return data;
};


/***/ }),

/***/ 30441:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(42877);
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(74146);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(date_fns__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var graphql_request__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5805);
/* harmony import */ var graphql_request__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(graphql_request__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(15941);
/* harmony import */ var utils_graphql__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(75509);
/* harmony import */ var views_Info_hooks_useBlocksFromTimestamps__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(79566);
/* harmony import */ var _views_Home__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(91061);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_views_Home__WEBPACK_IMPORTED_MODULE_8__, swr__WEBPACK_IMPORTED_MODULE_5__]);
([_views_Home__WEBPACK_IMPORTED_MODULE_8__, swr__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);









const IndexPage = ({ totalTx30Days , addressCount30Days  })=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swr__WEBPACK_IMPORTED_MODULE_5__.SWRConfig, {
        value: {
            fallback: {
                totalTx30Days,
                addressCount30Days
            }
        },
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_views_Home__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {})
    }));
};
// Values fetched from TheGraph and BitQuery jan 24, 2022
const txCount = 54780336;
const addressCount = 4425459;
const getStaticProps = async ()=>{
    const totalTxQuery = graphql_request__WEBPACK_IMPORTED_MODULE_3__.gql`
    query TotalTransactions($id: ID!, $block: Block_height) {
      pancakeFactory(id: $id, block: $block) {
        totalTransactions
      }
    }
  `;
    const days30Ago = (0,date_fns__WEBPACK_IMPORTED_MODULE_2__.sub)(new Date(), {
        days: 30
    });
    const results = {
        totalTx30Days: txCount,
        addressCount30Days: addressCount
    };
    try {
        const [days30AgoBlock] = await (0,views_Info_hooks_useBlocksFromTimestamps__WEBPACK_IMPORTED_MODULE_7__/* .getBlocksFromTimestamps */ .z)([
            (0,date_fns__WEBPACK_IMPORTED_MODULE_2__.getUnixTime)(days30Ago)
        ]);
        if (!days30AgoBlock) {
            throw new Error('No block found for 30 days ago');
        }
        const totalTx = await utils_graphql__WEBPACK_IMPORTED_MODULE_6__/* .infoServerClient.request */ .yH.request(totalTxQuery, {
            id: _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_1__.FACTORY_ADDRESS
        });
        const totalTx30DaysAgo = await utils_graphql__WEBPACK_IMPORTED_MODULE_6__/* .infoServerClient.request */ .yH.request(totalTxQuery, {
            block: {
                number: days30AgoBlock.number
            },
            id: _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_1__.FACTORY_ADDRESS
        });
        if (totalTx?.pancakeFactory?.totalTransactions && totalTx30DaysAgo?.pancakeFactory?.totalTransactions && parseInt(totalTx.pancakeFactory.totalTransactions) > parseInt(totalTx30DaysAgo.pancakeFactory.totalTransactions)) {
            results.totalTx30Days = parseInt(totalTx.pancakeFactory.totalTransactions) - parseInt(totalTx30DaysAgo.pancakeFactory.totalTransactions);
        }
    } catch (error) {
        console.error('Error when fetching total tx count', error);
    }
    const usersQuery = graphql_request__WEBPACK_IMPORTED_MODULE_3__.gql`
    query userCount($since: ISO8601DateTime, $till: ISO8601DateTime) {
      ethereum(network: bsc) {
        dexTrades(exchangeName: { in: ["Pancake", "Pancake v2"] }, date: { since: $since, till: $till }) {
          count(uniq: senders)
        }
      }
    }
  `;
    try {
        const result = await utils_graphql__WEBPACK_IMPORTED_MODULE_6__/* .bitQueryServerClient.request */ .iR.request(usersQuery, {
            since: days30Ago.toISOString(),
            till: new Date().toISOString()
        });
        if (result?.ethereum?.dexTrades?.[0]?.count) {
            results.addressCount30Days = result.ethereum.dexTrades[0].count;
        }
    } catch (error1) {
        if (true) {
            console.error('Error when fetching address count', error1);
        }
    }
    return {
        props: results,
        revalidate: 60 * 60 * 24 * 30
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (IndexPage);

});

/***/ }),

/***/ 43237:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var components_NextLink__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(53629);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(99150);






const StyledSubheading = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Heading).withConfig({
    componentId: "sc-b235ddc1-0"
})`
  background: -webkit-linear-gradient(#ffd800, #eb8c00);
  font-size: 20px;
  background-clip: text;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  -webkit-text-stroke: 1px rgba(0, 0, 0, 0.5);
  ${({ theme  })=>theme.mediaQueries.xs
} {
    font-size: 24px;
  }
  ${({ theme  })=>theme.mediaQueries.sm
} {
    -webkit-text-stroke: unset;
  }
  margin-bottom: 8px;
`;
const StyledHeading = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Heading).withConfig({
    componentId: "sc-b235ddc1-1"
})`
  color: #ffffff;
  background: -webkit-linear-gradient(#7645d9 0%, #452a7a 100%);
  background-clip: text;
  -webkit-background-clip: text;
  -webkit-text-stroke: 6px transparent;
  text-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
  margin-bottom: 16px;
`;
const Wrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-b235ddc1-2"
})`
  border-radius: 32px;
  width: 100%;
  background-image: linear-gradient(#7645d9, #452a7a);
  max-height: max-content;
  overflow: hidden;
`;
const Inner = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex).withConfig({
    componentId: "sc-b235ddc1-3"
})`
  position: relative;
  padding: 24px;
  flex-direction: row;
  justify-content: space-between;
  max-height: 220px;
`;
const LeftWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex).withConfig({
    componentId: "sc-b235ddc1-4"
})`
  z-index: 1;
  width: 100%;
  flex-direction: column;
  justify-content: center;

  ${({ theme  })=>theme.mediaQueries.md
} {
    padding-top: 40px;
    padding-bottom: 40px;
  }
`;
const RightWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-b235ddc1-5"
})`
  position: absolute;
  top: 0;
  right: 24px;
  opacity: 0.9;

  & img {
    height: 186px; // 200px for normal bunny, 186px for gaming bunny
  }

  ${({ theme  })=>theme.mediaQueries.md
} {
    position: relative;
    display: flex;
    align-items: center;
    justify-content: flex-end;
    opacity: 1;

    & img {
      height: 100%; // 100% for normal bunny, 130% for gaming bunny
    }
  }
`;
const FarmAuctionsBanner = ()=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_5__/* .useTranslation */ .$G)();
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Wrapper, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Inner, {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(LeftWrapper, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledSubheading, {
                            children: t('%num% Contenders...', {
                                num: 18
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledHeading, {
                            scale: "xl",
                            children: t('%num% Winners', {
                                num: 3
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_NextLink__WEBPACK_IMPORTED_MODULE_4__/* .NextLinkFromReactRouter */ .a, {
                            to: "/farms/auction",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Button, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                        color: "invertedContrast",
                                        bold: true,
                                        fontSize: "16px",
                                        mr: "4px",
                                        children: t('Farm Auctions')
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.ArrowForwardIcon, {
                                        color: "invertedContrast"
                                    })
                                ]
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(RightWrapper, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: "/images/decorations/auction-bunny.png",
                        alt: t('auction bunny')
                    })
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FarmAuctionsBanner);


/***/ }),

/***/ 44964:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_Balance__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(20922);
/* harmony import */ var config_abi_cake_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(93361);
/* harmony import */ var config_constants_tokens__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(29748);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(99150);
/* harmony import */ var hooks_useIntersectionObserver__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(76538);
/* harmony import */ var hooks_useRefreshEffect__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(27892);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var state_farms_hooks__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8733);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var utils_formatBalance__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(65044);
/* harmony import */ var utils_multicall__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(41144);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks_useRefreshEffect__WEBPACK_IMPORTED_MODULE_7__, state_farms_hooks__WEBPACK_IMPORTED_MODULE_9__]);
([hooks_useRefreshEffect__WEBPACK_IMPORTED_MODULE_7__, state_farms_hooks__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);













const StyledColumn = styled_components__WEBPACK_IMPORTED_MODULE_10___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Flex).withConfig({
    componentId: "sc-dfb47e46-0"
})`
  flex-direction: column;
  ${({ noMobileBorder , theme  })=>noMobileBorder ? `${theme.mediaQueries.md} {
           padding: 0 16px;
           border-left: 1px ${theme.colors.inputSecondary} solid;
         }
       ` : `border-left: 1px ${theme.colors.inputSecondary} solid;
         padding: 0 8px;
         ${theme.mediaQueries.sm} {
           padding: 0 16px;
         }
       `
}
`;
const Grid = styled_components__WEBPACK_IMPORTED_MODULE_10___default().div.withConfig({
    componentId: "sc-dfb47e46-1"
})`
  display: grid;
  grid-gap: 16px 8px;
  margin-top: 24px;
  grid-template-columns: repeat(2, auto);

  ${({ theme  })=>theme.mediaQueries.sm
} {
    grid-gap: 16px;
  }

  ${({ theme  })=>theme.mediaQueries.md
} {
    grid-gap: 32px;
    grid-template-columns: repeat(4, auto);
  }
`;
const emissionsPerBlock = 14.25;
const CakeDataRow = ()=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_5__/* .useTranslation */ .$G)();
    const { observerRef , isIntersecting  } = (0,hooks_useIntersectionObserver__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)();
    const { 0: loadData , 1: setLoadData  } = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)(false);
    const { 0: cakeSupply , 1: setCakeSupply  } = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)(0);
    const { 0: burnedBalance , 1: setBurnedBalance  } = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)(0);
    const cakePriceBusd = (0,state_farms_hooks__WEBPACK_IMPORTED_MODULE_9__/* .usePriceCakeBusd */ .Iu)();
    const mcap = cakePriceBusd.times(cakeSupply);
    const mcapString = (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_11__/* .formatLocalisedCompactNumber */ .uI)(mcap.toNumber());
    (0,react__WEBPACK_IMPORTED_MODULE_8__.useEffect)(()=>{
        if (isIntersecting) {
            setLoadData(true);
        }
    }, [
        isIntersecting
    ]);
    (0,hooks_useRefreshEffect__WEBPACK_IMPORTED_MODULE_7__/* .useSlowRefreshEffect */ .X)(()=>{
        const fetchTokenData = async ()=>{
            const totalSupplyCall = {
                address: config_constants_tokens__WEBPACK_IMPORTED_MODULE_4__/* ["default"].cake.address */ .ZP.cake.address,
                name: 'totalSupply'
            };
            const burnedTokenCall = {
                address: config_constants_tokens__WEBPACK_IMPORTED_MODULE_4__/* ["default"].cake.address */ .ZP.cake.address,
                name: 'balanceOf',
                params: [
                    '0x000000000000000000000000000000000000dEaD'
                ]
            };
            const tokenDataResultRaw = await (0,utils_multicall__WEBPACK_IMPORTED_MODULE_12__/* .multicallv2 */ .v)(config_abi_cake_json__WEBPACK_IMPORTED_MODULE_3__, [
                totalSupplyCall,
                burnedTokenCall
            ], {
                requireSuccess: false
            });
            const [totalSupply, burned] = tokenDataResultRaw.flat();
            setCakeSupply(totalSupply && burned ? +(0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_11__/* .formatBigNumber */ .dp)(totalSupply.sub(burned)) : 0);
            setBurnedBalance(burned ? +(0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_11__/* .formatBigNumber */ .dp)(burned) : 0);
        };
        if (loadData) {
            fetchTokenData();
        }
    }, [
        loadData
    ]);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Grid, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                flexDirection: "column",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Text, {
                        color: "textSubtle",
                        children: t('Total supply')
                    }),
                    cakeSupply ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        decimals: 0,
                        lineHeight: "1.1",
                        fontSize: "24px",
                        bold: true,
                        value: cakeSupply
                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                ref: observerRef
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Skeleton, {
                                height: 24,
                                width: 126,
                                my: "4px"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(StyledColumn, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Text, {
                        color: "textSubtle",
                        children: t('Burned to date')
                    }),
                    burnedBalance ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        decimals: 0,
                        lineHeight: "1.1",
                        fontSize: "24px",
                        bold: true,
                        value: burnedBalance
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Skeleton, {
                        height: 24,
                        width: 126,
                        my: "4px"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(StyledColumn, {
                noMobileBorder: true,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Text, {
                        color: "textSubtle",
                        children: t('Market cap')
                    }),
                    mcap?.gt(0) && mcapString ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Heading, {
                        scale: "lg",
                        children: t('$%marketCap%', {
                            marketCap: mcapString
                        })
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Skeleton, {
                        height: 24,
                        width: 126,
                        my: "4px"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(StyledColumn, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Text, {
                        color: "textSubtle",
                        children: t('Current emissions')
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Heading, {
                        scale: "lg",
                        children: t('%cakeEmissions%/block', {
                            cakeEmissions: emissionsPerBlock
                        })
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CakeDataRow);

});

/***/ }),

/***/ 10413:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "gA": () => (/* binding */ getSrcSet),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export getImageUrl */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);




const floatingAnim = (x, y)=>styled_components__WEBPACK_IMPORTED_MODULE_2__.keyframes`
  from {
    transform: translate(0,  0px);
  }
  50% {
    transform: translate(${x}, ${y});
  }
  to {
    transform: translate(0, 0px);
  }
`
;
const Wrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Box).withConfig({
    componentId: "sc-f25349f0-0"
})`
  position: relative;
  max-height: ${({ maxHeight  })=>maxHeight
};

  & :nth-child(2) {
    animation: ${floatingAnim('3px', '15px')} 3s ease-in-out infinite;
    animation-delay: 1s;
  }

  & :nth-child(3) {
    animation: ${floatingAnim('5px', '10px')} 3s ease-in-out infinite;
    animation-delay: 0.66s;
  }

  & :nth-child(4) {
    animation: ${floatingAnim('6px', '5px')} 3s ease-in-out infinite;
    animation-delay: 0.33s;
  }

  & :nth-child(5) {
    animation: ${floatingAnim('4px', '12px')} 3s ease-in-out infinite;
    animation-delay: 0s;
  }
`;
const DummyImg = styled_components__WEBPACK_IMPORTED_MODULE_2___default().img.withConfig({
    componentId: "sc-f25349f0-1"
})`
  max-height: ${({ maxHeight  })=>maxHeight
};
  visibility: hidden;
`;
const ImageWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Box).withConfig({
    componentId: "sc-f25349f0-2"
})`
  height: 100%;
  position: absolute;
  top: 0;
  left: 0;

  img {
    max-height: 100%;
    width: auto;
  }
`;
var Resolution;
(function(Resolution) {
    Resolution["MD"] = '1.5x';
    Resolution["LG"] = '2x';
})(Resolution || (Resolution = {}));
const getImageUrl = (base, imageSrc, resolution, extension = '.png')=>`${base}${imageSrc}${resolution ? `@${resolution}${extension}` : extension}`
;
const getSrcSet = (base, imageSrc, extension = '.png')=>{
    return `${getImageUrl(base, imageSrc, undefined, extension)} 512w,
  ${getImageUrl(base, imageSrc, Resolution.MD, extension)} 768w,
  ${getImageUrl(base, imageSrc, Resolution.LG, extension)} 1024w,`;
};
const CompositeImage = ({ path , attributes , maxHeight ='512px'  })=>{
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Wrapper, {
        maxHeight: maxHeight,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("picture", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                        type: "image/webp",
                        srcSet: getSrcSet(path, attributes[0].src, '.webp')
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                        type: "image/png",
                        srcSet: getSrcSet(path, attributes[0].src)
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(DummyImg, {
                        src: getImageUrl(path, attributes[0].src),
                        maxHeight: maxHeight,
                        loading: "lazy",
                        decoding: "async"
                    })
                ]
            }),
            attributes.map((image)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ImageWrapper, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("picture", {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                                type: "image/webp",
                                srcSet: getSrcSet(path, image.src, '.webp')
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                                type: "image/png",
                                srcSet: getSrcSet(path, image.src)
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                src: getImageUrl(path, image.src),
                                alt: image.alt,
                                loading: "lazy",
                                decoding: "async"
                            })
                        ]
                    })
                }, image.src)
            )
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CompositeImage);


/***/ }),

/***/ 56565:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var hooks_useTheme__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(23917);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks_useTheme__WEBPACK_IMPORTED_MODULE_3__]);
hooks_useTheme__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];




const RowHeading = ({ text , ...props })=>{
    const { theme  } = (0,hooks_useTheme__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)();
    const split = text.split(' ');
    const firstWord = split[0];
    const remainingWords = split.slice(1).join(' ');
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Heading, {
        ...props,
        children: [
            firstWord,
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                style: {
                    color: theme.colors.secondary
                },
                children: [
                    " ",
                    remainingWords
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RowHeading);

});

/***/ }),

/***/ 94480:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var components_Balance__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(20922);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(99150);






const StyledWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex).withConfig({
    componentId: "sc-d41d0ded-0"
})`
  position: relative;
`;
const AbsoluteWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex).withConfig({
    componentId: "sc-d41d0ded-1"
})`
  position: absolute;
  top: ${({ topOffset  })=>topOffset
};
  opacity: ${({ visible  })=>visible ? 1 : 0
};
  margin-top: ${({ visible  })=>visible ? 0 : `50%`
};
  transition: opacity, margin-top, 0.4s ease-out;
  flex-direction: column;

  ${({ index , theme  })=>index > 0 ? `
         ${theme.mediaQueries.sm} {
           height: 80px;
           top: 0;
           padding-left: 16px;
           border-left: 1px ${theme.colors.inputSecondary} solid;
         }
       ` : `padding-right: 16px;`
}
`;
const TopFarmPool = ({ title , percentage , index , visible  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_5__/* .useTranslation */ .$G)();
    const topOffset = ()=>{
        if (index >= 0 && index < 2) {
            return '0px';
        }
        if (index >= 2 && index < 3) {
            return '80px';
        }
        return '160px';
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledWrapper, {
        index: index,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(AbsoluteWrapper, {
            index: index,
            visible: visible,
            topOffset: topOffset(),
            children: [
                title ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                    bold: true,
                    mb: "8px",
                    fontSize: "12px",
                    color: "secondary",
                    children: title
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Skeleton, {
                    width: 80,
                    height: 12,
                    mb: "8px"
                }),
                percentage ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                    lineHeight: "1.1",
                    fontSize: "16px",
                    bold: true,
                    unit: "%",
                    value: percentage
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Skeleton, {
                    width: 60,
                    height: 16
                }),
                percentage ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                    fontSize: "16px",
                    color: "textSubtle",
                    children: t('APR')
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Skeleton, {
                    width: 30,
                    height: 16,
                    mt: "4px"
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TopFarmPool);


/***/ }),

/***/ 77956:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99150);
/* harmony import */ var hooks_useIntersectionObserver__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(76538);
/* harmony import */ var views_Home_hooks_useGetTopFarmsByApr__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4727);
/* harmony import */ var views_Home_hooks_useGetTopPoolsByApr__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(81587);
/* harmony import */ var config_constants_pools__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(71080);
/* harmony import */ var _TopFarmPool__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(94480);
/* harmony import */ var _RowHeading__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(56565);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_RowHeading__WEBPACK_IMPORTED_MODULE_10__, views_Home_hooks_useGetTopPoolsByApr__WEBPACK_IMPORTED_MODULE_7__, views_Home_hooks_useGetTopFarmsByApr__WEBPACK_IMPORTED_MODULE_6__]);
([_RowHeading__WEBPACK_IMPORTED_MODULE_10__, views_Home_hooks_useGetTopPoolsByApr__WEBPACK_IMPORTED_MODULE_7__, views_Home_hooks_useGetTopFarmsByApr__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);











const Grid = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-35b3c4fc-0"
})`
  display: grid;
  grid-template-columns: repeat(2, auto);

  ${({ theme  })=>theme.mediaQueries.sm
} {
    grid-gap: 16px;
    grid-template-columns: repeat(5, auto);
  }

  ${({ theme  })=>theme.mediaQueries.md
} {
    grid-gap: 32px;
  }
`;
const FarmsPoolsRow = ()=>{
    const { 0: showFarms , 1: setShowFarms  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    const { observerRef , isIntersecting  } = (0,hooks_useIntersectionObserver__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)();
    const { topFarms  } = (0,views_Home_hooks_useGetTopFarmsByApr__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)(isIntersecting);
    const { topPools  } = (0,views_Home_hooks_useGetTopPoolsByApr__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)(isIntersecting);
    const timer = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const isLoaded = topFarms[0] && topPools[0];
    const startTimer = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        timer.current = setInterval(()=>{
            setShowFarms((prev)=>!prev
            );
        }, 6000);
    }, [
        timer
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (isLoaded) {
            startTimer();
        }
        return ()=>{
            clearInterval(timer.current);
        };
    }, [
        timer,
        isLoaded,
        startTimer
    ]);
    const getPoolText = (pool)=>{
        if (pool.vaultKey) {
            return t(config_constants_pools__WEBPACK_IMPORTED_MODULE_8__/* .vaultPoolConfig */ .Y[pool.vaultKey].name);
        }
        if (pool.sousId === 0) {
            return t('Manual CAKE');
        }
        return t('Stake %stakingSymbol% - Earn %earningSymbol%', {
            earningSymbol: pool.earningToken.symbol,
            stakingSymbol: pool.stakingToken.symbol
        });
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        ref: observerRef,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
            flexDirection: "column",
            mt: "24px",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                    mb: "24px",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_RowHeading__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                            text: showFarms ? t('Top Farms') : t('Top Syrup Pools')
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.IconButton, {
                            variant: "text",
                            height: "100%",
                            width: "auto",
                            onClick: ()=>{
                                setShowFarms((prev)=>!prev
                                );
                                clearInterval(timer.current);
                                startTimer();
                            },
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.SwapVertIcon, {
                                height: "24px",
                                width: "24px",
                                color: "textSubtle"
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Box, {
                    height: [
                        '240px',
                        null,
                        '80px'
                    ],
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Grid, {
                            children: topFarms.map((topFarm, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TopFarmPool__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                    title: topFarm?.lpSymbol,
                                    percentage: topFarm?.apr + topFarm?.lpRewardsApr,
                                    index: index,
                                    visible: showFarms
                                }, index)
                            )
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Grid, {
                            children: topPools.map((topPool, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TopFarmPool__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                    title: topPool && getPoolText(topPool),
                                    percentage: topPool?.apr,
                                    index: index,
                                    visible: !showFarms
                                }, index)
                            )
                        })
                    ]
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FarmsPoolsRow);

});

/***/ }),

/***/ 26408:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_Footer)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(57518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: external "@pancakeswap/uikit"
var uikit_ = __webpack_require__(2829);
// EXTERNAL MODULE: ./src/contexts/Localization/index.tsx + 3 modules
var Localization = __webpack_require__(99150);
// EXTERNAL MODULE: ./src/components/ConnectWalletButton.tsx
var ConnectWalletButton = __webpack_require__(30621);
// EXTERNAL MODULE: ./src/components/Layout/Container.tsx
var Container = __webpack_require__(55027);
// EXTERNAL MODULE: external "@web3-react/core"
var core_ = __webpack_require__(18054);
;// CONCATENATED MODULE: ./src/views/Home/components/SunburstSvg.tsx



const SunburstSvg = (props)=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(uikit_.Svg, {
        viewBox: "0 0 1956 1956",
        ...props,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("g", {
                filter: "url(#filter0_f)",
                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    d: "M978 20L987.526 796.229L1078.14 25.248L1006.47 798.221L1177.18 40.9346L1025.11 802.182L1274.04 66.8879L1043.23 808.07L1367.65 102.823L1060.64 815.819L1457 148.348L1077.14 825.345L1541.1 202.962L1092.55 836.544L1619.03 266.067L1106.71 849.292L1689.93 336.973L1119.46 863.451L1753.04 414.902L1130.65 878.865L1807.65 499L1140.18 895.365L1853.18 588.346L1147.93 912.77L1889.11 681.962L1153.82 930.89L1915.07 778.821L1157.78 949.526L1930.75 877.862L1159.77 968.474L1936 978L1159.77 987.526L1930.75 1078.14L1157.78 1006.47L1915.07 1177.18L1153.82 1025.11L1889.11 1274.04L1147.93 1043.23L1853.18 1367.65L1140.18 1060.64L1807.65 1457L1130.65 1077.14L1753.04 1541.1L1119.46 1092.55L1689.93 1619.03L1106.71 1106.71L1619.03 1689.93L1092.55 1119.46L1541.1 1753.04L1077.14 1130.65L1457 1807.65L1060.64 1140.18L1367.65 1853.18L1043.23 1147.93L1274.04 1889.11L1025.11 1153.82L1177.18 1915.07L1006.47 1157.78L1078.14 1930.75L987.526 1159.77L978 1936L968.474 1159.77L877.862 1930.75L949.526 1157.78L778.821 1915.07L930.89 1153.82L681.962 1889.11L912.77 1147.93L588.346 1853.18L895.365 1140.18L499 1807.65L878.865 1130.65L414.902 1753.04L863.451 1119.46L336.973 1689.93L849.292 1106.71L266.067 1619.03L836.544 1092.55L202.962 1541.1L825.345 1077.14L148.348 1457L815.819 1060.64L102.823 1367.65L808.07 1043.23L66.8879 1274.04L802.182 1025.11L40.9346 1177.18L798.221 1006.47L25.248 1078.14L796.229 987.526L20 978L796.229 968.474L25.248 877.862L798.221 949.526L40.9346 778.821L802.182 930.89L66.8879 681.962L808.07 912.77L102.823 588.346L815.819 895.365L148.348 499L825.345 878.865L202.962 414.902L836.544 863.451L266.067 336.973L849.292 849.292L336.973 266.067L863.451 836.544L414.902 202.962L878.865 825.345L499 148.348L895.365 815.819L588.346 102.823L912.77 808.07L681.962 66.8879L930.89 802.182L778.821 40.9346L949.526 798.221L877.862 25.248L968.474 796.229L978 20Z",
                    fill: "url(#paint0_radial)",
                    fillOpacity: "0.1"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("defs", {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("filter", {
                        id: "filter0_f",
                        x: "0",
                        y: "0",
                        width: "1956",
                        height: "1956",
                        filterUnits: "userSpaceOnUse",
                        colorInterpolationFilters: "sRGB",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("feFlood", {
                                floodOpacity: "0",
                                result: "BackgroundImageFix"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("feBlend", {
                                mode: "normal",
                                in: "SourceGraphic",
                                in2: "BackgroundImageFix",
                                result: "shape"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("feGaussianBlur", {
                                stdDeviation: "10",
                                result: "effect1_foregroundBlur"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("radialGradient", {
                        id: "paint0_radial",
                        cx: "0",
                        cy: "0",
                        r: "1",
                        gradientUnits: "userSpaceOnUse",
                        gradientTransform: "translate(978 978) rotate(90) scale(958)",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("stop", {
                                offset: "0.114547",
                                stopColor: "white",
                                stopOpacity: "0"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("stop", {
                                offset: "0.374975",
                                stopColor: "white"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("stop", {
                                offset: "1",
                                stopColor: "white",
                                stopOpacity: "0"
                            })
                        ]
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const components_SunburstSvg = (SunburstSvg);

// EXTERNAL MODULE: ./src/views/Home/components/CompositeImage.tsx
var CompositeImage = __webpack_require__(10413);
;// CONCATENATED MODULE: ./src/views/Home/components/Footer.tsx










const BgWrapper = external_styled_components_default().div.withConfig({
    componentId: "sc-14343c62-0"
})`
  overflow: hidden;
  position: absolute;
  width: 100%;
  height: 100%;
  top: 0px;
  left: 0px;
`;
const StyledSunburst = external_styled_components_default()(components_SunburstSvg).withConfig({
    componentId: "sc-14343c62-1"
})`
  height: 350%;
  width: 350%;

  ${({ theme  })=>theme.mediaQueries.xl
} {
    height: 400%;
    width: 400%;
  }
`;
const Wrapper = external_styled_components_default()(uikit_.Flex).withConfig({
    componentId: "sc-14343c62-2"
})`
  z-index: 1;
  position: relative;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  overflow: hidden;
`;
const FloatingPancakesWrapper = external_styled_components_default()(Container/* default */.Z).withConfig({
    componentId: "sc-14343c62-3"
})`
  overflow: hidden;
  position: absolute;
  width: 100%;
  height: 100%;
  top: 0;
  left: 50%;
  transform: translateX(-50%);
  visibility: hidden;

  ${({ theme  })=>theme.mediaQueries.md
} {
    visibility: visible;
  }
`;
const TopLeftImgWrapper = external_styled_components_default()(uikit_.Flex).withConfig({
    componentId: "sc-14343c62-4"
})`
  position: absolute;
  left: 0;
  top: 0;
`;
const BottomRightImgWrapper = external_styled_components_default()(uikit_.Flex).withConfig({
    componentId: "sc-14343c62-5"
})`
  position: absolute;
  right: 0;
  bottom: 0;
`;
const topLeftImage = {
    path: '/images/home/flying-pancakes/',
    attributes: [
        {
            src: '1-bottom',
            alt: 'Pancake flying on the bottom'
        },
        {
            src: '1-left',
            alt: 'Pancake flying on the left'
        },
        {
            src: '1-top',
            alt: 'Pancake flying on the top'
        }, 
    ]
};
const bottomRightImage = {
    path: '/images/home/flying-pancakes/',
    attributes: [
        {
            src: '2-bottom',
            alt: 'Pancake flying on the bottom'
        },
        {
            src: '2-top',
            alt: 'Pancake flying on the top'
        },
        {
            src: '2-right',
            alt: 'Pancake flying on the right'
        }, 
    ]
};
const Footer = ()=>{
    const { t  } = (0,Localization/* useTranslation */.$G)();
    const { account  } = (0,core_.useWeb3React)();
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(BgWrapper, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Flex, {
                    alignItems: "center",
                    justifyContent: "center",
                    width: "100%",
                    height: "100%",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(StyledSunburst, {})
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(FloatingPancakesWrapper, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(TopLeftImgWrapper, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(CompositeImage/* default */.ZP, {
                            ...topLeftImage,
                            maxHeight: "256px"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(BottomRightImgWrapper, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(CompositeImage/* default */.ZP, {
                            ...bottomRightImage,
                            maxHeight: "256px"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Wrapper, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Heading, {
                        mb: "24px",
                        scale: "xl",
                        color: "white",
                        children: t('Start in seconds.')
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Text, {
                        textAlign: "center",
                        color: "white",
                        children: t('Connect your crypto wallet to start using the app in seconds.')
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Text, {
                        mb: "24px",
                        bold: true,
                        color: "white",
                        children: t('No registration needed.')
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Link, {
                        external: true,
                        href: "https://docs.pancakeswap.finance/",
                        children: t('Learn how to start')
                    }),
                    !account && /*#__PURE__*/ jsx_runtime_.jsx(ConnectWalletButton/* default */.Z, {
                        mt: "24px"
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const components_Footer = (Footer);


/***/ }),

/***/ 46444:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);



const GradientLogo = (props)=>{
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Svg, {
        viewBox: "0 0 48 48",
        ...props,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M14.9024 0C10.8947 0 7.87179 3.60289 8.60749 7.50271L10.3484 16.7306C4.45101 19.3061 0 23.7533 0 29.3333V32.7273C0 37.3405 3.08306 41.2029 7.39317 43.8102C11.7369 46.4379 17.6132 48 24 48C30.3868 48 36.2631 46.4379 40.6068 43.8102C44.9169 41.2029 48 37.3405 48 32.7273V29.3333C48 23.7236 43.5028 19.2593 37.5552 16.6889L39.2882 7.50271C40.0239 3.6029 37.001 0 32.9933 0C29.4567 0 26.5896 2.83809 26.5896 6.33904V14.147C25.7386 14.0899 24.8746 14.0606 24 14.0606C23.0897 14.0606 22.1908 14.0923 21.3061 14.1541V6.33904C21.3061 2.83809 18.4391 0 14.9024 0ZM17.8776 28.3637C17.8776 30.372 16.7811 32 15.4286 32C14.0761 32 12.9796 30.372 12.9796 28.3637C12.9796 26.3554 14.0761 24.7273 15.4286 24.7273C16.7811 24.7273 17.8776 26.3554 17.8776 28.3637ZM34.7757 28.3637C34.7757 30.372 33.6792 32 32.3267 32C30.9742 32 29.8777 30.372 29.8777 28.3637C29.8777 26.3554 30.9742 24.7273 32.3267 24.7273C33.6792 24.7273 34.7757 26.3554 34.7757 28.3637Z",
                fill: "url(#paint0_linear)"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("defs", {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("linearGradient", {
                    id: "paint0_linear",
                    x1: "24",
                    y1: "0",
                    x2: "24",
                    y2: "48",
                    gradientUnits: "userSpaceOnUse",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                            stopColor: "#7645D9"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                            offset: "1",
                            stopColor: "#5121B1"
                        })
                    ]
                })
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (GradientLogo);


/***/ }),

/***/ 12851:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var components_NextLink__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(53629);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(18054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(99150);
/* harmony import */ var components_ConnectWalletButton__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(30621);
/* harmony import */ var hooks_useTheme__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(23917);
/* harmony import */ var _SlideSvg__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(51889);
/* harmony import */ var _CompositeImage__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(10413);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks_useTheme__WEBPACK_IMPORTED_MODULE_8__]);
hooks_useTheme__WEBPACK_IMPORTED_MODULE_8__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];











const flyingAnim = ()=>styled_components__WEBPACK_IMPORTED_MODULE_2__.keyframes`
  from {
    transform: translate(0,  0px);
  }
  50% {
    transform: translate(-5px, -5px);
  }
  to {
    transform: translate(0, 0px);
  }
`
;
const fading = ()=>styled_components__WEBPACK_IMPORTED_MODULE_2__.keyframes`
  from {
    opacity: 0.9;
  }
  50% {
    opacity: 0.1;
  }
  to {
    opacity: 0.9;
  }
`
;
const BgWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-5c9d0e9c-0"
})`
  z-index: -1;
  overflow: hidden;
  position: absolute;
  width: 100%;
  height: 100%;
  bottom: 0px;
  left: 0px;
`;
const InnerWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-5c9d0e9c-1"
})`
  position: absolute;
  width: 100%;
  bottom: -3px;
`;
const BunnyWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-5c9d0e9c-2"
})`
  width: 100%;
  animation: ${flyingAnim} 3.5s ease-in-out infinite;
`;
const StarsWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-5c9d0e9c-3"
})`
  position: absolute;
  top: 0;
  left: 0;

  & :nth-child(2) {
    animation: ${fading} 2s ease-in-out infinite;
    animation-delay: 1s;
  }

  & :nth-child(3) {
    animation: ${fading} 5s ease-in-out infinite;
    animation-delay: 0.66s;
  }

  & :nth-child(4) {
    animation: ${fading} 2.5s ease-in-out infinite;
    animation-delay: 0.33s;
  }
`;
const imagePath = '/images/home/lunar-bunny/';
const imageSrc = 'bunny';
const starsImage = {
    path: '/images/home/lunar-bunny/',
    attributes: [
        {
            src: 'star-l',
            alt: '3D Star'
        },
        {
            src: 'star-r',
            alt: '3D Star'
        },
        {
            src: 'star-top-r',
            alt: '3D Star'
        }, 
    ]
};
const Hero = ()=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_6__/* .useTranslation */ .$G)();
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_5__.useWeb3React)();
    const { theme  } = (0,hooks_useTheme__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(BgWrapper, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(InnerWrapper, {
                    children: theme.isDark ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SlideSvg__WEBPACK_IMPORTED_MODULE_9__/* .SlideSvgDark */ .U, {
                        width: "100%"
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SlideSvg__WEBPACK_IMPORTED_MODULE_9__/* .SlideSvgLight */ .s, {
                        width: "100%"
                    })
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Flex, {
                position: "relative",
                flexDirection: [
                    'column-reverse',
                    null,
                    null,
                    'row'
                ],
                alignItems: [
                    'flex-end',
                    null,
                    null,
                    'center'
                ],
                justifyContent: "center",
                mt: [
                    account ? '280px' : '50px',
                    null,
                    0
                ],
                id: "homepage-hero",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Flex, {
                        flex: "1",
                        flexDirection: "column",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Heading, {
                                scale: "xxl",
                                color: "secondary",
                                mb: "24px",
                                children: t('The moon is made of pancakes.')
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Heading, {
                                scale: "md",
                                mb: "24px",
                                children: t('Trade, earn, and win crypto on the most popular decentralized platform in the galaxy.')
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Flex, {
                                children: [
                                    !account && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_ConnectWalletButton__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                        mr: "8px"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_NextLink__WEBPACK_IMPORTED_MODULE_3__/* .NextLinkFromReactRouter */ .a, {
                                        to: "/swap",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Button, {
                                            variant: !account ? 'secondary' : 'primary',
                                            children: t('Trade Now')
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Flex, {
                        height: [
                            '192px',
                            null,
                            null,
                            '100%'
                        ],
                        width: [
                            '192px',
                            null,
                            null,
                            '100%'
                        ],
                        flex: [
                            null,
                            null,
                            null,
                            '1'
                        ],
                        mb: [
                            '24px',
                            null,
                            null,
                            '0'
                        ],
                        position: "relative",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(BunnyWrapper, {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("picture", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                                            type: "image/webp",
                                            srcSet: (0,_CompositeImage__WEBPACK_IMPORTED_MODULE_10__/* .getSrcSet */ .gA)(imagePath, imageSrc, '.webp')
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                                            type: "image/png",
                                            srcSet: (0,_CompositeImage__WEBPACK_IMPORTED_MODULE_10__/* .getSrcSet */ .gA)(imagePath, imageSrc)
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: `${imagePath}${imageSrc}.png`,
                                            alt: t('Lunar bunny')
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StarsWrapper, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CompositeImage__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .ZP, {
                                    ...starsImage
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Hero);

});

/***/ }),

/***/ 20923:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);




const StyledCard = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Card).withConfig({
    componentId: "sc-f6b8eb43-0"
})`
  height: fit-content;
  padding: 1px 1px 4px 1px;
  box-sizing: border-box;

  ${({ theme  })=>theme.mediaQueries.md
} {
    ${({ rotation  })=>rotation ? `transform: rotate(${rotation});` : ''
}
  }
`;
const IconWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Box).withConfig({
    componentId: "sc-f6b8eb43-1"
})`
  position: absolute;
  top: 24px;
  right: 24px;

  ${({ theme  })=>theme.mediaQueries.md
} {
    ${({ rotation  })=>rotation ? `transform: rotate(${rotation});` : ''
}
  }
`;
const IconCard = ({ icon , background , borderColor , rotation , children , ...props })=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledCard, {
        background: background,
        borderBackground: borderColor,
        rotation: rotation,
        ...props,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.CardBody, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(IconWrapper, {
                    rotation: rotation,
                    children: icon
                }),
                children
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (IconCard);


/***/ }),

/***/ 23805:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);



const StatCardContent = ({ headingText , bodyText , highlightColor ,  })=>{
    const { isMobile , isTablet  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.useMatchBreakpoints)();
    const isSmallerScreen = isMobile || isTablet;
    const split = headingText.split(' ');
    const lastWord = split.pop();
    const remainingWords = split.slice(0, split.length).join(' ');
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
        minHeight: [
            null,
            null,
            null,
            '168px'
        ],
        minWidth: "232px",
        width: "fit-content",
        flexDirection: "column",
        justifyContent: "flex-end",
        mt: [
            null,
            null,
            null,
            '64px'
        ],
        children: [
            isSmallerScreen && remainingWords.length > 13 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Heading, {
                scale: "lg",
                children: remainingWords
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Heading, {
                scale: "xl",
                children: remainingWords
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Heading, {
                color: highlightColor,
                scale: "xl",
                mb: "24px",
                children: lastWord
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                color: "textSubtle",
                children: bodyText
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (StatCardContent);


/***/ }),

/***/ 44899:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(99150);
/* harmony import */ var hooks_api__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2010);
/* harmony import */ var hooks_useTheme__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(23917);
/* harmony import */ var utils_formatBalance__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(65044);
/* harmony import */ var swr_immutable__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(79847);
/* harmony import */ var _IconCard__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(20923);
/* harmony import */ var _StatCardContent__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(23805);
/* harmony import */ var _GradientLogoSvg__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(46444);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swr_immutable__WEBPACK_IMPORTED_MODULE_7__, hooks_useTheme__WEBPACK_IMPORTED_MODULE_5__]);
([swr_immutable__WEBPACK_IMPORTED_MODULE_7__, hooks_useTheme__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);











const Stats = ()=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_3__/* .useTranslation */ .$G)();
    const data = (0,hooks_api__WEBPACK_IMPORTED_MODULE_4__/* .useGetStats */ .M)();
    const { theme  } = (0,hooks_useTheme__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)();
    const tvlString = data ? (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_6__/* .formatLocalisedCompactNumber */ .uI)(data.tvl) : '-';
    const { data: txCount  } = (0,swr_immutable__WEBPACK_IMPORTED_MODULE_7__["default"])('totalTx30Days');
    const { data: addressCount  } = (0,swr_immutable__WEBPACK_IMPORTED_MODULE_7__["default"])('addressCount30Days');
    const trades = (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_6__/* .formatLocalisedCompactNumber */ .uI)(txCount);
    const users = (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_6__/* .formatLocalisedCompactNumber */ .uI)(addressCount);
    const tvlText = t('And those users are now entrusting the platform with over $%tvl% in funds.', {
        tvl: tvlString
    });
    const [entrusting, inFunds] = tvlText.split(tvlString);
    const UsersCardData = {
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.CommunityIcon, {
            color: "secondary",
            width: "36px"
        })
    };
    const TradesCardData = {
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.SwapIcon, {
            color: "primary",
            width: "36px"
        })
    };
    const StakedCardData = {
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.ChartIcon, {
            color: "failure",
            width: "36px"
        })
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
        justifyContent: "center",
        alignItems: "center",
        flexDirection: "column",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_GradientLogoSvg__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                height: "48px",
                width: "48px",
                mb: "24px"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Heading, {
                textAlign: "center",
                scale: "xl",
                children: t('Used by millions.')
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Heading, {
                textAlign: "center",
                scale: "xl",
                mb: "32px",
                children: t('Trusted with billions.')
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                textAlign: "center",
                color: "textSubtle",
                children: t('PancakeSwap has the most users of any decentralized platform, ever.')
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                flexWrap: "wrap",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                    display: "inline",
                    textAlign: "center",
                    color: "textSubtle",
                    mb: "20px",
                    children: [
                        entrusting,
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: data ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: tvlString
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Skeleton, {
                                display: "inline-block",
                                height: 16,
                                width: 70,
                                mt: "2px"
                            })
                        }),
                        inFunds
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                textAlign: "center",
                color: "textSubtle",
                bold: true,
                mb: "32px",
                children: t('Will you join them?')
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                flexDirection: [
                    'column',
                    null,
                    null,
                    'row'
                ],
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IconCard__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                        ...UsersCardData,
                        mr: [
                            null,
                            null,
                            null,
                            '16px'
                        ],
                        mb: [
                            '16px',
                            null,
                            null,
                            '0'
                        ],
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_StatCardContent__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                            headingText: t('%users% users', {
                                users
                            }),
                            bodyText: t('in the last 30 days'),
                            highlightColor: theme.colors.secondary
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IconCard__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                        ...TradesCardData,
                        mr: [
                            null,
                            null,
                            null,
                            '16px'
                        ],
                        mb: [
                            '16px',
                            null,
                            null,
                            '0'
                        ],
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_StatCardContent__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                            headingText: t('%trades% trades', {
                                trades
                            }),
                            bodyText: t('made in the last 30 days'),
                            highlightColor: theme.colors.primary
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IconCard__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                        ...StakedCardData,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_StatCardContent__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                            headingText: t('$%tvl% staked', {
                                tvl: tvlString
                            }),
                            bodyText: t('Total Value Locked'),
                            highlightColor: theme.colors.failure
                        })
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Stats);

});

/***/ }),

/***/ 98463:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "hk": () => (/* binding */ swapSectionData),
/* harmony export */   "pH": () => (/* binding */ earnSectionData),
/* harmony export */   "Tu": () => (/* binding */ cakeSectionData)
/* harmony export */ });
const swapSectionData = {
    headingText: 'Trade anything. No registration, no hassle.',
    bodyText: 'Trade any token on Binance Smart Chain in seconds, just by connecting your wallet.',
    reverse: false,
    primaryButton: {
        to: '/swap',
        text: 'Trade Now',
        external: false
    },
    secondaryButton: {
        to: 'https://docs.pancakeswap.finance/',
        text: 'Learn',
        external: true
    },
    images: {
        path: '/images/home/trade/',
        attributes: [
            {
                src: 'BNB',
                alt: 'BNB token'
            },
            {
                src: 'BTC',
                alt: 'BTC token'
            },
            {
                src: 'CAKE',
                alt: 'CAKE token'
            }, 
        ]
    }
};
const earnSectionData = {
    headingText: 'Earn passive income with crypto.',
    bodyText: 'PancakeSwap makes it easy to make your crypto work for you.',
    reverse: true,
    primaryButton: {
        to: '/farms',
        text: 'Explore',
        external: false
    },
    secondaryButton: {
        to: 'https://docs.pancakeswap.finance/products/yield-farming',
        text: 'Learn',
        external: true
    },
    images: {
        path: '/images/home/earn/',
        attributes: [
            {
                src: 'pie',
                alt: 'Pie chart'
            },
            {
                src: 'stonks',
                alt: 'Stocks chart'
            },
            {
                src: 'folder',
                alt: 'Folder with cake token'
            }, 
        ]
    }
};
const cakeSectionData = {
    headingText: 'CAKE makes our world go round.',
    bodyText: 'CAKE token is at the heart of the PancakeSwap ecosystem. Buy it, win it, farm it, spend it, stake it... heck, you can even vote with it!',
    reverse: false,
    primaryButton: {
        to: '/swap?outputCurrency=0x0e09fabb73bd3ade0a17ecc321fd13a19e81ce82',
        text: 'Buy CAKE',
        external: false
    },
    secondaryButton: {
        to: 'https://docs.pancakeswap.finance/tokenomics/cake',
        text: 'Learn',
        external: true
    },
    images: {
        path: '/images/home/cake/',
        attributes: [
            {
                src: 'bottom-right',
                alt: 'Small 3d pancake'
            },
            {
                src: 'top-right',
                alt: 'Small 3d pancake'
            },
            {
                src: 'coin',
                alt: 'CAKE token'
            },
            {
                src: 'top-left',
                alt: 'Small 3d pancake'
            }, 
        ]
    }
};


/***/ }),

/***/ 49804:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var components_NextLink__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(53629);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99150);
/* harmony import */ var _CompositeImage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(10413);
/* harmony import */ var _ColoredWordHeading__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(87927);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_ColoredWordHeading__WEBPACK_IMPORTED_MODULE_6__]);
_ColoredWordHeading__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];







const SalesSection = (props)=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    const { headingText , bodyText , reverse , primaryButton , secondaryButton , images  } = props;
    const headingTranslatedText = t(headingText);
    const bodyTranslatedText = t(bodyText);
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
        flexDirection: "column",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
            flexDirection: [
                'column-reverse',
                null,
                null,
                reverse ? 'row-reverse' : 'row'
            ],
            alignItems: [
                'flex-end',
                null,
                null,
                'center'
            ],
            justifyContent: "center",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                    flexDirection: "column",
                    flex: "1",
                    ml: [
                        null,
                        null,
                        null,
                        reverse && '64px'
                    ],
                    mr: [
                        null,
                        null,
                        null,
                        !reverse && '64px'
                    ],
                    alignSelf: [
                        'flex-start',
                        null,
                        null,
                        'center'
                    ],
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ColoredWordHeading__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                            text: headingTranslatedText
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                            color: "textSubtle",
                            mb: "24px",
                            children: bodyTranslatedText
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                                    mr: "16px",
                                    children: primaryButton.external ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Link, {
                                        external: true,
                                        href: primaryButton.to,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                            color: "card",
                                            bold: true,
                                            fontSize: "16px",
                                            children: t(primaryButton.text)
                                        })
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_NextLink__WEBPACK_IMPORTED_MODULE_3__/* .NextLinkFromReactRouter */ .a, {
                                        to: primaryButton.to,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                            color: "card",
                                            bold: true,
                                            fontSize: "16px",
                                            children: t(primaryButton.text)
                                        })
                                    })
                                }),
                                secondaryButton.external ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Link, {
                                    external: true,
                                    href: secondaryButton.to,
                                    children: t(secondaryButton.text)
                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_NextLink__WEBPACK_IMPORTED_MODULE_3__/* .NextLinkFromReactRouter */ .a, {
                                    to: secondaryButton.to,
                                    children: t(secondaryButton.text)
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                    height: [
                        '192px',
                        null,
                        null,
                        '100%'
                    ],
                    width: [
                        '192px',
                        null,
                        null,
                        '100%'
                    ],
                    flex: [
                        null,
                        null,
                        null,
                        '1'
                    ],
                    mb: [
                        '24px',
                        null,
                        null,
                        '0'
                    ],
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CompositeImage__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP, {
                        ...images
                    })
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SalesSection);

});

/***/ }),

/***/ 47979:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D": () => (/* binding */ getEarningsText)
/* harmony export */ });
const getEarningsText = (numFarmsToCollect, hasCakePoolToCollect, earningsBusd, t)=>{
    const data = {
        earningsBusd: earningsBusd.toString(),
        count: numFarmsToCollect
    };
    let earningsText = t('%earningsBusd% to collect', data);
    if (numFarmsToCollect > 0 && hasCakePoolToCollect) {
        if (numFarmsToCollect > 1) {
            earningsText = t('%earningsBusd% to collect from %count% farms and CAKE pool', data);
        } else {
            earningsText = t('%earningsBusd% to collect from %count% farm and CAKE pool', data);
        }
    } else if (numFarmsToCollect > 0) {
        if (numFarmsToCollect > 1) {
            earningsText = t('%earningsBusd% to collect from %count% farms', data);
        } else {
            earningsText = t('%earningsBusd% to collect from %count% farm', data);
        }
    } else if (hasCakePoolToCollect) {
        earningsText = t('%earningsBusd% to collect from CAKE pool', data);
    }
    return earningsText;
};


/***/ }),

/***/ 98457:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var components_NextLink__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(53629);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(34215);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(bignumber_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(99150);
/* harmony import */ var state_farms_hooks__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8733);
/* harmony import */ var hooks_useToast__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(789);
/* harmony import */ var hooks_useContract__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(46063);
/* harmony import */ var utils_calls__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(50059);
/* harmony import */ var components_Balance__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(20922);
/* harmony import */ var components_Toast__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(63937);
/* harmony import */ var utils_sentry__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(17226);
/* harmony import */ var views_Home_hooks_useFarmsWithBalance__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(7600);
/* harmony import */ var _EarningsText__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(47979);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([state_farms_hooks__WEBPACK_IMPORTED_MODULE_7__, views_Home_hooks_useFarmsWithBalance__WEBPACK_IMPORTED_MODULE_14__]);
([state_farms_hooks__WEBPACK_IMPORTED_MODULE_7__, views_Home_hooks_useFarmsWithBalance__WEBPACK_IMPORTED_MODULE_14__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);
















const StyledCard = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Card).withConfig({
    componentId: "sc-def71db8-0"
})`
  width: 100%;
  height: fit-content;
`;
const HarvestCard = ()=>{
    const { 0: pendingTx , 1: setPendingTx  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_6__/* .useTranslation */ .$G)();
    const { toastSuccess , toastError  } = (0,hooks_useToast__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
    const { farmsWithStakedBalance , earningsSum: farmEarningsSum  } = (0,views_Home_hooks_useFarmsWithBalance__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z)();
    const masterChefContract = (0,hooks_useContract__WEBPACK_IMPORTED_MODULE_9__/* .useMasterchef */ .y8)();
    const cakePriceBusd = (0,state_farms_hooks__WEBPACK_IMPORTED_MODULE_7__/* .usePriceCakeBusd */ .Iu)();
    const earningsBusd = new (bignumber_js__WEBPACK_IMPORTED_MODULE_5___default())(farmEarningsSum).multipliedBy(cakePriceBusd);
    const numTotalToCollect = farmsWithStakedBalance.length;
    const numFarmsToCollect = farmsWithStakedBalance.filter((value)=>value.pid !== 0
    ).length;
    const hasCakePoolToCollect = numTotalToCollect - numFarmsToCollect > 0;
    const earningsText = (0,_EarningsText__WEBPACK_IMPORTED_MODULE_15__/* .getEarningsText */ .D)(numFarmsToCollect, hasCakePoolToCollect, earningsBusd, t);
    const [preText, toCollectText] = earningsText.split(earningsBusd.toString());
    const harvestAllFarms = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(async ()=>{
        setPendingTx(true);
        // eslint-disable-next-line no-restricted-syntax
        for (const farmWithBalance of farmsWithStakedBalance){
            try {
                // eslint-disable-next-line no-await-in-loop
                const tx = await (0,utils_calls__WEBPACK_IMPORTED_MODULE_10__/* .harvestFarm */ .sA)(masterChefContract, farmWithBalance.pid);
                toastSuccess(`${t('Transaction Submitted')}!`, /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_12__/* .ToastDescriptionWithTx */ .YO, {
                    txHash: tx.hash
                }));
                // eslint-disable-next-line no-await-in-loop
                const receipt = await tx.wait();
                if (receipt.status) {
                    toastSuccess(`${t('Harvested')}!`, /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_12__/* .ToastDescriptionWithTx */ .YO, {
                        txHash: receipt.transactionHash,
                        children: t('Your %symbol% earnings have been sent to your wallet!', {
                            symbol: 'CAKE'
                        })
                    }));
                } else {
                    toastError(t('Error'), /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_12__/* .ToastDescriptionWithTx */ .YO, {
                        txHash: receipt.transactionHash,
                        children: t('Please try again. Confirm the transaction and make sure you are paying enough gas!')
                    }));
                }
            } catch (error) {
                (0,utils_sentry__WEBPACK_IMPORTED_MODULE_13__/* .logError */ .H)(error);
                toastError(t('Error'), t('Please try again. Confirm the transaction and make sure you are paying enough gas!'));
            }
        }
        setPendingTx(false);
    }, [
        farmsWithStakedBalance,
        masterChefContract,
        toastSuccess,
        toastError,
        t
    ]);
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledCard, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.CardBody, {
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                flexDirection: [
                    'column',
                    null,
                    null,
                    'row'
                ],
                justifyContent: "space-between",
                alignItems: "center",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                        flexDirection: "column",
                        alignItems: [
                            'center',
                            null,
                            null,
                            'flex-start'
                        ],
                        children: [
                            preText && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                mb: "4px",
                                color: "textSubtle",
                                children: preText
                            }),
                            !earningsBusd.isNaN() ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                decimals: earningsBusd.gt(0) ? 2 : 0,
                                fontSize: "24px",
                                bold: true,
                                prefix: earningsBusd.gt(0) ? '~$' : '$',
                                lineHeight: "1.1",
                                value: earningsBusd.toNumber()
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Skeleton, {
                                width: 96,
                                height: 24,
                                my: "2px"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                mb: [
                                    '16px',
                                    null,
                                    null,
                                    '0'
                                ],
                                color: "textSubtle",
                                children: toCollectText
                            })
                        ]
                    }),
                    numTotalToCollect <= 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_NextLink__WEBPACK_IMPORTED_MODULE_4__/* .NextLinkFromReactRouter */ .a, {
                        to: "farms",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Button, {
                            width: [
                                '100%',
                                null,
                                null,
                                'auto'
                            ],
                            variant: "secondary",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                    color: "primary",
                                    bold: true,
                                    children: t('Start earning')
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.ArrowForwardIcon, {
                                    ml: "4px",
                                    color: "primary"
                                })
                            ]
                        })
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Button, {
                        width: [
                            '100%',
                            null,
                            null,
                            'auto'
                        ],
                        id: "harvest-all",
                        isLoading: pendingTx,
                        endIcon: pendingTx ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.AutoRenewIcon, {
                            spin: true,
                            color: "currentColor"
                        }) : null,
                        disabled: pendingTx,
                        onClick: harvestAllFarms,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                            color: "invertedContrast",
                            bold: true,
                            children: pendingTx ? t('Harvesting') : t('Harvest all')
                        })
                    })
                ]
            })
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HarvestCard);

});

/***/ }),

/***/ 26243:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(18054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var state_profile_hooks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(89424);
/* harmony import */ var components_ProfileAvatarWithTeam__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(78703);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(99150);
/* harmony import */ var utils_truncateHash__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(53467);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([state_profile_hooks__WEBPACK_IMPORTED_MODULE_5__]);
state_profile_hooks__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];









const Desktop = styled_components__WEBPACK_IMPORTED_MODULE_4___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex).withConfig({
    componentId: "sc-c9d512ef-0"
})`
  align-items: center;
  display: none;
  ${({ theme  })=>theme.mediaQueries.md
} {
    display: flex;
  }
`;
const Mobile = styled_components__WEBPACK_IMPORTED_MODULE_4___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex).withConfig({
    componentId: "sc-c9d512ef-1"
})`
  ${({ theme  })=>theme.mediaQueries.md
} {
    display: none;
  }
`;
const Sticker = styled_components__WEBPACK_IMPORTED_MODULE_4___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex).withConfig({
    componentId: "sc-c9d512ef-2"
})`
  height: 92px;
  width: 92px;
  background-color: ${({ theme  })=>theme.colors.invertedContrast
};
  border: 3px solid ${({ theme  })=>theme.colors.invertedContrast
};
  border-radius: ${({ theme  })=>theme.radii.circle
};
  box-shadow: ${({ theme  })=>theme.card.boxShadow
};
`;
const StyledNoProfileAvatarIcon = styled_components__WEBPACK_IMPORTED_MODULE_4___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.NoProfileAvatarIcon).withConfig({
    componentId: "sc-c9d512ef-3"
})`
  height: 100%;
  width: 100%;
`;
const UserDetail = ()=>{
    const { profile , isLoading  } = (0,state_profile_hooks__WEBPACK_IMPORTED_MODULE_5__/* .useProfile */ .Un)();
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_7__/* .useTranslation */ .$G)();
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_3__.useWeb3React)();
    const truncatedAddress = (0,utils_truncateHash__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)(account);
    const getDesktopHeading = ()=>{
        if (profile) {
            return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Heading, {
                scale: "xl",
                children: t('Hi, %userName%!', {
                    userName: profile.username
                })
            }));
        }
        if (isLoading && !profile) {
            return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Skeleton, {
                width: 200,
                height: 40,
                my: "4px"
            }));
        }
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}));
    };
    const getMobileHeading = ()=>{
        if (profile) {
            return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Heading, {
                mb: "18px",
                textAlign: "center",
                children: t('Hi, %userName%!', {
                    userName: profile.username
                })
            }));
        }
        if (isLoading && !profile) {
            return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Skeleton, {
                width: 120,
                height: 20,
                mt: "2px",
                mb: "18px"
            }));
        }
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}));
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Desktop, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Box, {
                        mr: "24px",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Sticker, {
                            children: profile ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_ProfileAvatarWithTeam__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                profile: profile
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledNoProfileAvatarIcon, {})
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        flexDirection: "column",
                        children: [
                            getDesktopHeading(),
                            isLoading || !account ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Skeleton, {
                                width: 160,
                                height: 16,
                                my: "4px"
                            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                fontSize: "16px",
                                children: [
                                    " ",
                                    t('Connected with %address%', {
                                        address: truncatedAddress
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Mobile, {
                children: getMobileHeading()
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (UserDetail);

});

/***/ }),

/***/ 51470:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _HarvestCard__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(98457);
/* harmony import */ var _UserDetail__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(26243);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_HarvestCard__WEBPACK_IMPORTED_MODULE_4__, _UserDetail__WEBPACK_IMPORTED_MODULE_5__]);
([_HarvestCard__WEBPACK_IMPORTED_MODULE_4__, _UserDetail__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);






const StyledCard = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Box).withConfig({
    componentId: "sc-814c0d0d-0"
})`
  border-bottom: 1px ${({ theme  })=>theme.colors.secondary
} solid;
  border-left: 1px ${({ theme  })=>theme.colors.secondary
} solid;
  border-right: 1px ${({ theme  })=>theme.colors.secondary
} solid;
  border-radius: ${({ theme  })=>`0 0 ${theme.radii.card} ${theme.radii.card}`
};
  background: ${({ theme  })=>theme.isDark ? 'linear-gradient(360deg, rgba(49, 61, 92, 0.9) 0%, rgba(61, 42, 84, 0.9) 100%)' : 'linear-gradient(180deg, rgba(202, 194, 236, 0.9) 0%,  rgba(204, 220, 239, 0.9) 51.04%, rgba(206, 236, 243, 0.9) 100%)'
};
`;
const UserBanner = ()=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledCard, {
        p: [
            '16px',
            null,
            null,
            '24px'
        ],
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
            alignItems: "center",
            justifyContent: "center",
            flexDirection: [
                'column',
                null,
                null,
                'row'
            ],
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                    flex: "1",
                    mr: [
                        null,
                        null,
                        null,
                        '32px'
                    ],
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UserDetail__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                    flex: "1",
                    width: [
                        '100%',
                        null,
                        'auto'
                    ],
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_HarvestCard__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (UserBanner);

});

/***/ }),

/***/ 34191:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "vx": () => (/* binding */ OuterWedgeWrapper),
/* harmony export */   "N5": () => (/* binding */ InnerWedgeWrapper),
/* harmony export */   "UK": () => (/* binding */ WedgeTopLeft),
/* harmony export */   "SH": () => (/* binding */ WedgeTopRight)
/* harmony export */ });
/* unused harmony exports WedgeBottomRight, WedgeBottomLeft */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);




const OuterWedgeWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-c02a4df3-0"
})`
  z-index: -1;
  overflow: hidden;
  position: absolute;
  width: 100%;
  height: 100%;
  right: 0px;
  top: 0px;
`;
const InnerWedgeWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-c02a4df3-1"
})`
  position: absolute;
  display: flex;
  width: 100%;
  ${({ top  })=>top ? 'top: 0px' : 'bottom: 0px'
};

  svg {
    fill: ${({ fill  })=>fill
};
    width: ${({ width  })=>width || '100%'
};
    height: 100%;
    max-height: 48px;
  }
`;
const WedgeTopLeft = (props)=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Svg, {
        viewBox: "0 0 1660 48",
        ...props,
        preserveAspectRatio: "none",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            d: "M1660 48C1139.02 46.1887 336.256 15.2453 0 0H1660V48Z"
        })
    }));
};
const WedgeTopRight = (props)=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Svg, {
        viewBox: "0 0 1660 48",
        ...props,
        preserveAspectRatio: "none",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            d: "M-346 48C174.985 46.1887 977.744 15.2453 1314 0H-346V48Z"
        })
    }));
};
const WedgeBottomRight = (props)=>{
    return(/*#__PURE__*/ _jsx(Svg, {
        viewBox: "0 0 1660 48",
        ...props,
        preserveAspectRatio: "none",
        children: /*#__PURE__*/ _jsx("path", {
            d: "M0 0C520.985 1.81132 1323.74 32.7547 1660 48H0V0Z"
        })
    }));
};
const WedgeBottomLeft = (props)=>{
    return(/*#__PURE__*/ _jsx(Svg, {
        viewBox: "0 0 1660 48",
        ...props,
        preserveAspectRatio: "none",
        children: /*#__PURE__*/ _jsx("path", {
            d: "M1660 0C1139.02 1.81132 336.256 32.7547 0 48H1660V0Z"
        })
    }));
};


/***/ }),

/***/ 26775:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var components_NextLink__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(53629);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99150);
/* harmony import */ var hooks_useIntersectionObserver__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(76538);
/* harmony import */ var state_farms_hooks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8733);
/* harmony import */ var components_Balance__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(20922);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var state_lottery_helpers__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(60816);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(34215);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(bignumber_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var utils_formatBalance__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(65044);
/* harmony import */ var hooks_useRefreshEffect__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(27892);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks_useRefreshEffect__WEBPACK_IMPORTED_MODULE_12__, state_farms_hooks__WEBPACK_IMPORTED_MODULE_6__]);
([hooks_useRefreshEffect__WEBPACK_IMPORTED_MODULE_12__, state_farms_hooks__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);













const StyledLink = styled_components__WEBPACK_IMPORTED_MODULE_8___default()(components_NextLink__WEBPACK_IMPORTED_MODULE_3__/* .NextLinkFromReactRouter */ .a).withConfig({
    componentId: "sc-9066ffe5-0"
})`
  width: 100%;
`;
const StyledBalance = styled_components__WEBPACK_IMPORTED_MODULE_8___default()(components_Balance__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z).withConfig({
    componentId: "sc-9066ffe5-1"
})`
  background: ${({ theme  })=>theme.colors.gradients.gold
};
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
`;
const LotteryCardContent = ()=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    const { observerRef , isIntersecting  } = (0,hooks_useIntersectionObserver__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)();
    const { 0: loadData , 1: setLoadData  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: lotteryId , 1: setLotteryId  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: currentLotteryPrize , 1: setCurrentLotteryPrize  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const cakePriceBusdAsString = (0,state_farms_hooks__WEBPACK_IMPORTED_MODULE_6__/* .usePriceCakeBusd */ .Iu)().toString();
    const cakePrizesText = t('%cakePrizeInUsd% in CAKE prizes this round', {
        cakePrizeInUsd: cakePriceBusdAsString
    });
    const [pretext, prizesThisRound] = cakePrizesText.split(cakePriceBusdAsString);
    const cakePriceBusd = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        return new (bignumber_js__WEBPACK_IMPORTED_MODULE_10___default())(cakePriceBusdAsString);
    }, [
        cakePriceBusdAsString
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (isIntersecting) {
            setLoadData(true);
        }
    }, [
        isIntersecting
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        // get current lottery ID
        const fetchCurrentID = async ()=>{
            const { currentLotteryId  } = await (0,state_lottery_helpers__WEBPACK_IMPORTED_MODULE_9__/* .fetchCurrentLotteryIdAndMaxBuy */ .xT)();
            setLotteryId(currentLotteryId);
        };
        if (loadData) {
            fetchCurrentID();
        }
    }, [
        loadData,
        setLotteryId
    ]);
    (0,hooks_useRefreshEffect__WEBPACK_IMPORTED_MODULE_12__/* .useSlowRefreshEffect */ .X)(()=>{
        // get public data for current lottery
        const fetchCurrentLotteryPrize = async ()=>{
            const { amountCollectedInCake  } = await (0,state_lottery_helpers__WEBPACK_IMPORTED_MODULE_9__/* .fetchLottery */ .JE)(lotteryId);
            const prizeInBusd = cakePriceBusd.times(amountCollectedInCake);
            setCurrentLotteryPrize(prizeInBusd);
        };
        if (lotteryId) {
            fetchCurrentLotteryPrize();
        }
    }, [
        lotteryId,
        setCurrentLotteryPrize,
        cakePriceBusd
    ]);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                flexDirection: "column",
                mt: "48px",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        color: "white",
                        bold: true,
                        fontSize: "16px",
                        children: t('Lottery')
                    }),
                    pretext && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        color: "white",
                        mt: "12px",
                        bold: true,
                        fontSize: "16px",
                        children: pretext
                    }),
                    currentLotteryPrize && currentLotteryPrize.gt(0) ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledBalance, {
                        fontSize: "40px",
                        bold: true,
                        prefix: "$",
                        decimals: 0,
                        value: (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_11__/* .getBalanceAmount */ .U4)(currentLotteryPrize).toNumber()
                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Skeleton, {
                                width: 200,
                                height: 40,
                                my: "8px"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                ref: observerRef
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        color: "white",
                        mb: "24px",
                        bold: true,
                        fontSize: "16px",
                        children: prizesThisRound
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        color: "white",
                        mb: "40px",
                        children: t('Buy tickets with CAKE, win CAKE if your numbers match')
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                alignItems: "center",
                justifyContent: "center",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledLink, {
                    to: "/lottery",
                    id: "homepage-prediction-cta",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                        width: "100%",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                bold: true,
                                color: "invertedContrast",
                                children: t('Buy Tickets')
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.ArrowForwardIcon, {
                                ml: "4px",
                                color: "invertedContrast"
                            })
                        ]
                    })
                })
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LotteryCardContent);

});

/***/ }),

/***/ 85480:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var components_NextLink__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(53629);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(99150);
/* harmony import */ var utils_formatBalance__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(65044);
/* harmony import */ var hooks_useIntersectionObserver__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(76538);
/* harmony import */ var state_predictions_helpers__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(88925);
/* harmony import */ var hooks_useBUSDPrice__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(90834);
/* harmony import */ var utils_prices__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7879);
/* harmony import */ var hooks_useRefreshEffect__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(27892);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks_useRefreshEffect__WEBPACK_IMPORTED_MODULE_11__, hooks_useBUSDPrice__WEBPACK_IMPORTED_MODULE_9__]);
([hooks_useRefreshEffect__WEBPACK_IMPORTED_MODULE_11__, hooks_useBUSDPrice__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);












const StyledLink = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(components_NextLink__WEBPACK_IMPORTED_MODULE_4__/* .NextLinkFromReactRouter */ .a).withConfig({
    componentId: "sc-f767c881-0"
})`
  width: 100%;
`;
const PredictionCardContent = ()=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_5__/* .useTranslation */ .$G)();
    const { observerRef , isIntersecting  } = (0,hooks_useIntersectionObserver__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
    const { 0: loadData , 1: setLoadData  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const bnbBusdPrice = (0,hooks_useBUSDPrice__WEBPACK_IMPORTED_MODULE_9__/* .useBNBBusdPrice */ .Hf)();
    const { 0: bnbWon , 1: setBnbWon  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const bnbWonInUsd = (0,utils_prices__WEBPACK_IMPORTED_MODULE_10__/* .multiplyPriceByAmount */ .as)(bnbBusdPrice, bnbWon);
    const localisedBnbUsdString = (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_6__/* .formatLocalisedCompactNumber */ .uI)(bnbWonInUsd);
    const bnbWonText = t('$%bnbWonInUsd% in BNB won so far', {
        bnbWonInUsd: localisedBnbUsdString
    });
    const [pretext, wonSoFar] = bnbWonText.split(localisedBnbUsdString);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (isIntersecting) {
            setLoadData(true);
        }
    }, [
        isIntersecting
    ]);
    (0,hooks_useRefreshEffect__WEBPACK_IMPORTED_MODULE_11__/* .useSlowRefreshEffect */ .X)(()=>{
        const fetchMarketData = async ()=>{
            const totalWon = await (0,state_predictions_helpers__WEBPACK_IMPORTED_MODULE_8__/* .getTotalWon */ .yn)();
            setBnbWon(totalWon);
        };
        if (loadData) {
            fetchMarketData();
        }
    }, [
        loadData
    ]);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                flexDirection: "column",
                mt: "48px",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                        color: "#280D5F",
                        bold: true,
                        fontSize: "16px",
                        children: t('Prediction')
                    }),
                    bnbWonInUsd ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Heading, {
                        color: "#280D5F",
                        my: "8px",
                        scale: "xl",
                        bold: true,
                        children: [
                            pretext,
                            localisedBnbUsdString
                        ]
                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Skeleton, {
                                width: 230,
                                height: 40,
                                my: "8px"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                ref: observerRef
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                        color: "#280D5F",
                        mb: "24px",
                        bold: true,
                        fontSize: "16px",
                        children: wonSoFar
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                        color: "#280D5F",
                        mb: "40px",
                        children: t('Will BNB price rise or fall? guess correctly to win!')
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                alignItems: "center",
                justifyContent: "center",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledLink, {
                    to: "/prediction",
                    id: "homepage-prediction-cta",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Button, {
                        width: "100%",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                bold: true,
                                color: "invertedContrast",
                                children: t('Play')
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.ArrowForwardIcon, {
                                ml: "4px",
                                color: "invertedContrast"
                            })
                        ]
                    })
                })
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PredictionCardContent);

});

/***/ }),

/***/ 26465:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99150);
/* harmony import */ var hooks_useTheme__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(23917);
/* harmony import */ var _ColoredWordHeading__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(87927);
/* harmony import */ var _IconCard__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(20923);
/* harmony import */ var _PredictionCardContent__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(85480);
/* harmony import */ var _LotteryCardContent__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(26775);
/* harmony import */ var _CompositeImage__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(10413);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_LotteryCardContent__WEBPACK_IMPORTED_MODULE_9__, _PredictionCardContent__WEBPACK_IMPORTED_MODULE_8__, _ColoredWordHeading__WEBPACK_IMPORTED_MODULE_6__, hooks_useTheme__WEBPACK_IMPORTED_MODULE_5__]);
([_LotteryCardContent__WEBPACK_IMPORTED_MODULE_9__, _PredictionCardContent__WEBPACK_IMPORTED_MODULE_8__, _ColoredWordHeading__WEBPACK_IMPORTED_MODULE_6__, hooks_useTheme__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);











const TransparentFrame = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-26f26a8e-0"
})`
  background: ${({ theme  })=>theme.isDark ? 'rgba(8, 6, 11, 0.6)' : ' rgba(255, 255, 255, 0.6)'
};
  padding: 16px;
  border: 1px solid ${({ theme  })=>theme.colors.cardBorder
};
  box-sizing: border-box;
  backdrop-filter: blur(12px);
  border-radius: 72px;

  ${({ theme  })=>theme.mediaQueries.md
} {
    padding: 40px;
  }
`;
const BgWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-26f26a8e-1"
})`
  z-index: -1;
  overflow: hidden;
  position: absolute;
  width: 100%;
  height: 100%;
  top: 0px;
  left: 0px;
`;
const BottomLeftImgWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex).withConfig({
    componentId: "sc-26f26a8e-2"
})`
  position: absolute;
  left: 0;
  bottom: -64px;
  max-width: 192px;

  ${({ theme  })=>theme.mediaQueries.md
} {
    max-width: 100%;
  }
`;
const TopRightImgWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex).withConfig({
    componentId: "sc-26f26a8e-3"
})`
  position: absolute;
  right: 0;
  top: -64px;

  max-width: 192px;

  ${({ theme  })=>theme.mediaQueries.md
} {
    max-width: 100%;
  }
`;
const PredictionCardData = {
    icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.PredictionsIcon, {
        width: "36px",
        color: "inverseContrast"
    }),
    background: 'linear-gradient(180deg, #ffb237 0%, #ffcd51 51.17%, #ffe76a 100%);',
    borderColor: '#ffb237',
    rotation: '-2.36deg'
};
const LotteryCardData = {
    icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.TicketFillIcon, {
        color: "white",
        width: "36px"
    }),
    background: ' linear-gradient(180deg, #7645D9 0%, #5121B1 100%);',
    borderColor: '#3C1786',
    rotation: '1.43deg'
};
const bottomLeftImage = {
    path: '/images/home/prediction-cards/',
    attributes: [
        {
            src: 'bottom-left',
            alt: 'CAKE card'
        },
        {
            src: 'green',
            alt: 'Green CAKE card with up arrow'
        },
        {
            src: 'red',
            alt: 'Red Cake card with down arrow'
        },
        {
            src: 'top-right',
            alt: 'CAKE card'
        }, 
    ]
};
const topRightImage = {
    path: '/images/home/lottery-balls/',
    attributes: [
        {
            src: '2',
            alt: 'Lottery ball number 2'
        },
        {
            src: '4',
            alt: 'Lottery ball number 4'
        },
        {
            src: '6',
            alt: 'Lottery ball number 6'
        },
        {
            src: '7',
            alt: 'Lottery ball number 7'
        },
        {
            src: '9',
            alt: 'Lottery ball number 9'
        }, 
    ]
};
const WinSection = ()=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    const { theme  } = (0,hooks_useTheme__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)();
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(BgWrapper, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(BottomLeftImgWrapper, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CompositeImage__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .ZP, {
                            ...bottomLeftImage
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TopRightImgWrapper, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CompositeImage__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .ZP, {
                            ...topRightImage
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TransparentFrame, {
                isDark: theme.isDark,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                    flexDirection: "column",
                    alignItems: "center",
                    justifyContent: "center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ColoredWordHeading__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                            textAlign: "center",
                            text: t('Win millions in prizes')
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                            color: "textSubtle",
                            children: t('Provably fair, on-chain games.')
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                            mb: "40px",
                            color: "textSubtle",
                            children: t('Win big with PancakeSwap.')
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                            m: "0 auto",
                            flexDirection: [
                                'column',
                                null,
                                null,
                                'row'
                            ],
                            maxWidth: "600px",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                                    flex: "1",
                                    maxWidth: [
                                        '275px',
                                        null,
                                        null,
                                        '100%'
                                    ],
                                    mr: [
                                        null,
                                        null,
                                        null,
                                        '24px'
                                    ],
                                    mb: [
                                        '32px',
                                        null,
                                        null,
                                        '0'
                                    ],
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IconCard__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                        ...PredictionCardData,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PredictionCardContent__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {})
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                                    flex: "1",
                                    maxWidth: [
                                        '275px',
                                        null,
                                        null,
                                        '100%'
                                    ],
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IconCard__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                        ...LotteryCardData,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_LotteryCardContent__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {})
                                    })
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WinSection);

});

/***/ }),

/***/ 7600:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(34215);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(bignumber_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(18054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var utils_multicall__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(41144);
/* harmony import */ var utils_addressHelpers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(55878);
/* harmony import */ var config_abi_masterchef_json__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(84951);
/* harmony import */ var config_constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3862);
/* harmony import */ var config__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(33206);
/* harmony import */ var hooks_useRefreshEffect__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(27892);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks_useRefreshEffect__WEBPACK_IMPORTED_MODULE_8__]);
hooks_useRefreshEffect__WEBPACK_IMPORTED_MODULE_8__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];









const useFarmsWithBalance = ()=>{
    const { 0: farmsWithStakedBalance , 1: setFarmsWithStakedBalance  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const { 0: earningsSum , 1: setEarningsSum  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_2__.useWeb3React)();
    (0,hooks_useRefreshEffect__WEBPACK_IMPORTED_MODULE_8__/* .useFastRefreshEffect */ .a)(()=>{
        const fetchBalances = async ()=>{
            const calls = config_constants__WEBPACK_IMPORTED_MODULE_6__/* .farmsConfig.map */ .jt.map((farm)=>({
                    address: (0,utils_addressHelpers__WEBPACK_IMPORTED_MODULE_4__/* .getMasterChefAddress */ .Oc)(),
                    name: 'pendingCake',
                    params: [
                        farm.pid,
                        account
                    ]
                })
            );
            const rawResults = await (0,utils_multicall__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)(config_abi_masterchef_json__WEBPACK_IMPORTED_MODULE_5__, calls);
            const results = config_constants__WEBPACK_IMPORTED_MODULE_6__/* .farmsConfig.map */ .jt.map((farm, index)=>({
                    ...farm,
                    balance: new (bignumber_js__WEBPACK_IMPORTED_MODULE_1___default())(rawResults[index])
                })
            );
            const farmsWithBalances = results.filter((balanceType)=>balanceType.balance.gt(0)
            );
            const totalEarned = farmsWithBalances.reduce((accum, earning)=>{
                const earningNumber = new (bignumber_js__WEBPACK_IMPORTED_MODULE_1___default())(earning.balance);
                if (earningNumber.eq(0)) {
                    return accum;
                }
                return accum + earningNumber.div(config__WEBPACK_IMPORTED_MODULE_7__/* .DEFAULT_TOKEN_DECIMAL */ .o3).toNumber();
            }, 0);
            setFarmsWithStakedBalance(farmsWithBalances);
            setEarningsSum(totalEarned);
        };
        if (account) {
            fetchBalances();
        }
    }, [
        account
    ]);
    return {
        farmsWithStakedBalance,
        earningsSum
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useFarmsWithBalance);

});

/***/ }),

/***/ 4727:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(42877);
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var state_farms_hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8733);
/* harmony import */ var state__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(82727);
/* harmony import */ var state_farms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(66319);
/* harmony import */ var utils_apr__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(28668);
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(49949);
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(lodash_orderBy__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var config_constants_types__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(97971);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([state_farms_hooks__WEBPACK_IMPORTED_MODULE_2__]);
state_farms_hooks__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];








const useGetTopFarmsByApr = (isIntersecting)=>{
    const dispatch = (0,state__WEBPACK_IMPORTED_MODULE_3__/* .useAppDispatch */ .TL)();
    const { data: farms  } = (0,state_farms_hooks__WEBPACK_IMPORTED_MODULE_2__/* .useFarms */ .E2)();
    const { 0: fetchStatus , 1: setFetchStatus  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(config_constants_types__WEBPACK_IMPORTED_MODULE_7__/* .FetchStatus.Idle */ .iF.Idle);
    const { 0: topFarms , 1: setTopFarms  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([
        null,
        null,
        null,
        null,
        null
    ]);
    const cakePriceBusd = (0,state_farms_hooks__WEBPACK_IMPORTED_MODULE_2__/* .usePriceCakeBusd */ .Iu)();
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        const fetchFarmData = async ()=>{
            setFetchStatus(config_constants_types__WEBPACK_IMPORTED_MODULE_7__/* .FetchStatus.Fetching */ .iF.Fetching);
            const activeFarms = state_farms__WEBPACK_IMPORTED_MODULE_4__/* .nonArchivedFarms.filter */ .ck.filter((farm)=>farm.pid !== 0
            );
            try {
                await dispatch((0,state_farms__WEBPACK_IMPORTED_MODULE_4__/* .fetchFarmsPublicDataAsync */ .eG)(activeFarms.map((farm)=>farm.pid
                )));
                setFetchStatus(config_constants_types__WEBPACK_IMPORTED_MODULE_7__/* .FetchStatus.Fetched */ .iF.Fetched);
            } catch (e) {
                console.error(e);
                setFetchStatus(config_constants_types__WEBPACK_IMPORTED_MODULE_7__/* .FetchStatus.Failed */ .iF.Failed);
            }
        };
        if (isIntersecting && fetchStatus === config_constants_types__WEBPACK_IMPORTED_MODULE_7__/* .FetchStatus.Idle */ .iF.Idle) {
            fetchFarmData();
        }
    }, [
        dispatch,
        setFetchStatus,
        fetchStatus,
        topFarms,
        isIntersecting
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        const getTopFarmsByApr = (farmsState)=>{
            const farmsWithPrices = farmsState.filter((farm)=>farm.lpTotalInQuoteToken && farm.quoteTokenPriceBusd && farm.pid !== 0 && farm.multiplier && farm.multiplier !== '0X'
            );
            const farmsWithApr = farmsWithPrices.map((farm)=>{
                const totalLiquidity = farm.lpTotalInQuoteToken.times(farm.quoteTokenPriceBusd);
                const { cakeRewardsApr , lpRewardsApr  } = (0,utils_apr__WEBPACK_IMPORTED_MODULE_5__/* .getFarmApr */ .yW)(farm.poolWeight, cakePriceBusd, totalLiquidity, farm.lpAddresses[_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MAINNET]);
                return {
                    ...farm,
                    apr: cakeRewardsApr,
                    lpRewardsApr
                };
            });
            const sortedByApr = lodash_orderBy__WEBPACK_IMPORTED_MODULE_6___default()(farmsWithApr, (farm)=>farm.apr + farm.lpRewardsApr
            , 'desc');
            setTopFarms(sortedByApr.slice(0, 5));
        };
        if (fetchStatus === config_constants_types__WEBPACK_IMPORTED_MODULE_7__/* .FetchStatus.Fetched */ .iF.Fetched && !topFarms[0]) {
            getTopFarmsByApr(farms);
        }
    }, [
        setTopFarms,
        farms,
        fetchStatus,
        cakePriceBusd,
        topFarms
    ]);
    return {
        topFarms
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useGetTopFarmsByApr);

});

/***/ }),

/***/ 91061:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var components_PageSection__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(67512);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(18054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var hooks_useTheme__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(23917);
/* harmony import */ var components_Layout_Container__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(55027);
/* harmony import */ var components_Layout_Page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9770);
/* harmony import */ var _components_Hero__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(12851);
/* harmony import */ var _components_SalesSection_data__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(98463);
/* harmony import */ var _components_MetricsSection__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(44899);
/* harmony import */ var _components_SalesSection__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(49804);
/* harmony import */ var _components_WinSection__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(26465);
/* harmony import */ var _components_FarmsPoolsRow__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(77956);
/* harmony import */ var _components_Footer__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(26408);
/* harmony import */ var _components_CakeDataRow__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(44964);
/* harmony import */ var _components_WedgeSvgs__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(34191);
/* harmony import */ var _components_UserBanner__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(51470);
/* harmony import */ var _components_Banners_FarmAuctionsBanner__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(43237);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_CakeDataRow__WEBPACK_IMPORTED_MODULE_16__, _components_SalesSection__WEBPACK_IMPORTED_MODULE_12__, _components_WinSection__WEBPACK_IMPORTED_MODULE_13__, _components_FarmsPoolsRow__WEBPACK_IMPORTED_MODULE_14__, _components_MetricsSection__WEBPACK_IMPORTED_MODULE_11__, _components_Hero__WEBPACK_IMPORTED_MODULE_9__, _components_UserBanner__WEBPACK_IMPORTED_MODULE_18__, components_Layout_Page__WEBPACK_IMPORTED_MODULE_8__, hooks_useTheme__WEBPACK_IMPORTED_MODULE_6__]);
([_components_CakeDataRow__WEBPACK_IMPORTED_MODULE_16__, _components_SalesSection__WEBPACK_IMPORTED_MODULE_12__, _components_WinSection__WEBPACK_IMPORTED_MODULE_13__, _components_FarmsPoolsRow__WEBPACK_IMPORTED_MODULE_14__, _components_MetricsSection__WEBPACK_IMPORTED_MODULE_11__, _components_Hero__WEBPACK_IMPORTED_MODULE_9__, _components_UserBanner__WEBPACK_IMPORTED_MODULE_18__, components_Layout_Page__WEBPACK_IMPORTED_MODULE_8__, hooks_useTheme__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);




















const showBanner = false;
const HomeBanner = ({ account  })=>{
    if (!showBanner) {
        return null;
    }
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
        pt: [
            account ? '220px' : '0',
            null,
            null,
            account ? '76px' : '0'
        ],
        mt: [
            account ? '0' : '-16px',
            null,
            null,
            account ? '0' : '-48px'
        ],
        pb: "24px",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Banners_FarmAuctionsBanner__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z, {})
    }));
};
const StyledHeroSection = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(components_PageSection__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z).withConfig({
    componentId: "sc-f4511543-0"
})`
  padding-top: 16px;

  ${({ theme  })=>theme.mediaQueries.md
} {
    padding-top: 48px;
  }
`;
const UserBannerWrapper = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(components_Layout_Container__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z).withConfig({
    componentId: "sc-f4511543-1"
})`
  z-index: 1;
  position: absolute;
  width: 100%;
  top: 0;
  left: 50%;
  transform: translate(-50%, 0);
  padding-left: 0px;
  padding-right: 0px;

  ${({ theme  })=>theme.mediaQueries.lg
} {
    padding-left: 24px;
    padding-right: 24px;
  }
`;
const Home = ()=>{
    const { theme  } = (0,hooks_useTheme__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)();
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_5__.useWeb3React)();
    const HomeSectionContainerStyles = {
        margin: '0',
        width: '100%',
        maxWidth: '968px'
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Layout_Page__WEBPACK_IMPORTED_MODULE_8__/* .PageMeta */ .V, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(StyledHeroSection, {
                innerProps: {
                    style: {
                        margin: '0',
                        width: '100%'
                    }
                },
                background: theme.isDark ? 'radial-gradient(103.12% 50% at 50% 50%, #21193A 0%, #191326 100%)' : 'linear-gradient(139.73deg, #E6FDFF 0%, #F3EFFF 100%)',
                index: 2,
                hasCurvedDivider: false,
                children: [
                    account && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(UserBannerWrapper, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_UserBanner__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(HomeBanner, {
                        account: account
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Hero__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {})
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_PageSection__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                innerProps: {
                    style: {
                        margin: '0',
                        width: '100%'
                    }
                },
                background: theme.isDark ? 'linear-gradient(180deg, #09070C 22%, #201335 100%)' : 'linear-gradient(180deg, #FFFFFF 22%, #D7CAEC 100%)',
                index: 2,
                hasCurvedDivider: false,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_MetricsSection__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {})
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(components_PageSection__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                innerProps: {
                    style: HomeSectionContainerStyles
                },
                background: theme.colors.background,
                index: 2,
                hasCurvedDivider: false,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_WedgeSvgs__WEBPACK_IMPORTED_MODULE_17__/* .OuterWedgeWrapper */ .vx, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_WedgeSvgs__WEBPACK_IMPORTED_MODULE_17__/* .InnerWedgeWrapper */ .N5, {
                            top: true,
                            fill: theme.isDark ? '#201335' : '#D8CBED',
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_WedgeSvgs__WEBPACK_IMPORTED_MODULE_17__/* .WedgeTopLeft */ .UK, {})
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_SalesSection__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                        ..._components_SalesSection_data__WEBPACK_IMPORTED_MODULE_10__/* .swapSectionData */ .hk
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(components_PageSection__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                innerProps: {
                    style: HomeSectionContainerStyles
                },
                background: theme.colors.gradients.cardHeader,
                index: 2,
                hasCurvedDivider: false,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_WedgeSvgs__WEBPACK_IMPORTED_MODULE_17__/* .OuterWedgeWrapper */ .vx, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_WedgeSvgs__WEBPACK_IMPORTED_MODULE_17__/* .InnerWedgeWrapper */ .N5, {
                            width: "150%",
                            top: true,
                            fill: theme.colors.background,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_WedgeSvgs__WEBPACK_IMPORTED_MODULE_17__/* .WedgeTopRight */ .SH, {})
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_SalesSection__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                        ..._components_SalesSection_data__WEBPACK_IMPORTED_MODULE_10__/* .earnSectionData */ .pH
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FarmsPoolsRow__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {})
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_PageSection__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                innerProps: {
                    style: HomeSectionContainerStyles
                },
                background: theme.isDark ? 'linear-gradient(180deg, #0B4576 0%, #091115 100%)' : 'linear-gradient(180deg, #6FB6F1 0%, #EAF2F6 100%)',
                index: 2,
                hasCurvedDivider: false,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_WinSection__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {})
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(components_PageSection__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                innerProps: {
                    style: HomeSectionContainerStyles
                },
                background: theme.colors.background,
                index: 2,
                hasCurvedDivider: false,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_SalesSection__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                        ..._components_SalesSection_data__WEBPACK_IMPORTED_MODULE_10__/* .cakeSectionData */ .Tu
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_CakeDataRow__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {})
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_PageSection__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                innerProps: {
                    style: HomeSectionContainerStyles
                },
                background: "linear-gradient(180deg, #7645D9 0%, #5121B1 100%)",
                index: 2,
                hasCurvedDivider: false,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Footer__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {})
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Home);

});

/***/ }),

/***/ 68454:
/***/ ((module) => {

module.exports = require("@binance-chain/bsc-connector");

/***/ }),

/***/ 6187:
/***/ ((module) => {

module.exports = require("@ethersproject/abi");

/***/ }),

/***/ 51541:
/***/ ((module) => {

module.exports = require("@ethersproject/address");

/***/ }),

/***/ 65757:
/***/ ((module) => {

module.exports = require("@ethersproject/bignumber");

/***/ }),

/***/ 49935:
/***/ ((module) => {

module.exports = require("@ethersproject/bytes");

/***/ }),

/***/ 26644:
/***/ ((module) => {

module.exports = require("@ethersproject/constants");

/***/ }),

/***/ 12792:
/***/ ((module) => {

module.exports = require("@ethersproject/contracts");

/***/ }),

/***/ 40750:
/***/ ((module) => {

module.exports = require("@ethersproject/hash");

/***/ }),

/***/ 90399:
/***/ ((module) => {

module.exports = require("@ethersproject/providers");

/***/ }),

/***/ 49213:
/***/ ((module) => {

module.exports = require("@ethersproject/strings");

/***/ }),

/***/ 93138:
/***/ ((module) => {

module.exports = require("@ethersproject/units");

/***/ }),

/***/ 42877:
/***/ ((module) => {

module.exports = require("@mdemouchy/sdk");

/***/ }),

/***/ 85360:
/***/ ((module) => {

module.exports = require("@next/env");

/***/ }),

/***/ 2829:
/***/ ((module) => {

module.exports = require("@pancakeswap/uikit");

/***/ }),

/***/ 75184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 58097:
/***/ ((module) => {

module.exports = require("@sentry/nextjs");

/***/ }),

/***/ 15427:
/***/ ((module) => {

module.exports = require("@sentry/react");

/***/ }),

/***/ 7248:
/***/ ((module) => {

module.exports = require("@snapshot-labs/snapshot.js");

/***/ }),

/***/ 51554:
/***/ ((module) => {

module.exports = require("@uniswap/token-lists");

/***/ }),

/***/ 18054:
/***/ ((module) => {

module.exports = require("@web3-react/core");

/***/ }),

/***/ 76590:
/***/ ((module) => {

module.exports = require("@web3-react/injected-connector");

/***/ }),

/***/ 9795:
/***/ ((module) => {

module.exports = require("@web3-react/walletconnect-connector");

/***/ }),

/***/ 75888:
/***/ ((module) => {

module.exports = require("ajv");

/***/ }),

/***/ 34215:
/***/ ((module) => {

module.exports = require("bignumber.js");

/***/ }),

/***/ 10899:
/***/ ((module) => {

module.exports = require("bignumber.js/bignumber");

/***/ }),

/***/ 18729:
/***/ ((module) => {

module.exports = require("cids");

/***/ }),

/***/ 74146:
/***/ ((module) => {

module.exports = require("date-fns");

/***/ }),

/***/ 64175:
/***/ ((module) => {

module.exports = require("fast-json-stable-stringify");

/***/ }),

/***/ 5805:
/***/ ((module) => {

module.exports = require("graphql-request");

/***/ }),

/***/ 90221:
/***/ ((module) => {

module.exports = require("lodash/chunk");

/***/ }),

/***/ 38190:
/***/ ((module) => {

module.exports = require("lodash/flatMap");

/***/ }),

/***/ 58579:
/***/ ((module) => {

module.exports = require("lodash/flatten");

/***/ }),

/***/ 1712:
/***/ ((module) => {

module.exports = require("lodash/get");

/***/ }),

/***/ 51546:
/***/ ((module) => {

module.exports = require("lodash/kebabCase");

/***/ }),

/***/ 63385:
/***/ ((module) => {

module.exports = require("lodash/keyBy");

/***/ }),

/***/ 11341:
/***/ ((module) => {

module.exports = require("lodash/maxBy");

/***/ }),

/***/ 61831:
/***/ ((module) => {

module.exports = require("lodash/merge");

/***/ }),

/***/ 49949:
/***/ ((module) => {

module.exports = require("lodash/orderBy");

/***/ }),

/***/ 64042:
/***/ ((module) => {

module.exports = require("lodash/range");

/***/ }),

/***/ 47657:
/***/ ((module) => {

module.exports = require("lodash/sample");

/***/ }),

/***/ 4354:
/***/ ((module) => {

module.exports = require("lodash/times");

/***/ }),

/***/ 16677:
/***/ ((module) => {

module.exports = require("multicodec");

/***/ }),

/***/ 63735:
/***/ ((module) => {

module.exports = require("multihashes");

/***/ }),

/***/ 54426:
/***/ ((module) => {

module.exports = require("next/dist/compiled/chalk");

/***/ }),

/***/ 40252:
/***/ ((module) => {

module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 19371:
/***/ ((module) => {

module.exports = require("next/dist/compiled/node-fetch");

/***/ }),

/***/ 97999:
/***/ ((module) => {

module.exports = require("next/dist/compiled/path-to-regexp");

/***/ }),

/***/ 60600:
/***/ ((module) => {

module.exports = require("next/dist/server/accept-header.js");

/***/ }),

/***/ 18612:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils.js");

/***/ }),

/***/ 60562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 94140:
/***/ ((module) => {

module.exports = require("next/dist/server/get-page-files.js");

/***/ }),

/***/ 89716:
/***/ ((module) => {

module.exports = require("next/dist/server/htmlescape.js");

/***/ }),

/***/ 25071:
/***/ ((module) => {

module.exports = require("next/dist/server/render-result.js");

/***/ }),

/***/ 33100:
/***/ ((module) => {

module.exports = require("next/dist/server/render.js");

/***/ }),

/***/ 92779:
/***/ ((module) => {

module.exports = require("next/dist/server/request-meta.js");

/***/ }),

/***/ 79502:
/***/ ((module) => {

module.exports = require("next/dist/server/send-payload.js");

/***/ }),

/***/ 76368:
/***/ ((module) => {

module.exports = require("next/dist/server/utils.js");

/***/ }),

/***/ 56724:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 27664:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/escape-regexp.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 82374:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-locale-cookie.js");

/***/ }),

/***/ 34014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 78524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 95832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 78020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 29565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 64365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 95714:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-route-from-asset-path.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 91292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 25753:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-match.js");

/***/ }),

/***/ 99521:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/prepare-destination.js");

/***/ }),

/***/ 80979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 36052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 84226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 95566:
/***/ ((module) => {

module.exports = require("next/error");

/***/ }),

/***/ 40968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 71853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 4780:
/***/ ((module) => {

module.exports = require("next/script");

/***/ }),

/***/ 59819:
/***/ ((module) => {

module.exports = require("querystring");

/***/ }),

/***/ 16689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 10609:
/***/ ((module) => {

module.exports = require("react-countup");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 84466:
/***/ ((module) => {

module.exports = require("react-transition-group");

/***/ }),

/***/ 20997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 14161:
/***/ ((module) => {

module.exports = require("redux-persist");

/***/ }),

/***/ 61127:
/***/ ((module) => {

module.exports = require("redux-persist/integration/react");

/***/ }),

/***/ 98936:
/***/ ((module) => {

module.exports = require("redux-persist/lib/storage");

/***/ }),

/***/ 57518:
/***/ ((module) => {

module.exports = require("styled-components");

/***/ }),

/***/ 84269:
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ 15941:
/***/ ((module) => {

module.exports = import("swr");;

/***/ }),

/***/ 79847:
/***/ ((module) => {

module.exports = import("swr/immutable");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9635,2151,59,9645,1624,6538,7512,1587,4097,8703], () => (__webpack_exec__(95683)));
module.exports = __webpack_exports__;

})();
//# sourceMappingURL=index.js.map