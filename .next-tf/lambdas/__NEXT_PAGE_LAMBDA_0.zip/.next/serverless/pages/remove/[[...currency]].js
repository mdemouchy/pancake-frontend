"use strict";
(() => {
var exports = {};
exports.id = 6928;
exports.ids = [6928];
exports.modules = {

/***/ 68914:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "unstable_getStaticParams": () => (/* binding */ unstable_getStaticParams),
/* harmony export */   "unstable_getStaticProps": () => (/* binding */ unstable_getStaticProps),
/* harmony export */   "unstable_getStaticPaths": () => (/* binding */ unstable_getStaticPaths),
/* harmony export */   "unstable_getServerProps": () => (/* binding */ unstable_getServerProps),
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "_app": () => (/* binding */ _app),
/* harmony export */   "renderReqToHTML": () => (/* binding */ renderReqToHTML),
/* harmony export */   "render": () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(70607);
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59450);
/* harmony import */ var private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97020);
/* harmony import */ var private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(73978);
/* harmony import */ var next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99436);

      
      
      
      

      
      const { processEnv } = __webpack_require__(85360)
      processEnv([{"path":".env.production","contents":"NEXT_PUBLIC_CHAIN_ID = \"1666700000\"\nNEXT_PUBLIC_GTAG = \"GTM-PXLD3XW\"\n\n# 10+ nodes balanced, US/EU\nNEXT_PUBLIC_NODE_1 = \"https://api.s0.b.hmny.io\"\n\n# 10+ nodes balanced, US/EU\nNEXT_PUBLIC_NODE_2 = \"https://api.s0.b.hmny.io\"\n\n# 10+ nodes balanced in each region, global\nNEXT_PUBLIC_NODE_3 = \"https://api.s0.b.hmny.io\"\n\n# Google Cloud Infrastructure Endpoint - Global\n#NEXT_PUBLIC_NODE_PRODUCTION = \"https://nodes.pancakeswap.com\"\n\nNEXT_PUBLIC_GRAPH_API_PROFILE = \"https://api.thegraph.com/subgraphs/name/pancakeswap/profile\"\nNEXT_PUBLIC_GRAPH_API_PREDICTION = \"https://api.thegraph.com/subgraphs/name/pancakeswap/prediction-v2\"\nNEXT_PUBLIC_GRAPH_API_LOTTERY = \"https://api.thegraph.com/subgraphs/name/pancakeswap/lottery\"\nNEXT_PUBLIC_GRAPH_API_NFT_MARKET = \"https://api.thegraph.com/subgraphs/name/pancakeswap/nft-market\"\n\nNEXT_PUBLIC_SNAPSHOT_BASE_URL = \"https://hub.snapshot.org\"\nNEXT_PUBLIC_SNAPSHOT_VOTING_API = \"https://voting-api.pancakeswap.info/api\"\n\nNEXT_PUBLIC_API_NFT = \"https://nft.pancakeswap.com/api/v1\"\nNEXT_PUBLIC_BIT_QUERY_ENDPOINT = \"https://graphql.bitquery.io\"\n"},{"path":".env","contents":"NEXT_PUBLIC_API_PROFILE = https://profile.pancakeswap.com"}])
    
      
      const runtimeConfig = {}
      ;

      const documentModule = __webpack_require__(85641)

      const appMod = __webpack_require__(12957)
      let App = appMod.default || appMod.then && appMod.then(mod => mod.default);

      const compMod = __webpack_require__(48573)

      const Component = compMod.default || compMod.then && compMod.then(mod => mod.default)
      /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Component);
      const getStaticProps = compMod['getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['getStaticProp' + 's'])
      const getStaticPaths = compMod['getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['getStaticPath' + 's'])
      const getServerSideProps = compMod['getServerSideProp' + 's'] || compMod.then && compMod.then(mod => mod['getServerSideProp' + 's'])

      // kept for detecting legacy exports
      const unstable_getStaticParams = compMod['unstable_getStaticParam' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticParam' + 's'])
      const unstable_getStaticProps = compMod['unstable_getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticProp' + 's'])
      const unstable_getStaticPaths = compMod['unstable_getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticPath' + 's'])
      const unstable_getServerProps = compMod['unstable_getServerProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getServerProp' + 's'])

      let config = compMod['confi' + 'g'] || (compMod.then && compMod.then(mod => mod['confi' + 'g'])) || {}
      const _app = App

      const combinedRewrites = Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)
        ? private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg
        : []

      if (!Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)) {
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.beforeFiles */ .Dg.beforeFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.afterFiles */ .Dg.afterFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.fallback */ .Dg.fallback)
      }

      const { renderReqToHTML, render } = (0,next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__/* .getPageHandler */ .u)({
        pageModule: compMod,
        pageComponent: Component,
        pageConfig: config,
        appModule: App,
        documentModule: documentModule,
        errorModule: __webpack_require__(54141),
        notFoundModule: __webpack_require__(59622),
        pageGetStaticProps: getStaticProps,
        pageGetStaticPaths: getStaticPaths,
        pageGetServerSideProps: getServerSideProps,

        assetPrefix: "",
        canonicalBase: "",
        generateEtags: true,
        poweredByHeader: true,

        runtimeConfig,
        buildManifest: private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__,
        reactLoadableManifest: private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__,

        rewrites: combinedRewrites,
        i18n: undefined,
        page: "/remove/[[...currency]]",
        buildId: "pA0qXx8N8yV4x51Q8eKRJ",
        escapedBuildId: "pA0qXx8N8yV4x51Q8eKRJ",
        basePath: "",
        pageIsDynamic: true,
        encodedPreviewProps: {previewModeId:"4be1d5f31f1c05ab7d94512e7c5324a6",previewModeSigningKey:"bc6aa2b2074ecf664cef37e2cf2b9a8c7f10e81a4e58b764ce70d78163ce2360",previewModeEncryptionKey:"620945a7ce3f1dee81153e4e394922ca059a150870ea548250af9ef14ef4d062"}
      })
      
    

/***/ }),

/***/ 96492:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(41664);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);




const StyledInternalLink = styled_components__WEBPACK_IMPORTED_MODULE_2___default()('a').withConfig({
    componentId: "sc-68a903d6-0"
})`
  text-decoration: none;
  cursor: pointer;
  color: ${({ theme  })=>theme.colors.primary
};
  font-weight: 500;

  :hover {
    text-decoration: underline;
  }

  :focus {
    outline: none;
    text-decoration: underline;
  }

  :active {
    text-decoration: none;
  }
`;
const InternalLink = ({ children , ...props })=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
        ...props,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledInternalLink, {
            children: children
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (InternalLink);


/***/ }),

/***/ 80115:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useDebouncedChangeHandler)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

/**
 * Easy way to debounce the handling of a rapidly changing value, e.g. a changing slider input
 * @param value value that is rapidly changing
 * @param onChange change handler that should receive the debounced updates to the value
 * @param debouncedMs how long we should wait for changes to be applied
 */ function useDebouncedChangeHandler(value, onChange, debouncedMs = 100) {
    const { 0: inner , 1: setInner  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(()=>value
    );
    const timer = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
    const onChangeInner = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((newValue)=>{
        setInner(newValue);
        if (timer.current) {
            clearTimeout(timer.current);
        }
        timer.current = setTimeout(()=>{
            onChange(newValue);
            timer.current = undefined;
        }, debouncedMs);
    }, [
        debouncedMs,
        onChange
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        if (timer.current) {
            clearTimeout(timer.current);
            timer.current = undefined;
        }
        setInner(value);
    }, [
        value
    ]);
    return [
        inner,
        onChangeInner
    ];
};


/***/ }),

/***/ 48573:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var views_RemoveLiquidity__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(86659);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([views_RemoveLiquidity__WEBPACK_IMPORTED_MODULE_0__]);
views_RemoveLiquidity__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (views_RemoveLiquidity__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);
const OLD_PATH_STRUCTURE = /^(0x[a-fA-F0-9]{40})-(0x[a-fA-F0-9]{40})$/;
const getStaticPaths = ()=>{
    return {
        paths: [],
        fallback: true
    };
};
const getStaticProps = async ({ params  })=>{
    const currency = params.currency || [];
    if (currency.length === 0) {
        return {
            notFound: true
        };
    }
    if (currency.length === 1) {
        if (!OLD_PATH_STRUCTURE.test(currency[0])) {
            return {
                redirect: {
                    statusCode: 307,
                    destination: `/pool`
                }
            };
        }
        const split = currency[0].split('-');
        if (split.length > 1) {
            const [currency0, currency1] = split;
            return {
                redirect: {
                    statusCode: 307,
                    destination: `/remove/${currency0}/${currency1}`
                }
            };
        }
    }
    return {
        props: {}
    };
};

});

/***/ }),

/***/ 96524:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Xi": () => (/* binding */ useBurnState),
/* harmony export */   "Vx": () => (/* binding */ useDerivedBurnInfo),
/* harmony export */   "GF": () => (/* binding */ useBurnActionHandlers)
/* harmony export */ });
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(42877);
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(64011);
/* harmony import */ var utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(53854);
/* harmony import */ var hooks_usePairs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(84915);
/* harmony import */ var hooks_useTotalSupply__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(23552);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(99150);
/* harmony import */ var _swap_hooks__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(36717);
/* harmony import */ var _wallet_hooks__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(71900);
/* harmony import */ var _actions__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(52171);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_swap_hooks__WEBPACK_IMPORTED_MODULE_8__, hooks_useTotalSupply__WEBPACK_IMPORTED_MODULE_6__, _wallet_hooks__WEBPACK_IMPORTED_MODULE_9__, hooks_usePairs__WEBPACK_IMPORTED_MODULE_5__]);
([_swap_hooks__WEBPACK_IMPORTED_MODULE_8__, hooks_useTotalSupply__WEBPACK_IMPORTED_MODULE_6__, _wallet_hooks__WEBPACK_IMPORTED_MODULE_9__, hooks_usePairs__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);











function useBurnState() {
    return (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useSelector)((state)=>state.burn
    );
}
function useDerivedBurnInfo(currencyA, currencyB) {
    const { account , chainId  } = (0,hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)();
    const { independentField , typedValue  } = useBurnState();
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_7__/* .useTranslation */ .$G)();
    // pair + totalsupply
    const [, pair] = (0,hooks_usePairs__WEBPACK_IMPORTED_MODULE_5__/* .usePair */ .yX)(currencyA, currencyB);
    // balances
    const relevantTokenBalances = (0,_wallet_hooks__WEBPACK_IMPORTED_MODULE_9__/* .useTokenBalances */ .Z)(account ?? undefined, [
        pair?.liquidityToken
    ]);
    const userLiquidity = relevantTokenBalances?.[pair?.liquidityToken?.address ?? ''];
    const [tokenA, tokenB] = [
        (0,utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_4__/* .wrappedCurrency */ .pu)(currencyA, chainId),
        (0,utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_4__/* .wrappedCurrency */ .pu)(currencyB, chainId)
    ];
    const tokens = {
        [_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_A */ .g.CURRENCY_A]: tokenA,
        [_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_B */ .g.CURRENCY_B]: tokenB,
        [_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.LIQUIDITY */ .g.LIQUIDITY]: pair?.liquidityToken
    };
    // liquidity values
    const totalSupply = (0,hooks_useTotalSupply__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)(pair?.liquidityToken);
    const liquidityValueA = pair && totalSupply && userLiquidity && tokenA && // this condition is a short-circuit in the case where useTokenBalance updates sooner than useTotalSupply
    _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.greaterThanOrEqual(totalSupply.raw, userLiquidity.raw) ? new _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.TokenAmount(tokenA, pair.getLiquidityValue(tokenA, totalSupply, userLiquidity, false).raw) : undefined;
    const liquidityValueB = pair && totalSupply && userLiquidity && tokenB && // this condition is a short-circuit in the case where useTokenBalance updates sooner than useTotalSupply
    _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.greaterThanOrEqual(totalSupply.raw, userLiquidity.raw) ? new _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.TokenAmount(tokenB, pair.getLiquidityValue(tokenB, totalSupply, userLiquidity, false).raw) : undefined;
    const liquidityValues = {
        [_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_A */ .g.CURRENCY_A]: liquidityValueA,
        [_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_B */ .g.CURRENCY_B]: liquidityValueB
    };
    let percentToRemove = new _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.Percent('0', '100');
    // user specified a %
    if (independentField === _actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.LIQUIDITY_PERCENT */ .g.LIQUIDITY_PERCENT) {
        percentToRemove = new _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.Percent(typedValue, '100');
    } else if (independentField === _actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.LIQUIDITY */ .g.LIQUIDITY) {
        if (pair?.liquidityToken) {
            const independentAmount = (0,_swap_hooks__WEBPACK_IMPORTED_MODULE_8__/* .tryParseAmount */ .eo)(typedValue, pair.liquidityToken);
            if (independentAmount && userLiquidity && !independentAmount.greaterThan(userLiquidity)) {
                percentToRemove = new _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.Percent(independentAmount.raw, userLiquidity.raw);
            }
        }
    } else if (tokens[independentField]) {
        const independentAmount = (0,_swap_hooks__WEBPACK_IMPORTED_MODULE_8__/* .tryParseAmount */ .eo)(typedValue, tokens[independentField]);
        const liquidityValue = liquidityValues[independentField];
        if (independentAmount && liquidityValue && !independentAmount.greaterThan(liquidityValue)) {
            percentToRemove = new _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.Percent(independentAmount.raw, liquidityValue.raw);
        }
    }
    const parsedAmounts = {
        [_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.LIQUIDITY_PERCENT */ .g.LIQUIDITY_PERCENT]: percentToRemove,
        [_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.LIQUIDITY */ .g.LIQUIDITY]: userLiquidity && percentToRemove && percentToRemove.greaterThan('0') ? new _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.TokenAmount(userLiquidity.token, percentToRemove.multiply(userLiquidity.raw).quotient) : undefined,
        [_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_A */ .g.CURRENCY_A]: tokenA && percentToRemove && percentToRemove.greaterThan('0') && liquidityValueA ? new _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.TokenAmount(tokenA, percentToRemove.multiply(liquidityValueA.raw).quotient) : undefined,
        [_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_B */ .g.CURRENCY_B]: tokenB && percentToRemove && percentToRemove.greaterThan('0') && liquidityValueB ? new _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.TokenAmount(tokenB, percentToRemove.multiply(liquidityValueB.raw).quotient) : undefined
    };
    let error;
    if (!account) {
        error = t('Connect Wallet');
    }
    if (!parsedAmounts[_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.LIQUIDITY */ .g.LIQUIDITY] || !parsedAmounts[_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_A */ .g.CURRENCY_A] || !parsedAmounts[_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_B */ .g.CURRENCY_B]) {
        error = error ?? t('Enter an amount');
    }
    return {
        pair,
        parsedAmounts,
        error
    };
}
function useBurnActionHandlers() {
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useDispatch)();
    const onUserInput = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((field, typedValue)=>{
        dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_10__/* .typeInput */ .L)({
            field,
            typedValue
        }));
    }, [
        dispatch
    ]);
    return {
        onUserInput
    };
}

});

/***/ }),

/***/ 86659:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ RemoveLiquidity)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ethersproject_bytes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(49935);
/* harmony import */ var _ethersproject_bytes__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_bytes__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(42877);
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(65757);
/* harmony import */ var _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(99150);
/* harmony import */ var _components_Layout_Column__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(41914);
/* harmony import */ var _components_TransactionConfirmationModal__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(41228);
/* harmony import */ var _components_CurrencyInputPanel__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(71372);
/* harmony import */ var _components_PositionCard__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(86323);
/* harmony import */ var _components_App__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(85101);
/* harmony import */ var _components_Layout_Row__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(39475);
/* harmony import */ var _components_ConnectWalletButton__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(30621);
/* harmony import */ var _components_Card__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(36261);
/* harmony import */ var _components_Logo__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(83356);
/* harmony import */ var _config_constants__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(3862);
/* harmony import */ var _hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(64011);
/* harmony import */ var _hooks_Tokens__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(86435);
/* harmony import */ var _hooks_useContract__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(46063);
/* harmony import */ var _hooks_useTransactionDeadline__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(81748);
/* harmony import */ var _state_transactions_hooks__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(55892);
/* harmony import */ var _components_Links__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(96492);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(38328);
/* harmony import */ var _utils_currencyId__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(28996);
/* harmony import */ var _hooks_useDebouncedChangeHandler__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(80115);
/* harmony import */ var _utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(53854);
/* harmony import */ var _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(69398);
/* harmony import */ var _components_Loader_Dots__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(48468);
/* harmony import */ var _state_burn_hooks__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(96524);
/* harmony import */ var _state_burn_actions__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(52171);
/* harmony import */ var _state_user_hooks__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(68605);
/* harmony import */ var _Page__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(49438);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_PositionCard__WEBPACK_IMPORTED_MODULE_12__, _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_29__, _components_CurrencyInputPanel__WEBPACK_IMPORTED_MODULE_11__, _components_Logo__WEBPACK_IMPORTED_MODULE_17__, _components_App__WEBPACK_IMPORTED_MODULE_13__, _Page__WEBPACK_IMPORTED_MODULE_34__, _state_user_hooks__WEBPACK_IMPORTED_MODULE_33__, _hooks_useTransactionDeadline__WEBPACK_IMPORTED_MODULE_22__, _state_burn_hooks__WEBPACK_IMPORTED_MODULE_31__, _hooks_Tokens__WEBPACK_IMPORTED_MODULE_20__]);
([_components_PositionCard__WEBPACK_IMPORTED_MODULE_12__, _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_29__, _components_CurrencyInputPanel__WEBPACK_IMPORTED_MODULE_11__, _components_Logo__WEBPACK_IMPORTED_MODULE_17__, _components_App__WEBPACK_IMPORTED_MODULE_13__, _Page__WEBPACK_IMPORTED_MODULE_34__, _state_user_hooks__WEBPACK_IMPORTED_MODULE_33__, _hooks_useTransactionDeadline__WEBPACK_IMPORTED_MODULE_22__, _state_burn_hooks__WEBPACK_IMPORTED_MODULE_31__, _hooks_Tokens__WEBPACK_IMPORTED_MODULE_20__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);



































const BorderCard = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-71d2dbbb-0"
})`
  border: solid 1px ${({ theme  })=>theme.colors.cardBorder
};
  border-radius: 16px;
  padding: 16px;
`;
function RemoveLiquidity() {
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const [currencyIdA, currencyIdB] = router.query.currency || [];
    const [currencyA, currencyB] = [
        (0,_hooks_Tokens__WEBPACK_IMPORTED_MODULE_20__/* .useCurrency */ .U8)(currencyIdA) ?? undefined,
        (0,_hooks_Tokens__WEBPACK_IMPORTED_MODULE_20__/* .useCurrency */ .U8)(currencyIdB) ?? undefined
    ];
    const { account , chainId , library  } = (0,_hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z)();
    const { 0: tokenA , 1: tokenB  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>[
            (0,_utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_28__/* .wrappedCurrency */ .pu)(currencyA, chainId),
            (0,_utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_28__/* .wrappedCurrency */ .pu)(currencyB, chainId)
        ]
    , [
        currencyA,
        currencyB,
        chainId
    ]);
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_8__/* .useTranslation */ .$G)();
    const gasPrice = (0,_state_user_hooks__WEBPACK_IMPORTED_MODULE_33__/* .useGasPrice */ .Fh)();
    // burn state
    const { independentField , typedValue  } = (0,_state_burn_hooks__WEBPACK_IMPORTED_MODULE_31__/* .useBurnState */ .Xi)();
    const { pair , parsedAmounts , error  } = (0,_state_burn_hooks__WEBPACK_IMPORTED_MODULE_31__/* .useDerivedBurnInfo */ .Vx)(currencyA ?? undefined, currencyB ?? undefined);
    const { onUserInput: _onUserInput  } = (0,_state_burn_hooks__WEBPACK_IMPORTED_MODULE_31__/* .useBurnActionHandlers */ .GF)();
    const isValid = !error;
    // modal and loading
    const { 0: showDetailed , 1: setShowDetailed  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: attemptingTxn , 1: setAttemptingTxn  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false) // clicked confirm
    ;
    // txn values
    const { 0: txHash , 1: setTxHash  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const deadline = (0,_hooks_useTransactionDeadline__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .Z)();
    const [allowedSlippage] = (0,_state_user_hooks__WEBPACK_IMPORTED_MODULE_33__/* .useUserSlippageTolerance */ .$2)();
    const formattedAmounts = {
        [_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.LIQUIDITY_PERCENT */ .g.LIQUIDITY_PERCENT]: parsedAmounts[_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.LIQUIDITY_PERCENT */ .g.LIQUIDITY_PERCENT].equalTo('0') ? '0' : parsedAmounts[_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.LIQUIDITY_PERCENT */ .g.LIQUIDITY_PERCENT].lessThan(new _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_5__.Percent('1', '100')) ? '<1' : parsedAmounts[_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.LIQUIDITY_PERCENT */ .g.LIQUIDITY_PERCENT].toFixed(0),
        [_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.LIQUIDITY */ .g.LIQUIDITY]: independentField === _state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.LIQUIDITY */ .g.LIQUIDITY ? typedValue : parsedAmounts[_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.LIQUIDITY */ .g.LIQUIDITY]?.toSignificant(6) ?? '',
        [_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.CURRENCY_A */ .g.CURRENCY_A]: independentField === _state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.CURRENCY_A */ .g.CURRENCY_A ? typedValue : parsedAmounts[_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.CURRENCY_A */ .g.CURRENCY_A]?.toSignificant(6) ?? '',
        [_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.CURRENCY_B */ .g.CURRENCY_B]: independentField === _state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.CURRENCY_B */ .g.CURRENCY_B ? typedValue : parsedAmounts[_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.CURRENCY_B */ .g.CURRENCY_B]?.toSignificant(6) ?? ''
    };
    const atMaxAmount = parsedAmounts[_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.LIQUIDITY_PERCENT */ .g.LIQUIDITY_PERCENT]?.equalTo(new _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_5__.Percent('1'));
    // pair contract
    const pairContract = (0,_hooks_useContract__WEBPACK_IMPORTED_MODULE_21__/* .usePairContract */ .t0)(pair?.liquidityToken?.address);
    // allowance handling
    const { 0: signatureData , 1: setSignatureData  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [approval, approveCallback] = (0,_hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_29__/* .useApproveCallback */ .qL)(parsedAmounts[_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.LIQUIDITY */ .g.LIQUIDITY], _config_constants__WEBPACK_IMPORTED_MODULE_18__/* .ROUTER_ADDRESS */ .bR);
    async function onAttemptToApprove() {
        if (!pairContract || !pair || !library || !deadline) throw new Error('missing dependencies');
        const liquidityAmount = parsedAmounts[_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.LIQUIDITY */ .g.LIQUIDITY];
        if (!liquidityAmount) throw new Error('missing liquidity amount');
        // try to gather a signature for permission
        const nonce = await pairContract.nonces(account);
        const EIP712Domain = [
            {
                name: 'name',
                type: 'string'
            },
            {
                name: 'version',
                type: 'string'
            },
            {
                name: 'chainId',
                type: 'uint256'
            },
            {
                name: 'verifyingContract',
                type: 'address'
            }, 
        ];
        const domain = {
            name: 'Pancake LPs',
            version: '1',
            chainId,
            verifyingContract: pair.liquidityToken.address
        };
        const Permit = [
            {
                name: 'owner',
                type: 'address'
            },
            {
                name: 'spender',
                type: 'address'
            },
            {
                name: 'value',
                type: 'uint256'
            },
            {
                name: 'nonce',
                type: 'uint256'
            },
            {
                name: 'deadline',
                type: 'uint256'
            }, 
        ];
        const message = {
            owner: account,
            spender: _config_constants__WEBPACK_IMPORTED_MODULE_18__/* .ROUTER_ADDRESS */ .bR,
            value: liquidityAmount.raw.toString(),
            nonce: nonce.toHexString(),
            deadline: deadline.toNumber()
        };
        const data = JSON.stringify({
            types: {
                EIP712Domain,
                Permit
            },
            domain,
            primaryType: 'Permit',
            message
        });
        library.send('eth_signTypedData_v4', [
            account,
            data
        ]).then(_ethersproject_bytes__WEBPACK_IMPORTED_MODULE_3__.splitSignature).then((signature)=>{
            setSignatureData({
                v: signature.v,
                r: signature.r,
                s: signature.s,
                deadline: deadline.toNumber()
            });
        }).catch((err)=>{
            // for all errors other than 4001 (EIP-1193 user rejected request), fall back to manual approve
            if (err?.code !== 4001) {
                approveCallback();
            }
        });
    }
    // wrapped onUserInput to clear signatures
    const onUserInput = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((field, value)=>{
        setSignatureData(null);
        return _onUserInput(field, value);
    }, [
        _onUserInput
    ]);
    const onLiquidityInput = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((value)=>onUserInput(_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.LIQUIDITY */ .g.LIQUIDITY, value)
    , [
        onUserInput
    ]);
    const onCurrencyAInput = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((value)=>onUserInput(_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.CURRENCY_A */ .g.CURRENCY_A, value)
    , [
        onUserInput
    ]);
    const onCurrencyBInput = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((value)=>onUserInput(_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.CURRENCY_B */ .g.CURRENCY_B, value)
    , [
        onUserInput
    ]);
    // tx sending
    const addTransaction = (0,_state_transactions_hooks__WEBPACK_IMPORTED_MODULE_23__/* .useTransactionAdder */ .h7)();
    async function onRemove() {
        if (!chainId || !library || !account || !deadline) throw new Error('missing dependencies');
        const { [_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.CURRENCY_A */ .g.CURRENCY_A]: currencyAmountA , [_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.CURRENCY_B */ .g.CURRENCY_B]: currencyAmountB  } = parsedAmounts;
        if (!currencyAmountA || !currencyAmountB) {
            throw new Error('missing currency amounts');
        }
        const routerContract = (0,_utils__WEBPACK_IMPORTED_MODULE_25__/* .getRouterContract */ .iY)(chainId, library, account);
        const amountsMin = {
            [_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.CURRENCY_A */ .g.CURRENCY_A]: (0,_utils__WEBPACK_IMPORTED_MODULE_25__/* .calculateSlippageAmount */ .uc)(currencyAmountA, allowedSlippage)[0],
            [_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.CURRENCY_B */ .g.CURRENCY_B]: (0,_utils__WEBPACK_IMPORTED_MODULE_25__/* .calculateSlippageAmount */ .uc)(currencyAmountB, allowedSlippage)[0]
        };
        if (!currencyA || !currencyB) throw new Error('missing tokens');
        const liquidityAmount = parsedAmounts[_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.LIQUIDITY */ .g.LIQUIDITY];
        if (!liquidityAmount) throw new Error('missing liquidity amount');
        const currencyBIsETH = currencyB === _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_5__.ETHER;
        const oneCurrencyIsETH = currencyA === _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_5__.ETHER || currencyBIsETH;
        if (!tokenA || !tokenB) throw new Error('could not wrap');
        let methodNames;
        let args;
        // we have approval, use normal remove liquidity
        if (approval === _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_29__/* .ApprovalState.APPROVED */ .UK.APPROVED) {
            // removeLiquidityETH
            if (oneCurrencyIsETH) {
                methodNames = [
                    'removeLiquidityETH',
                    'removeLiquidityETHSupportingFeeOnTransferTokens'
                ];
                args = [
                    currencyBIsETH ? tokenA.address : tokenB.address,
                    liquidityAmount.raw.toString(),
                    amountsMin[currencyBIsETH ? _state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.CURRENCY_A */ .g.CURRENCY_A : _state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.CURRENCY_B */ .g.CURRENCY_B].toString(),
                    amountsMin[currencyBIsETH ? _state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.CURRENCY_B */ .g.CURRENCY_B : _state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.CURRENCY_A */ .g.CURRENCY_A].toString(),
                    account,
                    deadline.toHexString(), 
                ];
            } else {
                methodNames = [
                    'removeLiquidity'
                ];
                args = [
                    tokenA.address,
                    tokenB.address,
                    liquidityAmount.raw.toString(),
                    amountsMin[_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.CURRENCY_A */ .g.CURRENCY_A].toString(),
                    amountsMin[_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.CURRENCY_B */ .g.CURRENCY_B].toString(),
                    account,
                    deadline.toHexString(), 
                ];
            }
        } else if (signatureData !== null) {
            // removeLiquidityETHWithPermit
            if (oneCurrencyIsETH) {
                methodNames = [
                    'removeLiquidityETHWithPermit',
                    'removeLiquidityETHWithPermitSupportingFeeOnTransferTokens'
                ];
                args = [
                    currencyBIsETH ? tokenA.address : tokenB.address,
                    liquidityAmount.raw.toString(),
                    amountsMin[currencyBIsETH ? _state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.CURRENCY_A */ .g.CURRENCY_A : _state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.CURRENCY_B */ .g.CURRENCY_B].toString(),
                    amountsMin[currencyBIsETH ? _state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.CURRENCY_B */ .g.CURRENCY_B : _state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.CURRENCY_A */ .g.CURRENCY_A].toString(),
                    account,
                    signatureData.deadline,
                    false,
                    signatureData.v,
                    signatureData.r,
                    signatureData.s, 
                ];
            } else {
                methodNames = [
                    'removeLiquidityWithPermit'
                ];
                args = [
                    tokenA.address,
                    tokenB.address,
                    liquidityAmount.raw.toString(),
                    amountsMin[_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.CURRENCY_A */ .g.CURRENCY_A].toString(),
                    amountsMin[_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.CURRENCY_B */ .g.CURRENCY_B].toString(),
                    account,
                    signatureData.deadline,
                    false,
                    signatureData.v,
                    signatureData.r,
                    signatureData.s, 
                ];
            }
        } else {
            throw new Error('Attempting to confirm without approval or a signature. Please contact support.');
        }
        const safeGasEstimates = await Promise.all(methodNames.map((methodName)=>routerContract.estimateGas[methodName](...args).then(_utils__WEBPACK_IMPORTED_MODULE_25__/* .calculateGasMargin */ .yC).catch((err)=>{
                console.error(`estimateGas failed`, methodName, args, err);
                return undefined;
            })
        ));
        const indexOfSuccessfulEstimation = safeGasEstimates.findIndex((safeGasEstimate)=>_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_7__.BigNumber.isBigNumber(safeGasEstimate)
        );
        // all estimations failed...
        if (indexOfSuccessfulEstimation === -1) {
            console.error('This transaction would fail. Please contact support.');
        } else {
            const methodName = methodNames[indexOfSuccessfulEstimation];
            const safeGasEstimate = safeGasEstimates[indexOfSuccessfulEstimation];
            setAttemptingTxn(true);
            await routerContract[methodName](...args, {
                gasLimit: safeGasEstimate,
                gasPrice
            }).then((response)=>{
                setAttemptingTxn(false);
                addTransaction(response, {
                    summary: `Remove ${parsedAmounts[_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.CURRENCY_A */ .g.CURRENCY_A]?.toSignificant(3)} ${currencyA?.symbol} and ${parsedAmounts[_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.CURRENCY_B */ .g.CURRENCY_B]?.toSignificant(3)} ${currencyB?.symbol}`
                });
                setTxHash(response.hash);
            }).catch((err)=>{
                setAttemptingTxn(false);
                // we only care if the error is something _other_ than the user rejected the tx
                console.error(err);
            });
        }
    }
    function modalHeader() {
        return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layout_Column__WEBPACK_IMPORTED_MODULE_9__/* .AutoColumn */ .Tz, {
            gap: "md",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layout_Row__WEBPACK_IMPORTED_MODULE_14__/* .RowBetween */ .m0, {
                    align: "flex-end",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Text, {
                            fontSize: "24px",
                            children: parsedAmounts[_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.CURRENCY_A */ .g.CURRENCY_A]?.toSignificant(6)
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layout_Row__WEBPACK_IMPORTED_MODULE_14__/* .RowFixed */ .DA, {
                            gap: "4px",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Logo__WEBPACK_IMPORTED_MODULE_17__/* .CurrencyLogo */ .Xw, {
                                    currency: currencyA,
                                    size: "24px"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Text, {
                                    fontSize: "24px",
                                    ml: "10px",
                                    children: currencyA?.symbol
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Layout_Row__WEBPACK_IMPORTED_MODULE_14__/* .RowFixed */ .DA, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.AddIcon, {
                        width: "16px"
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layout_Row__WEBPACK_IMPORTED_MODULE_14__/* .RowBetween */ .m0, {
                    align: "flex-end",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Text, {
                            fontSize: "24px",
                            children: parsedAmounts[_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.CURRENCY_B */ .g.CURRENCY_B]?.toSignificant(6)
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layout_Row__WEBPACK_IMPORTED_MODULE_14__/* .RowFixed */ .DA, {
                            gap: "4px",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Logo__WEBPACK_IMPORTED_MODULE_17__/* .CurrencyLogo */ .Xw, {
                                    currency: currencyB,
                                    size: "24px"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Text, {
                                    fontSize: "24px",
                                    ml: "10px",
                                    children: currencyB?.symbol
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Text, {
                    small: true,
                    textAlign: "left",
                    pt: "12px",
                    children: t('Output is estimated. If the price changes by more than %slippage%% your transaction will revert.', {
                        slippage: allowedSlippage / 100
                    })
                })
            ]
        }));
    }
    function modalBottom() {
        return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layout_Row__WEBPACK_IMPORTED_MODULE_14__/* .RowBetween */ .m0, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Text, {
                            children: t('%assetA%/%assetB% Burned', {
                                assetA: currencyA?.symbol ?? '',
                                assetB: currencyB?.symbol ?? ''
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layout_Row__WEBPACK_IMPORTED_MODULE_14__/* .RowFixed */ .DA, {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Logo__WEBPACK_IMPORTED_MODULE_17__/* .DoubleCurrencyLogo */ .ge, {
                                    currency0: currencyA,
                                    currency1: currencyB,
                                    margin: true
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Text, {
                                    children: parsedAmounts[_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.LIQUIDITY */ .g.LIQUIDITY]?.toSignificant(6)
                                })
                            ]
                        })
                    ]
                }),
                pair && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layout_Row__WEBPACK_IMPORTED_MODULE_14__/* .RowBetween */ .m0, {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Text, {
                                    children: t('Price')
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Text, {
                                    children: [
                                        "1 ",
                                        currencyA?.symbol,
                                        " = ",
                                        tokenA ? pair.priceOf(tokenA).toSignificant(6) : '-',
                                        " ",
                                        currencyB?.symbol
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layout_Row__WEBPACK_IMPORTED_MODULE_14__/* .RowBetween */ .m0, {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {}),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Text, {
                                    children: [
                                        "1 ",
                                        currencyB?.symbol,
                                        " = ",
                                        tokenB ? pair.priceOf(tokenB).toSignificant(6) : '-',
                                        " ",
                                        currencyA?.symbol
                                    ]
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Button, {
                    disabled: !(approval === _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_29__/* .ApprovalState.APPROVED */ .UK.APPROVED || signatureData !== null),
                    onClick: onRemove,
                    children: t('Confirm')
                })
            ]
        }));
    }
    const pendingText = t('Removing %amountA% %symbolA% and %amountB% %symbolB%', {
        amountA: parsedAmounts[_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.CURRENCY_A */ .g.CURRENCY_A]?.toSignificant(6) ?? '',
        symbolA: currencyA?.symbol ?? '',
        amountB: parsedAmounts[_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.CURRENCY_B */ .g.CURRENCY_B]?.toSignificant(6) ?? '',
        symbolB: currencyB?.symbol ?? ''
    });
    const liquidityPercentChangeCallback = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((value)=>{
        onUserInput(_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.LIQUIDITY_PERCENT */ .g.LIQUIDITY_PERCENT, value.toString());
    }, [
        onUserInput
    ]);
    const oneCurrencyIsETH1 = currencyA === _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_5__.ETHER || currencyB === _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_5__.ETHER;
    const oneCurrencyIsWETH = Boolean(chainId && (currencyA && (0,_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_5__.currencyEquals)(_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_5__.WETH[chainId], currencyA) || currencyB && (0,_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_5__.currencyEquals)(_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_5__.WETH[chainId], currencyB)));
    const handleSelectCurrencyA = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((currency)=>{
        if (currencyIdB && (0,_utils_currencyId__WEBPACK_IMPORTED_MODULE_26__/* .currencyId */ .H)(currency) === currencyIdB) {
            router.replace(`/remove/${(0,_utils_currencyId__WEBPACK_IMPORTED_MODULE_26__/* .currencyId */ .H)(currency)}/${currencyIdA}`, undefined, {
                shallow: true
            });
        } else {
            router.replace(`/remove/${(0,_utils_currencyId__WEBPACK_IMPORTED_MODULE_26__/* .currencyId */ .H)(currency)}/${currencyIdB}`, undefined, {
                shallow: true
            });
        }
    }, [
        currencyIdA,
        currencyIdB,
        router
    ]);
    const handleSelectCurrencyB = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((currency)=>{
        if (currencyIdA && (0,_utils_currencyId__WEBPACK_IMPORTED_MODULE_26__/* .currencyId */ .H)(currency) === currencyIdA) {
            router.replace(`/remove/${currencyIdB}/${(0,_utils_currencyId__WEBPACK_IMPORTED_MODULE_26__/* .currencyId */ .H)(currency)}`, undefined, {
                shallow: true
            });
        } else {
            router.replace(`/remove/${currencyIdA}/${(0,_utils_currencyId__WEBPACK_IMPORTED_MODULE_26__/* .currencyId */ .H)(currency)}`, undefined, {
                shallow: true
            });
        }
    }, [
        currencyIdA,
        currencyIdB,
        router
    ]);
    const handleDismissConfirmation = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        setSignatureData(null) // important that we clear signature data to avoid bad sigs
        ;
        // if there was a tx hash, we want to clear the input
        if (txHash) {
            onUserInput(_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.LIQUIDITY_PERCENT */ .g.LIQUIDITY_PERCENT, '0');
        }
        setTxHash('');
    }, [
        onUserInput,
        txHash
    ]);
    const [innerLiquidityPercentage, setInnerLiquidityPercentage] = (0,_hooks_useDebouncedChangeHandler__WEBPACK_IMPORTED_MODULE_27__/* ["default"] */ .Z)(Number.parseInt(parsedAmounts[_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.LIQUIDITY_PERCENT */ .g.LIQUIDITY_PERCENT].toFixed(0)), liquidityPercentChangeCallback);
    const [onPresentRemoveLiquidity] = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.useModal)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_TransactionConfirmationModal__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .ZP, {
        title: t('You will receive'),
        customOnDismiss: handleDismissConfirmation,
        attemptingTxn: attemptingTxn,
        hash: txHash || '',
        content: ()=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_TransactionConfirmationModal__WEBPACK_IMPORTED_MODULE_10__/* .ConfirmationModalContent */ .pM, {
                topContent: modalHeader,
                bottomContent: modalBottom
            })
        ,
        pendingText: pendingText
    }), true, true, 'removeLiquidityModal');
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Page__WEBPACK_IMPORTED_MODULE_34__/* ["default"] */ .Z, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_App__WEBPACK_IMPORTED_MODULE_13__/* .AppBody */ .j, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_App__WEBPACK_IMPORTED_MODULE_13__/* .AppHeader */ .t, {
                        backTo: "/liquidity",
                        title: t('Remove %assetA%-%assetB% liquidity', {
                            assetA: currencyA?.symbol ?? '',
                            assetB: currencyB?.symbol ?? ''
                        }),
                        subtitle: t('To receive %assetA% and %assetB%', {
                            assetA: currencyA?.symbol ?? '',
                            assetB: currencyB?.symbol ?? ''
                        }),
                        noConfig: true
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.CardBody, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layout_Column__WEBPACK_IMPORTED_MODULE_9__/* .AutoColumn */ .Tz, {
                                gap: "20px",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layout_Row__WEBPACK_IMPORTED_MODULE_14__/* .RowBetween */ .m0, {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Text, {
                                                children: t('Amount')
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Button, {
                                                variant: "text",
                                                scale: "sm",
                                                onClick: ()=>setShowDetailed(!showDetailed)
                                                ,
                                                children: showDetailed ? t('Simple') : t('Detailed')
                                            })
                                        ]
                                    }),
                                    !showDetailed && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(BorderCard, {
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Text, {
                                                fontSize: "40px",
                                                bold: true,
                                                mb: "16px",
                                                style: {
                                                    lineHeight: 1
                                                },
                                                children: [
                                                    formattedAmounts[_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.LIQUIDITY_PERCENT */ .g.LIQUIDITY_PERCENT],
                                                    "%"
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Slider, {
                                                name: "lp-amount",
                                                min: 0,
                                                max: 100,
                                                value: innerLiquidityPercentage,
                                                onValueChanged: (value)=>setInnerLiquidityPercentage(Math.ceil(value))
                                                ,
                                                mb: "16px"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Flex, {
                                                flexWrap: "wrap",
                                                justifyContent: "space-evenly",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Button, {
                                                        variant: "tertiary",
                                                        scale: "sm",
                                                        onClick: ()=>onUserInput(_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.LIQUIDITY_PERCENT */ .g.LIQUIDITY_PERCENT, '25')
                                                        ,
                                                        children: "25%"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Button, {
                                                        variant: "tertiary",
                                                        scale: "sm",
                                                        onClick: ()=>onUserInput(_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.LIQUIDITY_PERCENT */ .g.LIQUIDITY_PERCENT, '50')
                                                        ,
                                                        children: "50%"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Button, {
                                                        variant: "tertiary",
                                                        scale: "sm",
                                                        onClick: ()=>onUserInput(_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.LIQUIDITY_PERCENT */ .g.LIQUIDITY_PERCENT, '75')
                                                        ,
                                                        children: "75%"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Button, {
                                                        variant: "tertiary",
                                                        scale: "sm",
                                                        onClick: ()=>onUserInput(_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.LIQUIDITY_PERCENT */ .g.LIQUIDITY_PERCENT, '100')
                                                        ,
                                                        children: "Max"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }),
                            !showDetailed && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Layout_Column__WEBPACK_IMPORTED_MODULE_9__/* .ColumnCenter */ .lg, {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.ArrowDownIcon, {
                                            color: "textSubtle",
                                            width: "24px",
                                            my: "16px"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layout_Column__WEBPACK_IMPORTED_MODULE_9__/* .AutoColumn */ .Tz, {
                                        gap: "10px",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Text, {
                                                bold: true,
                                                color: "secondary",
                                                fontSize: "12px",
                                                textTransform: "uppercase",
                                                children: t('You will receive')
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Card__WEBPACK_IMPORTED_MODULE_16__/* .LightGreyCard */ .m5, {
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Flex, {
                                                        justifyContent: "space-between",
                                                        mb: "8px",
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Flex, {
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Logo__WEBPACK_IMPORTED_MODULE_17__/* .CurrencyLogo */ .Xw, {
                                                                        currency: currencyA
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Text, {
                                                                        small: true,
                                                                        color: "textSubtle",
                                                                        id: "remove-liquidity-tokena-symbol",
                                                                        ml: "4px",
                                                                        children: currencyA?.symbol
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Text, {
                                                                small: true,
                                                                children: formattedAmounts[_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.CURRENCY_A */ .g.CURRENCY_A] || '-'
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Flex, {
                                                        justifyContent: "space-between",
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Flex, {
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Logo__WEBPACK_IMPORTED_MODULE_17__/* .CurrencyLogo */ .Xw, {
                                                                        currency: currencyB
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Text, {
                                                                        small: true,
                                                                        color: "textSubtle",
                                                                        id: "remove-liquidity-tokenb-symbol",
                                                                        ml: "4px",
                                                                        children: currencyB?.symbol
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Text, {
                                                                small: true,
                                                                children: formattedAmounts[_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.CURRENCY_B */ .g.CURRENCY_B] || '-'
                                                            })
                                                        ]
                                                    }),
                                                    chainId && (oneCurrencyIsWETH || oneCurrencyIsETH1) ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Layout_Row__WEBPACK_IMPORTED_MODULE_14__/* .RowBetween */ .m0, {
                                                        style: {
                                                            justifyContent: 'flex-end',
                                                            fontSize: '14px'
                                                        },
                                                        children: oneCurrencyIsETH1 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Links__WEBPACK_IMPORTED_MODULE_24__/* ["default"] */ .Z, {
                                                            href: `/remove/${currencyA === _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_5__.ETHER ? _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_5__.WETH[chainId].address : currencyIdA}/${currencyB === _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_5__.ETHER ? _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_5__.WETH[chainId].address : currencyIdB}`,
                                                            children: t('Receive WBNB')
                                                        }) : oneCurrencyIsWETH ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Links__WEBPACK_IMPORTED_MODULE_24__/* ["default"] */ .Z, {
                                                            href: `/remove/${currencyA && (0,_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_5__.currencyEquals)(currencyA, _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_5__.WETH[chainId]) ? 'BNB' : currencyIdA}/${currencyB && (0,_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_5__.currencyEquals)(currencyB, _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_5__.WETH[chainId]) ? 'BNB' : currencyIdB}`,
                                                            children: t('Receive BNB')
                                                        }) : null
                                                    }) : null
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }),
                            showDetailed && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Box, {
                                my: "16px",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_CurrencyInputPanel__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                        value: formattedAmounts[_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.LIQUIDITY */ .g.LIQUIDITY],
                                        onUserInput: onLiquidityInput,
                                        onMax: ()=>{
                                            onUserInput(_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.LIQUIDITY_PERCENT */ .g.LIQUIDITY_PERCENT, '100');
                                        },
                                        showMaxButton: !atMaxAmount,
                                        disableCurrencySelect: true,
                                        currency: pair?.liquidityToken,
                                        pair: pair,
                                        id: "liquidity-amount",
                                        onCurrencySelect: ()=>null
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Layout_Column__WEBPACK_IMPORTED_MODULE_9__/* .ColumnCenter */ .lg, {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.ArrowDownIcon, {
                                            width: "24px",
                                            my: "16px"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_CurrencyInputPanel__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                        hideBalance: true,
                                        value: formattedAmounts[_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.CURRENCY_A */ .g.CURRENCY_A],
                                        onUserInput: onCurrencyAInput,
                                        onMax: ()=>onUserInput(_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.LIQUIDITY_PERCENT */ .g.LIQUIDITY_PERCENT, '100')
                                        ,
                                        showMaxButton: !atMaxAmount,
                                        currency: currencyA,
                                        label: t('Output'),
                                        onCurrencySelect: handleSelectCurrencyA,
                                        id: "remove-liquidity-tokena"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Layout_Column__WEBPACK_IMPORTED_MODULE_9__/* .ColumnCenter */ .lg, {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.AddIcon, {
                                            width: "24px",
                                            my: "16px"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_CurrencyInputPanel__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                        hideBalance: true,
                                        value: formattedAmounts[_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.CURRENCY_B */ .g.CURRENCY_B],
                                        onUserInput: onCurrencyBInput,
                                        onMax: ()=>onUserInput(_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.LIQUIDITY_PERCENT */ .g.LIQUIDITY_PERCENT, '100')
                                        ,
                                        showMaxButton: !atMaxAmount,
                                        currency: currencyB,
                                        label: t('Output'),
                                        onCurrencySelect: handleSelectCurrencyB,
                                        id: "remove-liquidity-tokenb"
                                    })
                                ]
                            }),
                            pair && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layout_Column__WEBPACK_IMPORTED_MODULE_9__/* .AutoColumn */ .Tz, {
                                gap: "10px",
                                style: {
                                    marginTop: '16px'
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Text, {
                                        bold: true,
                                        color: "secondary",
                                        fontSize: "12px",
                                        textTransform: "uppercase",
                                        children: t('Prices')
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Card__WEBPACK_IMPORTED_MODULE_16__/* .LightGreyCard */ .m5, {
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Flex, {
                                                justifyContent: "space-between",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Text, {
                                                        small: true,
                                                        color: "textSubtle",
                                                        children: [
                                                            "1 ",
                                                            currencyA?.symbol,
                                                            " ="
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Text, {
                                                        small: true,
                                                        children: [
                                                            tokenA ? pair.priceOf(tokenA).toSignificant(6) : '-',
                                                            " ",
                                                            currencyB?.symbol
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Flex, {
                                                justifyContent: "space-between",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Text, {
                                                        small: true,
                                                        color: "textSubtle",
                                                        children: [
                                                            "1 ",
                                                            currencyB?.symbol,
                                                            " ="
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Text, {
                                                        small: true,
                                                        children: [
                                                            tokenB ? pair.priceOf(tokenB).toSignificant(6) : '-',
                                                            " ",
                                                            currencyA?.symbol
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Box, {
                                position: "relative",
                                mt: "16px",
                                children: !account ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ConnectWalletButton__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {}) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layout_Row__WEBPACK_IMPORTED_MODULE_14__/* .RowBetween */ .m0, {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Button, {
                                            variant: approval === _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_29__/* .ApprovalState.APPROVED */ .UK.APPROVED || signatureData !== null ? 'success' : 'primary',
                                            onClick: onAttemptToApprove,
                                            disabled: approval !== _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_29__/* .ApprovalState.NOT_APPROVED */ .UK.NOT_APPROVED || signatureData !== null,
                                            width: "100%",
                                            mr: "0.5rem",
                                            children: approval === _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_29__/* .ApprovalState.PENDING */ .UK.PENDING ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Loader_Dots__WEBPACK_IMPORTED_MODULE_30__/* ["default"] */ .Z, {
                                                children: t('Enabling')
                                            }) : approval === _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_29__/* .ApprovalState.APPROVED */ .UK.APPROVED || signatureData !== null ? t('Enabled') : t('Enable')
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Button, {
                                            variant: !isValid && !!parsedAmounts[_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.CURRENCY_A */ .g.CURRENCY_A] && !!parsedAmounts[_state_burn_actions__WEBPACK_IMPORTED_MODULE_32__/* .Field.CURRENCY_B */ .g.CURRENCY_B] ? 'danger' : 'primary',
                                            onClick: ()=>{
                                                onPresentRemoveLiquidity();
                                            },
                                            width: "100%",
                                            disabled: !isValid || signatureData === null && approval !== _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_29__/* .ApprovalState.APPROVED */ .UK.APPROVED,
                                            children: error || t('Remove')
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                ]
            }),
            pair ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Layout_Column__WEBPACK_IMPORTED_MODULE_9__/* .AutoColumn */ .Tz, {
                style: {
                    minWidth: '20rem',
                    width: '100%',
                    maxWidth: '400px',
                    marginTop: '1rem'
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_PositionCard__WEBPACK_IMPORTED_MODULE_12__/* .MinimalPositionCard */ .W, {
                    showUnwrapped: oneCurrencyIsWETH,
                    pair: pair
                })
            }) : null
        ]
    }));
};

});

/***/ }),

/***/ 68454:
/***/ ((module) => {

module.exports = require("@binance-chain/bsc-connector");

/***/ }),

/***/ 6187:
/***/ ((module) => {

module.exports = require("@ethersproject/abi");

/***/ }),

/***/ 51541:
/***/ ((module) => {

module.exports = require("@ethersproject/address");

/***/ }),

/***/ 65757:
/***/ ((module) => {

module.exports = require("@ethersproject/bignumber");

/***/ }),

/***/ 49935:
/***/ ((module) => {

module.exports = require("@ethersproject/bytes");

/***/ }),

/***/ 26644:
/***/ ((module) => {

module.exports = require("@ethersproject/constants");

/***/ }),

/***/ 12792:
/***/ ((module) => {

module.exports = require("@ethersproject/contracts");

/***/ }),

/***/ 40750:
/***/ ((module) => {

module.exports = require("@ethersproject/hash");

/***/ }),

/***/ 90399:
/***/ ((module) => {

module.exports = require("@ethersproject/providers");

/***/ }),

/***/ 49213:
/***/ ((module) => {

module.exports = require("@ethersproject/strings");

/***/ }),

/***/ 93138:
/***/ ((module) => {

module.exports = require("@ethersproject/units");

/***/ }),

/***/ 42877:
/***/ ((module) => {

module.exports = require("@mdemouchy/sdk");

/***/ }),

/***/ 85360:
/***/ ((module) => {

module.exports = require("@next/env");

/***/ }),

/***/ 2829:
/***/ ((module) => {

module.exports = require("@pancakeswap/uikit");

/***/ }),

/***/ 75184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 58097:
/***/ ((module) => {

module.exports = require("@sentry/nextjs");

/***/ }),

/***/ 15427:
/***/ ((module) => {

module.exports = require("@sentry/react");

/***/ }),

/***/ 7248:
/***/ ((module) => {

module.exports = require("@snapshot-labs/snapshot.js");

/***/ }),

/***/ 51554:
/***/ ((module) => {

module.exports = require("@uniswap/token-lists");

/***/ }),

/***/ 18054:
/***/ ((module) => {

module.exports = require("@web3-react/core");

/***/ }),

/***/ 76590:
/***/ ((module) => {

module.exports = require("@web3-react/injected-connector");

/***/ }),

/***/ 9795:
/***/ ((module) => {

module.exports = require("@web3-react/walletconnect-connector");

/***/ }),

/***/ 75888:
/***/ ((module) => {

module.exports = require("ajv");

/***/ }),

/***/ 34215:
/***/ ((module) => {

module.exports = require("bignumber.js");

/***/ }),

/***/ 10899:
/***/ ((module) => {

module.exports = require("bignumber.js/bignumber");

/***/ }),

/***/ 18729:
/***/ ((module) => {

module.exports = require("cids");

/***/ }),

/***/ 74146:
/***/ ((module) => {

module.exports = require("date-fns");

/***/ }),

/***/ 64175:
/***/ ((module) => {

module.exports = require("fast-json-stable-stringify");

/***/ }),

/***/ 5805:
/***/ ((module) => {

module.exports = require("graphql-request");

/***/ }),

/***/ 90221:
/***/ ((module) => {

module.exports = require("lodash/chunk");

/***/ }),

/***/ 38190:
/***/ ((module) => {

module.exports = require("lodash/flatMap");

/***/ }),

/***/ 58579:
/***/ ((module) => {

module.exports = require("lodash/flatten");

/***/ }),

/***/ 1712:
/***/ ((module) => {

module.exports = require("lodash/get");

/***/ }),

/***/ 51546:
/***/ ((module) => {

module.exports = require("lodash/kebabCase");

/***/ }),

/***/ 63385:
/***/ ((module) => {

module.exports = require("lodash/keyBy");

/***/ }),

/***/ 11341:
/***/ ((module) => {

module.exports = require("lodash/maxBy");

/***/ }),

/***/ 61831:
/***/ ((module) => {

module.exports = require("lodash/merge");

/***/ }),

/***/ 49949:
/***/ ((module) => {

module.exports = require("lodash/orderBy");

/***/ }),

/***/ 64042:
/***/ ((module) => {

module.exports = require("lodash/range");

/***/ }),

/***/ 47657:
/***/ ((module) => {

module.exports = require("lodash/sample");

/***/ }),

/***/ 4354:
/***/ ((module) => {

module.exports = require("lodash/times");

/***/ }),

/***/ 16677:
/***/ ((module) => {

module.exports = require("multicodec");

/***/ }),

/***/ 63735:
/***/ ((module) => {

module.exports = require("multihashes");

/***/ }),

/***/ 54426:
/***/ ((module) => {

module.exports = require("next/dist/compiled/chalk");

/***/ }),

/***/ 40252:
/***/ ((module) => {

module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 19371:
/***/ ((module) => {

module.exports = require("next/dist/compiled/node-fetch");

/***/ }),

/***/ 97999:
/***/ ((module) => {

module.exports = require("next/dist/compiled/path-to-regexp");

/***/ }),

/***/ 60600:
/***/ ((module) => {

module.exports = require("next/dist/server/accept-header.js");

/***/ }),

/***/ 18612:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils.js");

/***/ }),

/***/ 60562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 94140:
/***/ ((module) => {

module.exports = require("next/dist/server/get-page-files.js");

/***/ }),

/***/ 89716:
/***/ ((module) => {

module.exports = require("next/dist/server/htmlescape.js");

/***/ }),

/***/ 25071:
/***/ ((module) => {

module.exports = require("next/dist/server/render-result.js");

/***/ }),

/***/ 33100:
/***/ ((module) => {

module.exports = require("next/dist/server/render.js");

/***/ }),

/***/ 92779:
/***/ ((module) => {

module.exports = require("next/dist/server/request-meta.js");

/***/ }),

/***/ 79502:
/***/ ((module) => {

module.exports = require("next/dist/server/send-payload.js");

/***/ }),

/***/ 76368:
/***/ ((module) => {

module.exports = require("next/dist/server/utils.js");

/***/ }),

/***/ 56724:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 27664:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/escape-regexp.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 82374:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-locale-cookie.js");

/***/ }),

/***/ 34014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 78524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 95832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 78020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 29565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 64365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 95714:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-route-from-asset-path.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 91292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 25753:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-match.js");

/***/ }),

/***/ 99521:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/prepare-destination.js");

/***/ }),

/***/ 80979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 36052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 84226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 95566:
/***/ ((module) => {

module.exports = require("next/error");

/***/ }),

/***/ 40968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 71853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 4780:
/***/ ((module) => {

module.exports = require("next/script");

/***/ }),

/***/ 59819:
/***/ ((module) => {

module.exports = require("querystring");

/***/ }),

/***/ 16689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 84466:
/***/ ((module) => {

module.exports = require("react-transition-group");

/***/ }),

/***/ 80551:
/***/ ((module) => {

module.exports = require("react-window");

/***/ }),

/***/ 20997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 14161:
/***/ ((module) => {

module.exports = require("redux-persist");

/***/ }),

/***/ 61127:
/***/ ((module) => {

module.exports = require("redux-persist/integration/react");

/***/ }),

/***/ 98936:
/***/ ((module) => {

module.exports = require("redux-persist/lib/storage");

/***/ }),

/***/ 57518:
/***/ ((module) => {

module.exports = require("styled-components");

/***/ }),

/***/ 84269:
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ 15941:
/***/ ((module) => {

module.exports = import("swr");;

/***/ }),

/***/ 79847:
/***/ ((module) => {

module.exports = import("swr/immutable");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9635,2151,1228,2402,7010,4796,1721,6323,7904], () => (__webpack_exec__(68914)));
module.exports = __webpack_exports__;

})();
//# sourceMappingURL=[[...currency]].js.map