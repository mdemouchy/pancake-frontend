"use strict";
(() => {
var exports = {};
exports.id = 861;
exports.ids = [861];
exports.modules = {

/***/ 50427:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "unstable_getStaticParams": () => (/* binding */ unstable_getStaticParams),
/* harmony export */   "unstable_getStaticProps": () => (/* binding */ unstable_getStaticProps),
/* harmony export */   "unstable_getStaticPaths": () => (/* binding */ unstable_getStaticPaths),
/* harmony export */   "unstable_getServerProps": () => (/* binding */ unstable_getServerProps),
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "_app": () => (/* binding */ _app),
/* harmony export */   "renderReqToHTML": () => (/* binding */ renderReqToHTML),
/* harmony export */   "render": () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(70607);
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59450);
/* harmony import */ var private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97020);
/* harmony import */ var private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(73978);
/* harmony import */ var next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99436);

      
      
      
      

      
      const { processEnv } = __webpack_require__(85360)
      processEnv([{"path":".env.production","contents":"NEXT_PUBLIC_CHAIN_ID = \"1666700000\"\nNEXT_PUBLIC_GTAG = \"GTM-PXLD3XW\"\n\n# 10+ nodes balanced, US/EU\nNEXT_PUBLIC_NODE_1 = \"https://api.s0.b.hmny.io\"\n\n# 10+ nodes balanced, US/EU\nNEXT_PUBLIC_NODE_2 = \"https://api.s0.b.hmny.io\"\n\n# 10+ nodes balanced in each region, global\nNEXT_PUBLIC_NODE_3 = \"https://api.s0.b.hmny.io\"\n\n# Google Cloud Infrastructure Endpoint - Global\n#NEXT_PUBLIC_NODE_PRODUCTION = \"https://nodes.pancakeswap.com\"\n\nNEXT_PUBLIC_GRAPH_API_PROFILE = \"https://api.thegraph.com/subgraphs/name/pancakeswap/profile\"\nNEXT_PUBLIC_GRAPH_API_PREDICTION = \"https://api.thegraph.com/subgraphs/name/pancakeswap/prediction-v2\"\nNEXT_PUBLIC_GRAPH_API_LOTTERY = \"https://api.thegraph.com/subgraphs/name/pancakeswap/lottery\"\nNEXT_PUBLIC_GRAPH_API_NFT_MARKET = \"https://api.thegraph.com/subgraphs/name/pancakeswap/nft-market\"\n\nNEXT_PUBLIC_SNAPSHOT_BASE_URL = \"https://hub.snapshot.org\"\nNEXT_PUBLIC_SNAPSHOT_VOTING_API = \"https://voting-api.pancakeswap.info/api\"\n\nNEXT_PUBLIC_API_NFT = \"https://nft.pancakeswap.com/api/v1\"\nNEXT_PUBLIC_BIT_QUERY_ENDPOINT = \"https://graphql.bitquery.io\"\n"},{"path":".env","contents":"NEXT_PUBLIC_API_PROFILE = https://profile.pancakeswap.com"}])
    
      
      const runtimeConfig = {}
      ;

      const documentModule = __webpack_require__(85641)

      const appMod = __webpack_require__(12957)
      let App = appMod.default || appMod.then && appMod.then(mod => mod.default);

      const compMod = __webpack_require__(20430)

      const Component = compMod.default || compMod.then && compMod.then(mod => mod.default)
      /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Component);
      const getStaticProps = compMod['getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['getStaticProp' + 's'])
      const getStaticPaths = compMod['getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['getStaticPath' + 's'])
      const getServerSideProps = compMod['getServerSideProp' + 's'] || compMod.then && compMod.then(mod => mod['getServerSideProp' + 's'])

      // kept for detecting legacy exports
      const unstable_getStaticParams = compMod['unstable_getStaticParam' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticParam' + 's'])
      const unstable_getStaticProps = compMod['unstable_getStaticProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticProp' + 's'])
      const unstable_getStaticPaths = compMod['unstable_getStaticPath' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getStaticPath' + 's'])
      const unstable_getServerProps = compMod['unstable_getServerProp' + 's'] || compMod.then && compMod.then(mod => mod['unstable_getServerProp' + 's'])

      let config = compMod['confi' + 'g'] || (compMod.then && compMod.then(mod => mod['confi' + 'g'])) || {}
      const _app = App

      const combinedRewrites = Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)
        ? private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg
        : []

      if (!Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)) {
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.beforeFiles */ .Dg.beforeFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.afterFiles */ .Dg.afterFiles)
        combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.fallback */ .Dg.fallback)
      }

      const { renderReqToHTML, render } = (0,next_dist_build_webpack_loaders_next_serverless_loader_page_handler__WEBPACK_IMPORTED_MODULE_4__/* .getPageHandler */ .u)({
        pageModule: compMod,
        pageComponent: Component,
        pageConfig: config,
        appModule: App,
        documentModule: documentModule,
        errorModule: __webpack_require__(54141),
        notFoundModule: __webpack_require__(59622),
        pageGetStaticProps: getStaticProps,
        pageGetStaticPaths: getStaticPaths,
        pageGetServerSideProps: getServerSideProps,

        assetPrefix: "",
        canonicalBase: "",
        generateEtags: true,
        poweredByHeader: true,

        runtimeConfig,
        buildManifest: private_dot_next_build_manifest_json__WEBPACK_IMPORTED_MODULE_2__,
        reactLoadableManifest: private_dot_next_react_loadable_manifest_json__WEBPACK_IMPORTED_MODULE_3__,

        rewrites: combinedRewrites,
        i18n: undefined,
        page: "/info/tokens/[address]",
        buildId: "pA0qXx8N8yV4x51Q8eKRJ",
        escapedBuildId: "pA0qXx8N8yV4x51Q8eKRJ",
        basePath: "",
        pageIsDynamic: true,
        encodedPreviewProps: {previewModeId:"4be1d5f31f1c05ab7d94512e7c5324a6",previewModeSigningKey:"bc6aa2b2074ecf664cef37e2cf2b9a8c7f10e81a4e58b764ce70d78163ce2360",previewModeEncryptionKey:"620945a7ce3f1dee81153e4e394922ca059a150870ea548250af9ef14ef4d062"}
      })
      
    

/***/ }),

/***/ 20430:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var views_Info_Tokens_TokenPage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7028);
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(38328);
/* harmony import */ var views_Info__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(70095);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([views_Info__WEBPACK_IMPORTED_MODULE_4__, views_Info_Tokens_TokenPage__WEBPACK_IMPORTED_MODULE_2__]);
([views_Info__WEBPACK_IMPORTED_MODULE_4__, views_Info_Tokens_TokenPage__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);





const TokenPage = ({ address  })=>{
    if (!address) {
        return null;
    }
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(views_Info_Tokens_TokenPage__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        routeAddress: address
    }));
};
TokenPage.Layout = views_Info__WEBPACK_IMPORTED_MODULE_4__/* .InfoPageLayout */ .O;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TokenPage);
const getStaticPaths = ()=>{
    return {
        paths: [],
        fallback: true
    };
};
const getStaticProps = async ({ params  })=>{
    const address = params?.address;
    // In case somebody pastes checksummed address into url (since GraphQL expects lowercase address)
    if (!address || !(0,utils__WEBPACK_IMPORTED_MODULE_3__/* .isAddress */ .UJ)(String(address).toLowerCase())) {
        return {
            redirect: {
                destination: '/',
                permanent: false
            }
        };
    }
    return {
        props: {
            address
        }
    };
};

});

/***/ }),

/***/ 7028:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_NextLink__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(53629);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var components_Layout_Page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9770);
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(38328);
/* harmony import */ var utils_truncateHash__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(53467);
/* harmony import */ var views_Info_hooks_useCMCLink__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4720);
/* harmony import */ var views_Info_components_CurrencyLogo__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(60764);
/* harmony import */ var views_Info_utils_formatInfoNumbers__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(83589);
/* harmony import */ var views_Info_components_Percent__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(37795);
/* harmony import */ var views_Info_components_SaveIcon__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(53614);
/* harmony import */ var state_info_hooks__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(53985);
/* harmony import */ var views_Info_components_InfoTables_PoolsTable__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(994);
/* harmony import */ var views_Info_components_InfoTables_TransactionsTable__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(85943);
/* harmony import */ var state_user_hooks__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(68605);
/* harmony import */ var config_constants_info__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(4003);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(99150);
/* harmony import */ var views_Info_components_InfoCharts_ChartCard__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(5004);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([views_Info_components_InfoCharts_ChartCard__WEBPACK_IMPORTED_MODULE_17__, views_Info_components_SaveIcon__WEBPACK_IMPORTED_MODULE_11__, components_Layout_Page__WEBPACK_IMPORTED_MODULE_5__, state_user_hooks__WEBPACK_IMPORTED_MODULE_15__]);
([views_Info_components_InfoCharts_ChartCard__WEBPACK_IMPORTED_MODULE_17__, views_Info_components_SaveIcon__WEBPACK_IMPORTED_MODULE_11__, components_Layout_Page__WEBPACK_IMPORTED_MODULE_5__, state_user_hooks__WEBPACK_IMPORTED_MODULE_15__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);

/* eslint-disable no-nested-ternary */ 


















const ContentLayout = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
    componentId: "sc-4f3c89b-0"
})`
  margin-top: 16px;
  display: grid;
  grid-template-columns: 260px 1fr;
  grid-gap: 1em;
  @media screen and (max-width: 800px) {
    grid-template-columns: 1fr;
    grid-template-rows: 1fr 1fr;
  }
`;
const StyledCMCLink = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Link).withConfig({
    componentId: "sc-4f3c89b-1"
})`
  width: 24px;
  height: 24px;
  margin-right: 8px;

  & :hover {
    opacity: 0.8;
  }
`;
const DEFAULT_TIME_WINDOW = {
    weeks: 1
};
const TokenPage = ({ routeAddress  })=>{
    const { isXs , isSm  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.useMatchBreakpoints)();
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_16__/* .useTranslation */ .$G)();
    // In case somebody pastes checksummed address into url (since GraphQL expects lowercase address)
    const address = routeAddress.toLowerCase();
    const cmcLink = (0,views_Info_hooks_useCMCLink__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)(address);
    const tokenData = (0,state_info_hooks__WEBPACK_IMPORTED_MODULE_12__/* .useTokenData */ .Ws)(address);
    const poolsForToken = (0,state_info_hooks__WEBPACK_IMPORTED_MODULE_12__/* .usePoolsForToken */ .CN)(address);
    const poolDatas = (0,state_info_hooks__WEBPACK_IMPORTED_MODULE_12__/* .usePoolDatas */ .zV)(poolsForToken ?? []);
    const transactions = (0,state_info_hooks__WEBPACK_IMPORTED_MODULE_12__/* .useTokenTransactions */ .Vq)(address);
    const chartData = (0,state_info_hooks__WEBPACK_IMPORTED_MODULE_12__/* .useTokenChartData */ .ku)(address);
    // pricing data
    const priceData = (0,state_info_hooks__WEBPACK_IMPORTED_MODULE_12__/* .useTokenPriceData */ .Q4)(address, config_constants_info__WEBPACK_IMPORTED_MODULE_18__/* .ONE_HOUR_SECONDS */ .Tb, DEFAULT_TIME_WINDOW);
    const adjustedPriceData = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        // Include latest available price
        if (priceData && tokenData && priceData.length > 0) {
            return [
                ...priceData,
                {
                    time: new Date().getTime() / 1000,
                    open: priceData[priceData.length - 1].close,
                    close: tokenData?.priceUSD,
                    high: tokenData?.priceUSD,
                    low: priceData[priceData.length - 1].close
                }, 
            ];
        }
        return undefined;
    }, [
        priceData,
        tokenData
    ]);
    const [watchlistTokens, addWatchlistToken] = (0,state_user_hooks__WEBPACK_IMPORTED_MODULE_15__/* .useWatchlistTokens */ .z6)();
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Layout_Page__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
        symbol: tokenData?.symbol,
        children: tokenData ? !tokenData.exists ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Card, {
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Box, {
                p: "16px",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                    children: [
                        t('No pool has been created with this token yet. Create one'),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_NextLink__WEBPACK_IMPORTED_MODULE_2__/* .NextLinkFromReactRouter */ .a, {
                            style: {
                                display: 'inline',
                                marginLeft: '6px'
                            },
                            to: `/add/${address}`,
                            children: t('here.')
                        })
                    ]
                })
            })
        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Flex, {
                    justifyContent: "space-between",
                    mb: "24px",
                    flexDirection: [
                        'column',
                        'column',
                        'row'
                    ],
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Breadcrumbs, {
                            mb: "32px",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_NextLink__WEBPACK_IMPORTED_MODULE_2__/* .NextLinkFromReactRouter */ .a, {
                                    to: "/info",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                                        color: "primary",
                                        children: t('Info')
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_NextLink__WEBPACK_IMPORTED_MODULE_2__/* .NextLinkFromReactRouter */ .a, {
                                    to: "/info/tokens",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                                        color: "primary",
                                        children: t('Tokens')
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Flex, {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                                            mr: "8px",
                                            children: tokenData.symbol
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                                            children: `(${(0,utils_truncateHash__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z)(address)})`
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Flex, {
                            justifyContent: [
                                null,
                                null,
                                'flex-end'
                            ],
                            mt: [
                                '8px',
                                '8px',
                                0
                            ],
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.LinkExternal, {
                                    mr: "8px",
                                    color: "primary",
                                    href: (0,utils__WEBPACK_IMPORTED_MODULE_6__/* .getBscScanLink */ .s6)(address, 'address'),
                                    children: t('View on BscScan')
                                }),
                                cmcLink && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledCMCLink, {
                                    href: cmcLink,
                                    rel: "noopener noreferrer nofollow",
                                    target: "_blank",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Image, {
                                        src: "/images/CMC-logo.svg",
                                        height: 22,
                                        width: 22,
                                        alt: t('View token on CoinMarketCap')
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(views_Info_components_SaveIcon__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                    fill: watchlistTokens.includes(address),
                                    onClick: ()=>addWatchlistToken(address)
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Flex, {
                    justifyContent: "space-between",
                    flexDirection: [
                        'column',
                        'column',
                        'column',
                        'row'
                    ],
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Flex, {
                            flexDirection: "column",
                            mb: [
                                '8px',
                                null
                            ],
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Flex, {
                                    alignItems: "center",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(views_Info_components_CurrencyLogo__WEBPACK_IMPORTED_MODULE_8__/* .CurrencyLogo */ .X, {
                                            size: "32px",
                                            address: address
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                                            ml: "12px",
                                            bold: true,
                                            lineHeight: "0.7",
                                            fontSize: isXs || isSm ? '24px' : '40px',
                                            id: "info-token-name-title",
                                            children: tokenData.name
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                                            ml: "12px",
                                            lineHeight: "1",
                                            color: "textSubtle",
                                            fontSize: isXs || isSm ? '14px' : '20px',
                                            children: [
                                                "(",
                                                tokenData.symbol,
                                                ")"
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Flex, {
                                    mt: "8px",
                                    ml: "46px",
                                    alignItems: "center",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                                            mr: "16px",
                                            bold: true,
                                            fontSize: "24px",
                                            children: [
                                                "$",
                                                (0,views_Info_utils_formatInfoNumbers__WEBPACK_IMPORTED_MODULE_9__/* .formatAmount */ .d)(tokenData.priceUSD, {
                                                    notation: 'standard'
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(views_Info_components_Percent__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                            value: tokenData.priceUSDChange,
                                            fontWeight: 600
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Flex, {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_NextLink__WEBPACK_IMPORTED_MODULE_2__/* .NextLinkFromReactRouter */ .a, {
                                    to: `/add/${address}`,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Button, {
                                        mr: "8px",
                                        variant: "secondary",
                                        children: t('Add Liquidity')
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_NextLink__WEBPACK_IMPORTED_MODULE_2__/* .NextLinkFromReactRouter */ .a, {
                                    to: `/swap?inputCurrency=${address}`,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Button, {
                                        children: t('Trade')
                                    })
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ContentLayout, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Card, {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Box, {
                                p: "24px",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                                        bold: true,
                                        small: true,
                                        color: "secondary",
                                        fontSize: "12px",
                                        textTransform: "uppercase",
                                        children: t('Liquidity')
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                                        bold: true,
                                        fontSize: "24px",
                                        children: [
                                            "$",
                                            (0,views_Info_utils_formatInfoNumbers__WEBPACK_IMPORTED_MODULE_9__/* .formatAmount */ .d)(tokenData.liquidityUSD)
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(views_Info_components_Percent__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                        value: tokenData.liquidityUSDChange
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                                        mt: "24px",
                                        bold: true,
                                        color: "secondary",
                                        fontSize: "12px",
                                        textTransform: "uppercase",
                                        children: t('Volume 24H')
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                                        bold: true,
                                        fontSize: "24px",
                                        textTransform: "uppercase",
                                        children: [
                                            "$",
                                            (0,views_Info_utils_formatInfoNumbers__WEBPACK_IMPORTED_MODULE_9__/* .formatAmount */ .d)(tokenData.volumeUSD)
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(views_Info_components_Percent__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                        value: tokenData.volumeUSDChange
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                                        mt: "24px",
                                        bold: true,
                                        color: "secondary",
                                        fontSize: "12px",
                                        textTransform: "uppercase",
                                        children: t('Volume 7D')
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                                        bold: true,
                                        fontSize: "24px",
                                        children: [
                                            "$",
                                            (0,views_Info_utils_formatInfoNumbers__WEBPACK_IMPORTED_MODULE_9__/* .formatAmount */ .d)(tokenData.volumeUSDWeek)
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                                        mt: "24px",
                                        bold: true,
                                        color: "secondary",
                                        fontSize: "12px",
                                        textTransform: "uppercase",
                                        children: t('Transactions 24H')
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                                        bold: true,
                                        fontSize: "24px",
                                        children: (0,views_Info_utils_formatInfoNumbers__WEBPACK_IMPORTED_MODULE_9__/* .formatAmount */ .d)(tokenData.txCount, {
                                            isInteger: true
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(views_Info_components_InfoCharts_ChartCard__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                            variant: "token",
                            chartData: chartData,
                            tokenData: tokenData,
                            tokenPriceData: adjustedPriceData
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Heading, {
                    scale: "lg",
                    mb: "16px",
                    mt: "40px",
                    children: t('Pools')
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(views_Info_components_InfoTables_PoolsTable__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                    poolDatas: poolDatas
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Heading, {
                    scale: "lg",
                    mb: "16px",
                    mt: "40px",
                    children: t('Transactions')
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(views_Info_components_InfoTables_TransactionsTable__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                    transactions: transactions
                })
            ]
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Flex, {
            mt: "80px",
            justifyContent: "center",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Spinner, {})
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TokenPage);

});

/***/ }),

/***/ 4720:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

// endpoint to check asset exists and get url to CMC page
// returns 400 status code if token is not on CMC
const CMC_ENDPOINT = 'https://3rdparty-apis.coinmarketcap.com/v1/cryptocurrency/contract?address=';
/**
 * Check if asset exists on CMC, if exists
 * return  url, if not return undefined
 * @param address token address (all lowercase, checksummed are not supported by CMC)
 */ const useCMCLink = (address)=>{
    const { 0: cmcPageUrl , 1: setCMCPageUrl  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(undefined);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        const fetchLink = async ()=>{
            const result = await fetch(`${CMC_ENDPOINT}${address}`);
            // if link exists, format the url
            if (result.status === 200) {
                result.json().then(({ data  })=>{
                    setCMCPageUrl(data.url);
                });
            }
        };
        if (address) {
            fetchLink();
        }
    }, [
        address
    ]);
    return cmcPageUrl;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useCMCLink);


/***/ }),

/***/ 68454:
/***/ ((module) => {

module.exports = require("@binance-chain/bsc-connector");

/***/ }),

/***/ 6187:
/***/ ((module) => {

module.exports = require("@ethersproject/abi");

/***/ }),

/***/ 51541:
/***/ ((module) => {

module.exports = require("@ethersproject/address");

/***/ }),

/***/ 65757:
/***/ ((module) => {

module.exports = require("@ethersproject/bignumber");

/***/ }),

/***/ 49935:
/***/ ((module) => {

module.exports = require("@ethersproject/bytes");

/***/ }),

/***/ 26644:
/***/ ((module) => {

module.exports = require("@ethersproject/constants");

/***/ }),

/***/ 12792:
/***/ ((module) => {

module.exports = require("@ethersproject/contracts");

/***/ }),

/***/ 40750:
/***/ ((module) => {

module.exports = require("@ethersproject/hash");

/***/ }),

/***/ 90399:
/***/ ((module) => {

module.exports = require("@ethersproject/providers");

/***/ }),

/***/ 49213:
/***/ ((module) => {

module.exports = require("@ethersproject/strings");

/***/ }),

/***/ 93138:
/***/ ((module) => {

module.exports = require("@ethersproject/units");

/***/ }),

/***/ 42877:
/***/ ((module) => {

module.exports = require("@mdemouchy/sdk");

/***/ }),

/***/ 85360:
/***/ ((module) => {

module.exports = require("@next/env");

/***/ }),

/***/ 2829:
/***/ ((module) => {

module.exports = require("@pancakeswap/uikit");

/***/ }),

/***/ 75184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 58097:
/***/ ((module) => {

module.exports = require("@sentry/nextjs");

/***/ }),

/***/ 15427:
/***/ ((module) => {

module.exports = require("@sentry/react");

/***/ }),

/***/ 7248:
/***/ ((module) => {

module.exports = require("@snapshot-labs/snapshot.js");

/***/ }),

/***/ 51554:
/***/ ((module) => {

module.exports = require("@uniswap/token-lists");

/***/ }),

/***/ 18054:
/***/ ((module) => {

module.exports = require("@web3-react/core");

/***/ }),

/***/ 76590:
/***/ ((module) => {

module.exports = require("@web3-react/injected-connector");

/***/ }),

/***/ 9795:
/***/ ((module) => {

module.exports = require("@web3-react/walletconnect-connector");

/***/ }),

/***/ 75888:
/***/ ((module) => {

module.exports = require("ajv");

/***/ }),

/***/ 34215:
/***/ ((module) => {

module.exports = require("bignumber.js");

/***/ }),

/***/ 10899:
/***/ ((module) => {

module.exports = require("bignumber.js/bignumber");

/***/ }),

/***/ 18729:
/***/ ((module) => {

module.exports = require("cids");

/***/ }),

/***/ 74146:
/***/ ((module) => {

module.exports = require("date-fns");

/***/ }),

/***/ 64175:
/***/ ((module) => {

module.exports = require("fast-json-stable-stringify");

/***/ }),

/***/ 5805:
/***/ ((module) => {

module.exports = require("graphql-request");

/***/ }),

/***/ 90221:
/***/ ((module) => {

module.exports = require("lodash/chunk");

/***/ }),

/***/ 38190:
/***/ ((module) => {

module.exports = require("lodash/flatMap");

/***/ }),

/***/ 58579:
/***/ ((module) => {

module.exports = require("lodash/flatten");

/***/ }),

/***/ 1712:
/***/ ((module) => {

module.exports = require("lodash/get");

/***/ }),

/***/ 51546:
/***/ ((module) => {

module.exports = require("lodash/kebabCase");

/***/ }),

/***/ 63385:
/***/ ((module) => {

module.exports = require("lodash/keyBy");

/***/ }),

/***/ 11341:
/***/ ((module) => {

module.exports = require("lodash/maxBy");

/***/ }),

/***/ 61831:
/***/ ((module) => {

module.exports = require("lodash/merge");

/***/ }),

/***/ 49949:
/***/ ((module) => {

module.exports = require("lodash/orderBy");

/***/ }),

/***/ 64042:
/***/ ((module) => {

module.exports = require("lodash/range");

/***/ }),

/***/ 47657:
/***/ ((module) => {

module.exports = require("lodash/sample");

/***/ }),

/***/ 4354:
/***/ ((module) => {

module.exports = require("lodash/times");

/***/ }),

/***/ 16677:
/***/ ((module) => {

module.exports = require("multicodec");

/***/ }),

/***/ 63735:
/***/ ((module) => {

module.exports = require("multihashes");

/***/ }),

/***/ 54426:
/***/ ((module) => {

module.exports = require("next/dist/compiled/chalk");

/***/ }),

/***/ 40252:
/***/ ((module) => {

module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 19371:
/***/ ((module) => {

module.exports = require("next/dist/compiled/node-fetch");

/***/ }),

/***/ 97999:
/***/ ((module) => {

module.exports = require("next/dist/compiled/path-to-regexp");

/***/ }),

/***/ 60600:
/***/ ((module) => {

module.exports = require("next/dist/server/accept-header.js");

/***/ }),

/***/ 18612:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils.js");

/***/ }),

/***/ 60562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 94140:
/***/ ((module) => {

module.exports = require("next/dist/server/get-page-files.js");

/***/ }),

/***/ 89716:
/***/ ((module) => {

module.exports = require("next/dist/server/htmlescape.js");

/***/ }),

/***/ 25071:
/***/ ((module) => {

module.exports = require("next/dist/server/render-result.js");

/***/ }),

/***/ 33100:
/***/ ((module) => {

module.exports = require("next/dist/server/render.js");

/***/ }),

/***/ 92779:
/***/ ((module) => {

module.exports = require("next/dist/server/request-meta.js");

/***/ }),

/***/ 79502:
/***/ ((module) => {

module.exports = require("next/dist/server/send-payload.js");

/***/ }),

/***/ 76368:
/***/ ((module) => {

module.exports = require("next/dist/server/utils.js");

/***/ }),

/***/ 56724:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 27664:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/escape-regexp.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 82374:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-locale-cookie.js");

/***/ }),

/***/ 34014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 78524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 95832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 78020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 29565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 64365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 95714:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-route-from-asset-path.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 91292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 25753:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-match.js");

/***/ }),

/***/ 99521:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/prepare-destination.js");

/***/ }),

/***/ 80979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 36052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 84226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 95566:
/***/ ((module) => {

module.exports = require("next/error");

/***/ }),

/***/ 40968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 71853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 4780:
/***/ ((module) => {

module.exports = require("next/script");

/***/ }),

/***/ 88032:
/***/ ((module) => {

module.exports = require("numeral");

/***/ }),

/***/ 59819:
/***/ ((module) => {

module.exports = require("querystring");

/***/ }),

/***/ 16689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 84466:
/***/ ((module) => {

module.exports = require("react-transition-group");

/***/ }),

/***/ 20997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 23655:
/***/ ((module) => {

module.exports = require("recharts");

/***/ }),

/***/ 14161:
/***/ ((module) => {

module.exports = require("redux-persist");

/***/ }),

/***/ 61127:
/***/ ((module) => {

module.exports = require("redux-persist/integration/react");

/***/ }),

/***/ 98936:
/***/ ((module) => {

module.exports = require("redux-persist/lib/storage");

/***/ }),

/***/ 57518:
/***/ ((module) => {

module.exports = require("styled-components");

/***/ }),

/***/ 84269:
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ 15941:
/***/ ((module) => {

module.exports = import("swr");;

/***/ }),

/***/ 79847:
/***/ ((module) => {

module.exports = import("swr/immutable");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9635,2151,3589,1254,6631,4838,994,7041,5004], () => (__webpack_exec__(50427)));
module.exports = __webpack_exports__;

})();
//# sourceMappingURL=[address].js.map