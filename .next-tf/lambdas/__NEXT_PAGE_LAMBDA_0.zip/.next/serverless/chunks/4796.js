"use strict";
exports.id = 4796;
exports.ids = [4796];
exports.modules = {

/***/ 70209:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ AppBody)
/* harmony export */ });
/* unused harmony export BodyWrapper */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);




const BodyWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Card).withConfig({
    componentId: "sc-ea9abdc9-0"
})`
  border-radius: 24px;
  max-width: 436px;
  width: 100%;
  z-index: 1;
`;
/**
 * The styled container element that wraps the content of most pages and the tabs.
 */ function AppBody({ children  }) {
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(BodyWrapper, {
        children: children
    }));
};


/***/ }),

/***/ 83875:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var state_user_hooks__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(68605);
/* harmony import */ var components_Menu_GlobalSettings__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(24339);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(41664);
/* harmony import */ var _Transactions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(70311);
/* harmony import */ var _QuestionHelper__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(45061);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([components_Menu_GlobalSettings__WEBPACK_IMPORTED_MODULE_5__, state_user_hooks__WEBPACK_IMPORTED_MODULE_4__]);
([components_Menu_GlobalSettings__WEBPACK_IMPORTED_MODULE_5__, state_user_hooks__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);









const AppHeaderContainer = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex).withConfig({
    componentId: "sc-1a3d0ce4-0"
})`
  align-items: center;
  justify-content: space-between;
  padding: 24px;
  width: 100%;
  border-bottom: 1px solid ${({ theme  })=>theme.colors.cardBorder
};
`;
const AppHeader = ({ title , subtitle , helper , backTo , noConfig =false  })=>{
    const [expertMode] = (0,state_user_hooks__WEBPACK_IMPORTED_MODULE_4__/* .useExpertModeManager */ .DG)();
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(AppHeaderContainer, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                alignItems: "center",
                mr: noConfig ? 0 : '16px',
                children: [
                    backTo && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_6__["default"], {
                        passHref: true,
                        href: backTo,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.IconButton, {
                            as: "a",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.ArrowBackIcon, {
                                width: "32px"
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                        flexDirection: "column",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Heading, {
                                as: "h2",
                                mb: "8px",
                                children: title
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                                alignItems: "center",
                                children: [
                                    helper && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_QuestionHelper__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                        text: helper,
                                        mr: "4px",
                                        placement: "top-start"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                        color: "textSubtle",
                                        fontSize: "14px",
                                        children: subtitle
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            !noConfig && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                alignItems: "center",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.NotificationDot, {
                        show: expertMode,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Menu_GlobalSettings__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Transactions__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {})
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AppHeader);

});

/***/ }),

/***/ 86921:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Transactions_TransactionsModal)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
// EXTERNAL MODULE: ./src/hooks/useActiveWeb3React.ts
var useActiveWeb3React = __webpack_require__(64011);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: external "@pancakeswap/uikit"
var uikit_ = __webpack_require__(2829);
// EXTERNAL MODULE: ./src/contexts/Localization/index.tsx + 3 modules
var Localization = __webpack_require__(99150);
// EXTERNAL MODULE: external "lodash/orderBy"
var orderBy_ = __webpack_require__(49949);
var orderBy_default = /*#__PURE__*/__webpack_require__.n(orderBy_);
// EXTERNAL MODULE: ./src/state/transactions/hooks.tsx
var hooks = __webpack_require__(55892);
// EXTERNAL MODULE: ./src/state/transactions/actions.ts
var actions = __webpack_require__(81564);
// EXTERNAL MODULE: ./src/components/Layout/Row.tsx
var Row = __webpack_require__(39475);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(57518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: ./src/utils/index.ts + 1 modules
var utils = __webpack_require__(38328);
// EXTERNAL MODULE: ./src/components/Loader/CircleLoader.tsx
var CircleLoader = __webpack_require__(7010);
;// CONCATENATED MODULE: ./src/components/App/Transactions/Transaction.tsx







const TransactionState = external_styled_components_default().div.withConfig({
    componentId: "sc-948fadb0-0"
})`
  display: flex;
  justify-content: space-between;
  align-items: center;
  text-decoration: none !important;
  border-radius: 0.5rem;
  padding: 0.25rem 0rem;
  font-weight: 500;
  font-size: 0.825rem;
  color: ${({ theme  })=>theme.colors.primary
};
`;
const IconWrapper = external_styled_components_default().div.withConfig({
    componentId: "sc-948fadb0-1"
})`
  color: ${({ pending , success , theme  })=>pending ? theme.colors.primary : success ? theme.colors.success : theme.colors.failure
};
`;
function Transaction({ tx  }) {
    const { chainId  } = (0,useActiveWeb3React/* default */.Z)();
    const summary = tx?.summary;
    const pending = !tx?.receipt;
    const success = !pending && tx && (tx.receipt?.status === 1 || typeof tx.receipt?.status === 'undefined');
    if (!chainId) return null;
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(TransactionState, {
        pending: pending,
        success: success,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(uikit_.LinkExternal, {
                href: (0,utils/* getBscScanLink */.s6)(tx.hash, 'transaction', chainId),
                children: summary ?? tx.hash
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(IconWrapper, {
                pending: pending,
                success: success,
                children: pending ? /*#__PURE__*/ jsx_runtime_.jsx(CircleLoader/* default */.Z, {}) : success ? /*#__PURE__*/ jsx_runtime_.jsx(uikit_.CheckmarkIcon, {
                    color: "success"
                }) : /*#__PURE__*/ jsx_runtime_.jsx(uikit_.CloseIcon, {
                    color: "failure"
                })
            })
        ]
    }));
};

// EXTERNAL MODULE: ./src/components/ConnectWalletButton.tsx
var ConnectWalletButton = __webpack_require__(30621);
;// CONCATENATED MODULE: ./src/components/App/Transactions/TransactionsModal.tsx












function renderTransactions(transactions) {
    return(/*#__PURE__*/ jsx_runtime_.jsx(uikit_.Flex, {
        flexDirection: "column",
        children: transactions.map((tx)=>{
            return(/*#__PURE__*/ jsx_runtime_.jsx(Transaction, {
                tx: tx
            }, tx.hash + tx.addedTime));
        })
    }));
}
const TransactionsModal = ({ onDismiss  })=>{
    const { account , chainId  } = (0,useActiveWeb3React/* default */.Z)();
    const dispatch = (0,external_react_redux_.useDispatch)();
    const allTransactions = (0,hooks/* useAllTransactions */.kf)();
    const { t  } = (0,Localization/* useTranslation */.$G)();
    const sortedRecentTransactions = orderBy_default()(Object.values(allTransactions).filter(hooks/* isTransactionRecent */.mH), 'addedTime', 'desc');
    const pending = sortedRecentTransactions.filter((tx)=>!tx.receipt
    );
    const confirmed = sortedRecentTransactions.filter((tx)=>tx.receipt
    );
    const clearAllTransactionsCallback = (0,external_react_.useCallback)(()=>{
        if (chainId) dispatch((0,actions/* clearAllTransactions */.fY)({
            chainId
        }));
    }, [
        dispatch,
        chainId
    ]);
    return(/*#__PURE__*/ jsx_runtime_.jsx(uikit_.Modal, {
        title: t('Recent Transactions'),
        headerBackground: "gradients.cardHeader",
        onDismiss: onDismiss,
        children: account ? /*#__PURE__*/ jsx_runtime_.jsx(uikit_.ModalBody, {
            children: !!pending.length || !!confirmed.length ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Row/* AutoRow */.BA, {
                        mb: "1rem",
                        style: {
                            justifyContent: 'space-between'
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Text, {
                                children: t('Recent Transactions')
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Button, {
                                variant: "tertiary",
                                scale: "xs",
                                onClick: clearAllTransactionsCallback,
                                children: t('clear all')
                            })
                        ]
                    }),
                    renderTransactions(pending),
                    renderTransactions(confirmed)
                ]
            }) : /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Text, {
                children: t('No recent transactions')
            })
        }) : /*#__PURE__*/ jsx_runtime_.jsx(ConnectWalletButton/* default */.Z, {})
    }));
};
/* harmony default export */ const Transactions_TransactionsModal = (TransactionsModal);


/***/ }),

/***/ 70311:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _TransactionsModal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(86921);




const Transactions = ()=>{
    const [onPresentTransactionsModal] = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.useModal)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TransactionsModal__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}));
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
            variant: "text",
            p: 0,
            onClick: onPresentTransactionsModal,
            ml: "16px",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.HistoryIcon, {
                color: "textSubtle",
                width: "24px"
            })
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Transactions);


/***/ }),

/***/ 85101:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "t": () => (/* reexport safe */ _AppHeader__WEBPACK_IMPORTED_MODULE_0__.Z),
/* harmony export */   "j": () => (/* reexport safe */ _AppBody__WEBPACK_IMPORTED_MODULE_1__.Z)
/* harmony export */ });
/* harmony import */ var _AppHeader__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(83875);
/* harmony import */ var _AppBody__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(70209);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_AppHeader__WEBPACK_IMPORTED_MODULE_0__]);
_AppHeader__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];



});

/***/ }),

/***/ 36261:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "hl": () => (/* binding */ LightCard),
/* harmony export */   "m5": () => (/* binding */ LightGreyCard),
/* harmony export */   "h2": () => (/* binding */ GreyCard)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__);


const Card = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Box).withConfig({
    componentId: "sc-2d513063-0"
})`
  width: ${({ width  })=>width ?? '100%'
};
  padding: ${({ padding  })=>padding ?? '1.25rem'
};
  border: ${({ border  })=>border
};
  border-radius: ${({ borderRadius  })=>borderRadius ?? '16px'
};
  background-color: ${({ theme  })=>theme.colors.background
};
`;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Card);
const LightCard = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(Card).withConfig({
    componentId: "sc-2d513063-1"
})`
  border: 1px solid ${({ theme  })=>theme.colors.background
};
  background-color: ${({ theme  })=>theme.colors.backgroundAlt
};
`;
const LightGreyCard = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(Card).withConfig({
    componentId: "sc-2d513063-2"
})`
  border: 1px solid ${({ theme  })=>theme.colors.cardBorder
};
  background-color: ${({ theme  })=>theme.colors.background
};
`;
const GreyCard = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(Card).withConfig({
    componentId: "sc-2d513063-3"
})`
  background-color: ${({ theme  })=>theme.colors.dropdown
};
`;


/***/ }),

/***/ 41914:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "lg": () => (/* binding */ ColumnCenter),
/* harmony export */   "Tz": () => (/* binding */ AutoColumn),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const Column = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
    componentId: "sc-91e5cc43-0"
})`
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
`;
const ColumnCenter = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(Column).withConfig({
    componentId: "sc-91e5cc43-1"
})`
  width: 100%;
  align-items: center;
`;
const AutoColumn = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
    componentId: "sc-91e5cc43-2"
})`
  display: grid;
  grid-auto-rows: auto;
  grid-row-gap: ${({ gap  })=>gap === 'sm' && '8px' || gap === 'md' && '12px' || gap === 'lg' && '24px' || gap
};
  justify-items: ${({ justify  })=>justify
};
`;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Column);


/***/ }),

/***/ 39475:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "m0": () => (/* binding */ RowBetween),
/* harmony export */   "BA": () => (/* binding */ AutoRow),
/* harmony export */   "DA": () => (/* binding */ RowFixed),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export RowFlat */
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__);


const Row = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Box).withConfig({
    componentId: "sc-2ce7e6d-0"
})`
  width: ${({ width  })=>width ?? '100%'
};
  display: flex;
  align-items: ${({ align  })=>align ?? 'center'
};
  justify-content: ${({ justify  })=>justify ?? 'flex-start'
};
  padding: ${({ padding  })=>padding ?? '0'
};
  border: ${({ border  })=>border
};
  border-radius: ${({ borderRadius  })=>borderRadius
};
`;
const RowBetween = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(Row).withConfig({
    componentId: "sc-2ce7e6d-1"
})`
  justify-content: space-between;
`;
const RowFlat = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
    componentId: "sc-2ce7e6d-2"
})`
  display: flex;
  align-items: flex-end;
`;
const AutoRow = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(Row).withConfig({
    componentId: "sc-2ce7e6d-3"
})`
  flex-wrap: wrap;
  margin: ${({ gap  })=>gap && `-${gap}`
};
  justify-content: ${({ justify  })=>justify
};

  & > * {
    margin: ${({ gap  })=>gap
} !important;
  }
`;
const RowFixed = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(Row).withConfig({
    componentId: "sc-2ce7e6d-4"
})`
  width: fit-content;
  margin: ${({ gap  })=>gap && `-${gap}`
};
`;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Row);


/***/ }),

/***/ 34966:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ CurrencyLogo)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(42877);
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _hooks_useHttpLocations__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(74753);
/* harmony import */ var _state_lists_hooks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(97952);
/* harmony import */ var _utils_getTokenLogoURL__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(72941);
/* harmony import */ var _Logo__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(79350);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_useHttpLocations__WEBPACK_IMPORTED_MODULE_5__]);
_hooks_useHttpLocations__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];









const StyledLogo = styled_components__WEBPACK_IMPORTED_MODULE_4___default()(_Logo__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z).withConfig({
    componentId: "sc-d9f41f6c-0"
})`
  width: ${({ size  })=>size
};
  height: ${({ size  })=>size
};
`;
function CurrencyLogo({ currency , size ='24px' , style  }) {
    const uriLocations = (0,_hooks_useHttpLocations__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)(currency instanceof _state_lists_hooks__WEBPACK_IMPORTED_MODULE_6__/* .WrappedTokenInfo */ .DT ? currency.logoURI : undefined);
    const srcs = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        if (currency === _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_1__.ETHER) return [];
        if (currency instanceof _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_1__.Token) {
            if (currency instanceof _state_lists_hooks__WEBPACK_IMPORTED_MODULE_6__/* .WrappedTokenInfo */ .DT) {
                return [
                    ...uriLocations,
                    (0,_utils_getTokenLogoURL__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)(currency.address)
                ];
            }
            return [
                (0,_utils_getTokenLogoURL__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)(currency.address)
            ];
        }
        return [];
    }, [
        currency,
        uriLocations
    ]);
    if (currency === _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_1__.ETHER) {
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.BinanceIcon, {
            width: size,
            style: style
        }));
    }
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledLogo, {
        size: size,
        srcs: srcs,
        alt: `${currency?.symbol ?? 'token'} logo`,
        style: style
    }));
};

});

/***/ }),

/***/ 35207:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ DoubleCurrencyLogo)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _CurrencyLogo__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(34966);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_CurrencyLogo__WEBPACK_IMPORTED_MODULE_3__]);
_CurrencyLogo__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];




const Wrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-2d98548-0"
})`
  display: flex;
  flex-direction: row;
  margin-right: ${({ margin  })=>margin && '4px'
};
`;
function DoubleCurrencyLogo({ currency0 , currency1 , size =20 , margin =false  }) {
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Wrapper, {
        margin: margin,
        children: [
            currency0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CurrencyLogo__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                currency: currency0,
                size: `${size.toString()}px`,
                style: {
                    marginRight: '4px'
                }
            }),
            currency1 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CurrencyLogo__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                currency: currency1,
                size: `${size.toString()}px`
            })
        ]
    }));
};

});

/***/ }),

/***/ 84980:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ListLogo)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _hooks_useHttpLocations__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(74753);
/* harmony import */ var _Logo__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(79350);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_useHttpLocations__WEBPACK_IMPORTED_MODULE_3__]);
_hooks_useHttpLocations__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];





const StyledListLogo = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_Logo__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z).withConfig({
    componentId: "sc-36fab3a-0"
})`
  width: ${({ size  })=>size
};
  height: ${({ size  })=>size
};
`;
function ListLogo({ logoURI , style , size ='24px' , alt  }) {
    const srcs = (0,_hooks_useHttpLocations__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)(logoURI);
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledListLogo, {
        alt: alt,
        size: size,
        srcs: srcs,
        style: style
    }));
};

});

/***/ }),

/***/ 79350:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);



const BAD_SRCS = {};
/**
 * Renders an image by sequentially trying a list of URIs, and then eventually a fallback triangle alert
 */ const Logo = ({ srcs , alt , ...rest })=>{
    const { 1: refresh  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const src = srcs.find((s)=>!BAD_SRCS[s]
    );
    if (src) {
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
            ...rest,
            alt: alt,
            src: src,
            onError: ()=>{
                if (src) BAD_SRCS[src] = true;
                refresh((i)=>i + 1
                );
            }
        }));
    }
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.HelpIcon, {
        ...rest
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Logo);


/***/ }),

/***/ 83356:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Xw": () => (/* reexport safe */ _CurrencyLogo__WEBPACK_IMPORTED_MODULE_0__.Z),
/* harmony export */   "ge": () => (/* reexport safe */ _DoubleLogo__WEBPACK_IMPORTED_MODULE_1__.Z),
/* harmony export */   "_r": () => (/* reexport safe */ _ListLogo__WEBPACK_IMPORTED_MODULE_2__.Z)
/* harmony export */ });
/* harmony import */ var _CurrencyLogo__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(34966);
/* harmony import */ var _DoubleLogo__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(35207);
/* harmony import */ var _ListLogo__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(84980);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_ListLogo__WEBPACK_IMPORTED_MODULE_2__, _DoubleLogo__WEBPACK_IMPORTED_MODULE_1__, _CurrencyLogo__WEBPACK_IMPORTED_MODULE_0__]);
([_ListLogo__WEBPACK_IMPORTED_MODULE_2__, _DoubleLogo__WEBPACK_IMPORTED_MODULE_1__, _CurrencyLogo__WEBPACK_IMPORTED_MODULE_0__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);




});

/***/ }),

/***/ 13625:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99150);





const Wrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-50b1cb03-0"
})`
  width: 100%;
  height: ${({ $isSide  })=>$isSide ? '100%' : 'auto'
};
  display: flex;
  flex-direction: column;
  flex-wrap: wrap;
  align-items: center;
  padding-top: 16px;
  padding-right: ${({ $isSide  })=>$isSide ? '32px' : '0px'
};
  ${({ theme  })=>theme.mediaQueries.md
} {
    justify-content: space-between;
    flex-direction: ${({ $isSide  })=>$isSide ? 'column' : 'row'
};
  }
`;
const BubbleWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex).withConfig({
    componentId: "sc-50b1cb03-1"
})`
  svg {
    fill: ${({ theme  })=>theme.colors.textSubtle
};
    transition: background-color 0.2s, opacity 0.2s;
  }
  &:hover {
    svg {
      opacity: 0.65;
    }
  }
  &:active {
    svg {
      opacity: 0.85;
    }
  }
`;
const Footer = ({ variant ='default'  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    const isSide = variant === 'side';
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Wrapper, {
        $isSide: isSide,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                flexDirection: isSide ? 'column' : [
                    'column',
                    'column',
                    'row'
                ],
                alignItems: "center",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.ButtonMenu, {
                        variant: "subtle",
                        scale: "sm",
                        activeIndex: 0,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.ButtonMenuItem, {
                                children: "V2"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.ButtonMenuItem, {
                                as: "a",
                                href: "https://v1exchange.pancakeswap.finance/#/",
                                children: t('V1 (old)')
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.LinkExternal, {
                        id: "ercBridge",
                        href: "https://docs.binance.org/smart-chain/guides/cross-chain.html",
                        ml: [
                            0,
                            0,
                            '40px'
                        ],
                        mt: [
                            '20px',
                            '20px',
                            isSide ? '20px' : 0
                        ],
                        mb: [
                            '8px',
                            '8px',
                            0
                        ],
                        children: t('Convert ERC-20 to BEP-20')
                    })
                ]
            }),
            isSide && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                flexGrow: 1
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                flexGrow: isSide ? 0 : 1,
                alignItems: "center",
                width: [
                    '100%',
                    '100%',
                    '100%',
                    isSide ? '100%' : 'auto'
                ],
                justifyContent: [
                    'center',
                    'center',
                    'center',
                    'flex-end'
                ],
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(BubbleWrapper, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Button, {
                                id: "clickExchangeHelp",
                                as: "a",
                                external: true,
                                href: "https://docs.pancakeswap.finance/products/pancakeswap-exchange",
                                variant: "subtle",
                                children: t('Need help ?')
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Svg, {
                                viewBox: "0 0 16 16",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                    d: "M0 16V0C0 0 3 1 6 1C9 1 16 -2 16 3.5C16 10.5 7.5 16 0 16Z"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Image, {
                        src: "/images/help.png",
                        alt: "Get some help",
                        width: 160,
                        height: 108
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footer);


/***/ }),

/***/ 65729:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useENSContentHash)
/* harmony export */ });
/* harmony import */ var _ethersproject_hash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(40750);
/* harmony import */ var _ethersproject_hash__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_hash__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _state_multicall_hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(91001);
/* harmony import */ var _utils_isZero__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(83010);
/* harmony import */ var _useContract__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(46063);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_2__]);
_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];





/**
 * Does a lookup for an ENS name to find its contenthash.
 */ function useENSContentHash(ensName) {
    const ensNodeArgument = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        if (!ensName) return [
            undefined
        ];
        try {
            return ensName ? [
                (0,_ethersproject_hash__WEBPACK_IMPORTED_MODULE_0__.namehash)(ensName)
            ] : [
                undefined
            ];
        } catch (error) {
            return [
                undefined
            ];
        }
    }, [
        ensName
    ]);
    const registrarContract = (0,_useContract__WEBPACK_IMPORTED_MODULE_3__/* .useENSRegistrarContract */ .zb)(false);
    const resolverAddressResult = (0,_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_2__/* .useSingleCallResult */ .Wk)(registrarContract, 'resolver', ensNodeArgument);
    const resolverAddress = resolverAddressResult.result?.[0];
    const resolverContract = (0,_useContract__WEBPACK_IMPORTED_MODULE_3__/* .useENSResolverContract */ .uU)(resolverAddress && (0,_utils_isZero__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)(resolverAddress) ? undefined : resolverAddress, false);
    const contenthash = (0,_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_2__/* .useSingleCallResult */ .Wk)(resolverContract, 'contenthash', ensNodeArgument);
    return {
        contenthash: contenthash.result?.[0] ?? null,
        loading: resolverAddressResult.loading || contenthash.loading
    };
};

});

/***/ }),

/***/ 74753:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useHttpLocations)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var utils_contenthashToUri__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(20864);
/* harmony import */ var utils_ENS_parseENSAddress__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(12188);
/* harmony import */ var utils_uriToHttp__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(90570);
/* harmony import */ var _ENS_useENSContentHash__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65729);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_ENS_useENSContentHash__WEBPACK_IMPORTED_MODULE_2__]);
_ENS_useENSContentHash__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];





function useHttpLocations(uri) {
    const ens = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>uri ? (0,utils_ENS_parseENSAddress__WEBPACK_IMPORTED_MODULE_3__/* .parseENSAddress */ .y)(uri) : undefined
    , [
        uri
    ]);
    const resolvedContentHash = (0,_ENS_useENSContentHash__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)(ens?.ensName);
    return (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        if (ens) {
            return resolvedContentHash.contenthash ? (0,utils_uriToHttp__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)((0,utils_contenthashToUri__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)(resolvedContentHash.contenthash)) : [];
        }
        return uri ? (0,utils_uriToHttp__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)(uri) : [];
    }, [
        ens,
        resolvedContentHash.contenthash,
        uri
    ]);
};

});

/***/ }),

/***/ 72941:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const getTokenLogoURL = (address)=>`https://assets.trustwalletapp.com/blockchains/smartchain/assets/${address}/logo.png`
;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (getTokenLogoURL);


/***/ }),

/***/ 49438:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var components_Menu_Footer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(13625);
/* harmony import */ var components_Layout_Page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9770);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([components_Layout_Page__WEBPACK_IMPORTED_MODULE_5__]);
components_Layout_Page__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];






const StyledPage = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-cca6ebbf-0"
})`
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
  padding: ${({ $removePadding  })=>$removePadding ? '0' : '16px'
};
  padding-bottom: 0;
  min-height: calc(100vh - 64px);
  background: ${({ theme  })=>theme.colors.gradients.bubblegum
};

  ${({ theme  })=>theme.mediaQueries.xs
} {
    background-size: auto;
  }

  ${({ theme  })=>theme.mediaQueries.sm
} {
    padding: ${({ $removePadding  })=>$removePadding ? '0' : '24px'
};
    padding-bottom: 0;
  }

  ${({ theme  })=>theme.mediaQueries.lg
} {
    padding: ${({ $removePadding  })=>$removePadding ? '0' : '32px'
};
    padding-bottom: 0;
    min-height: calc(100vh - 100px);
  }
`;
const Page = ({ children , removePadding =false , hideFooterOnDesktop =false , ...props })=>{
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Layout_Page__WEBPACK_IMPORTED_MODULE_5__/* .PageMeta */ .V, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(StyledPage, {
                $removePadding: removePadding,
                ...props,
                children: [
                    children,
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                        flexGrow: 1
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Box, {
                        display: [
                            'block',
                            null,
                            null,
                            hideFooterOnDesktop ? 'none' : 'block'
                        ],
                        width: "100%",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Menu_Footer__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Page);

});

/***/ })

};
;
//# sourceMappingURL=4796.js.map