"use strict";
exports.id = 3595;
exports.ids = [3595];
exports.modules = {

/***/ 68263:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99150);





const FixedContainer = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-5dd23ea3-0"
})`
  position: fixed;
  right: 5%;
  bottom: 110px;
`;
const ScrollToTopButton = ()=>{
    const { 0: visible , 1: setVisible  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    const toggleVisible = ()=>{
        const scrolled = document.documentElement.scrollTop;
        if (scrolled > 700) {
            setVisible(true);
        } else if (scrolled <= 700) {
            setVisible(false);
        }
    };
    const scrollToTop = ()=>{
        window.scrollTo({
            top: 400,
            behavior: 'auto'
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        window.addEventListener('scroll', toggleVisible);
        return ()=>window.removeEventListener('scroll', toggleVisible)
        ;
    }, []);
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FixedContainer, {
        style: {
            display: visible ? 'inline' : 'none'
        },
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Button, {
            variant: "subtle",
            endIcon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.ChevronUpIcon, {
                color: "invertedContrast"
            }),
            onClick: scrollToTop,
            children: t('To Top')
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ScrollToTopButton);


/***/ }),

/***/ 61846:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(99150);
/* harmony import */ var state__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(82727);
/* harmony import */ var state_nftMarket_reducer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(38263);
/* harmony import */ var state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(13968);
/* harmony import */ var config_constants_types__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(97971);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_6__]);
state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];








const ClearAllButton = ({ collectionAddress , ...props })=>{
    const dispatch = (0,state__WEBPACK_IMPORTED_MODULE_4__/* .useAppDispatch */ .TL)();
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_3__/* .useTranslation */ .$G)();
    const nftFilterState = (0,state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_6__/* .useGetNftFilterLoadingState */ .fm)(collectionAddress);
    const clearAll = ()=>{
        dispatch((0,state_nftMarket_reducer__WEBPACK_IMPORTED_MODULE_5__/* .removeAllFilters */ .Ze)(collectionAddress));
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
        variant: "text",
        scale: "sm",
        onClick: clearAll,
        disabled: nftFilterState === config_constants_types__WEBPACK_IMPORTED_MODULE_7__/* .FetchStatus.Fetching */ .iF.Fetching,
        ...props,
        children: t('Clear')
    }, "clear-all"));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ClearAllButton);

});

/***/ }),

/***/ 11841:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var lodash_uniqBy__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(69309);
/* harmony import */ var lodash_uniqBy__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lodash_uniqBy__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var state__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(82727);
/* harmony import */ var state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(13968);
/* harmony import */ var state_nftMarket_reducer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(38263);
/* harmony import */ var state_nftMarket_helpers__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(86849);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(99150);
/* harmony import */ var config_constants_types__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(97971);
/* harmony import */ var _components_GridPlaceholder__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(71424);
/* harmony import */ var _components_CollectibleCard__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(12962);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(79748);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_CollectibleCard__WEBPACK_IMPORTED_MODULE_11__, state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_5__]);
([_components_CollectibleCard__WEBPACK_IMPORTED_MODULE_11__, state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);













const CollectionNfts = ({ collection  })=>{
    const { totalSupply , numberTokensListed , address: collectionAddress  } = collection;
    const { 0: page , 1: setPage  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(1);
    const { 0: skip , 1: setSkip  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const { 0: nfts , 1: setNfts  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const { 0: isFetchingFilteredNfts , 1: setIsFetchingFilteredNfts  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_8__/* .useTranslation */ .$G)();
    const collectionNfts = (0,state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_5__/* .useNftsFromCollection */ .aA)(collectionAddress);
    const nftFilterLoadingState = (0,state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_5__/* .useGetNftFilterLoadingState */ .fm)(collectionAddress);
    const dispatch = (0,state__WEBPACK_IMPORTED_MODULE_4__/* .useAppDispatch */ .TL)();
    const showOnlyNftsOnSale = (0,state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_5__/* .useGetNftShowOnlyOnSale */ .q4)(collectionAddress);
    const { field: orderField , direction: orderDirection  } = (0,state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_5__/* .useGetNftOrdering */ .D7)(collectionAddress);
    const isFetching = orderField === 'tokenId' ? nftFilterLoadingState === config_constants_types__WEBPACK_IMPORTED_MODULE_9__/* .FetchStatus.Fetching */ .iF.Fetching : isFetchingFilteredNfts;
    const handleLoadMore = ()=>{
        if (orderField === 'tokenId') {
            setPage((prevPage)=>prevPage + 1
            );
        }
        setSkip(skip + _config__WEBPACK_IMPORTED_MODULE_12__/* .REQUEST_SIZE */ .z);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (orderField === 'tokenId') {
            setPage(1);
        }
    }, [
        orderField
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setNfts([]);
        setSkip(0);
    }, [
        orderField,
        orderDirection
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const fetchApiData = async (marketData)=>{
            const apiRequestPromises = marketData.map((marketNft)=>(0,state_nftMarket_helpers__WEBPACK_IMPORTED_MODULE_7__/* .getNftApi */ .hb)(collectionAddress, marketNft.tokenId)
            );
            const apiResponses = await Promise.all(apiRequestPromises);
            const responsesWithMarketData = apiResponses.reduce((acc, apiNft, i)=>{
                if (apiNft) {
                    acc.push({
                        ...apiNft,
                        collectionAddress,
                        collectionName: apiNft.collection.name,
                        marketData: marketData[i]
                    });
                }
                return acc;
            }, []);
            setIsFetchingFilteredNfts(false);
            setNfts((prevState)=>{
                const combinedNfts = [
                    ...prevState,
                    ...responsesWithMarketData
                ];
                return lodash_uniqBy__WEBPACK_IMPORTED_MODULE_2___default()(combinedNfts, 'tokenId');
            });
        };
        const fetchMarketData = async ()=>{
            const subgraphRes = await (0,state_nftMarket_helpers__WEBPACK_IMPORTED_MODULE_7__/* .getNftsMarketData */ .T5)({
                collection: collectionAddress.toLowerCase(),
                isTradable: true
            }, _config__WEBPACK_IMPORTED_MODULE_12__/* .REQUEST_SIZE */ .z, orderField, orderDirection, skip);
            fetchApiData(subgraphRes);
        };
        if (orderField !== 'tokenId') {
            // Query by tokenId is handled in useEffect below since we in this case
            // we need to show all NFTs, even those that never been on sale (i.e. they are not in subgraph)
            setIsFetchingFilteredNfts(true);
            fetchMarketData();
        }
    }, [
        orderField,
        orderDirection,
        skip,
        collectionAddress
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (orderField === 'tokenId') {
            dispatch((0,state_nftMarket_reducer__WEBPACK_IMPORTED_MODULE_6__/* .fetchNftsFromCollections */ .o)({
                collectionAddress,
                page,
                size: _config__WEBPACK_IMPORTED_MODULE_12__/* .REQUEST_SIZE */ .z
            }));
        }
    }, [
        page,
        collectionAddress,
        dispatch,
        orderField
    ]);
    const nftsToShow = orderField === 'tokenId' ? collectionNfts?.filter((nft)=>{
        if (showOnlyNftsOnSale) {
            return nft.marketData?.isTradable;
        }
        return true;
    }) : nfts;
    if (!nftsToShow || nftsToShow?.length === 0) {
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_GridPlaceholder__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {}));
    }
    const isNotLastPage = showOnlyNftsOnSale || orderField !== 'tokenId' ? nftsToShow?.length < Number(numberTokensListed) : nftsToShow?.length < Number(totalSupply);
    const resultsAmount = showOnlyNftsOnSale || orderField !== 'tokenId' ? numberTokensListed : totalSupply;
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                p: "16px",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                    bold: true,
                    children: [
                        resultsAmount,
                        " ",
                        t('Results')
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                gridGap: "16px",
                gridTemplateColumns: [
                    '1fr',
                    null,
                    'repeat(3, 1fr)',
                    null,
                    'repeat(4, 1fr)'
                ],
                alignItems: "start",
                children: nftsToShow.map((nft)=>{
                    const currentAskPriceAsNumber = nft.marketData && parseFloat(nft.marketData.currentAskPrice);
                    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_CollectibleCard__WEBPACK_IMPORTED_MODULE_11__/* .CollectibleLinkCard */ .ts, {
                        nft: nft,
                        currentAskPrice: currentAskPriceAsNumber > 0 ? currentAskPriceAsNumber : undefined
                    }, nft.tokenId));
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                mt: "60px",
                mb: "12px",
                justifyContent: "center",
                children: isNotLastPage && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Button, {
                    onClick: handleLoadMore,
                    scale: "sm",
                    endIcon: isFetching ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.AutoRenewIcon, {
                        spin: true,
                        color: "currentColor"
                    }) : undefined,
                    children: isFetching ? t('Loading') : t('Load more')
                })
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CollectionNfts);

});

/***/ }),

/***/ 52275:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(66405);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(89699);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(13968);
/* harmony import */ var components_Layout_Container__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(55027);
/* harmony import */ var components_ScrollToTopButton__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(68263);
/* harmony import */ var _Filters__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(57904);
/* harmony import */ var _CollectionNfts__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(11841);
/* harmony import */ var _FilteredCollectionNfts__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(12228);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_FilteredCollectionNfts__WEBPACK_IMPORTED_MODULE_10__, _CollectionNfts__WEBPACK_IMPORTED_MODULE_9__, _Filters__WEBPACK_IMPORTED_MODULE_8__, state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_5__]);
([_FilteredCollectionNfts__WEBPACK_IMPORTED_MODULE_10__, _CollectionNfts__WEBPACK_IMPORTED_MODULE_9__, _Filters__WEBPACK_IMPORTED_MODULE_8__, state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);











const CollectionWrapper = ({ collection  })=>{
    const nftFilters = (0,state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_5__/* .useGetNftFilters */ .DI)(collection.address);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Box, {
        py: "32px",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Layout_Container__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                px: [
                    0,
                    null,
                    '24px'
                ],
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Filters__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                    collection: collection
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Layout_Container__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                children: lodash_isEmpty__WEBPACK_IMPORTED_MODULE_4___default()(nftFilters) ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CollectionNfts__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                    collection: collection
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_FilteredCollectionNfts__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                    collection: collection
                })
            }),
            /*#__PURE__*/ (0,react_dom__WEBPACK_IMPORTED_MODULE_2__.createPortal)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_ScrollToTopButton__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {}), document.body)
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CollectionWrapper);

});

/***/ }),

/***/ 12228:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(49949);
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lodash_orderBy__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(13968);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(99150);
/* harmony import */ var config_constants_types__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(97971);
/* harmony import */ var _components_GridPlaceholder__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(71424);
/* harmony import */ var _components_CollectibleCard__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(12962);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(79748);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_CollectibleCard__WEBPACK_IMPORTED_MODULE_8__, state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_4__]);
([_components_CollectibleCard__WEBPACK_IMPORTED_MODULE_8__, state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);










const FilteredCollectionNfts = ({ collection  })=>{
    const { address: collectionAddress  } = collection;
    const { 0: numToShow , 1: setNumToShow  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(_config__WEBPACK_IMPORTED_MODULE_9__/* .REQUEST_SIZE */ .z);
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_5__/* .useTranslation */ .$G)();
    const selectedOrder = (0,state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_4__/* .useGetNftOrdering */ .D7)(collectionAddress);
    const showOnlyNftsOnSale = (0,state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_4__/* .useGetNftShowOnlyOnSale */ .q4)(collectionAddress);
    const collectionNfts = (0,state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_4__/* .useNftsFromCollection */ .aA)(collectionAddress);
    const nftFilterLoadingState = (0,state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_4__/* .useGetNftFilterLoadingState */ .fm)(collectionAddress);
    const handleLoadMore = ()=>{
        setNumToShow((prevNumToShow)=>prevNumToShow + _config__WEBPACK_IMPORTED_MODULE_9__/* .REQUEST_SIZE */ .z
        );
    };
    if (nftFilterLoadingState === config_constants_types__WEBPACK_IMPORTED_MODULE_6__/* .FetchStatus.Fetching */ .iF.Fetching) {
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_GridPlaceholder__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {}));
    }
    const orderedNfts = collectionNfts ? lodash_orderBy__WEBPACK_IMPORTED_MODULE_2___default()(collectionNfts, (nft)=>{
        if (selectedOrder.field === 'currentAskPrice') {
            const currentAskPriceAsNumber = nft.marketData?.currentAskPrice ? parseFloat(nft.marketData?.currentAskPrice) : 0;
            if (currentAskPriceAsNumber > 0) {
                return parseFloat(nft.marketData.currentAskPrice);
            }
            return selectedOrder.direction === 'asc' ? Infinity : -Infinity;
        }
        if (selectedOrder.field === 'tokenId') {
            const tokenIdNumber = Number(nft.tokenId);
            return Number.isFinite(tokenIdNumber) ? tokenIdNumber : 0;
        }
        // recently listed sorting
        return nft.marketData ? parseInt(nft.marketData[selectedOrder.field], 10) : 0;
    }, selectedOrder.direction) : [];
    const filteredNfts = showOnlyNftsOnSale ? orderedNfts.filter((nft)=>nft.marketData?.isTradable
    ) : orderedNfts;
    const nftsToShow = filteredNfts.slice(0, numToShow);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                p: "16px",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                    bold: true,
                    children: [
                        filteredNfts.length,
                        " ",
                        t('Results')
                    ]
                })
            }),
            nftsToShow.length > 0 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                        gridGap: "16px",
                        gridTemplateColumns: [
                            '1fr',
                            null,
                            'repeat(3, 1fr)',
                            null,
                            'repeat(4, 1fr)'
                        ],
                        alignItems: "start",
                        children: nftsToShow.map((nft)=>{
                            const currentAskPriceAsNumber = nft.marketData && parseFloat(nft.marketData.currentAskPrice);
                            return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_CollectibleCard__WEBPACK_IMPORTED_MODULE_8__/* .CollectibleLinkCard */ .ts, {
                                nft: nft,
                                currentAskPrice: currentAskPriceAsNumber > 0 ? currentAskPriceAsNumber : undefined
                            }, nft.tokenId));
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                        mt: "60px",
                        mb: "12px",
                        justifyContent: "center",
                        children: collectionNfts.length > numToShow && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Button, {
                            onClick: handleLoadMore,
                            scale: "sm",
                            children: t('Load more')
                        })
                    })
                ]
            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                alignItems: "center",
                py: "48px",
                flexDirection: "column",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.BunnyPlaceholderIcon, {
                        width: "96px",
                        mb: "24px"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                        fontWeight: 600,
                        children: t('No NFTs found')
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FilteredCollectionNfts);

});

/***/ }),

/***/ 57904:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var lodash_capitalize__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(59969);
/* harmony import */ var lodash_capitalize__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(lodash_capitalize__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(89699);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(13968);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(99150);
/* harmony import */ var views_Nft_market_components_Filters__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(99327);
/* harmony import */ var state__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(82727);
/* harmony import */ var state_nftMarket_reducer__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(38263);
/* harmony import */ var _hooks_useGetCollectionDistribution__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(74437);
/* harmony import */ var _ClearAllButton__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(61846);
/* harmony import */ var _SortSelect__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(59521);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_ClearAllButton__WEBPACK_IMPORTED_MODULE_12__, views_Nft_market_components_Filters__WEBPACK_IMPORTED_MODULE_8__, _SortSelect__WEBPACK_IMPORTED_MODULE_13__, state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_6__]);
([_ClearAllButton__WEBPACK_IMPORTED_MODULE_12__, views_Nft_market_components_Filters__WEBPACK_IMPORTED_MODULE_8__, _SortSelect__WEBPACK_IMPORTED_MODULE_13__, state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);














const GridContainer = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Grid).withConfig({
    componentId: "sc-dcd3c79f-0"
})`
  margin-bottom: 16px;
  padding: 0 16px;
  grid-gap: 8px 16px;
  grid-template-columns: 1fr 1fr;
  grid-template-areas:
    'filterByTitle .'
    'attributeFilters attributeFilters'
    '. sortByTitle'
    'filterByControls sortByControls';
  ${({ theme  })=>theme.mediaQueries.sm
} {
    grid-template-columns: 1fr 1fr 1fr;
    grid-template-areas:
      'filterByTitle . .'
      'attributeFilters attributeFilters attributeFilters'
      '. . sortByTitle'
      'filterByControls . sortByControls';
  }
  ${({ theme  })=>theme.mediaQueries.md
} {
    grid-template-columns: 2fr 5fr 1fr;
    grid-template-areas:
      'filterByTitle . .'
      'filterByControls attributeFilters attributeFilters'
      '. . sortByTitle'
      '. . sortByControls';
  }
  ${({ theme  })=>theme.mediaQueries.lg
} {
    grid-template-columns: 1.3fr 5fr 1fr;
    grid-template-areas:
      'filterByTitle . sortByTitle'
      'filterByControls attributeFilters sortByControls';
  }
  ${({ theme  })=>theme.mediaQueries.xxl
} {
    grid-template-columns: 1fr 5fr 1fr;
  }
`;
const FilterByTitle = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text).withConfig({
    componentId: "sc-dcd3c79f-1"
})`
  grid-area: filterByTitle;
`;
const FilterByControls = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Box).withConfig({
    componentId: "sc-dcd3c79f-2"
})`
  grid-area: filterByControls;
`;
const SortByTitle = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text).withConfig({
    componentId: "sc-dcd3c79f-3"
})`
  grid-area: sortByTitle;
`;
const SortByControls = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Box).withConfig({
    componentId: "sc-dcd3c79f-4"
})`
  grid-area: sortByControls;
`;
const ScrollableFlexContainer = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex).withConfig({
    componentId: "sc-dcd3c79f-5"
})`
  grid-area: attributeFilters;
  align-items: center;
  flex: 1;
  flex-wrap: nowrap;
  overflow-x: auto;
  -webkit-overflow-scrolling: touch;

  ${({ theme  })=>theme.mediaQueries.md
} {
    flex-wrap: wrap;
    overflow-x: revert;
  }
`;
const Filters = ({ collection  })=>{
    const { address  } = collection;
    const dispatch = (0,state__WEBPACK_IMPORTED_MODULE_9__/* .useAppDispatch */ .TL)();
    const { data  } = (0,_hooks_useGetCollectionDistribution__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z)(address);
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_7__/* .useTranslation */ .$G)();
    const showOnlyNftsOnSale = (0,state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_6__/* .useGetNftShowOnlyOnSale */ .q4)(address);
    const { 0: activeButtonIndex , 1: setActiveButtonIndex  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(showOnlyNftsOnSale ? 1 : 0);
    const onActiveButtonChange = (newIndex)=>{
        dispatch((0,state_nftMarket_reducer__WEBPACK_IMPORTED_MODULE_10__/* .setShowOnlyOnSale */ .an)({
            collection: address,
            showOnlyOnSale: newIndex === 1
        }));
        setActiveButtonIndex(newIndex);
    };
    const nftFilters = (0,state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_6__/* .useGetNftFilters */ .DI)(address);
    const attrsByType = collection?.attributes?.reduce((accum, attr)=>({
            ...accum,
            [attr.traitType]: accum[attr.traitType] ? [
                ...accum[attr.traitType],
                attr
            ] : [
                attr
            ]
        })
    , {});
    const uniqueTraitTypes = attrsByType ? Object.keys(attrsByType) : [];
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(GridContainer, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FilterByTitle, {
                textTransform: "uppercase",
                color: "textSubtle",
                fontSize: "12px",
                bold: true,
                children: t('Filter by')
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FilterByControls, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.ButtonMenu, {
                    scale: "sm",
                    activeIndex: activeButtonIndex,
                    onItemClick: onActiveButtonChange,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.ButtonMenuItem, {
                            children: t('All')
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.ButtonMenuItem, {
                            children: t('On Sale')
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SortByTitle, {
                fontSize: "12px",
                textTransform: "uppercase",
                color: "textSubtle",
                fontWeight: 600,
                mb: "4px",
                children: t('Sort By')
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SortByControls, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SortSelect__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                    collectionAddress: address
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ScrollableFlexContainer, {
                children: [
                    uniqueTraitTypes.map((traitType)=>{
                        const attrs = attrsByType[traitType];
                        const items = attrs.map((attr)=>({
                                label: lodash_capitalize__WEBPACK_IMPORTED_MODULE_4___default()(attr.value),
                                count: data && data[traitType] ? data[traitType][attr.value] : undefined,
                                attr
                            })
                        );
                        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(views_Nft_market_components_Filters__WEBPACK_IMPORTED_MODULE_8__/* .ListTraitFilter */ .y, {
                            title: lodash_capitalize__WEBPACK_IMPORTED_MODULE_4___default()(traitType),
                            traitType: traitType,
                            items: items,
                            collectionAddress: address
                        }, traitType));
                    }),
                    !lodash_isEmpty__WEBPACK_IMPORTED_MODULE_5___default()(nftFilters) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ClearAllButton__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                        collectionAddress: address,
                        mb: "4px"
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Filters);

});

/***/ }),

/***/ 93007:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(49949);
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(lodash_orderBy__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_CollectibleCard__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(12962);
/* harmony import */ var _hooks_useAllPancakeBunnyNfts__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(98695);
/* harmony import */ var _components_GridPlaceholder__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(71424);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_CollectibleCard__WEBPACK_IMPORTED_MODULE_4__]);
_components_CollectibleCard__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];







const PancakeBunniesCollectionNfts = ({ collection , sortBy ='updatedAt'  })=>{
    const { address  } = collection;
    const allPancakeBunnyNfts = (0,_hooks_useAllPancakeBunnyNfts__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)(address);
    const sortedNfts = allPancakeBunnyNfts ? lodash_orderBy__WEBPACK_IMPORTED_MODULE_3___default()(allPancakeBunnyNfts, (nft)=>nft.meta[sortBy] ? Number(nft?.meta[sortBy]) : 0
    , [
        sortBy === 'currentAskPrice' ? 'asc' : 'desc', 
    ]) : [];
    if (!sortedNfts.length) {
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_GridPlaceholder__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}));
    }
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            gridGap: "16px",
            gridTemplateColumns: [
                '1fr',
                null,
                'repeat(3, 1fr)',
                null,
                'repeat(4, 1fr)'
            ],
            alignItems: "start",
            children: sortedNfts.map((nft)=>{
                return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_CollectibleCard__WEBPACK_IMPORTED_MODULE_4__/* .CollectibleLinkCard */ .ts, {
                    nft: nft
                }, `${nft.tokenId}-${nft.collectionName}`));
            })
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PancakeBunniesCollectionNfts);

});

/***/ }),

/***/ 59521:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_Select_Select__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(37370);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(99150);
/* harmony import */ var state__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(82727);
/* harmony import */ var state_nftMarket_reducer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(38263);
/* harmony import */ var state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(13968);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_6__]);
state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];







const SortSelect = ({ collectionAddress  })=>{
    const dispatch = (0,state__WEBPACK_IMPORTED_MODULE_4__/* .useAppDispatch */ .TL)();
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_3__/* .useTranslation */ .$G)();
    const selectedOrder = (0,state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_6__/* .useGetNftOrdering */ .D7)(collectionAddress);
    const handleChange = (newOption)=>{
        const { field , direction  } = newOption.value;
        dispatch((0,state_nftMarket_reducer__WEBPACK_IMPORTED_MODULE_5__/* .setOrdering */ .pM)({
            collection: collectionAddress,
            field,
            direction
        }));
    };
    const sortByItems = [
        {
            label: t('Recently listed'),
            value: {
                field: 'updatedAt',
                direction: 'desc'
            }
        },
        {
            label: t('Lowest price'),
            value: {
                field: 'currentAskPrice',
                direction: 'asc'
            }
        },
        {
            label: t('Highest price'),
            value: {
                field: 'currentAskPrice',
                direction: 'desc'
            }
        },
        {
            label: t('Token ID'),
            value: {
                field: 'tokenId',
                direction: 'asc'
            }
        }, 
    ];
    const defaultOptionIndex = sortByItems.findIndex((option)=>option.value.field === selectedOrder.field && option.value.direction === selectedOrder.direction
    );
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Select_Select__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        options: sortByItems,
        onOptionChange: handleChange,
        defaultOptionIndex: defaultOptionIndex !== -1 ? defaultOptionIndex : undefined
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SortSelect);

});

/***/ }),

/***/ 23595:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var state__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(82727);
/* harmony import */ var state_nftMarket_reducer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(38263);
/* harmony import */ var state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(13968);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(99150);
/* harmony import */ var components_Select_Select__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(37370);
/* harmony import */ var components_Layout_Container__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(55027);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1940);
/* harmony import */ var _PancakeBunniesCollectionNfts__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(93007);
/* harmony import */ var _CollectionWrapper__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(52275);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_CollectionWrapper__WEBPACK_IMPORTED_MODULE_12__, _PancakeBunniesCollectionNfts__WEBPACK_IMPORTED_MODULE_11__, state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_6__]);
([_CollectionWrapper__WEBPACK_IMPORTED_MODULE_12__, _PancakeBunniesCollectionNfts__WEBPACK_IMPORTED_MODULE_11__, state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);













const Items = ()=>{
    const collectionAddress = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)().query.collectionAddress;
    const { 0: sortBy , 1: setSortBy  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('updatedAt');
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_7__/* .useTranslation */ .$G)();
    const dispatch = (0,state__WEBPACK_IMPORTED_MODULE_4__/* .useAppDispatch */ .TL)();
    const collection = (0,state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_6__/* .useGetCollection */ .YD)(collectionAddress);
    const isPBCollection = collectionAddress.toLowerCase() === _constants__WEBPACK_IMPORTED_MODULE_10__/* .pancakeBunniesAddress.toLowerCase */ .Jr.toLowerCase();
    const { address  } = collection || {};
    const sortByItems = [
        {
            label: t('Recently listed'),
            value: 'updatedAt'
        },
        {
            label: t('Lowest price'),
            value: 'currentAskPrice'
        }, 
    ];
    const handleChange = (newOption)=>{
        setSortBy(newOption.value);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (address) {
            dispatch((0,state_nftMarket_reducer__WEBPACK_IMPORTED_MODULE_5__/* .fetchCollection */ .lA)(address));
        }
    }, [
        address,
        dispatch
    ]);
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: isPBCollection ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(components_Layout_Container__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
            mb: "24px",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                    alignItems: "center",
                    justifyContent: [
                        'flex-start',
                        null,
                        null,
                        'flex-end'
                    ],
                    mb: "24px",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Box, {
                        minWidth: "165px",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                fontSize: "12px",
                                textTransform: "uppercase",
                                color: "textSubtle",
                                fontWeight: 600,
                                mb: "4px",
                                children: t('Sort By')
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Select_Select__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                options: sortByItems,
                                onOptionChange: handleChange
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PancakeBunniesCollectionNfts__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                    collection: collection,
                    sortBy: sortBy
                })
            ]
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CollectionWrapper__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
            collection: collection
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Items);

});

/***/ }),

/***/ 79748:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "z": () => (/* binding */ REQUEST_SIZE)
/* harmony export */ });
const REQUEST_SIZE = 100;


/***/ }),

/***/ 44202:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "y": () => (/* binding */ ListTraitFilter)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var config_constants_types__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(97971);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99150);
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(49949);
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(lodash_orderBy__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var state__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(82727);
/* harmony import */ var state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(13968);
/* harmony import */ var state_nftMarket_reducer__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(38263);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _ListFilter_styles__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(62627);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(52838);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_7__]);
state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_7__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];












const TriggerButton = styled_components__WEBPACK_IMPORTED_MODULE_9___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button).withConfig({
    componentId: "sc-dafd973a-0"
})`
  ${({ hasItem  })=>hasItem && `
    border-top-right-radius: 0;
    border-bottom-right-radius: 0;
    padding-right: 8px;
  `
}
`;
const CloseButton = styled_components__WEBPACK_IMPORTED_MODULE_9___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.IconButton).withConfig({
    componentId: "sc-dafd973a-1"
})`
  border-top-left-radius: 0;
  border-bottom-left-radius: 0;
`;
const ListTraitFilter = ({ title , traitType , items , collectionAddress  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    const { 0: isOpen , 1: setIsOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: query , 1: setQuery  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const { 0: orderState , 1: setOrderState  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        orderKey: 'count',
        orderDir: 'asc'
    });
    const wrapperRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const menuRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const nftFilters = (0,state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_7__/* .useGetNftFilters */ .DI)(collectionAddress);
    const nftFilterState = (0,state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_7__/* .useGetNftFilterLoadingState */ .fm)(collectionAddress);
    const dispatch = (0,state__WEBPACK_IMPORTED_MODULE_6__/* .useAppDispatch */ .TL)();
    const { orderKey , orderDir  } = orderState;
    const traitFilter = nftFilters[traitType];
    const isTraitSelected = !!traitFilter;
    const filteredItems = query && query.length > 1 ? items.filter((item)=>item.label.toLowerCase().indexOf(query.toLowerCase()) !== -1
    ) : items;
    const handleClearItem = ()=>{
        const newFilters = {
            ...nftFilters
        };
        delete newFilters[traitType];
        dispatch((0,state_nftMarket_reducer__WEBPACK_IMPORTED_MODULE_8__/* .filterNftsFromCollection */ .iU)({
            collectionAddress,
            nftFilters: newFilters
        }));
    };
    const handleMenuClick = ()=>setIsOpen(!isOpen)
    ;
    const handleChange = (evt)=>{
        const { value  } = evt.target;
        setQuery(value);
    };
    const handleItemSelect = ({ attr  })=>{
        dispatch((0,state_nftMarket_reducer__WEBPACK_IMPORTED_MODULE_8__/* .filterNftsFromCollection */ .iU)({
            collectionAddress,
            nftFilters: {
                ...nftFilters,
                [traitType]: attr
            }
        }));
    };
    const toggleSort = (newOrderKey)=>()=>{
            setOrderState((prevOrderDir)=>{
                if (prevOrderDir.orderKey !== newOrderKey) {
                    return {
                        orderKey: newOrderKey,
                        orderDir: 'asc'
                    };
                }
                return {
                    orderKey: newOrderKey,
                    orderDir: prevOrderDir.orderDir === 'asc' ? 'desc' : 'asc'
                };
            });
        }
    ;
    // @TODO Fix this in the Toolkit
    // This is a fix to ensure the "isOpen" value is aligned with the menus's (to avoid a double click)
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const handleClickOutside = ({ target  })=>{
            if (wrapperRef.current && menuRef.current && !menuRef.current.contains(target) && !wrapperRef.current.contains(target)) {
                setIsOpen(false);
            }
        };
        document.addEventListener('click', handleClickOutside);
        return ()=>{
            document.removeEventListener('click', handleClickOutside);
        };
    }, [
        setIsOpen,
        wrapperRef,
        menuRef
    ]);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
        alignItems: "center",
        mr: "4px",
        mb: "4px",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Box, {
                ref: wrapperRef,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.InlineMenu, {
                    component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TriggerButton, {
                        onClick: handleMenuClick,
                        variant: isTraitSelected ? 'subtle' : 'light',
                        scale: "sm",
                        disabled: nftFilterState === config_constants_types__WEBPACK_IMPORTED_MODULE_3__/* .FetchStatus.Fetching */ .iF.Fetching,
                        hasItem: isTraitSelected,
                        children: title
                    }),
                    isOpen: isOpen,
                    options: {
                        placement: 'bottom'
                    },
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Box, {
                        maxWidth: "375px",
                        ref: menuRef,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ListFilter_styles__WEBPACK_IMPORTED_MODULE_10__/* .SearchWrapper */ ._8, {
                                alignItems: "center",
                                p: "16px",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.InputGroup, {
                                    startIcon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.SearchIcon, {
                                        color: "textSubtle"
                                    }),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Input, {
                                        name: "query",
                                        placeholder: t('Search'),
                                        onChange: handleChange,
                                        value: query
                                    })
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                                alignItems: "center",
                                p: "16px",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_ListFilter_styles__WEBPACK_IMPORTED_MODULE_10__/* .FilterButton */ .Lb, {
                                        onClick: toggleSort('label'),
                                        style: {
                                            flex: 1
                                        },
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                                fontSize: "12px",
                                                color: "secondary",
                                                fontWeight: "bold",
                                                textTransform: "uppercase",
                                                children: t('Name')
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                                width: "18px",
                                                children: [
                                                    orderKey === 'label' && orderDir === 'asc' && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.ArrowUpIcon, {
                                                        width: "18px",
                                                        color: "secondary"
                                                    }),
                                                    orderKey === 'label' && orderDir === 'desc' && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.ArrowDownIcon, {
                                                        width: "18px",
                                                        color: "secondary"
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_ListFilter_styles__WEBPACK_IMPORTED_MODULE_10__/* .FilterButton */ .Lb, {
                                        onClick: toggleSort('count'),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                                fontSize: "12px",
                                                color: "secondary",
                                                fontWeight: "bold",
                                                textTransform: "uppercase",
                                                children: t('Count')
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                                width: "18px",
                                                children: [
                                                    orderKey === 'count' && orderDir === 'asc' && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.ArrowUpIcon, {
                                                        width: "18px",
                                                        color: "secondary"
                                                    }),
                                                    orderKey === 'count' && orderDir === 'desc' && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.ArrowDownIcon, {
                                                        width: "18px",
                                                        color: "secondary"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                height: "240px",
                                overflowY: "auto",
                                children: filteredItems.length > 0 ? lodash_orderBy__WEBPACK_IMPORTED_MODULE_5___default()(filteredItems, orderKey, orderDir).map((filteredItem)=>{
                                    const handleSelect = ()=>handleItemSelect(filteredItem)
                                    ;
                                    const isItemSelected = traitFilter ? traitFilter.value === filteredItem.attr.value : false;
                                    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styles__WEBPACK_IMPORTED_MODULE_11__/* .TraitItemRow */ .u, {
                                        item: filteredItem,
                                        isSelected: isItemSelected,
                                        onSelect: handleSelect
                                    }, filteredItem.label));
                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                                    alignItems: "center",
                                    justifyContent: "center",
                                    height: "230px",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                        color: "textDisabled",
                                        textAlign: "center",
                                        children: t('No results found')
                                    })
                                })
                            })
                        ]
                    })
                })
            }),
            isTraitSelected && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CloseButton, {
                variant: isTraitSelected ? 'subtle' : 'light',
                scale: "sm",
                onClick: handleClearItem,
                disabled: nftFilterState === config_constants_types__WEBPACK_IMPORTED_MODULE_3__/* .FetchStatus.Fetching */ .iF.Fetching,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.CloseIcon, {
                    color: "currentColor",
                    width: "18px"
                })
            })
        ]
    }));
};

});

/***/ }),

/***/ 52838:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "u": () => (/* binding */ TraitItemRow)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var lodash_noop__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(87553);
/* harmony import */ var lodash_noop__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(lodash_noop__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var utils_formatBalance__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(65044);
/* harmony import */ var _ListFilter_styles__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(62627);






const TraitItemRow = ({ item , isSelected , onSelect  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_ListFilter_styles__WEBPACK_IMPORTED_MODULE_5__/* .StyledItemRow */ .Ak, {
        alignItems: "center",
        px: "16px",
        py: "8px",
        onClick: onSelect,
        children: [
            item.image && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ListFilter_styles__WEBPACK_IMPORTED_MODULE_5__/* .ItemImage */ .Re, {
                src: item.image,
                height: 48,
                width: 48,
                mr: "16px"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                style: {
                    flex: 1
                },
                children: item.label
            }),
            item.count !== undefined && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                color: "textSubtle",
                px: "8px",
                children: (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_4__/* .formatNumber */ .uf)(item.count, 0, 0)
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Radio, {
                name: "item-select",
                scale: "sm",
                checked: isSelected,
                value: item.label,
                onChange: (lodash_noop__WEBPACK_IMPORTED_MODULE_3___default()),
                ml: "24px"
            })
        ]
    })
;


/***/ }),

/***/ 99112:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {


// UNUSED EXPORTS: MinMaxFilter

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
// EXTERNAL MODULE: external "@pancakeswap/uikit"
var uikit_ = __webpack_require__(2829);
// EXTERNAL MODULE: ./src/contexts/Localization/index.tsx + 3 modules
var Localization = __webpack_require__(99150);
;// CONCATENATED MODULE: ./src/views/Nft/market/components/Filters/FilterFooter.tsx



const FilterFooter_FilterFooter = ({ children , ...props })=>/*#__PURE__*/ _jsx(Grid, {
        gridGap: "16px",
        gridTemplateColumns: "repeat(2,1fr)",
        ...props,
        px: "24px",
        py: "16px",
        borderTop: "1px solid",
        borderTopColor: "cardBorder",
        children: children
    })
;
/* harmony default export */ const Filters_FilterFooter = ((/* unused pure expression or super */ null && (FilterFooter_FilterFooter)));

;// CONCATENATED MODULE: ./src/views/Nft/market/components/Filters/MinMaxFilter/index.tsx





const MinMaxFilter = ({ onApply , onClear , max , min =0 , ...props })=>{
    const { t  } = useTranslation();
    const { 0: currentMax , 1: setCurrentMax  } = useState(max);
    const { 0: currentMin , 1: setCurrentMin  } = useState(min);
    const { 0: isError , 1: setIsError  } = useState(min > max);
    const handleMinChange = (newMin)=>{
        setCurrentMin(newMin ? parseFloat(newMin) : 0);
    };
    const handleMaxChange = (newMax)=>{
        setCurrentMax(parseFloat(newMax));
    };
    const handleApply = ()=>{
        onApply(currentMin, currentMax);
    };
    // TODO: circle back to this
    const handleClear = ()=>{
        setCurrentMax(max);
        setCurrentMin(min);
        if (onClear) {
            onClear();
        }
    };
    // If a change comes down from the top update local state
    useEffect(()=>{
        setCurrentMax(max);
    }, [
        max,
        setCurrentMax
    ]);
    useEffect(()=>{
        setCurrentMin(min);
    }, [
        min,
        setCurrentMin
    ]);
    useEffect(()=>{
        setIsError(currentMin > currentMax);
    }, [
        currentMin,
        currentMax,
        setIsError
    ]);
    return(/*#__PURE__*/ _jsx(InlineMenu, {
        component: /*#__PURE__*/ _jsx(Button, {
            variant: "light",
            scale: "sm",
            children: t('Price')
        }),
        ...props,
        children: /*#__PURE__*/ _jsxs(Box, {
            width: "320px",
            children: [
                /*#__PURE__*/ _jsx(Box, {
                    px: "24px",
                    py: "16px",
                    children: /*#__PURE__*/ _jsxs(Grid, {
                        gridGap: "16px",
                        gridTemplateColumns: "repeat(2, 1fr)",
                        children: [
                            /*#__PURE__*/ _jsx(TextField, {
                                label: t('Min'),
                                value: currentMin,
                                onUserInput: handleMinChange,
                                isWarning: isError
                            }),
                            /*#__PURE__*/ _jsx(TextField, {
                                label: t('Max'),
                                value: currentMax,
                                onUserInput: handleMaxChange,
                                isWarning: isError
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ _jsxs(FilterFooter, {
                    children: [
                        /*#__PURE__*/ _jsx(Button, {
                            variant: "secondary",
                            onClick: handleClear,
                            children: t('Clear')
                        }),
                        /*#__PURE__*/ _jsx(Button, {
                            onClick: handleApply,
                            disabled: isError,
                            children: t('Apply')
                        })
                    ]
                })
            ]
        })
    }));
};


/***/ }),

/***/ 99327:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "y": () => (/* reexport safe */ _ListTraitFilter__WEBPACK_IMPORTED_MODULE_0__.y)
/* harmony export */ });
/* harmony import */ var _ListTraitFilter__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(44202);
/* harmony import */ var _MinMaxFilter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(99112);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_ListTraitFilter__WEBPACK_IMPORTED_MODULE_0__]);
_ListTraitFilter__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];




});

/***/ })

};
;
//# sourceMappingURL=3595.js.map