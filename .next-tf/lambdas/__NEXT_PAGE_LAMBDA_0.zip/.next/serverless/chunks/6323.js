"use strict";
exports.id = 6323;
exports.ids = [6323];
exports.modules = {

/***/ 48468:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const Dots = styled_components__WEBPACK_IMPORTED_MODULE_0___default().span.withConfig({
    componentId: "sc-818b03ea-0"
})`
  &::after {
    display: inline-block;
    animation: ellipsis 1.25s infinite;
    content: '.';
    width: 1em;
    text-align: left;
  }
  @keyframes ellipsis {
    0% {
      content: '.';
    }
    33% {
      content: '..';
    }
    66% {
      content: '...';
    }
  }
`;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Dots);


/***/ }),

/***/ 86323:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "W": () => (/* binding */ MinimalPositionCard),
/* harmony export */   "Z": () => (/* binding */ FullPositionCard)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(42877);
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var components_NextLink__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(53629);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(99150);
/* harmony import */ var hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(64011);
/* harmony import */ var _hooks_useTotalSupply__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(23552);
/* harmony import */ var _state_wallet_hooks__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(71900);
/* harmony import */ var _utils_currencyId__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(28996);
/* harmony import */ var _utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(53854);
/* harmony import */ var _Card__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(36261);
/* harmony import */ var _Layout_Column__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(41914);
/* harmony import */ var _Logo_CurrencyLogo__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(34966);
/* harmony import */ var _Logo__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(83356);
/* harmony import */ var _Layout_Row__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(39475);
/* harmony import */ var _config_constants__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(3862);
/* harmony import */ var _Loader_Dots__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(48468);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Logo_CurrencyLogo__WEBPACK_IMPORTED_MODULE_14__, _Logo__WEBPACK_IMPORTED_MODULE_15__, _hooks_useTotalSupply__WEBPACK_IMPORTED_MODULE_8__, _state_wallet_hooks__WEBPACK_IMPORTED_MODULE_9__]);
([_Logo_CurrencyLogo__WEBPACK_IMPORTED_MODULE_14__, _Logo__WEBPACK_IMPORTED_MODULE_15__, _hooks_useTotalSupply__WEBPACK_IMPORTED_MODULE_8__, _state_wallet_hooks__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);



















const FixedHeightRow = styled_components__WEBPACK_IMPORTED_MODULE_4___default()(_Layout_Row__WEBPACK_IMPORTED_MODULE_16__/* .RowBetween */ .m0).withConfig({
    componentId: "sc-d2853da5-0"
})`
  height: 24px;
`;
function MinimalPositionCard({ pair , showUnwrapped =false  }) {
    const { account  } = (0,hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_6__/* .useTranslation */ .$G)();
    const currency0 = showUnwrapped ? pair.token0 : (0,_utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_11__/* .unwrappedToken */ .Bv)(pair.token0);
    const currency1 = showUnwrapped ? pair.token1 : (0,_utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_11__/* .unwrappedToken */ .Bv)(pair.token1);
    const { 0: showMore , 1: setShowMore  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const userPoolBalance = (0,_state_wallet_hooks__WEBPACK_IMPORTED_MODULE_9__/* .useTokenBalance */ .mM)(account ?? undefined, pair.liquidityToken);
    const totalPoolTokens = (0,_hooks_useTotalSupply__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)(pair.liquidityToken);
    const poolTokenPercentage = !!userPoolBalance && !!totalPoolTokens && _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_2__.JSBI.greaterThanOrEqual(totalPoolTokens.raw, userPoolBalance.raw) ? new _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_2__.Percent(userPoolBalance.raw, totalPoolTokens.raw) : undefined;
    const [token0Deposited, token1Deposited] = !!pair && !!totalPoolTokens && !!userPoolBalance && // this condition is a short-circuit in the case where useTokenBalance updates sooner than useTotalSupply
    _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_2__.JSBI.greaterThanOrEqual(totalPoolTokens.raw, userPoolBalance.raw) ? [
        pair.getLiquidityValue(pair.token0, totalPoolTokens, userPoolBalance, false),
        pair.getLiquidityValue(pair.token1, totalPoolTokens, userPoolBalance, false), 
    ] : [
        undefined,
        undefined
    ];
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: userPoolBalance && _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_2__.JSBI.greaterThan(userPoolBalance.raw, _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_2__.JSBI.BigInt(0)) ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Card, {
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.CardBody, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Layout_Column__WEBPACK_IMPORTED_MODULE_13__/* .AutoColumn */ .Tz, {
                    gap: "16px",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FixedHeightRow, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Layout_Row__WEBPACK_IMPORTED_MODULE_16__/* .RowFixed */ .DA, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                    color: "secondary",
                                    bold: true,
                                    children: t('LP tokens in your wallet')
                                })
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(FixedHeightRow, {
                            onClick: ()=>setShowMore(!showMore)
                            ,
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Layout_Row__WEBPACK_IMPORTED_MODULE_16__/* .RowFixed */ .DA, {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Logo__WEBPACK_IMPORTED_MODULE_15__/* .DoubleCurrencyLogo */ .ge, {
                                            currency0: currency0,
                                            currency1: currency1,
                                            margin: true,
                                            size: 20
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                            small: true,
                                            color: "textSubtle",
                                            children: [
                                                currency0.symbol,
                                                "-",
                                                currency1.symbol,
                                                " LP"
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Layout_Row__WEBPACK_IMPORTED_MODULE_16__/* .RowFixed */ .DA, {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                        children: userPoolBalance ? userPoolBalance.toSignificant(4) : '-'
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Layout_Column__WEBPACK_IMPORTED_MODULE_13__/* .AutoColumn */ .Tz, {
                            gap: "4px",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(FixedHeightRow, {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                            color: "textSubtle",
                                            small: true,
                                            children: [
                                                t('Share of Pool'),
                                                ":"
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                            children: poolTokenPercentage ? `${poolTokenPercentage.toFixed(6)}%` : '-'
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(FixedHeightRow, {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                            color: "textSubtle",
                                            small: true,
                                            children: [
                                                t('Pooled %asset%', {
                                                    asset: currency0.symbol
                                                }),
                                                ":"
                                            ]
                                        }),
                                        token0Deposited ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Layout_Row__WEBPACK_IMPORTED_MODULE_16__/* .RowFixed */ .DA, {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                                ml: "6px",
                                                children: token0Deposited?.toSignificant(6)
                                            })
                                        }) : '-'
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(FixedHeightRow, {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                            color: "textSubtle",
                                            small: true,
                                            children: [
                                                t('Pooled %asset%', {
                                                    asset: currency1.symbol
                                                }),
                                                ":"
                                            ]
                                        }),
                                        token1Deposited ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Layout_Row__WEBPACK_IMPORTED_MODULE_16__/* .RowFixed */ .DA, {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                                ml: "6px",
                                                children: token1Deposited?.toSignificant(6)
                                            })
                                        }) : '-'
                                    ]
                                })
                            ]
                        })
                    ]
                })
            })
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Card__WEBPACK_IMPORTED_MODULE_12__/* .LightCard */ .hl, {
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                fontSize: "14px",
                style: {
                    textAlign: 'center'
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        role: "img",
                        "aria-label": "pancake-icon",
                        children: "🥞"
                    }),
                    ' ',
                    t("By adding liquidity you'll earn 0.17% of all trades on this pair proportional to your share of the pool. Fees are added to the pool, accrue in real time and can be claimed by withdrawing your liquidity.")
                ]
            })
        })
    }));
}
function FullPositionCard({ pair , ...props }) {
    const { account  } = (0,hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_6__/* .useTranslation */ .$G)();
    const currency0 = (0,_utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_11__/* .unwrappedToken */ .Bv)(pair.token0);
    const currency1 = (0,_utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_11__/* .unwrappedToken */ .Bv)(pair.token1);
    const { 0: showMore , 1: setShowMore  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const userPoolBalance = (0,_state_wallet_hooks__WEBPACK_IMPORTED_MODULE_9__/* .useTokenBalance */ .mM)(account ?? undefined, pair.liquidityToken);
    const totalPoolTokens = (0,_hooks_useTotalSupply__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)(pair.liquidityToken);
    const poolTokenPercentage = !!userPoolBalance && !!totalPoolTokens && _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_2__.JSBI.greaterThanOrEqual(totalPoolTokens.raw, userPoolBalance.raw) ? new _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_2__.Percent(userPoolBalance.raw, totalPoolTokens.raw) : undefined;
    const [token0Deposited, token1Deposited] = !!pair && !!totalPoolTokens && !!userPoolBalance && // this condition is a short-circuit in the case where useTokenBalance updates sooner than useTotalSupply
    _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_2__.JSBI.greaterThanOrEqual(totalPoolTokens.raw, userPoolBalance.raw) ? [
        pair.getLiquidityValue(pair.token0, totalPoolTokens, userPoolBalance, false),
        pair.getLiquidityValue(pair.token1, totalPoolTokens, userPoolBalance, false), 
    ] : [
        undefined,
        undefined
    ];
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Card, {
        style: {
            borderRadius: '12px'
        },
        ...props,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                justifyContent: "space-between",
                role: "button",
                onClick: ()=>setShowMore(!showMore)
                ,
                p: "16px",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                        flexDirection: "column",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                                alignItems: "center",
                                mb: "4px",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Logo__WEBPACK_IMPORTED_MODULE_15__/* .DoubleCurrencyLogo */ .ge, {
                                        currency0: currency0,
                                        currency1: currency1,
                                        size: 20
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                        bold: true,
                                        ml: "8px",
                                        children: !currency0 || !currency1 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Loader_Dots__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {
                                            children: t('Loading')
                                        }) : `${currency0.symbol}/${currency1.symbol}`
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                fontSize: "14px",
                                color: "textSubtle",
                                children: userPoolBalance?.toSignificant(4)
                            })
                        ]
                    }),
                    showMore ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.ChevronUpIcon, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.ChevronDownIcon, {})
                ]
            }),
            showMore && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Layout_Column__WEBPACK_IMPORTED_MODULE_13__/* .AutoColumn */ .Tz, {
                gap: "8px",
                style: {
                    padding: '16px'
                },
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(FixedHeightRow, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Layout_Row__WEBPACK_IMPORTED_MODULE_16__/* .RowFixed */ .DA, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Logo_CurrencyLogo__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                                        size: "20px",
                                        currency: currency0
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                        color: "textSubtle",
                                        ml: "4px",
                                        children: [
                                            t('Pooled %asset%', {
                                                asset: currency0.symbol
                                            }),
                                            ":"
                                        ]
                                    })
                                ]
                            }),
                            token0Deposited ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Layout_Row__WEBPACK_IMPORTED_MODULE_16__/* .RowFixed */ .DA, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                    ml: "6px",
                                    children: token0Deposited?.toSignificant(6)
                                })
                            }) : '-'
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(FixedHeightRow, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Layout_Row__WEBPACK_IMPORTED_MODULE_16__/* .RowFixed */ .DA, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Logo_CurrencyLogo__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                                        size: "20px",
                                        currency: currency1
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                        color: "textSubtle",
                                        ml: "4px",
                                        children: [
                                            t('Pooled %asset%', {
                                                asset: currency1.symbol
                                            }),
                                            ":"
                                        ]
                                    })
                                ]
                            }),
                            token1Deposited ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Layout_Row__WEBPACK_IMPORTED_MODULE_16__/* .RowFixed */ .DA, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                    ml: "6px",
                                    children: token1Deposited?.toSignificant(6)
                                })
                            }) : '-'
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(FixedHeightRow, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                color: "textSubtle",
                                children: t('Share of Pool')
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                children: poolTokenPercentage ? `${poolTokenPercentage.toFixed(2) === '0.00' ? '<0.01' : poolTokenPercentage.toFixed(2)}%` : '-'
                            })
                        ]
                    }),
                    userPoolBalance && _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_2__.JSBI.greaterThan(userPoolBalance.raw, _config_constants__WEBPACK_IMPORTED_MODULE_17__/* .BIG_INT_ZERO */ .iV) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                        flexDirection: "column",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Button, {
                                as: components_NextLink__WEBPACK_IMPORTED_MODULE_5__/* .NextLinkFromReactRouter */ .a,
                                to: `/remove/${(0,_utils_currencyId__WEBPACK_IMPORTED_MODULE_10__/* .currencyId */ .H)(currency0)}/${(0,_utils_currencyId__WEBPACK_IMPORTED_MODULE_10__/* .currencyId */ .H)(currency1)}`,
                                variant: "primary",
                                width: "100%",
                                mb: "8px",
                                children: t('Remove')
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Button, {
                                as: components_NextLink__WEBPACK_IMPORTED_MODULE_5__/* .NextLinkFromReactRouter */ .a,
                                to: `/add/${(0,_utils_currencyId__WEBPACK_IMPORTED_MODULE_10__/* .currencyId */ .H)(currency0)}/${(0,_utils_currencyId__WEBPACK_IMPORTED_MODULE_10__/* .currencyId */ .H)(currency1)}`,
                                variant: "text",
                                startIcon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.AddIcon, {
                                    color: "primary"
                                }),
                                width: "100%",
                                children: t('Add liquidity instead')
                            })
                        ]
                    })
                ]
            })
        ]
    }));
};

});

/***/ }),

/***/ 23552:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(42877);
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _useContract__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(46063);
/* harmony import */ var _state_multicall_hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(91001);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_2__]);
_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];



// returns undefined if input token is undefined, or fails to get token contract,
// or contract total supply cannot be fetched
function useTotalSupply(token) {
    const contract = (0,_useContract__WEBPACK_IMPORTED_MODULE_1__/* .useTokenContract */ .Ib)(token?.address, false);
    const totalSupply = (0,_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_2__/* .useSingleCallResult */ .Wk)(contract, 'totalSupply')?.result?.[0];
    return token && totalSupply ? new _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.TokenAmount(token, totalSupply.toString()) : undefined;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useTotalSupply);

});

/***/ }),

/***/ 28996:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "H": () => (/* binding */ currencyId)
/* harmony export */ });
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(42877);
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__);

function currencyId(currency) {
    if (currency === _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.ETHER) return 'BNB';
    if (currency instanceof _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.Token) return currency.address;
    throw new Error('invalid currency');
}
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (currencyId)));


/***/ })

};
;
//# sourceMappingURL=6323.js.map