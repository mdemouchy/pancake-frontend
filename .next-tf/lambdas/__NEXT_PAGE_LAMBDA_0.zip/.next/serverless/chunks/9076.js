"use strict";
exports.id = 9076;
exports.ids = [9076];
exports.modules = {

/***/ 75279:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "z": () => (/* binding */ NftMarketLayout)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_Loader_PageLoader__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(36196);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(13968);
/* harmony import */ var state_nftMarket_types__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(75186);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([components_Loader_PageLoader__WEBPACK_IMPORTED_MODULE_1__, state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_3__]);
([components_Loader_PageLoader__WEBPACK_IMPORTED_MODULE_1__, state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);





const NftMarketLayout = ({ children  })=>{
    const initializationState = (0,state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_3__/* .useGetNFTInitializationState */ .l2)();
    (0,state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_3__/* .useFetchCollections */ .vD)();
    if (initializationState !== state_nftMarket_types__WEBPACK_IMPORTED_MODULE_4__/* .NFTMarketInitializationState.INITIALIZED */ .IB.INITIALIZED) {
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Loader_PageLoader__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {}));
    }
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: children
    }));
};

});

/***/ }),

/***/ 29949:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(99150);
/* harmony import */ var hooks_useContract__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(46063);
/* harmony import */ var hooks_useToast__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(789);
/* harmony import */ var state_profile_hooks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(89424);
/* harmony import */ var utils_addressHelpers__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(55878);
/* harmony import */ var utils_formatBalance__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(65044);
/* harmony import */ var views_Nft_market_Profile_hooks_useGetProfileCosts__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(33573);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([state_profile_hooks__WEBPACK_IMPORTED_MODULE_6__]);
state_profile_hooks__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];










const ApproveCakePage = ({ goToChange , onDismiss  })=>{
    const { 0: isApproving , 1: setIsApproving  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { profile  } = (0,state_profile_hooks__WEBPACK_IMPORTED_MODULE_6__/* .useProfile */ .Un)();
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_3__/* .useTranslation */ .$G)();
    const { costs: { numberCakeToUpdate , numberCakeToReactivate  } ,  } = (0,views_Nft_market_Profile_hooks_useGetProfileCosts__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)();
    const cakeContract = (0,hooks_useContract__WEBPACK_IMPORTED_MODULE_4__/* .useCake */ .kL)();
    const { toastError  } = (0,hooks_useToast__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)();
    const cost = profile.isActive ? numberCakeToUpdate : numberCakeToReactivate;
    const handleApprove = async ()=>{
        const tx = await cakeContract.approve((0,utils_addressHelpers__WEBPACK_IMPORTED_MODULE_7__/* .getPancakeProfileAddress */ .Re)(), cost.mul(2).toString());
        setIsApproving(true);
        const receipt = await tx.wait();
        if (receipt.status) {
            goToChange();
        } else {
            toastError(t('Error'), t('Please try again. Confirm the transaction and make sure you are paying enough gas!'));
            setIsApproving(false);
        }
    };
    if (!profile) {
        return null;
    }
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
        flexDirection: "column",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                alignItems: "center",
                justifyContent: "space-between",
                mb: "24px",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        children: profile.isActive ? t('Cost to update:') : t('Cost to reactivate:')
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        children: [
                            (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_8__/* .formatBigNumber */ .dp)(cost),
                            " CAKE"
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                disabled: isApproving,
                isLoading: isApproving,
                endIcon: isApproving ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.AutoRenewIcon, {
                    spin: true,
                    color: "currentColor"
                }) : null,
                width: "100%",
                mb: "8px",
                onClick: handleApprove,
                children: t('Enable')
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                variant: "text",
                width: "100%",
                onClick: onDismiss,
                disabled: isApproving,
                children: t('Close Window')
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ApproveCakePage);

});

/***/ }),

/***/ 25332:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(18054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var state__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(82727);
/* harmony import */ var state_profile_hooks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(89424);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(99150);
/* harmony import */ var hooks_useToast__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(789);
/* harmony import */ var state_profile__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(95952);
/* harmony import */ var hooks_useApproveConfirmTransaction__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(67218);
/* harmony import */ var utils_contractHelpers__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(61432);
/* harmony import */ var hooks_useContract__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(46063);
/* harmony import */ var hooks_useCallWithGasPrice__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(71228);
/* harmony import */ var utils_addressHelpers__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(55878);
/* harmony import */ var components_Toast__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(63937);
/* harmony import */ var components_ApproveConfirmButtons__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(75673);
/* harmony import */ var views_ProfileCreation_SelectionCard__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(74136);
/* harmony import */ var state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(13968);
/* harmony import */ var state_nftMarket_types__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(75186);
/* harmony import */ var _hooks_useNftsForAddress__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(10056);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_17__, hooks_useCallWithGasPrice__WEBPACK_IMPORTED_MODULE_12__, _hooks_useNftsForAddress__WEBPACK_IMPORTED_MODULE_19__, state_profile_hooks__WEBPACK_IMPORTED_MODULE_5__]);
([state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_17__, hooks_useCallWithGasPrice__WEBPACK_IMPORTED_MODULE_12__, _hooks_useNftsForAddress__WEBPACK_IMPORTED_MODULE_19__, state_profile_hooks__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);




















const ChangeProfilePicPage = ({ onDismiss , onSuccess  })=>{
    const { 0: selectedNft , 1: setSelectedNft  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        tokenId: null,
        collectionAddress: null
    });
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_6__/* .useTranslation */ .$G)();
    const { account , library  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_3__.useWeb3React)();
    const { isLoading: isProfileLoading , profile  } = (0,state_profile_hooks__WEBPACK_IMPORTED_MODULE_5__/* .useProfile */ .Un)();
    const { nfts  } = (0,_hooks_useNftsForAddress__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z)(account, profile, isProfileLoading);
    const dispatch = (0,state__WEBPACK_IMPORTED_MODULE_4__/* .useAppDispatch */ .TL)();
    const profileContract = (0,hooks_useContract__WEBPACK_IMPORTED_MODULE_11__/* .useProfileContract */ .wr)();
    const { toastSuccess  } = (0,hooks_useToast__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
    const { callWithGasPrice  } = (0,hooks_useCallWithGasPrice__WEBPACK_IMPORTED_MODULE_12__/* .useCallWithGasPrice */ .d)();
    const nftsInWallet = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>nfts.filter((nft)=>nft.location === state_nftMarket_types__WEBPACK_IMPORTED_MODULE_18__/* .NftLocation.WALLET */ .Fb.WALLET
        )
    , [
        nfts
    ]);
    const { data  } = (0,state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_17__/* .useApprovalNfts */ .mN)(nftsInWallet);
    const isAlreadyApproved = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        return data ? !!data[selectedNft.tokenId] : false;
    }, [
        data,
        selectedNft.tokenId
    ]);
    const { isApproving , isApproved , isConfirmed , isConfirming , handleApprove , handleConfirm  } = (0,hooks_useApproveConfirmTransaction__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)({
        onApprove: ()=>{
            const contract = (0,utils_contractHelpers__WEBPACK_IMPORTED_MODULE_10__/* .getErc721Contract */ .vE)(selectedNft.collectionAddress, library.getSigner());
            return callWithGasPrice(contract, 'approve', [
                (0,utils_addressHelpers__WEBPACK_IMPORTED_MODULE_13__/* .getPancakeProfileAddress */ .Re)(),
                selectedNft.tokenId
            ]);
        },
        onConfirm: ()=>{
            if (!profile.isActive) {
                return callWithGasPrice(profileContract, 'reactivateProfile', [
                    selectedNft.collectionAddress,
                    selectedNft.tokenId, 
                ]);
            }
            return callWithGasPrice(profileContract, 'updateProfile', [
                selectedNft.collectionAddress,
                selectedNft.tokenId
            ]);
        },
        onSuccess: async ({ receipt  })=>{
            // Re-fetch profile
            await dispatch((0,state_profile__WEBPACK_IMPORTED_MODULE_8__/* .fetchProfile */ .In)(account));
            toastSuccess(t('Profile Updated!'), /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_14__/* .ToastDescriptionWithTx */ .YO, {
                txHash: receipt.transactionHash
            }));
            if (onSuccess) {
                onSuccess();
            }
            onDismiss();
        }
    });
    const alreadyApproved = isApproved || isAlreadyApproved;
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                as: "p",
                color: "textSubtle",
                mb: "24px",
                children: t('Choose a new Collectible to use as your profile pic.')
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Box, {
                maxHeight: "300px",
                overflowY: "scroll",
                children: nftsInWallet.map((walletNft)=>{
                    const handleChange = ()=>{
                        setSelectedNft({
                            tokenId: walletNft.tokenId,
                            collectionAddress: walletNft.collectionAddress
                        });
                    };
                    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(views_ProfileCreation_SelectionCard__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                        name: "profilePicture",
                        value: walletNft.tokenId,
                        image: walletNft.image.thumbnail,
                        isChecked: walletNft.tokenId === selectedNft.tokenId,
                        onChange: handleChange,
                        disabled: isApproving || isConfirming || isConfirmed,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                            bold: true,
                            children: walletNft.name
                        })
                    }, `${walletNft.collectionAddress}#${walletNft.tokenId}`));
                })
            }),
            nfts.length === 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        as: "p",
                        color: "textSubtle",
                        mb: "16px",
                        children: t('Sorry! You don’t have any eligible Collectibles in your wallet to use!')
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        as: "p",
                        color: "textSubtle",
                        mb: "24px",
                        children: t('Make sure you have a Pancake Collectible in your wallet and try again!')
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_ApproveConfirmButtons__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                isApproveDisabled: isConfirmed || isConfirming || alreadyApproved || selectedNft.tokenId === null,
                isApproving: isApproving,
                isConfirmDisabled: !alreadyApproved || isConfirmed || selectedNft.tokenId === null,
                isConfirming: isConfirming,
                onApprove: handleApprove,
                onConfirm: handleConfirm
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                mt: "8px",
                variant: "text",
                width: "100%",
                onClick: onDismiss,
                disabled: isApproving || isConfirming,
                children: t('Close Window')
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ChangeProfilePicPage);

});

/***/ }),

/***/ 99896:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(99150);
/* harmony import */ var views_Nft_market_Profile_hooks_useGetProfileCosts__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(33573);
/* harmony import */ var state__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(82727);
/* harmony import */ var state_profile_hooks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(89424);
/* harmony import */ var state_profile__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(95952);
/* harmony import */ var hooks_useToast__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(789);
/* harmony import */ var utils_formatBalance__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(65044);
/* harmony import */ var hooks_useContract__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(46063);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(18054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var hooks_useCallWithGasPrice__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(71228);
/* harmony import */ var components_Toast__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(63937);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks_useCallWithGasPrice__WEBPACK_IMPORTED_MODULE_12__, state_profile_hooks__WEBPACK_IMPORTED_MODULE_6__]);
([hooks_useCallWithGasPrice__WEBPACK_IMPORTED_MODULE_12__, state_profile_hooks__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);














const PauseProfilePage = ({ onDismiss , onSuccess  })=>{
    const { 0: isAcknowledged , 1: setIsAcknowledged  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: isConfirming , 1: setIsConfirming  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { profile  } = (0,state_profile_hooks__WEBPACK_IMPORTED_MODULE_6__/* .useProfile */ .Un)();
    const { costs: { numberCakeToReactivate  } ,  } = (0,views_Nft_market_Profile_hooks_useGetProfileCosts__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)();
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_3__/* .useTranslation */ .$G)();
    const pancakeProfileContract = (0,hooks_useContract__WEBPACK_IMPORTED_MODULE_10__/* .useProfileContract */ .wr)();
    const { callWithGasPrice  } = (0,hooks_useCallWithGasPrice__WEBPACK_IMPORTED_MODULE_12__/* .useCallWithGasPrice */ .d)();
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_11__.useWeb3React)();
    const { toastSuccess , toastError  } = (0,hooks_useToast__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
    const dispatch = (0,state__WEBPACK_IMPORTED_MODULE_5__/* .useAppDispatch */ .TL)();
    const handleChange = ()=>setIsAcknowledged(!isAcknowledged)
    ;
    const handleDeactivateProfile = async ()=>{
        const tx = await callWithGasPrice(pancakeProfileContract, 'pauseProfile');
        toastSuccess(`${t('Transaction Submitted')}!`, /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_13__/* .ToastDescriptionWithTx */ .YO, {
            txHash: tx.hash
        }));
        setIsConfirming(true);
        const receipt = await tx.wait();
        if (receipt.status) {
            // Re-fetch profile
            await dispatch((0,state_profile__WEBPACK_IMPORTED_MODULE_7__/* .fetchProfile */ .In)(account));
            toastSuccess(t('Profile Paused!'), /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_13__/* .ToastDescriptionWithTx */ .YO, {
                txHash: receipt.transactionHash
            }));
            if (onSuccess) {
                onSuccess();
            }
            onDismiss();
        } else {
            toastError(t('Error'), t('Please try again. Confirm the transaction and make sure you are paying enough gas!'));
            setIsConfirming(false);
        }
    };
    if (!profile) {
        return null;
    }
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                as: "p",
                color: "failure",
                mb: "24px",
                children: t('This will suspend your profile and send your Collectible back to your wallet')
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                as: "p",
                color: "textSubtle",
                mb: "24px",
                children: t("While your profile is suspended, you won't be able to earn points, but your achievements and points will stay associated with your profile")
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                as: "p",
                color: "textSubtle",
                mb: "24px",
                children: t('Cost to reactivate in the future: %cost% CAKE', {
                    cost: (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_9__/* .formatBigNumber */ .dp)(numberCakeToReactivate)
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                htmlFor: "acknowledgement",
                style: {
                    cursor: 'pointer',
                    display: 'block',
                    marginBottom: '24px'
                },
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                    alignItems: "center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Checkbox, {
                            id: "acknowledgement",
                            checked: isAcknowledged,
                            onChange: handleChange,
                            scale: "sm"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                            ml: "8px",
                            children: t('I understand')
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                width: "100%",
                isLoading: isConfirming,
                endIcon: isConfirming ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.AutoRenewIcon, {
                    spin: true,
                    color: "currentColor"
                }) : null,
                disabled: !isAcknowledged || isConfirming,
                onClick: handleDeactivateProfile,
                mb: "8px",
                children: t('Confirm')
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                variant: "text",
                width: "100%",
                onClick: onDismiss,
                children: t('Close Window')
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PauseProfilePage);

});

/***/ }),

/***/ 11391:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(18054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var utils_formatBalance__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(65044);
/* harmony import */ var utils_addressHelpers__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(55878);
/* harmony import */ var hooks_useContract__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(46063);
/* harmony import */ var hooks_useTokenBalance__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(24319);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(99150);
/* harmony import */ var views_Nft_market_Profile_hooks_useGetProfileCosts__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(33573);
/* harmony import */ var config_constants_types__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(97971);
/* harmony import */ var state_profile_hooks__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(89424);
/* harmony import */ var components_ProfileAvatarWithTeam__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(78703);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks_useTokenBalance__WEBPACK_IMPORTED_MODULE_8__, state_profile_hooks__WEBPACK_IMPORTED_MODULE_12__]);
([hooks_useTokenBalance__WEBPACK_IMPORTED_MODULE_8__, state_profile_hooks__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);














const DangerOutline = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Button).attrs({
    variant: 'secondary'
}).withConfig({
    componentId: "sc-7b4ba77b-0"
})`
  border-color: ${({ theme  })=>theme.colors.failure
};
  color: ${({ theme  })=>theme.colors.failure
};
  margin-bottom: 24px;

  &:hover:not(:disabled):not(.button--disabled):not(:active) {
    border-color: ${({ theme  })=>theme.colors.failure
};
    opacity: 0.8;
  }
`;
const AvatarWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-7b4ba77b-1"
})`
  height: 64px;
  width: 64px;

  ${({ theme  })=>theme.mediaQueries.sm
} {
    height: 128px;
    width: 128px;
  }
`;
const StartPage = ({ goToApprove , goToChange , goToRemove , onDismiss  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_9__/* .useTranslation */ .$G)();
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_3__.useWeb3React)();
    const cakeContract = (0,hooks_useContract__WEBPACK_IMPORTED_MODULE_7__/* .useCake */ .kL)();
    const { profile  } = (0,state_profile_hooks__WEBPACK_IMPORTED_MODULE_12__/* .useProfile */ .Un)();
    const { balance: cakeBalance , fetchStatus  } = (0,hooks_useTokenBalance__WEBPACK_IMPORTED_MODULE_8__/* .useGetCakeBalance */ .Nn)();
    const { costs: { numberCakeToUpdate , numberCakeToReactivate  } , isLoading: isProfileCostsLoading ,  } = (0,views_Nft_market_Profile_hooks_useGetProfileCosts__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)();
    const { 0: needsApproval , 1: setNeedsApproval  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const minimumCakeRequired = profile.isActive ? numberCakeToUpdate : numberCakeToReactivate;
    const hasMinimumCakeRequired = fetchStatus === config_constants_types__WEBPACK_IMPORTED_MODULE_11__/* .FetchStatus.Fetched */ .iF.Fetched && cakeBalance.gte(minimumCakeRequired);
    /**
   * Check if the wallet has the required CAKE allowance to change their profile pic or reactivate
   * If they don't, we send them to the approval screen first
   */ (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const checkApprovalStatus = async ()=>{
            const response = await cakeContract.allowance(account, (0,utils_addressHelpers__WEBPACK_IMPORTED_MODULE_6__/* .getPancakeProfileAddress */ .Re)());
            setNeedsApproval(response.lt(minimumCakeRequired));
        };
        if (account && !isProfileCostsLoading) {
            checkApprovalStatus();
        }
    }, [
        account,
        minimumCakeRequired,
        setNeedsApproval,
        cakeContract,
        isProfileCostsLoading
    ]);
    if (!profile) {
        return null;
    }
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Flex, {
        alignItems: "center",
        justifyContent: "center",
        flexDirection: "column",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AvatarWrapper, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_ProfileAvatarWithTeam__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                    profile: profile
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Flex, {
                alignItems: "center",
                style: {
                    height: '48px'
                },
                justifyContent: "center",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                    as: "p",
                    color: "failure",
                    children: !isProfileCostsLoading && !hasMinimumCakeRequired && t('%minimum% CAKE required to change profile pic', {
                        minimum: (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_5__/* .formatBigNumber */ .dp)(minimumCakeRequired)
                    })
                })
            }),
            profile.isActive ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Button, {
                        width: "100%",
                        mb: "8px",
                        onClick: needsApproval === true ? goToApprove : goToChange,
                        disabled: isProfileCostsLoading || !hasMinimumCakeRequired || needsApproval === null,
                        children: t('Change Profile Pic')
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(DangerOutline, {
                        width: "100%",
                        onClick: goToRemove,
                        children: t('Remove Profile Pic')
                    })
                ]
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Button, {
                width: "100%",
                mb: "8px",
                onClick: needsApproval === true ? goToApprove : goToChange,
                disabled: isProfileCostsLoading || !hasMinimumCakeRequired || needsApproval === null,
                children: t('Reactivate Profile')
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Button, {
                variant: "text",
                width: "100%",
                onClick: onDismiss,
                children: t('Close Window')
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (StartPage);

});

/***/ }),

/***/ 92583:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(99150);
/* harmony import */ var _reducer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(88129);
/* harmony import */ var _StartView__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(11391);
/* harmony import */ var _PauseProfileView__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(99896);
/* harmony import */ var _ChangeProfilePicView__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(25332);
/* harmony import */ var _ApproveCakeView__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(29949);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_ApproveCakeView__WEBPACK_IMPORTED_MODULE_8__, _ChangeProfilePicView__WEBPACK_IMPORTED_MODULE_7__, _PauseProfileView__WEBPACK_IMPORTED_MODULE_6__, _StartView__WEBPACK_IMPORTED_MODULE_5__]);
([_ApproveCakeView__WEBPACK_IMPORTED_MODULE_8__, _ChangeProfilePicView__WEBPACK_IMPORTED_MODULE_7__, _PauseProfileView__WEBPACK_IMPORTED_MODULE_6__, _StartView__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);









const viewTitle = (t, currentView)=>{
    switch(currentView){
        case _reducer__WEBPACK_IMPORTED_MODULE_4__/* .Views.START */ .k.START:
            return t('Edit Profile');
        case _reducer__WEBPACK_IMPORTED_MODULE_4__/* .Views.CHANGE */ .k.CHANGE:
            return t('Change Profile Pic');
        case _reducer__WEBPACK_IMPORTED_MODULE_4__/* .Views.REMOVE */ .k.REMOVE:
            return t('Remove Profile Pic');
        case _reducer__WEBPACK_IMPORTED_MODULE_4__/* .Views.APPROVE */ .k.APPROVE:
            return t('Enable CAKE');
        default:
            return '';
    }
};
const EditProfileModal = ({ onDismiss , onSuccess  })=>{
    const { currentView , goToChange , goToRemove , goToApprove , goPrevious  } = (0,_reducer__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)();
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_3__/* .useTranslation */ .$G)();
    const isStartView = currentView === _reducer__WEBPACK_IMPORTED_MODULE_4__/* .Views.START */ .k.START;
    const handleBack = isStartView ? null : ()=>goPrevious()
    ;
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Modal, {
        title: viewTitle(t, currentView),
        onBack: handleBack,
        onDismiss: onDismiss,
        hideCloseButton: !isStartView,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            style: {
                maxWidth: '400px'
            },
            children: [
                currentView === _reducer__WEBPACK_IMPORTED_MODULE_4__/* .Views.START */ .k.START && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_StartView__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                    goToApprove: goToApprove,
                    goToChange: goToChange,
                    goToRemove: goToRemove,
                    onDismiss: onDismiss
                }),
                currentView === _reducer__WEBPACK_IMPORTED_MODULE_4__/* .Views.REMOVE */ .k.REMOVE && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PauseProfileView__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                    onDismiss: onDismiss,
                    onSuccess: onSuccess
                }),
                currentView === _reducer__WEBPACK_IMPORTED_MODULE_4__/* .Views.CHANGE */ .k.CHANGE && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ChangeProfilePicView__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                    onDismiss: onDismiss,
                    onSuccess: onSuccess
                }),
                currentView === _reducer__WEBPACK_IMPORTED_MODULE_4__/* .Views.APPROVE */ .k.APPROVE && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ApproveCakeView__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                    goToChange: goToChange,
                    onDismiss: onDismiss
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EditProfileModal);

});

/***/ }),

/***/ 88129:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "k": () => (/* binding */ Views),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

var Views;
(function(Views) {
    Views["START"] = 'start';
    Views["CHANGE"] = 'change';
    Views["REMOVE"] = 'remove';
    Views["APPROVE"] = 'approve';
})(Views || (Views = {}));
const reducer = (state, action)=>{
    switch(action.type){
        case 'set_view':
            return {
                ...state,
                currentView: action.view,
                previousView: state.currentView
            };
        case 'go_previous':
            return {
                ...state,
                currentView: state.previousView,
                previousView: state.currentView
            };
        default:
            return state;
    }
};
const useEditProfile = ()=>{
    const { 0: state , 1: dispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useReducer)(reducer, {
        currentView: Views.START,
        previousView: null
    });
    const goToStart = ()=>dispatch({
            type: 'set_view',
            view: Views.START
        })
    ;
    const goToChange = ()=>dispatch({
            type: 'set_view',
            view: Views.CHANGE
        })
    ;
    const goToRemove = ()=>dispatch({
            type: 'set_view',
            view: Views.REMOVE
        })
    ;
    const goToApprove = ()=>dispatch({
            type: 'set_view',
            view: Views.APPROVE
        })
    ;
    const goPrevious = ()=>dispatch({
            type: 'go_previous'
        })
    ;
    return {
        ...state,
        goToStart,
        goToChange,
        goToRemove,
        goToApprove,
        goPrevious
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useEditProfile);


/***/ }),

/***/ 33573:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65757);
/* harmony import */ var _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(99150);
/* harmony import */ var utils_multicall__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(41144);
/* harmony import */ var config_abi_pancakeProfile_json__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(92335);
/* harmony import */ var utils_addressHelpers__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(55878);
/* harmony import */ var hooks_useToast__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(789);







const useGetProfileCosts = ()=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_2__/* .useTranslation */ .$G)();
    const { 0: isLoading , 1: setIsLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const { 0: costs , 1: setCosts  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({
        numberCakeToReactivate: _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_1__.BigNumber.from(0),
        numberCakeToRegister: _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_1__.BigNumber.from(0),
        numberCakeToUpdate: _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_1__.BigNumber.from(0)
    });
    const { toastError  } = (0,hooks_useToast__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)();
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        const fetchCosts = async ()=>{
            try {
                const calls = [
                    'numberCakeToReactivate',
                    'numberCakeToRegister',
                    'numberCakeToUpdate'
                ].map((method)=>({
                        address: (0,utils_addressHelpers__WEBPACK_IMPORTED_MODULE_5__/* .getPancakeProfileAddress */ .Re)(),
                        name: method
                    })
                );
                const [[numberCakeToReactivate], [numberCakeToRegister], [numberCakeToUpdate]] = await (0,utils_multicall__WEBPACK_IMPORTED_MODULE_3__/* .multicallv2 */ .v)(config_abi_pancakeProfile_json__WEBPACK_IMPORTED_MODULE_4__, calls);
                setCosts({
                    numberCakeToReactivate,
                    numberCakeToRegister,
                    numberCakeToUpdate
                });
                setIsLoading(false);
            } catch (error) {
                toastError(t('Error'), t('Could not retrieve CAKE costs for profile'));
            }
        };
        fetchCosts();
    }, [
        setCosts,
        toastError,
        t
    ]);
    return {
        costs,
        isLoading
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useGetProfileCosts);


/***/ })

};
;
//# sourceMappingURL=9076.js.map