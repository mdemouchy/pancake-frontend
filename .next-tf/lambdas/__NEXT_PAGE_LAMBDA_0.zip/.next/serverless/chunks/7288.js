"use strict";
exports.id = 7288;
exports.ids = [7288];
exports.modules = {

/***/ 27288:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(38328);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(99150);
/* harmony import */ var components_Loader_CircleLoader__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7010);







var ResultStatus;
(function(ResultStatus) {
    ResultStatus[ResultStatus["NOT_VALID"] = 0] = "NOT_VALID";
    ResultStatus[ResultStatus["FOUND"] = 1] = "FOUND";
    ResultStatus[ResultStatus["NOT_FOUND"] = 2] = "NOT_FOUND";
})(ResultStatus || (ResultStatus = {}));
const SubMenu = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
    componentId: "sc-2bcd624c-0"
})`
  align-items: center;
  background: ${({ theme  })=>theme.colors.input
};
  border: 1px solid ${({ theme  })=>theme.colors.inputSecondary
};
  border-radius: 0 0 ${({ theme  })=>theme.radii.default
} ${({ theme  })=>theme.radii.default
};
  left: 0;
  padding-bottom: 8px;
  padding-top: 16px;
  position: absolute;
  top: calc(100% - 12px);
  transition: transform 0.15s, opacity 0.15s;
  transform: scaleY(0);
  transform-origin: top;
  width: 100%;
  z-index: 15;

  ${({ isOpen  })=>isOpen && `
    height: auto;
    opacity: 1;
    transform: scaleY(1);
  `
}
`;
const AddressLink = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text).withConfig({
    componentId: "sc-2bcd624c-1"
})`
  cursor: pointer;
  overflow-wrap: break-word;
  font-weight: bold;
  padding-left: 16px;
  padding-right: 16px;
`;
const initialState = {
    isFetching: false,
    resultFound: ResultStatus.NOT_VALID,
    value: ''
};
const defaultValidAddressHandler = ()=>Promise.resolve(true)
;
const AddressInputSelect = ({ onValidAddress =defaultValidAddressHandler , onAddressClick , ...props })=>{
    const { 0: state , 1: setState  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(initialState);
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_5__/* .useTranslation */ .$G)();
    const { isFetching , resultFound , value  } = state;
    const handleChange = (evt)=>{
        const { value: newValue  } = evt.target;
        setState((prevState)=>({
                ...prevState,
                value: newValue
            })
        );
    };
    const handleClick = ()=>{
        setState(initialState);
        onAddressClick(state.value);
    };
    // When we have a valid address fetch the data
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const isValidAddress = (0,utils__WEBPACK_IMPORTED_MODULE_4__/* .isAddress */ .UJ)(value) !== false;
        const validAddressHandler = async ()=>{
            try {
                setState((prevState)=>({
                        ...prevState,
                        isFetching: true
                    })
                );
                const hasResults = await onValidAddress(value);
                setState((prevState)=>({
                        ...prevState,
                        isFetching: false,
                        resultFound: hasResults ? ResultStatus.FOUND : ResultStatus.NOT_FOUND
                    })
                );
            } catch  {
                setState((prevState)=>({
                        ...prevState,
                        isFetching: false
                    })
                );
            }
        };
        if (isValidAddress) {
            validAddressHandler();
        } else {
            setState((prevState)=>({
                    ...prevState,
                    resultFound: ResultStatus.NOT_VALID
                })
            );
        }
    }, [
        value,
        onValidAddress,
        setState
    ]);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Box, {
        position: "relative",
        ...props,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Input, {
                placeholder: t('Search %subject%', {
                    subject: t('Address').toLowerCase()
                }),
                value: state.value,
                onChange: handleChange,
                style: {
                    position: 'relative',
                    zIndex: 16,
                    paddingRight: '40px'
                }
            }),
            isFetching && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Box, {
                position: "absolute",
                top: "12px",
                right: "16px",
                style: {
                    zIndex: 17
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Loader_CircleLoader__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SubMenu, {
                isOpen: resultFound !== ResultStatus.NOT_VALID,
                children: resultFound === ResultStatus.FOUND ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AddressLink, {
                    onClick: handleClick,
                    children: state.value
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                    px: "16px",
                    fontWeight: "bold",
                    children: t('No results found.')
                })
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AddressInputSelect);


/***/ })

};
;
//# sourceMappingURL=7288.js.map