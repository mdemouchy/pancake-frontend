"use strict";
exports.id = 1587;
exports.ids = [1587];
exports.modules = {

/***/ 81587:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "f": () => (/* binding */ usePoolsWithVault),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var state_farms_hooks__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8733);
/* harmony import */ var state__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(82727);
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(49949);
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(lodash_orderBy__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var state_types__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(45101);
/* harmony import */ var state_pools__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(13591);
/* harmony import */ var state_pools_hooks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1624);
/* harmony import */ var views_Pools_helpers__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(53136);
/* harmony import */ var config_constants_types__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(97971);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([state_farms_hooks__WEBPACK_IMPORTED_MODULE_1__, state_pools_hooks__WEBPACK_IMPORTED_MODULE_6__]);
([state_farms_hooks__WEBPACK_IMPORTED_MODULE_1__, state_pools_hooks__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);









function usePoolsWithVault() {
    const { pools: poolsWithoutAutoVault  } = (0,state_pools_hooks__WEBPACK_IMPORTED_MODULE_6__/* .usePools */ .Oh)();
    const cakeVault = (0,state_pools_hooks__WEBPACK_IMPORTED_MODULE_6__/* .useCakeVault */ .Xo)();
    const ifoPool = (0,state_pools_hooks__WEBPACK_IMPORTED_MODULE_6__/* .useIfoPoolVault */ .IK)();
    const pools = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        const activePools = poolsWithoutAutoVault.filter((pool)=>!pool.isFinished
        );
        const cakePool = activePools.find((pool)=>pool.sousId === 0
        );
        const cakeAutoVault = {
            ...cakePool,
            vaultKey: state_types__WEBPACK_IMPORTED_MODULE_4__/* .VaultKey.CakeVault */ .om.CakeVault
        };
        const ifoPoolVault = {
            ...cakePool,
            vaultKey: state_types__WEBPACK_IMPORTED_MODULE_4__/* .VaultKey.IfoPool */ .om.IfoPool
        };
        const cakeAutoVaultWithApr = {
            ...cakeAutoVault,
            apr: (0,views_Pools_helpers__WEBPACK_IMPORTED_MODULE_7__/* .getAprData */ .rD)(cakeAutoVault, cakeVault.fees.performanceFeeAsDecimal).apr,
            rawApr: cakePool.apr
        };
        const ifoPoolWithApr = {
            ...ifoPoolVault,
            apr: (0,views_Pools_helpers__WEBPACK_IMPORTED_MODULE_7__/* .getAprData */ .rD)(ifoPoolVault, ifoPool.fees.performanceFeeAsDecimal).apr,
            rawApr: cakePool.apr
        };
        return [
            ifoPoolWithApr,
            cakeAutoVaultWithApr,
            ...poolsWithoutAutoVault
        ];
    }, [
        poolsWithoutAutoVault,
        cakeVault.fees.performanceFeeAsDecimal,
        ifoPool.fees.performanceFeeAsDecimal
    ]);
    return pools;
}
const useGetTopPoolsByApr = (isIntersecting)=>{
    const dispatch = (0,state__WEBPACK_IMPORTED_MODULE_2__/* .useAppDispatch */ .TL)();
    const { 0: fetchStatus , 1: setFetchStatus  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(config_constants_types__WEBPACK_IMPORTED_MODULE_8__/* .FetchStatus.Idle */ .iF.Idle);
    const { 0: topPools , 1: setTopPools  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([
        null,
        null,
        null,
        null,
        null
    ]);
    const pools = usePoolsWithVault();
    const cakePriceBusd = (0,state_farms_hooks__WEBPACK_IMPORTED_MODULE_1__/* .usePriceCakeBusd */ .Iu)();
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        const fetchPoolsPublicData = async ()=>{
            setFetchStatus(config_constants_types__WEBPACK_IMPORTED_MODULE_8__/* .FetchStatus.Fetching */ .iF.Fetching);
            try {
                await dispatch((0,state_pools__WEBPACK_IMPORTED_MODULE_5__/* .fetchCakeVaultFees */ .HX)());
                await dispatch((0,state_pools__WEBPACK_IMPORTED_MODULE_5__/* .fetchPoolsPublicDataAsync */ .ht)());
                setFetchStatus(config_constants_types__WEBPACK_IMPORTED_MODULE_8__/* .FetchStatus.Fetched */ .iF.Fetched);
            } catch (e) {
                console.error(e);
                setFetchStatus(config_constants_types__WEBPACK_IMPORTED_MODULE_8__/* .FetchStatus.Failed */ .iF.Failed);
            }
        };
        if (isIntersecting && fetchStatus === config_constants_types__WEBPACK_IMPORTED_MODULE_8__/* .FetchStatus.Idle */ .iF.Idle) {
            fetchPoolsPublicData();
        }
    }, [
        dispatch,
        setFetchStatus,
        fetchStatus,
        topPools,
        isIntersecting
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        const getTopPoolsByApr = (activePools)=>{
            const sortedByApr = lodash_orderBy__WEBPACK_IMPORTED_MODULE_3___default()(activePools, (pool)=>pool.apr || 0
            , 'desc');
            setTopPools(sortedByApr.slice(0, 5));
        };
        if (fetchStatus === config_constants_types__WEBPACK_IMPORTED_MODULE_8__/* .FetchStatus.Fetched */ .iF.Fetched && !topPools[0]) {
            getTopPoolsByApr(pools);
        }
    }, [
        setTopPools,
        pools,
        fetchStatus,
        cakePriceBusd,
        topPools
    ]);
    return {
        topPools
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useGetTopPoolsByApr);

});

/***/ })

};
;
//# sourceMappingURL=1587.js.map