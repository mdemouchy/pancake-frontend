"use strict";
exports.id = 566;
exports.ids = [566];
exports.modules = {

/***/ 5509:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "vA": () => (/* binding */ getGQLHeaders),
/* harmony export */   "dQ": () => (/* binding */ infoClient),
/* harmony export */   "yH": () => (/* binding */ infoServerClient),
/* harmony export */   "iR": () => (/* binding */ bitQueryServerClient)
/* harmony export */ });
/* harmony import */ var config_constants_endpoints__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5906);
/* harmony import */ var graphql_request__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5805);
/* harmony import */ var graphql_request__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(graphql_request__WEBPACK_IMPORTED_MODULE_1__);


// Extra headers
// Mostly for dev environment
// No production env check since production preview might also need them
const getGQLHeaders = (endpoint)=>{
    if (endpoint === config_constants_endpoints__WEBPACK_IMPORTED_MODULE_0__/* .INFO_CLIENT */ .JY) {
        return {
            'X-Sf': process.env.NEXT_PUBLIC_SF_HEADER
        };
    }
    return undefined;
};
const infoClient = new graphql_request__WEBPACK_IMPORTED_MODULE_1__.GraphQLClient(config_constants_endpoints__WEBPACK_IMPORTED_MODULE_0__/* .INFO_CLIENT */ .JY, {
    headers: getGQLHeaders(config_constants_endpoints__WEBPACK_IMPORTED_MODULE_0__/* .INFO_CLIENT */ .JY)
});
const infoServerClient = new graphql_request__WEBPACK_IMPORTED_MODULE_1__.GraphQLClient(config_constants_endpoints__WEBPACK_IMPORTED_MODULE_0__/* .INFO_CLIENT */ .JY, {
    headers: {
        'X-Sf': process.env.SF_HEADER
    },
    timeout: 5000
});
const bitQueryServerClient = new graphql_request__WEBPACK_IMPORTED_MODULE_1__.GraphQLClient("https://graphql.bitquery.io", {
    headers: {
        // only server, no `NEXT_PUBLIC` not going to expose in client
        'X-API-KEY': process.env.BIT_QUERY_HEADER
    },
    timeout: 5000
});


/***/ }),

/***/ 9566:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "z": () => (/* binding */ getBlocksFromTimestamps),
/* harmony export */   "Z": () => (/* binding */ useBlocksFromTimestamps)
/* harmony export */ });
/* harmony import */ var graphql_request__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5805);
/* harmony import */ var graphql_request__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(graphql_request__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var views_Info_utils_infoQueryHelpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4796);
/* harmony import */ var config_constants_endpoints__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5906);




const getBlockSubqueries = (timestamps)=>timestamps.map((timestamp)=>{
        return `t${timestamp}:blocks(first: 1, orderBy: timestamp, orderDirection: desc, where: { timestamp_gt: ${timestamp}, timestamp_lt: ${timestamp + 600} }) {
      number
    }`;
    })
;
const blocksQueryConstructor = (subqueries)=>{
    return graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`query blocks {
    ${subqueries}
  }`;
};
/**
 * @notice Fetches block objects for an array of timestamps.
 * @param {Array} timestamps
 */ const getBlocksFromTimestamps = async (timestamps, sortDirection = 'desc', skipCount = 500)=>{
    if (timestamps?.length === 0) {
        return [];
    }
    const fetchedData = await (0,views_Info_utils_infoQueryHelpers__WEBPACK_IMPORTED_MODULE_2__/* .multiQuery */ .L)(blocksQueryConstructor, getBlockSubqueries(timestamps), config_constants_endpoints__WEBPACK_IMPORTED_MODULE_3__/* .BLOCKS_CLIENT */ .I0, skipCount);
    const sortingFunction = sortDirection === 'desc' ? (a, b)=>b.number - a.number
     : (a, b)=>a.number - b.number
    ;
    const blocks = [];
    if (fetchedData) {
        // eslint-disable-next-line no-restricted-syntax
        for (const key of Object.keys(fetchedData)){
            if (fetchedData[key].length > 0) {
                blocks.push({
                    timestamp: key.split('t')[1],
                    number: parseInt(fetchedData[key][0].number, 10)
                });
            }
        }
        // graphql-request does not guarantee same ordering of batched requests subqueries, hence manual sorting
        blocks.sort(sortingFunction);
    }
    return blocks;
};
/**
 * for a given array of timestamps, returns block entities
 * @param timestamps
 * @param sortDirection
 * @param skipCount
 */ const useBlocksFromTimestamps = (timestamps, sortDirection = 'desc', skipCount = 1000)=>{
    const { 0: blocks , 1: setBlocks  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { 0: error , 1: setError  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const timestampsString = JSON.stringify(timestamps);
    const blocksString = blocks ? JSON.stringify(blocks) : undefined;
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const fetchData = async ()=>{
            const timestampsArray = JSON.parse(timestampsString);
            const result = await getBlocksFromTimestamps(timestampsArray, sortDirection, skipCount);
            if (result.length === 0) {
                setError(true);
            } else {
                setBlocks(result);
            }
        };
        const blocksArray = blocksString ? JSON.parse(blocksString) : undefined;
        if (!blocksArray && !error) {
            fetchData();
        }
    }, [
        blocksString,
        error,
        skipCount,
        sortDirection,
        timestampsString
    ]);
    return {
        blocks,
        error
    };
};


/***/ }),

/***/ 4796:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "z": () => (/* binding */ getDeltaTimestamps),
  "L": () => (/* binding */ multiQuery)
});

// EXTERNAL MODULE: external "date-fns"
var external_date_fns_ = __webpack_require__(4146);
// EXTERNAL MODULE: external "graphql-request"
var external_graphql_request_ = __webpack_require__(5805);
// EXTERNAL MODULE: ./src/utils/graphql.ts
var graphql = __webpack_require__(5509);
;// CONCATENATED MODULE: ./src/utils/requestWithTimeout.ts
const requestWithTimeout = (graphQLClient, request, variables, timeout = 30000)=>{
    return Promise.race([
        variables ? graphQLClient.request(request, variables) : graphQLClient.request(request),
        new Promise((_, reject)=>{
            setTimeout(()=>{
                reject(new Error(`Request timed out after ${timeout} milliseconds`));
            }, timeout);
        }), 
    ]);
};
/* harmony default export */ const utils_requestWithTimeout = (requestWithTimeout);

;// CONCATENATED MODULE: ./src/views/Info/utils/infoQueryHelpers.ts




/**
 * Helper function to get large amount GraphQL subqueries
 * @param queryConstructor constructor function that combines subqueries
 * @param subqueries individual queries
 * @param endpoint GraphQL endpoint
 * @param skipCount how many subqueries to fire at a time
 * @returns
 */ const multiQuery = async (queryConstructor, subqueries, endpoint, skipCount = 1000)=>{
    let fetchedData = {};
    let allFound = false;
    let skip = 0;
    const client = new external_graphql_request_.GraphQLClient(endpoint, {
        headers: (0,graphql/* getGQLHeaders */.vA)(endpoint)
    });
    try {
        while(!allFound){
            let end = subqueries.length;
            if (skip + skipCount < subqueries.length) {
                end = skip + skipCount;
            }
            const subqueriesSlice = subqueries.slice(skip, end);
            // eslint-disable-next-line no-await-in-loop
            const result = await utils_requestWithTimeout(client, queryConstructor(subqueriesSlice));
            fetchedData = {
                ...fetchedData,
                ...result
            };
            allFound = Object.keys(result).length < skipCount || skip + skipCount > subqueries.length;
            skip += skipCount;
        }
        return fetchedData;
    } catch (error) {
        console.error('Failed to fetch info data', error);
        return null;
    }
};
/**
 * Returns UTC timestamps for 24h ago, 48h ago, 7d ago and 14d ago relative to current date and time
 */ const getDeltaTimestamps = ()=>{
    const utcCurrentTime = (0,external_date_fns_.getUnixTime)(new Date()) * 1000;
    const t24h = (0,external_date_fns_.getUnixTime)((0,external_date_fns_.startOfMinute)((0,external_date_fns_.subDays)(utcCurrentTime, 1)));
    const t48h = (0,external_date_fns_.getUnixTime)((0,external_date_fns_.startOfMinute)((0,external_date_fns_.subDays)(utcCurrentTime, 2)));
    const t7d = (0,external_date_fns_.getUnixTime)((0,external_date_fns_.startOfMinute)((0,external_date_fns_.subWeeks)(utcCurrentTime, 1)));
    const t14d = (0,external_date_fns_.getUnixTime)((0,external_date_fns_.startOfMinute)((0,external_date_fns_.subWeeks)(utcCurrentTime, 2)));
    return [
        t24h,
        t48h,
        t7d,
        t14d
    ];
};


/***/ })

};
;
//# sourceMappingURL=566.js.map