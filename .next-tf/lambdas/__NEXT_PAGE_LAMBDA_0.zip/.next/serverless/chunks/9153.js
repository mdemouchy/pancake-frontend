"use strict";
exports.id = 9153;
exports.ids = [9153];
exports.modules = {

/***/ 12087:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var views_Nft_market_components_BannerHeader_AvatarImage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(70217);
/* harmony import */ var _EditProfileModal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(92583);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_EditProfileModal__WEBPACK_IMPORTED_MODULE_5__]);
_EditProfileModal__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];






const EditOverlay = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-7f8c8de3-0"
})`
  background: rgba(0, 0, 0, 0.6) url('/images/camera.svg') no-repeat center center;
  border-radius: 50%;
  left: 0;
  height: 100%;
  opacity: 0;
  position: absolute;
  top: 0;
  transition: opacity 300ms;
  width: 100%;
  z-index: 1;
`;
const StyledEditProfileAvatar = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-7f8c8de3-1"
})`
  position: relative;

  &:hover {
    cursor: pointer;

    ${EditOverlay} {
      opacity: 1;
    }
  }
`;
const EditProfileAvatar = ({ src , alt , onSuccess  })=>{
    const [onEditProfileModal] = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.useModal)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_EditProfileModal__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
        onSuccess: onSuccess
    }), false);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(StyledEditProfileAvatar, {
        onClick: onEditProfileModal,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(views_Nft_market_components_BannerHeader_AvatarImage__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                src: src,
                alt: alt
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(EditOverlay, {})
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EditProfileAvatar);

});

/***/ }),

/***/ 89286:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_NextLink__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(53629);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99150);
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(38328);
/* harmony import */ var utils_formatBalance__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(65044);
/* harmony import */ var utils_truncateHash__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(53467);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(18054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _EditProfileAvatar__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(12087);
/* harmony import */ var _components_BannerHeader__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(12399);
/* harmony import */ var _components_StatBox__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(74298);
/* harmony import */ var _components_MarketPageTitle__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(75199);
/* harmony import */ var _EditProfileModal__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(92583);
/* harmony import */ var _components_BannerHeader_AvatarImage__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(70217);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_EditProfileAvatar__WEBPACK_IMPORTED_MODULE_8__, _EditProfileModal__WEBPACK_IMPORTED_MODULE_12__]);
([_EditProfileAvatar__WEBPACK_IMPORTED_MODULE_8__, _EditProfileModal__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);















// Account and profile passed down as the profile could be used to render _other_ users' profiles.
const ProfileHeader = ({ accountPath , profile , achievements , nftCollected , isAchievementsLoading , isNftLoading , isProfileLoading , onSuccess ,  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_7__.useWeb3React)();
    const [onEditProfileModal] = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.useModal)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_EditProfileModal__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
        onSuccess: ()=>{
            if (onSuccess) {
                onSuccess();
            }
        }
    }), false);
    const isConnectedAccount = account?.toLowerCase() === accountPath?.toLowerCase();
    const numNftCollected = !isNftLoading ? nftCollected ? (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_6__/* .formatNumber */ .uf)(nftCollected, 0, 0) : '-' : null;
    const numPoints = !isProfileLoading ? profile?.points ? (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_6__/* .formatNumber */ .uf)(profile.points, 0, 0) : '-' : null;
    const numAchievements = !isAchievementsLoading ? achievements?.length ? (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_6__/* .formatNumber */ .uf)(achievements.length, 0, 0) : '-' : null;
    const avatarImage = profile?.nft?.image?.thumbnail || '/images/nfts/no-profile-md.png';
    const getBannerImage = ()=>{
        const imagePath = '/images/teams';
        if (profile) {
            switch(profile.teamId){
                case 1:
                    return `${imagePath}/storm-banner.png`;
                case 2:
                    return `${imagePath}/flippers-banner.png`;
                case 3:
                    return `${imagePath}/cakers-banner.png`;
                default:
                    break;
            }
        }
        return `${imagePath}/no-team-banner.png`;
    };
    const getAvatar = ()=>{
        const getIconButtons = ()=>{
            return(// TODO: Share functionality once user profiles routed by ID
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                display: "inline-flex",
                children: accountPath && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.IconButton, {
                    as: "a",
                    target: "_blank",
                    style: {
                        width: 'fit-content'
                    },
                    href: (0,utils__WEBPACK_IMPORTED_MODULE_5__/* .getBscScanLink */ .s6)(accountPath, 'address') || '',
                    // @ts-ignore
                    alt: t('View BscScan for user address'),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.BscScanIcon, {
                        width: "20px",
                        color: "primary"
                    })
                })
            }));
        };
        const getImage = ()=>{
            return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: profile && accountPath && isConnectedAccount ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_EditProfileAvatar__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                    src: avatarImage,
                    alt: t('User profile picture'),
                    onSuccess: ()=>{
                        if (onSuccess) {
                            onSuccess();
                        }
                    }
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_BannerHeader_AvatarImage__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                    src: avatarImage,
                    alt: t('User profile picture')
                })
            }));
        };
        return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                getImage(),
                getIconButtons()
            ]
        }));
    };
    const getTitle = ()=>{
        if (profile?.username) {
            return `@${profile.username}`;
        }
        if (accountPath) {
            return (0,utils_truncateHash__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z)(accountPath, 5, 3);
        }
        return null;
    };
    const renderDescription = ()=>{
        const getActivateButton = ()=>{
            if (!profile) {
                return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_NextLink__WEBPACK_IMPORTED_MODULE_2__/* .NextLinkFromReactRouter */ .a, {
                    to: "/create-profile",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Button, {
                        mt: "16px",
                        children: t('Activate Profile')
                    })
                }));
            }
            return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Button, {
                width: "fit-content",
                mt: "16px",
                onClick: onEditProfileModal,
                children: t('Reactivate Profile')
            }));
        };
        return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
            flexDirection: "column",
            mb: [
                16,
                null,
                0
            ],
            mr: [
                0,
                null,
                16
            ],
            children: [
                accountPath && profile?.username && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Link, {
                    href: (0,utils__WEBPACK_IMPORTED_MODULE_5__/* .getBscScanLink */ .s6)(accountPath, 'address'),
                    external: true,
                    bold: true,
                    color: "primary",
                    children: (0,utils_truncateHash__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z)(accountPath)
                }),
                accountPath && isConnectedAccount && (!profile || !profile?.nft) && getActivateButton()
            ]
        }));
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_BannerHeader__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                bannerImage: getBannerImage(),
                bannerAlt: t('User team banner'),
                avatar: getAvatar()
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_MarketPageTitle__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                pb: "48px",
                title: getTitle(),
                description: renderDescription(),
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_StatBox__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_StatBox__WEBPACK_IMPORTED_MODULE_10__/* .StatBoxItem */ .B, {
                            title: t('NFT Collected'),
                            stat: numNftCollected
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_StatBox__WEBPACK_IMPORTED_MODULE_10__/* .StatBoxItem */ .B, {
                            title: t('Points'),
                            stat: numPoints
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_StatBox__WEBPACK_IMPORTED_MODULE_10__/* .StatBoxItem */ .B, {
                            title: t('Achievements'),
                            stat: numAchievements
                        })
                    ]
                })
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProfileHeader);

});

/***/ }),

/***/ 82834:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(99150);
/* harmony import */ var components_NextLink__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(53629);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var views_Nft_market_constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1940);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_7__);








const Tab = styled_components__WEBPACK_IMPORTED_MODULE_4___default().button.withConfig({
    componentId: "sc-b36abb46-0"
})`
  display: inline-flex;
  justify-content: center;
  cursor: pointer;
  color: ${({ theme , $active  })=>$active ? theme.colors.secondary : theme.colors.textSubtle
};
  border-width: ${({ $active  })=>$active ? '1px 1px 0 1px' : '0'
};
  border-style: solid solid none solid;
  border-color: ${({ theme  })=>`${theme.colors.cardBorder} ${theme.colors.cardBorder} transparent ${theme.colors.cardBorder}`
};
  outline: 0;
  padding: 12px 16px;
  border-radius: 16px 16px 0 0;
  font-size: 16px;
  font-weight: ${({ $active  })=>$active ? '600' : '400'
};
  background-color: ${({ theme , $active  })=>$active ? theme.colors.background : 'transparent'
};
  transition: background-color 0.3s ease-out;
`;
const TabMenu = ()=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_2__/* .useTranslation */ .$G)();
    const { pathname , query  } = (0,next_router__WEBPACK_IMPORTED_MODULE_7__.useRouter)();
    const { accountAddress  } = query;
    const { 0: achievementsActive , 1: setIsAchievementsActive  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(pathname.includes('achievements'));
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setIsAchievementsActive(pathname.includes('achievements'));
    }, [
        pathname
    ]);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Flex, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Tab, {
                onClick: ()=>setIsAchievementsActive(false)
                ,
                $active: !achievementsActive,
                as: components_NextLink__WEBPACK_IMPORTED_MODULE_3__/* .NextLinkFromReactRouter */ .a,
                to: `${views_Nft_market_constants__WEBPACK_IMPORTED_MODULE_6__/* .nftsBaseUrl */ .Vf}/profile/${accountAddress}`,
                children: "NFTs"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Tab, {
                onClick: ()=>setIsAchievementsActive(true)
                ,
                $active: achievementsActive,
                as: components_NextLink__WEBPACK_IMPORTED_MODULE_3__/* .NextLinkFromReactRouter */ .a,
                to: `${views_Nft_market_constants__WEBPACK_IMPORTED_MODULE_6__/* .nftsBaseUrl */ .Vf}/profile/${accountAddress}/achievements`,
                children: t('Achievements')
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TabMenu);


/***/ }),

/***/ 39153:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "K": () => (/* binding */ NftProfileLayout)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(38328);
/* harmony import */ var state_profile_hooks__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(89424);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var components_Layout_Page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9770);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(99150);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _components_MarketPageHeader__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(38282);
/* harmony import */ var _components_ProfileHeader__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(89286);
/* harmony import */ var _components_Activity_NoNftsImage__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7402);
/* harmony import */ var _Layout__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(75279);
/* harmony import */ var _hooks_useNftsForAddress__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(10056);
/* harmony import */ var _components_TabMenu__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(82834);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Layout__WEBPACK_IMPORTED_MODULE_12__, components_Layout_Page__WEBPACK_IMPORTED_MODULE_6__, _components_ProfileHeader__WEBPACK_IMPORTED_MODULE_10__, _components_MarketPageHeader__WEBPACK_IMPORTED_MODULE_9__, _hooks_useNftsForAddress__WEBPACK_IMPORTED_MODULE_13__, state_profile_hooks__WEBPACK_IMPORTED_MODULE_4__]);
([_Layout__WEBPACK_IMPORTED_MODULE_12__, components_Layout_Page__WEBPACK_IMPORTED_MODULE_6__, _components_ProfileHeader__WEBPACK_IMPORTED_MODULE_10__, _components_MarketPageHeader__WEBPACK_IMPORTED_MODULE_9__, _hooks_useNftsForAddress__WEBPACK_IMPORTED_MODULE_13__, state_profile_hooks__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);















const TabMenuWrapper = styled_components__WEBPACK_IMPORTED_MODULE_8___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Box).withConfig({
    componentId: "sc-f8e5a0c3-0"
})`
  position: absolute;
  bottom: 0;
  left: 50%;
  transform: translate(-50%, 0%);

  ${({ theme  })=>theme.mediaQueries.sm
} {
    left: auto;
    transform: none;
  }
`;
const NftProfile = ({ children  })=>{
    const accountAddress = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)().query.accountAddress;
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_7__/* .useTranslation */ .$G)();
    const invalidAddress = !accountAddress || (0,utils__WEBPACK_IMPORTED_MODULE_3__/* .isAddress */ .UJ)(accountAddress) === false;
    const { profile: profileHookState , isFetching: isProfileFetching , refresh: refreshProfile ,  } = (0,state_profile_hooks__WEBPACK_IMPORTED_MODULE_4__/* .useProfileForAddress */ .lC)(accountAddress);
    const { profile  } = profileHookState || {};
    const { achievements , isFetching: isAchievementsFetching  } = (0,state_profile_hooks__WEBPACK_IMPORTED_MODULE_4__/* .useAchievementsForAddress */ .$v)(accountAddress);
    const { nfts: userNfts , isLoading: isNftLoading , refresh: refreshUserNfts ,  } = (0,_hooks_useNftsForAddress__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z)(accountAddress, profile, isProfileFetching);
    if (invalidAddress) {
        return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_MarketPageHeader__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                    position: "relative",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ProfileHeader__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                        accountPath: accountAddress,
                        profile: null,
                        achievements: null,
                        nftCollected: null,
                        isAchievementsLoading: false,
                        isNftLoading: false,
                        isProfileLoading: false
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Layout_Page__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                    style: {
                        minHeight: 'auto'
                    },
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Flex, {
                        p: "24px",
                        flexDirection: "column",
                        alignItems: "center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Activity_NoNftsImage__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Text, {
                                textAlign: "center",
                                maxWidth: "420px",
                                pt: "8px",
                                bold: true,
                                children: t('Please enter a valid address, or connect your wallet to view your profile')
                            })
                        ]
                    })
                })
            ]
        }));
    }
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_MarketPageHeader__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                position: "relative",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ProfileHeader__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                        accountPath: accountAddress,
                        profile: profile,
                        achievements: achievements,
                        nftCollected: userNfts.length,
                        isProfileLoading: isProfileFetching,
                        isNftLoading: isNftLoading,
                        isAchievementsLoading: isAchievementsFetching,
                        onSuccess: async ()=>{
                            await refreshProfile();
                            refreshUserNfts();
                        }
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TabMenuWrapper, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_TabMenu__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {})
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Layout_Page__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                style: {
                    minHeight: 'auto'
                },
                children: children
            })
        ]
    }));
};
const NftProfileLayout = ({ children  })=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(NftProfile, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Layout__WEBPACK_IMPORTED_MODULE_12__/* .NftMarketLayout */ .z, {
            children: children
        })
    }));
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (NftProfile)));

});

/***/ })

};
;
//# sourceMappingURL=9153.js.map