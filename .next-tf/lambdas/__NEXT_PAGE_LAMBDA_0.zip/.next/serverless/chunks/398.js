"use strict";
exports.id = 398;
exports.ids = [398];
exports.modules = {

/***/ 14166:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tk": () => (/* binding */ TwoColumnsContainer),
/* harmony export */   "_v": () => (/* binding */ RoundedImage),
/* harmony export */   "em": () => (/* binding */ SmallRoundedImage),
/* harmony export */   "W2": () => (/* binding */ Container),
/* harmony export */   "Db": () => (/* binding */ CollectionLink),
/* harmony export */   "u$": () => (/* binding */ CollectibleRowContainer),
/* harmony export */   "IB": () => (/* binding */ StyledSortButton),
/* harmony export */   "qO": () => (/* binding */ ButtonContainer),
/* harmony export */   "cq": () => (/* binding */ TableHeading)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_NextLink__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(53629);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);



const TwoColumnsContainer = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex).withConfig({
    componentId: "sc-d90693fb-0"
})`
  gap: 22px;
  align-items: flex-start;
  & > div:first-child {
    flex: 1;
    gap: 20px;
  }
  & > div:last-child {
    flex: 2;
  }
`;
const RoundedImage = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Image).withConfig({
    componentId: "sc-d90693fb-1"
})`
  height: max-content;
  border-radius: ${({ theme  })=>theme.radii.default
};
  overflow: hidden;
  & > img {
    object-fit: contain;
  }
`;
const SmallRoundedImage = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Image).withConfig({
    componentId: "sc-d90693fb-2"
})`
  & > img {
    border-radius: ${({ theme  })=>theme.radii.default
};
  }
`;
const Container = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex).withConfig({
    componentId: "sc-d90693fb-3"
})`
  gap: 24px;
`;
const CollectionLink = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(components_NextLink__WEBPACK_IMPORTED_MODULE_1__/* .NextLinkFromReactRouter */ .a).withConfig({
    componentId: "sc-d90693fb-4"
})`
  color: ${({ theme  })=>theme.colors.primary
};
  display: block;
  font-weight: 600;
  margin-top: 16px;

  ${({ theme  })=>theme.mediaQueries.lg
} {
    margin-top: 50px;
  }
`;
const CollectibleRowContainer = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Grid).withConfig({
    componentId: "sc-d90693fb-5"
})`
  &:hover {
    opacity: 0.5;
    cursor: pointer;
  }
`;
const StyledSortButton = styled_components__WEBPACK_IMPORTED_MODULE_0___default().button.withConfig({
    componentId: "sc-d90693fb-6"
})`
  border: none;
  cursor: pointer;
  background: none;
  color: ${({ theme  })=>theme.colors.secondary
};
  font-weight: bold;
`;
const ButtonContainer = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Box).withConfig({
    componentId: "sc-d90693fb-7"
})`
  text-align: right;
  padding-right: 24px;
`;
const TableHeading = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Grid).withConfig({
    componentId: "sc-d90693fb-8"
})`
  border-bottom: ${({ theme  })=>`1px solid ${theme.colors.cardBorder}`
};
`;


/***/ }),

/***/ 50398:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export AspectRatio */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var hooks_useIntersectionObserver__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(76538);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _Collection_IndividualNFTPage_shared_styles__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(14166);






const StyledAspectRatio = styled_components__WEBPACK_IMPORTED_MODULE_4___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Box).withConfig({
    componentId: "sc-669701a5-0"
})`
  position: absolute;
  inset: 0;
`;
const AspectRatio = ({ ratio , children , ...props })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Box, {
        width: "100%",
        height: 0,
        pb: `${100 / ratio}%`,
        position: "relative",
        ...props,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledAspectRatio, {
            children: children
        })
    })
;
const NFTMedia = ({ width , height , nft , borderRadius ='default' , as , ...props })=>{
    const { observerRef , isIntersecting  } = (0,hooks_useIntersectionObserver__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)();
    const vidRef = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        if (vidRef.current) {
            if (isIntersecting) {
                vidRef.current.play();
            } else {
                vidRef.current.pause();
            }
        }
    }, [
        isIntersecting
    ]);
    if (nft?.image.webm || nft?.image.mp4) {
        return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(AspectRatio, {
            ratio: width / height,
            ...props,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    ref: observerRef
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Box, {
                    ref: vidRef,
                    borderRadius: borderRadius,
                    as: "video",
                    width: "100%",
                    height: "100%",
                    muted: true,
                    loop: true,
                    playsInline: true,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                            src: nft.image.webm,
                            type: "video/webm"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                            src: nft.image.mp4,
                            type: "video/mp4"
                        })
                    ]
                })
            ]
        }));
    }
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Collection_IndividualNFTPage_shared_styles__WEBPACK_IMPORTED_MODULE_5__/* .RoundedImage */ ._v, {
        width: width,
        height: height,
        src: nft?.image.gif || nft?.image.thumbnail,
        alt: nft?.name,
        as: as,
        ...props
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NFTMedia);


/***/ })

};
;
//# sourceMappingURL=398.js.map