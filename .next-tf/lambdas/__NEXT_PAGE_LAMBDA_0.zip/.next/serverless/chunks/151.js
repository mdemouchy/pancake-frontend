"use strict";
exports.id = 151;
exports.ids = [151];
exports.modules = {

/***/ 3442:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5941);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var state_user_hooks__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8605);
/* harmony import */ var utils_web3React__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2338);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9150);
/* harmony import */ var contexts_ToastsContext__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5083);
/* harmony import */ var hooks_useSWRContract__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8472);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks_useSWRContract__WEBPACK_IMPORTED_MODULE_11__, swr__WEBPACK_IMPORTED_MODULE_5__, state_user_hooks__WEBPACK_IMPORTED_MODULE_7__]);
([hooks_useSWRContract__WEBPACK_IMPORTED_MODULE_11__, swr__WEBPACK_IMPORTED_MODULE_5__, state_user_hooks__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);












const ThemeProviderWrapper = (props)=>{
    const [isDark] = (0,state_user_hooks__WEBPACK_IMPORTED_MODULE_7__/* .useThemeManager */ .HY)();
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(styled_components__WEBPACK_IMPORTED_MODULE_6__.ThemeProvider, {
        theme: isDark ? _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.dark : _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.light,
        ...props
    }));
};
const Providers = ({ children , store  })=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_web3_react_core__WEBPACK_IMPORTED_MODULE_3__.Web3ReactProvider, {
        getLibrary: utils_web3React__WEBPACK_IMPORTED_MODULE_8__/* .getLibrary */ .av,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_redux__WEBPACK_IMPORTED_MODULE_4__.Provider, {
            store: store,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(contexts_ToastsContext__WEBPACK_IMPORTED_MODULE_10__/* .ToastsProvider */ .d0, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ThemeProviderWrapper, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(contexts_Localization__WEBPACK_IMPORTED_MODULE_9__/* .LanguageProvider */ .iL, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swr__WEBPACK_IMPORTED_MODULE_5__.SWRConfig, {
                            value: {
                                use: [
                                    hooks_useSWRContract__WEBPACK_IMPORTED_MODULE_11__/* .fetchStatusMiddleware */ .qf
                                ]
                            },
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.ModalProvider, {
                                children: children
                            })
                        })
                    })
                })
            })
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Providers);

});

/***/ }),

/***/ 621:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var hooks_useAuth__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1222);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9150);





const ConnectWalletButton = (props)=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    const { login , logout  } = (0,hooks_useAuth__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)();
    const { onPresentConnectModal  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.useWalletModal)(login, logout, t);
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
        onClick: onPresentConnectModal,
        ...props,
        children: t('Connect Wallet')
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ConnectWalletButton);


/***/ }),

/***/ 6301:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* reexport */ EasterEgg_EasterEgg)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "@pancakeswap/uikit"
var uikit_ = __webpack_require__(2829);
;// CONCATENATED MODULE: ./src/components/EasterEgg/EasterEgg.tsx



const EasterEgg = (props)=>{
    const { 0: show , 1: setShow  } = (0,external_react_.useState)(false);
    const startFalling = (0,external_react_.useCallback)(()=>setShow(true)
    , [
        setShow
    ]);
    (0,uikit_.useKonamiCheatCode)(startFalling);
    if (show) {
        return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
            onAnimationEnd: ()=>setShow(false)
            ,
            children: /*#__PURE__*/ jsx_runtime_.jsx(uikit_.FallingBunnies, {
                ...props
            })
        }));
    }
    return null;
};
/* harmony default export */ const EasterEgg_EasterEgg = (/*#__PURE__*/external_react_default().memo(EasterEgg));

;// CONCATENATED MODULE: ./src/components/EasterEgg/index.ts



/***/ }),

/***/ 9452:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ErrorBoundary)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _sentry_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5427);
/* harmony import */ var _sentry_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_sentry_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var components_Layout_Page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9770);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9150);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([components_Layout_Page__WEBPACK_IMPORTED_MODULE_3__]);
components_Layout_Page__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];






function ErrorBoundary({ children  }) {
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_sentry_react__WEBPACK_IMPORTED_MODULE_2__.ErrorBoundary, {
        fallback: ()=>{
            return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Layout_Page__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Flex, {
                    flexDirection: "column",
                    justifyContent: "center",
                    alignItems: "center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.LogoIcon, {
                            width: "64px",
                            mb: "8px"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Text, {
                            mb: "16px",
                            children: t('Oops, something wrong.')
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Button, {
                            onClick: ()=>window.location.reload()
                            ,
                            children: t('Click here to reset!')
                        })
                    ]
                })
            }));
        },
        children: children
    }));
};

});

/***/ }),

/***/ 3408:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* reexport safe */ _ErrorBoundary__WEBPACK_IMPORTED_MODULE_0__.Z)
/* harmony export */ });
/* harmony import */ var _ErrorBoundary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9452);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_ErrorBoundary__WEBPACK_IMPORTED_MODULE_0__]);
_ErrorBoundary__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];


});

/***/ }),

/***/ 7580:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5152);
/* harmony import */ var utils_contractHelpers__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4765);







const AnniversaryAchievementModal = (0,next_dynamic__WEBPACK_IMPORTED_MODULE_5__["default"])(null, {
    loadableGenerated: {
        modules: [
            "../components/GlobalCheckClaimStatus/index.tsx -> " + "./AnniversaryAchievementModal"
        ]
    },
    ssr: false
});
// change it to true if we have events to check claim status
const enable = false;
const GlobalCheckClaimStatus = (props)=>{
    if (!enable) {
        return null;
    }
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(GlobalCheckClaim, {
        ...props
    }));
};
/**
 * This is represented as a component rather than a hook because we need to keep it
 * inside the Router.
 *
 * TODO: Put global checks in redux or make a generic area to house global checks
 */ const GlobalCheckClaim = ({ excludeLocations  })=>{
    const hasDisplayedModal = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(false);
    const { 0: canClaimAnniversaryPoints , 1: setCanClaimAnniversaryPoints  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_4__.useWeb3React)();
    const { pathname  } = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const [onPresentAnniversaryModal] = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.useModal)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AnniversaryAchievementModal, {}));
    // Check claim status
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const fetchClaimAnniversaryStatus = async ()=>{
            const { canClaim  } = (0,utils_contractHelpers__WEBPACK_IMPORTED_MODULE_6__/* .getAnniversaryAchievementContract */ .f$)();
            const canClaimAnniversary = await canClaim(account);
            setCanClaimAnniversaryPoints(canClaimAnniversary);
        };
        if (account) {
            fetchClaimAnniversaryStatus();
        }
    }, [
        account
    ]);
    // Check if we need to display the modal
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const matchesSomeLocations = excludeLocations.some((location)=>pathname.includes(location)
        );
        if (canClaimAnniversaryPoints && !matchesSomeLocations && !hasDisplayedModal.current) {
            onPresentAnniversaryModal();
            hasDisplayedModal.current = true;
        }
    }, [
        pathname,
        excludeLocations,
        hasDisplayedModal,
        onPresentAnniversaryModal,
        canClaimAnniversaryPoints
    ]);
    // Reset the check flag when account changes
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        hasDisplayedModal.current = false;
    }, [
        account,
        hasDisplayedModal
    ]);
    return null;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (GlobalCheckClaimStatus);


/***/ }),

/***/ 5027:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);



const Container = ({ children , ...props })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Box, {
        px: [
            '16px',
            '24px'
        ],
        mx: "auto",
        maxWidth: "1200px",
        ...props,
        children: children
    })
;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Container);


/***/ }),

/***/ 9770:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "V": () => (/* binding */ PageMeta),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9150);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var config_constants_meta__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7521);
/* harmony import */ var hooks_useBUSDPrice__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(834);
/* harmony import */ var _Container__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5027);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks_useBUSDPrice__WEBPACK_IMPORTED_MODULE_7__]);
hooks_useBUSDPrice__WEBPACK_IMPORTED_MODULE_7__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];









const StyledPage = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_Container__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z).withConfig({
    componentId: "sc-a071541c-0"
})`
  min-height: calc(100vh - 64px);
  padding-top: 16px;
  padding-bottom: 16px;

  ${({ theme  })=>theme.mediaQueries.sm
} {
    padding-top: 24px;
    padding-bottom: 24px;
  }

  ${({ theme  })=>theme.mediaQueries.lg
} {
    padding-top: 32px;
    padding-bottom: 32px;
  }
`;
const PageMeta = ({ symbol  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_3__/* .useTranslation */ .$G)();
    const { pathname  } = (0,next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)();
    const cakePriceUsd = (0,hooks_useBUSDPrice__WEBPACK_IMPORTED_MODULE_7__/* .useCakeBusdPrice */ .S9)();
    const cakePriceUsdDisplay = cakePriceUsd ? `$${cakePriceUsd.toFixed(3)}` : '...';
    const pageMeta = (0,config_constants_meta__WEBPACK_IMPORTED_MODULE_6__/* .getCustomMeta */ .S)(pathname, t) || {};
    const { title , description , image  } = {
        ...config_constants_meta__WEBPACK_IMPORTED_MODULE_6__/* .DEFAULT_META */ .k,
        ...pageMeta
    };
    let pageTitle = cakePriceUsdDisplay ? [
        title,
        cakePriceUsdDisplay
    ].join(' - ') : title;
    if (symbol) {
        pageTitle = [
            symbol,
            title
        ].join(' - ');
    }
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_4___default()), {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                children: pageTitle
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                property: "og:title",
                content: title
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                property: "og:description",
                content: description
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                property: "og:image",
                content: image
            })
        ]
    }));
};
const Page = ({ children , symbol , ...props })=>{
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(PageMeta, {
                symbol: symbol
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledPage, {
                ...props,
                children: children
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Page);

});

/***/ }),

/***/ 9829:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var state_user_hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8605);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9150);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([state_user_hooks__WEBPACK_IMPORTED_MODULE_3__]);
state_user_hooks__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];





const ExpertModal = ({ setShowConfirmExpertModal , setShowExpertModeAcknowledgement  })=>{
    const [, toggleExpertMode] = (0,state_user_hooks__WEBPACK_IMPORTED_MODULE_3__/* .useExpertModeManager */ .DG)();
    const { 0: isRememberChecked , 1: setIsRememberChecked  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Modal, {
        title: t('Expert Mode'),
        onBack: ()=>setShowConfirmExpertModal(false)
        ,
        onDismiss: ()=>setShowConfirmExpertModal(false)
        ,
        headerBackground: "gradients.cardHeader",
        style: {
            maxWidth: '360px'
        },
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Message, {
                variant: "warning",
                mb: "24px",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                    children: t("Expert mode turns off the 'Confirm' transaction prompt, and allows high slippage trades that often result in bad rates and lost funds.")
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                mb: "24px",
                children: t('Only use this mode if you know what you’re doing.')
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                alignItems: "center",
                mb: "24px",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Checkbox, {
                        name: "confirmed",
                        type: "checkbox",
                        checked: isRememberChecked,
                        onChange: ()=>setIsRememberChecked(!isRememberChecked)
                        ,
                        scale: "sm"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        ml: "10px",
                        color: "textSubtle",
                        style: {
                            userSelect: 'none'
                        },
                        children: t('Don’t show this again')
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                mb: "8px",
                id: "confirm-expert-mode",
                onClick: ()=>{
                    // eslint-disable-next-line no-alert
                    if (window.prompt(`Please type the word "confirm" to enable expert mode.`) === 'confirm') {
                        toggleExpertMode();
                        setShowConfirmExpertModal(false);
                        if (isRememberChecked) {
                            setShowExpertModeAcknowledgement(false);
                        }
                    }
                },
                children: t('Turn On Expert Mode')
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                variant: "secondary",
                onClick: ()=>{
                    setShowConfirmExpertModal(false);
                },
                children: t('Cancel')
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ExpertModal);

});

/***/ }),

/***/ 2683:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var components_QuestionHelper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5061);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9150);
/* harmony import */ var state_user_hooks_helpers__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(787);
/* harmony import */ var state_user_hooks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8605);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([state_user_hooks__WEBPACK_IMPORTED_MODULE_6__]);
state_user_hooks__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];







const GasSettings = ()=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    const [gasPrice, setGasPrice] = (0,state_user_hooks__WEBPACK_IMPORTED_MODULE_6__/* .useGasPriceManager */ .nF)();
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
        flexDirection: "column",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                mb: "12px",
                alignItems: "center",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        children: t('Default Transaction Speed (GWEI)')
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_QuestionHelper__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                        text: t('Adjusts the gas price (transaction fee) for your transaction. Higher GWEI = higher speed = higher fees'),
                        placement: "top-start",
                        ml: "4px"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                flexWrap: "wrap",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                        mt: "4px",
                        mr: "4px",
                        scale: "sm",
                        onClick: ()=>{
                            setGasPrice(state_user_hooks_helpers__WEBPACK_IMPORTED_MODULE_5__/* .GAS_PRICE_GWEI["default"] */ .j4["default"]);
                        },
                        variant: gasPrice === state_user_hooks_helpers__WEBPACK_IMPORTED_MODULE_5__/* .GAS_PRICE_GWEI["default"] */ .j4["default"] ? 'primary' : 'tertiary',
                        children: t('Standard (%gasPrice%)', {
                            gasPrice: state_user_hooks_helpers__WEBPACK_IMPORTED_MODULE_5__/* .GAS_PRICE["default"] */ .DB["default"]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                        mt: "4px",
                        mr: "4px",
                        scale: "sm",
                        onClick: ()=>{
                            setGasPrice(state_user_hooks_helpers__WEBPACK_IMPORTED_MODULE_5__/* .GAS_PRICE_GWEI.fast */ .j4.fast);
                        },
                        variant: gasPrice === state_user_hooks_helpers__WEBPACK_IMPORTED_MODULE_5__/* .GAS_PRICE_GWEI.fast */ .j4.fast ? 'primary' : 'tertiary',
                        children: t('Fast (%gasPrice%)', {
                            gasPrice: state_user_hooks_helpers__WEBPACK_IMPORTED_MODULE_5__/* .GAS_PRICE.fast */ .DB.fast
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                        mr: "4px",
                        mt: "4px",
                        scale: "sm",
                        onClick: ()=>{
                            setGasPrice(state_user_hooks_helpers__WEBPACK_IMPORTED_MODULE_5__/* .GAS_PRICE_GWEI.instant */ .j4.instant);
                        },
                        variant: gasPrice === state_user_hooks_helpers__WEBPACK_IMPORTED_MODULE_5__/* .GAS_PRICE_GWEI.instant */ .j4.instant ? 'primary' : 'tertiary',
                        children: t('Instant (%gasPrice%)', {
                            gasPrice: state_user_hooks_helpers__WEBPACK_IMPORTED_MODULE_5__/* .GAS_PRICE.instant */ .DB.instant
                        })
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (GasSettings);

});

/***/ }),

/***/ 4109:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var state_user_hooks__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8605);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9150);
/* harmony import */ var hooks_useTheme__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3917);
/* harmony import */ var _QuestionHelper__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5061);
/* harmony import */ var _TransactionSettings__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(599);
/* harmony import */ var _ExpertModal__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9829);
/* harmony import */ var _GasSettings__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2683);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_TransactionSettings__WEBPACK_IMPORTED_MODULE_8__, _GasSettings__WEBPACK_IMPORTED_MODULE_10__, _ExpertModal__WEBPACK_IMPORTED_MODULE_9__, hooks_useTheme__WEBPACK_IMPORTED_MODULE_6__, state_user_hooks__WEBPACK_IMPORTED_MODULE_4__]);
([_TransactionSettings__WEBPACK_IMPORTED_MODULE_8__, _GasSettings__WEBPACK_IMPORTED_MODULE_10__, _ExpertModal__WEBPACK_IMPORTED_MODULE_9__, hooks_useTheme__WEBPACK_IMPORTED_MODULE_6__, state_user_hooks__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);











const ScrollableContainer = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex).withConfig({
    componentId: "sc-31761d1a-0"
})`
  flex-direction: column;
  max-height: 400px;
  ${({ theme  })=>theme.mediaQueries.sm
} {
    max-height: none;
  }
`;
const SettingsModal = ({ onDismiss  })=>{
    const { 0: showConfirmExpertModal , 1: setShowConfirmExpertModal  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [showExpertModeAcknowledgement, setShowExpertModeAcknowledgement] = (0,state_user_hooks__WEBPACK_IMPORTED_MODULE_4__/* .useUserExpertModeAcknowledgementShow */ .wX)();
    const [expertMode, toggleExpertMode] = (0,state_user_hooks__WEBPACK_IMPORTED_MODULE_4__/* .useExpertModeManager */ .DG)();
    const [singleHopOnly, setSingleHopOnly] = (0,state_user_hooks__WEBPACK_IMPORTED_MODULE_4__/* .useUserSingleHopOnly */ .RO)();
    const [audioPlay, toggleSetAudioMode] = (0,state_user_hooks__WEBPACK_IMPORTED_MODULE_4__/* .useAudioModeManager */ .TO)();
    const [subgraphHealth, setSubgraphHealh] = (0,state_user_hooks__WEBPACK_IMPORTED_MODULE_4__/* .useSubgraphHealthIndicatorManager */ .YF)();
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_5__/* .useTranslation */ .$G)();
    const { theme , isDark , toggleTheme  } = (0,hooks_useTheme__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)();
    if (showConfirmExpertModal) {
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ExpertModal__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
            setShowConfirmExpertModal: setShowConfirmExpertModal,
            onDismiss: onDismiss,
            setShowExpertModeAcknowledgement: setShowExpertModeAcknowledgement
        }));
    }
    const handleExpertModeToggle = ()=>{
        if (expertMode) {
            toggleExpertMode();
        } else if (!showExpertModeAcknowledgement) {
            toggleExpertMode();
        } else {
            setShowConfirmExpertModal(true);
        }
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Modal, {
        title: t('Settings'),
        headerBackground: "gradients.cardHeader",
        onDismiss: onDismiss,
        style: {
            maxWidth: '420px'
        },
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ScrollableContainer, {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                    pb: "24px",
                    flexDirection: "column",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                            bold: true,
                            textTransform: "uppercase",
                            fontSize: "12px",
                            color: "secondary",
                            mb: "24px",
                            children: t('Global')
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                            justifyContent: "space-between",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                    mb: "24px",
                                    children: t('Dark mode')
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.ThemeSwitcher, {
                                    isDark: isDark,
                                    toggleTheme: toggleTheme
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_GasSettings__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {})
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                    pt: "24px",
                    flexDirection: "column",
                    borderTop: `1px ${theme.colors.cardBorder} solid`,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                            bold: true,
                            textTransform: "uppercase",
                            fontSize: "12px",
                            color: "secondary",
                            mb: "24px",
                            children: t('Swaps & Liquidity')
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TransactionSettings__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {})
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                    justifyContent: "space-between",
                    alignItems: "center",
                    mb: "24px",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                            alignItems: "center",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                    children: t('Expert Mode')
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_QuestionHelper__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                    text: t('Bypasses confirmation modals and allows high slippage trades. Use at your own risk.'),
                                    placement: "top-start",
                                    ml: "4px"
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Toggle, {
                            id: "toggle-expert-mode-button",
                            scale: "md",
                            checked: expertMode,
                            onChange: handleExpertModeToggle
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                    justifyContent: "space-between",
                    alignItems: "center",
                    mb: "24px",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                            alignItems: "center",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                    children: t('Disable Multihops')
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_QuestionHelper__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                    text: t('Restricts swaps to direct pairs only.'),
                                    placement: "top-start",
                                    ml: "4px"
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Toggle, {
                            id: "toggle-disable-multihop-button",
                            checked: singleHopOnly,
                            scale: "md",
                            onChange: ()=>{
                                setSingleHopOnly(!singleHopOnly);
                            }
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                    justifyContent: "space-between",
                    alignItems: "center",
                    mb: "24px",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                            alignItems: "center",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                    children: t('Subgraph Health Indicator')
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_QuestionHelper__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                    text: t('Turn on NFT market subgraph health indicator all the time. Default is to show the indicator only when the network is delayed'),
                                    placement: "top-start",
                                    ml: "4px"
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Toggle, {
                            id: "toggle-subgraph-health-button",
                            checked: subgraphHealth,
                            scale: "md",
                            onChange: ()=>{
                                setSubgraphHealh(!subgraphHealth);
                            }
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                    justifyContent: "space-between",
                    alignItems: "center",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                            alignItems: "center",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                    children: t('Flippy sounds')
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_QuestionHelper__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                    text: t('Fun sounds to make a truly immersive pancake-flipping trading experience'),
                                    placement: "top-start",
                                    ml: "4px"
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.PancakeToggle, {
                            checked: audioPlay,
                            onChange: toggleSetAudioMode,
                            scale: "md"
                        })
                    ]
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SettingsModal);

});

/***/ }),

/***/ 599:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8328);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9150);
/* harmony import */ var state_user_hooks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8605);
/* harmony import */ var _QuestionHelper__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5061);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([state_user_hooks__WEBPACK_IMPORTED_MODULE_5__]);
state_user_hooks__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];







var SlippageError;
(function(SlippageError) {
    SlippageError["InvalidInput"] = "InvalidInput";
    SlippageError["RiskyLow"] = "RiskyLow";
    SlippageError["RiskyHigh"] = "RiskyHigh";
})(SlippageError || (SlippageError = {}));
var DeadlineError;
(function(DeadlineError) {
    DeadlineError["InvalidInput"] = "InvalidInput";
})(DeadlineError || (DeadlineError = {}));
const inputRegex = RegExp(`^\\d*(?:\\\\[.])?\\d*$`) // match escaped "." characters via in a non-capturing group
;
const SlippageTabs = ()=>{
    const [userSlippageTolerance, setUserSlippageTolerance] = (0,state_user_hooks__WEBPACK_IMPORTED_MODULE_5__/* .useUserSlippageTolerance */ .$2)();
    const [ttl, setTtl] = (0,state_user_hooks__WEBPACK_IMPORTED_MODULE_5__/* .useUserTransactionTTL */ .A6)();
    const { 0: slippageInput , 1: setSlippageInput  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const { 0: deadlineInput , 1: setDeadlineInput  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    const slippageInputIsValid = slippageInput === '' || (userSlippageTolerance / 100).toFixed(2) === Number.parseFloat(slippageInput).toFixed(2);
    const deadlineInputIsValid = deadlineInput === '' || (ttl / 60).toString() === deadlineInput;
    let slippageError;
    if (slippageInput !== '' && !slippageInputIsValid) {
        slippageError = SlippageError.InvalidInput;
    } else if (slippageInputIsValid && userSlippageTolerance < 50) {
        slippageError = SlippageError.RiskyLow;
    } else if (slippageInputIsValid && userSlippageTolerance > 500) {
        slippageError = SlippageError.RiskyHigh;
    } else {
        slippageError = undefined;
    }
    let deadlineError;
    if (deadlineInput !== '' && !deadlineInputIsValid) {
        deadlineError = DeadlineError.InvalidInput;
    } else {
        deadlineError = undefined;
    }
    const parseCustomSlippage = (value)=>{
        if (value === '' || inputRegex.test((0,utils__WEBPACK_IMPORTED_MODULE_2__/* .escapeRegExp */ .hr)(value))) {
            setSlippageInput(value);
            try {
                const valueAsIntFromRoundedFloat = Number.parseInt((Number.parseFloat(value) * 100).toString());
                if (!Number.isNaN(valueAsIntFromRoundedFloat) && valueAsIntFromRoundedFloat < 5000) {
                    setUserSlippageTolerance(valueAsIntFromRoundedFloat);
                }
            } catch (error) {
                console.error(error);
            }
        }
    };
    const parseCustomDeadline = (value)=>{
        setDeadlineInput(value);
        try {
            const valueAsInt = Number.parseInt(value) * 60;
            if (!Number.isNaN(valueAsInt) && valueAsInt > 0) {
                setTtl(valueAsInt);
            }
        } catch (error) {
            console.error(error);
        }
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
        flexDirection: "column",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                flexDirection: "column",
                mb: "24px",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                        mb: "12px",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                children: t('Slippage Tolerance')
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_QuestionHelper__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                text: t('Setting a high slippage tolerance can help transactions succeed, but you may not get such a good price. Use with caution.'),
                                placement: "top-start",
                                ml: "4px"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                        flexWrap: "wrap",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Button, {
                                mt: "4px",
                                mr: "4px",
                                scale: "sm",
                                onClick: ()=>{
                                    setSlippageInput('');
                                    setUserSlippageTolerance(10);
                                },
                                variant: userSlippageTolerance === 10 ? 'primary' : 'tertiary',
                                children: "0.1%"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Button, {
                                mt: "4px",
                                mr: "4px",
                                scale: "sm",
                                onClick: ()=>{
                                    setSlippageInput('');
                                    setUserSlippageTolerance(50);
                                },
                                variant: userSlippageTolerance === 50 ? 'primary' : 'tertiary',
                                children: "0.5%"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Button, {
                                mr: "4px",
                                mt: "4px",
                                scale: "sm",
                                onClick: ()=>{
                                    setSlippageInput('');
                                    setUserSlippageTolerance(100);
                                },
                                variant: userSlippageTolerance === 100 ? 'primary' : 'tertiary',
                                children: "1.0%"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                                alignItems: "center",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Box, {
                                        width: "76px",
                                        mt: "4px",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Input, {
                                            scale: "sm",
                                            inputMode: "decimal",
                                            pattern: "^[0-9]*[.,]?[0-9]{0,2}$",
                                            placeholder: (userSlippageTolerance / 100).toFixed(2),
                                            value: slippageInput,
                                            onBlur: ()=>{
                                                parseCustomSlippage((userSlippageTolerance / 100).toFixed(2));
                                            },
                                            onChange: (event)=>{
                                                if (event.currentTarget.validity.valid) {
                                                    parseCustomSlippage(event.target.value.replace(/,/g, '.'));
                                                }
                                            },
                                            isWarning: !slippageInputIsValid,
                                            isSuccess: ![
                                                10,
                                                50,
                                                100
                                            ].includes(userSlippageTolerance)
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                        color: "primary",
                                        bold: true,
                                        ml: "2px",
                                        children: "%"
                                    })
                                ]
                            })
                        ]
                    }),
                    !!slippageError && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                        fontSize: "14px",
                        color: slippageError === SlippageError.InvalidInput ? 'red' : '#F3841E',
                        mt: "8px",
                        children: slippageError === SlippageError.InvalidInput ? t('Enter a valid slippage percentage') : slippageError === SlippageError.RiskyLow ? t('Your transaction may fail') : t('Your transaction may be frontrun')
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                justifyContent: "space-between",
                alignItems: "center",
                mb: "24px",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                        alignItems: "center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                children: t('Tx deadline (mins)')
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_QuestionHelper__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                text: t('Your transaction will revert if it is left confirming for longer than this time.'),
                                placement: "top-start",
                                ml: "4px"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Box, {
                            width: "52px",
                            mt: "4px",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Input, {
                                scale: "sm",
                                inputMode: "numeric",
                                pattern: "^[0-9]+$",
                                color: deadlineError ? 'red' : undefined,
                                onBlur: ()=>{
                                    parseCustomDeadline((ttl / 60).toString());
                                },
                                placeholder: (ttl / 60).toString(),
                                value: deadlineInput,
                                onChange: (event)=>{
                                    if (event.currentTarget.validity.valid) {
                                        parseCustomDeadline(event.target.value);
                                    }
                                }
                            })
                        })
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SlippageTabs);

});

/***/ }),

/***/ 4339:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _SettingsModal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4109);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_SettingsModal__WEBPACK_IMPORTED_MODULE_3__]);
_SettingsModal__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];




const GlobalSettings = ({ color , mr ='8px'  })=>{
    const [onPresentSettingsModal] = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.useModal)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SettingsModal__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}));
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.IconButton, {
            onClick: onPresentSettingsModal,
            variant: "text",
            scale: "sm",
            mr: mr,
            id: "open-settings-dialog-button",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.CogIcon, {
                height: 24,
                width: 24,
                color: color || 'textSubtle'
            })
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (GlobalSettings);

});

/***/ }),

/***/ 7414:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9150);





const Wrapper = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex).withConfig({
    componentId: "sc-f35b35c3-0"
})`
  align-items: center;
  background-color: ${({ theme  })=>theme.colors.dropdown
};
  border-radius: 16px;
  position: relative;
`;
const Address = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
    componentId: "sc-f35b35c3-1"
})`
  flex: 1;
  position: relative;
  padding-left: 16px;

  & > input {
    background: transparent;
    border: 0;
    color: ${({ theme  })=>theme.colors.text
};
    display: block;
    font-weight: 600;
    font-size: 16px;
    padding: 0;
    width: 100%;

    &:focus {
      outline: 0;
    }
  }

  &:after {
    background: linear-gradient(
      to right,
      ${({ theme  })=>theme.colors.background
}00,
      ${({ theme  })=>theme.colors.background
}E6
    );
    content: '';
    height: 100%;
    pointer-events: none;
    position: absolute;
    right: 0;
    top: 0;
    width: 40px;
  }
`;
const Tooltip = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
    componentId: "sc-f35b35c3-2"
})`
  display: ${({ isTooltipDisplayed  })=>isTooltipDisplayed ? 'inline-block' : 'none'
};
  position: absolute;
  padding: 8px;
  top: -38px;
  right: 0;
  text-align: center;
  background-color: ${({ theme  })=>theme.colors.contrast
};
  color: ${({ theme  })=>theme.colors.invertedContrast
};
  border-radius: 16px;
  opacity: 0.7;
  width: 100px;
`;
const CopyAddress = ({ account , ...props })=>{
    const { 0: isTooltipDisplayed , 1: setIsTooltipDisplayed  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    const copyAddress = ()=>{
        if (navigator.clipboard && navigator.permissions) {
            navigator.clipboard.writeText(account).then(()=>displayTooltip()
            );
        } else if (document.queryCommandSupported('copy')) {
            const ele = document.createElement('textarea');
            ele.value = account;
            document.body.appendChild(ele);
            ele.select();
            document.execCommand('copy');
            document.body.removeChild(ele);
            displayTooltip();
        }
    };
    function displayTooltip() {
        setIsTooltipDisplayed(true);
        setTimeout(()=>{
            setIsTooltipDisplayed(false);
        }, 1000);
    }
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Box, {
        position: "relative",
        ...props,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Wrapper, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Address, {
                        title: account,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            type: "text",
                            readOnly: true,
                            value: account
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.IconButton, {
                        variant: "text",
                        onClick: copyAddress,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.CopyIcon, {
                            color: "primary",
                            width: "24px"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Tooltip, {
                isTooltipDisplayed: isTooltipDisplayed,
                children: t('Copied')
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CopyAddress);


/***/ }),

/***/ 3111:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9150);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);






const Dot = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-f7c7d882-0"
})`
  background-color: ${({ theme  })=>theme.colors.failure
};
  border-radius: 50%;
  height: 8px;
  width: 8px;
`;
const ProfileUserMenuItem = ({ isLoading , hasProfile  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)();
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    const handleNoProfileClick = ()=>{
        router.push('/create-profile');
    };
    if (isLoading) {
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.UserMenuItem, {
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Skeleton, {
                height: "24px",
                width: "35%"
            })
        }));
    }
    if (!hasProfile) {
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.UserMenuItem, {
            as: "button",
            onClick: handleNoProfileClick,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                alignItems: "center",
                justifyContent: "space-between",
                width: "100%",
                children: [
                    t('Make a Profile'),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Dot, {})
                ]
            })
        }));
    }
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.UserMenuItem, {
        as: "button",
        children: [
            t('Your Profile'),
            " LoooL1"
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProfileUserMenuItem);


/***/ }),

/***/ 756:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var config_constants_tokens__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9748);
/* harmony import */ var config_constants_types__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7971);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9150);
/* harmony import */ var hooks_useAuth__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1222);
/* harmony import */ var hooks_useTokenBalance__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4319);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8328);
/* harmony import */ var utils_formatBalance__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5044);
/* harmony import */ var _CopyAddress__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7414);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks_useTokenBalance__WEBPACK_IMPORTED_MODULE_7__]);
hooks_useTokenBalance__WEBPACK_IMPORTED_MODULE_7__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];












const WalletInfo = ({ hasLowBnbBalance , onDismiss  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_5__/* .useTranslation */ .$G)();
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_2__.useWeb3React)();
    const { balance , fetchStatus  } = (0,hooks_useTokenBalance__WEBPACK_IMPORTED_MODULE_7__/* .useGetBnbBalance */ .nu)();
    const { balance: cakeBalance , fetchStatus: cakeFetchStatus  } = (0,hooks_useTokenBalance__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP)(config_constants_tokens__WEBPACK_IMPORTED_MODULE_3__/* ["default"].cake.address */ .ZP.cake.address);
    const { logout  } = (0,hooks_useAuth__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)();
    const handleLogout = ()=>{
        onDismiss();
        logout();
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Text, {
                color: "secondary",
                fontSize: "12px",
                textTransform: "uppercase",
                fontWeight: "bold",
                mb: "8px",
                children: t('Your Address')
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CopyAddress__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                account: account,
                mb: "24px"
            }),
            hasLowBnbBalance && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Message, {
                variant: "warning",
                mb: "24px",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Box, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Text, {
                            fontWeight: "bold",
                            children: t('BNB Balance Low')
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Text, {
                            as: "p",
                            children: t('You need BNB for transaction fees.')
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                alignItems: "center",
                justifyContent: "space-between",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Text, {
                        color: "textSubtle",
                        children: t('BNB Balance')
                    }),
                    fetchStatus !== config_constants_types__WEBPACK_IMPORTED_MODULE_4__/* .FetchStatus.Fetched */ .iF.Fetched ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Skeleton, {
                        height: "22px",
                        width: "60px"
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Text, {
                        children: (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_10__/* .formatBigNumber */ .dp)(balance, 6)
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                alignItems: "center",
                justifyContent: "space-between",
                mb: "24px",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Text, {
                        color: "textSubtle",
                        children: t('CAKE Balance')
                    }),
                    cakeFetchStatus !== config_constants_types__WEBPACK_IMPORTED_MODULE_4__/* .FetchStatus.Fetched */ .iF.Fetched ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Skeleton, {
                        height: "22px",
                        width: "60px"
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Text, {
                        children: (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_10__/* .getFullDisplayBalance */ .NJ)(cakeBalance, 18, 3)
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                alignItems: "center",
                justifyContent: "end",
                mb: "24px",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.LinkExternal, {
                    href: (0,utils__WEBPACK_IMPORTED_MODULE_9__/* .getBscScanLink */ .s6)(account, 'address'),
                    children: t('View on BscScan')
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Button, {
                variant: "secondary",
                width: "100%",
                onClick: handleLogout,
                children: t('Disconnect Wallet')
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WalletInfo);

});

/***/ }),

/***/ 5245:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "L9": () => (/* binding */ WalletView),
/* harmony export */   "Gh": () => (/* binding */ LOW_BNB_BALANCE),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ethersproject_units__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3138);
/* harmony import */ var _ethersproject_units__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_units__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9150);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var hooks_useTokenBalance__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4319);
/* harmony import */ var config_constants_types__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7971);
/* harmony import */ var _WalletInfo__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(756);
/* harmony import */ var _WalletTransactions__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1475);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_WalletInfo__WEBPACK_IMPORTED_MODULE_8__, hooks_useTokenBalance__WEBPACK_IMPORTED_MODULE_6__]);
([_WalletInfo__WEBPACK_IMPORTED_MODULE_8__, hooks_useTokenBalance__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);










var WalletView;
(function(WalletView) {
    WalletView[WalletView["WALLET_INFO"] = 0] = "WALLET_INFO";
    WalletView[WalletView["TRANSACTIONS"] = 1] = "TRANSACTIONS";
})(WalletView || (WalletView = {}));
const LOW_BNB_BALANCE = (0,_ethersproject_units__WEBPACK_IMPORTED_MODULE_3__.parseUnits)('2', 'gwei');
const ModalHeader = styled_components__WEBPACK_IMPORTED_MODULE_5___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.ModalHeader).withConfig({
    componentId: "sc-603407d1-0"
})`
  background: ${({ theme  })=>theme.colors.gradients.bubblegum
};
`;
const Tabs = styled_components__WEBPACK_IMPORTED_MODULE_5___default().div.withConfig({
    componentId: "sc-603407d1-1"
})`
  background-color: ${({ theme  })=>theme.colors.dropdown
};
  border-bottom: 1px solid ${({ theme  })=>theme.colors.cardBorder
};
  padding: 16px 24px;
`;
const WalletModal = ({ initialView =WalletView.WALLET_INFO , onDismiss  })=>{
    const { 0: view , 1: setView  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(initialView);
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    const { balance , fetchStatus  } = (0,hooks_useTokenBalance__WEBPACK_IMPORTED_MODULE_6__/* .useGetBnbBalance */ .nu)();
    const hasLowBnbBalance = fetchStatus === config_constants_types__WEBPACK_IMPORTED_MODULE_7__/* .FetchStatus.Fetched */ .iF.Fetched && balance.lte(LOW_BNB_BALANCE);
    const handleClick = (newIndex)=>{
        setView(newIndex);
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.ModalContainer, {
        title: t('Welcome!'),
        minWidth: "320px",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ModalHeader, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.ModalTitle, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Heading, {
                            children: t('Your Wallet')
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.IconButton, {
                        variant: "text",
                        onClick: onDismiss,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.CloseIcon, {
                            width: "24px",
                            color: "text"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Tabs, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.ButtonMenu, {
                    scale: "sm",
                    variant: "subtle",
                    onItemClick: handleClick,
                    activeIndex: view,
                    fullWidth: true,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.ButtonMenuItem, {
                            children: t('Wallet')
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.ButtonMenuItem, {
                            children: t('Transactions')
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.ModalBody, {
                p: "24px",
                maxWidth: "400px",
                width: "100%",
                children: [
                    view === WalletView.WALLET_INFO && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_WalletInfo__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                        hasLowBnbBalance: hasLowBnbBalance,
                        onDismiss: onDismiss
                    }),
                    view === WalletView.TRANSACTIONS && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_WalletTransactions__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {})
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WalletModal);

});

/***/ }),

/***/ 1475:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ UserMenu_WalletTransactions)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: external "@pancakeswap/uikit"
var uikit_ = __webpack_require__(2829);
// EXTERNAL MODULE: ./src/hooks/useActiveWeb3React.ts
var hooks_useActiveWeb3React = __webpack_require__(4011);
// EXTERNAL MODULE: ./src/state/transactions/actions.ts
var actions = __webpack_require__(1564);
;// CONCATENATED MODULE: ./src/state/transactions/hooks.tsx




// helper that can take a ethers library transaction response and add it to the list of transactions
function useTransactionAdder() {
    const { chainId , account  } = useActiveWeb3React();
    const dispatch = useDispatch();
    return useCallback((response, { summary , approval , claim  } = {})=>{
        if (!account) return;
        if (!chainId) return;
        const { hash  } = response;
        if (!hash) {
            throw Error('No transaction hash found.');
        }
        dispatch(addTransaction({
            hash,
            from: account,
            chainId,
            approval,
            summary,
            claim
        }));
    }, [
        dispatch,
        chainId,
        account
    ]);
}
// returns all the transactions for the current chain
function useAllTransactions() {
    const { chainId  } = (0,hooks_useActiveWeb3React/* default */.Z)();
    const state = (0,external_react_redux_.useSelector)((s)=>s.transactions
    );
    return chainId ? state[chainId] ?? {} : {};
}
function useIsTransactionPending(transactionHash) {
    const transactions = useAllTransactions();
    if (!transactionHash || !transactions[transactionHash]) return false;
    return !transactions[transactionHash].receipt;
}
/**
 * Returns whether a transaction happened in the last day (86400 seconds * 1000 milliseconds / second)
 * @param tx to check for recency
 */ function isTransactionRecent(tx) {
    return new Date().getTime() - tx.addedTime < 86400000;
}
// returns whether a token has a pending approval transaction
function useHasPendingApproval(tokenAddress, spender) {
    const allTransactions = useAllTransactions();
    return useMemo(()=>typeof tokenAddress === 'string' && typeof spender === 'string' && Object.keys(allTransactions).some((hash)=>{
            const tx = allTransactions[hash];
            if (!tx) return false;
            if (tx.receipt) {
                return false;
            }
            const { approval  } = tx;
            if (!approval) return false;
            return approval.spender === spender && approval.tokenAddress === tokenAddress && isTransactionRecent(tx);
        })
    , [
        allTransactions,
        spender,
        tokenAddress
    ]);
}

// EXTERNAL MODULE: ./src/contexts/Localization/index.tsx + 3 modules
var Localization = __webpack_require__(9150);
// EXTERNAL MODULE: external "lodash/orderBy"
var orderBy_ = __webpack_require__(9949);
var orderBy_default = /*#__PURE__*/__webpack_require__.n(orderBy_);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(7518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: ./src/utils/index.ts + 1 modules
var utils = __webpack_require__(8328);
;// CONCATENATED MODULE: ./src/components/Menu/UserMenu/TransactionRow.tsx






const TxnIcon = external_styled_components_default()(uikit_.Flex).withConfig({
    componentId: "sc-d1836170-0"
})`
  align-items: center;
  flex: none;
  width: 24px;
`;
const Summary = external_styled_components_default().div.withConfig({
    componentId: "sc-d1836170-1"
})`
  flex: 1;
  padding: 0 8px;
`;
const TxnLink = external_styled_components_default()(uikit_.Link).withConfig({
    componentId: "sc-d1836170-2"
})`
  align-items: center;
  color: ${({ theme  })=>theme.colors.text
};
  display: flex;
  margin-bottom: 16px;
  width: 100%;

  &:hover {
    text-decoration: none;
  }
`;
const renderIcon = (txn)=>{
    if (!txn.receipt) {
        return(/*#__PURE__*/ jsx_runtime_.jsx(uikit_.RefreshIcon, {
            spin: true,
            width: "24px"
        }));
    }
    return txn.receipt?.status === 1 || typeof txn.receipt?.status === 'undefined' ? /*#__PURE__*/ jsx_runtime_.jsx(uikit_.CheckmarkCircleIcon, {
        color: "success",
        width: "24px"
    }) : /*#__PURE__*/ jsx_runtime_.jsx(uikit_.BlockIcon, {
        color: "failure",
        width: "24px"
    });
};
const TransactionRow = ({ txn  })=>{
    const { chainId  } = (0,hooks_useActiveWeb3React/* default */.Z)();
    if (!txn) {
        return null;
    }
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(TxnLink, {
        href: (0,utils/* getBscScanLink */.s6)(txn.hash, 'transaction', chainId),
        external: true,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(TxnIcon, {
                children: renderIcon(txn)
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Summary, {
                children: txn.summary ?? txn.hash
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(TxnIcon, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(uikit_.OpenNewIcon, {
                    width: "24px",
                    color: "primary"
                })
            })
        ]
    }));
};
/* harmony default export */ const UserMenu_TransactionRow = (TransactionRow);

;// CONCATENATED MODULE: ./src/components/Menu/UserMenu/WalletTransactions.tsx










const WalletTransactions = ()=>{
    const { chainId  } = (0,hooks_useActiveWeb3React/* default */.Z)();
    const dispatch = (0,external_react_redux_.useDispatch)();
    const { t  } = (0,Localization/* useTranslation */.$G)();
    const allTransactions = useAllTransactions();
    const sortedTransactions = orderBy_default()(Object.values(allTransactions).filter(isTransactionRecent), 'addedTime', 'desc');
    const handleClearAll = ()=>{
        if (chainId) {
            dispatch((0,actions/* clearAllTransactions */.fY)({
                chainId
            }));
        }
    };
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(uikit_.Box, {
        minHeight: "120px",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(uikit_.Flex, {
                alignItems: "center",
                justifyContent: "space-between",
                mb: "24px",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Text, {
                        color: "secondary",
                        fontSize: "12px",
                        textTransform: "uppercase",
                        fontWeight: "bold",
                        children: t('Recent Transactions')
                    }),
                    sortedTransactions.length > 0 && /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Button, {
                        scale: "sm",
                        onClick: handleClearAll,
                        variant: "text",
                        px: "0",
                        children: t('Clear all')
                    })
                ]
            }),
            sortedTransactions.length > 0 ? sortedTransactions.map((txn)=>/*#__PURE__*/ jsx_runtime_.jsx(UserMenu_TransactionRow, {
                    txn: txn
                }, txn.hash)
            ) : /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Text, {
                textAlign: "center",
                children: t('No recent transactions')
            })
        ]
    }));
};
/* harmony default export */ const UserMenu_WalletTransactions = (WalletTransactions);


/***/ }),

/***/ 8837:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9150);




const WalletUserMenuItem = ({ hasLowBnbBalance , onPresentWalletModal  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_3__/* .useTranslation */ .$G)();
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.UserMenuItem, {
        as: "button",
        onClick: onPresentWalletModal,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
            alignItems: "center",
            justifyContent: "space-between",
            width: "100%",
            children: [
                t('Wallet'),
                hasLowBnbBalance && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.WarningIcon, {
                    color: "warning",
                    width: "24px"
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WalletUserMenuItem);


/***/ }),

/***/ 1989:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var hooks_useAuth__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1222);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var state_profile_hooks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9424);
/* harmony import */ var components_ConnectWalletButton__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(621);
/* harmony import */ var hooks_useTokenBalance__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4319);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9150);
/* harmony import */ var config_constants_types__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7971);
/* harmony import */ var _WalletModal__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5245);
/* harmony import */ var _ProfileUserMenutItem__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3111);
/* harmony import */ var _WalletUserMenuItem__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8837);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_WalletModal__WEBPACK_IMPORTED_MODULE_11__, state_profile_hooks__WEBPACK_IMPORTED_MODULE_6__, hooks_useTokenBalance__WEBPACK_IMPORTED_MODULE_8__]);
([_WalletModal__WEBPACK_IMPORTED_MODULE_11__, state_profile_hooks__WEBPACK_IMPORTED_MODULE_6__, hooks_useTokenBalance__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);














const UserMenu = ()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)();
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_9__/* .useTranslation */ .$G)();
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_2__.useWeb3React)();
    const { logout  } = (0,hooks_useAuth__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)();
    const { balance , fetchStatus  } = (0,hooks_useTokenBalance__WEBPACK_IMPORTED_MODULE_8__/* .useGetBnbBalance */ .nu)();
    const { isInitialized , isLoading , profile  } = (0,state_profile_hooks__WEBPACK_IMPORTED_MODULE_6__/* .useProfile */ .Un)();
    const [onPresentWalletModal] = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.useModal)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_WalletModal__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .ZP, {
        initialView: _WalletModal__WEBPACK_IMPORTED_MODULE_11__/* .WalletView.WALLET_INFO */ .L9.WALLET_INFO
    }));
    const [onPresentTransactionModal] = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.useModal)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_WalletModal__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .ZP, {
        initialView: _WalletModal__WEBPACK_IMPORTED_MODULE_11__/* .WalletView.TRANSACTIONS */ .L9.TRANSACTIONS
    }));
    const hasProfile = isInitialized && !!profile;
    const hasLowBnbBalance = fetchStatus === config_constants_types__WEBPACK_IMPORTED_MODULE_10__/* .FetchStatus.Fetched */ .iF.Fetched && balance.lte(_WalletModal__WEBPACK_IMPORTED_MODULE_11__/* .LOW_BNB_BALANCE */ .Gh);
    if (!account) {
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_ConnectWalletButton__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
            scale: "sm"
        }));
    }
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.UserMenu, {
        account: account,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_WalletUserMenuItem__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                hasLowBnbBalance: hasLowBnbBalance,
                onPresentWalletModal: onPresentWalletModal
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.UserMenuItem, {
                as: "button",
                onClick: onPresentTransactionModal,
                children: t('Transactions')
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.UserMenuDivider, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProfileUserMenutItem__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                isLoading: isLoading,
                hasProfile: hasProfile
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.UserMenuDivider, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.UserMenuItem, {
                as: "button",
                onClick: logout,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                    alignItems: "center",
                    justifyContent: "space-between",
                    width: "100%",
                    children: [
                        t('Disconnect'),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.LogoutIcon, {})
                    ]
                })
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (UserMenu);

});

/***/ }),

/***/ 1860:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_0__);

const config = (t)=>[
        {
            label: t('Win'),
            href: '/prediction',
            icon: 'Trophy',
            items: [
                {
                    label: t('Prediction (BETA)'),
                    href: '/prediction'
                }, 
            ]
        },
        {
            label: '',
            href: '/info',
            icon: 'More',
            hideSubNav: true,
            items: [
                {
                    label: t('Info'),
                    href: '/info'
                },
                {
                    type: _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_0__.DropdownMenuItemType.DIVIDER
                },
                {
                    label: t('Blog'),
                    href: 'https://medium.com/pancakeswap',
                    type: _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_0__.DropdownMenuItemType.EXTERNAL_LINK
                },
                {
                    type: _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_0__.DropdownMenuItemType.DIVIDER
                },
                {
                    label: t('Docs'),
                    href: 'https://docs.pancakeswap.finance',
                    type: _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_0__.DropdownMenuItemType.EXTERNAL_LINK
                }, 
            ]
        }, 
    ]
;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (config);


/***/ }),

/***/ 7794:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "d": () => (/* binding */ footerLinks)
/* harmony export */ });
const footerLinks = (t)=>[
        {
            label: t('About'),
            items: [
                {
                    label: t('Contact'),
                    href: 'https://docs.pancakeswap.finance/contact-us'
                },
                {
                    label: t('Brand'),
                    href: 'https://docs.pancakeswap.finance/brand'
                },
                {
                    label: t('Blog'),
                    href: 'https://medium.com/pancakeswap'
                },
                {
                    label: t('Community'),
                    href: 'https://docs.pancakeswap.finance/contact-us/telegram'
                },
                {
                    label: t('CAKE token'),
                    href: 'https://docs.pancakeswap.finance/tokenomics/cake'
                },
                {
                    label: '—'
                },
                {
                    label: t('Online Store'),
                    href: 'https://pancakeswap.creator-spring.com/',
                    isHighlighted: true
                }, 
            ]
        },
        {
            label: t('Help'),
            items: [
                {
                    label: t('Customer Support'),
                    href: 'https://docs.pancakeswap.finance/contact-us/customer-support'
                },
                {
                    label: t('Troubleshooting'),
                    href: 'https://docs.pancakeswap.finance/help/troubleshooting'
                },
                {
                    label: t('Guides'),
                    href: 'https://docs.pancakeswap.finance/get-started'
                }, 
            ]
        },
        {
            label: t('Developers'),
            items: [
                {
                    label: 'Github',
                    href: 'https://github.com/pancakeswap'
                },
                {
                    label: t('Documentation'),
                    href: 'https://docs.pancakeswap.finance'
                },
                {
                    label: t('Bug Bounty'),
                    href: 'https://docs.pancakeswap.finance/code/bug-bounty'
                },
                {
                    label: t('Audits'),
                    href: 'https://docs.pancakeswap.finance/help/faq#is-pancakeswap-safe-has-pancakeswap-been-audited'
                },
                {
                    label: t('Careers'),
                    href: 'https://docs.pancakeswap.finance/hiring/become-a-chef'
                }, 
            ]
        }, 
    ]
;


/***/ }),

/***/ 2485:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var components_NextLink__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3629);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var config_localization_languages__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9821);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9150);
/* harmony import */ var components_PhishingWarningBanner__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6134);
/* harmony import */ var hooks_useTheme__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3917);
/* harmony import */ var state_user_hooks__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8605);
/* harmony import */ var _config_config__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1860);
/* harmony import */ var _UserMenu__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1989);
/* harmony import */ var _GlobalSettings__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(4339);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1733);
/* harmony import */ var _config_footerConfig__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(7794);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_GlobalSettings__WEBPACK_IMPORTED_MODULE_12__, _UserMenu__WEBPACK_IMPORTED_MODULE_11__, state_user_hooks__WEBPACK_IMPORTED_MODULE_9__, hooks_useTheme__WEBPACK_IMPORTED_MODULE_8__, components_PhishingWarningBanner__WEBPACK_IMPORTED_MODULE_7__]);
([_GlobalSettings__WEBPACK_IMPORTED_MODULE_12__, _UserMenu__WEBPACK_IMPORTED_MODULE_11__, state_user_hooks__WEBPACK_IMPORTED_MODULE_9__, hooks_useTheme__WEBPACK_IMPORTED_MODULE_8__, components_PhishingWarningBanner__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);















const Menu = (props)=>{
    const { isDark , toggleTheme  } = (0,hooks_useTheme__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
    const { currentLanguage , setLanguage , t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_6__/* .useTranslation */ .$G)();
    const { pathname  } = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const [showPhishingWarningBanner] = (0,state_user_hooks__WEBPACK_IMPORTED_MODULE_9__/* .usePhishingBannerManager */ .FT)();
    const activeMenuItem = (0,_utils__WEBPACK_IMPORTED_MODULE_13__/* .getActiveMenuItem */ .t)({
        menuConfig: (0,_config_config__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)(t),
        pathname
    });
    const activeSubMenuItem = (0,_utils__WEBPACK_IMPORTED_MODULE_13__/* .getActiveSubMenuItem */ .u)({
        menuItem: activeMenuItem,
        pathname
    });
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Menu, {
        linkComponent: (linkProps)=>{
            return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_NextLink__WEBPACK_IMPORTED_MODULE_3__/* .NextLinkFromReactRouter */ .a, {
                to: linkProps.href,
                ...linkProps,
                prefetch: false
            }));
        },
        userMenu: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UserMenu__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {}),
        globalMenu: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_GlobalSettings__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {}),
        banner: showPhishingWarningBanner && "undefined" !== 'undefined' && /*#__PURE__*/ 0,
        isDark: isDark,
        toggleTheme: toggleTheme,
        currentLang: currentLanguage.code,
        langs: config_localization_languages__WEBPACK_IMPORTED_MODULE_5__/* .languageList */ .s0,
        setLang: setLanguage,
        links: (0,_config_config__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)(t),
        subLinks: activeMenuItem?.hideSubNav ? [] : activeMenuItem?.items,
        footerLinks: (0,_config_footerConfig__WEBPACK_IMPORTED_MODULE_14__/* .footerLinks */ .d)(t),
        activeItem: activeMenuItem?.href,
        activeSubItem: activeSubMenuItem?.href,
        buyCakeLabel: t('Buy CAKE'),
        ...props
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Menu);

});

/***/ }),

/***/ 1733:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "t": () => (/* binding */ getActiveMenuItem),
/* harmony export */   "u": () => (/* binding */ getActiveSubMenuItem)
/* harmony export */ });
const getActiveMenuItem = ({ pathname , menuConfig  })=>menuConfig.find((menuItem)=>pathname.startsWith(menuItem.href) || getActiveSubMenuItem({
            menuItem,
            pathname
        })
    )
;
const getActiveSubMenuItem = ({ pathname , menuItem  })=>{
    const activeSubMenuItems = menuItem?.items.filter((subMenuItem)=>pathname.startsWith(subMenuItem.href)
    ) ?? [];
    // Pathname doesn't include any submenu item href - return undefined
    if (!activeSubMenuItems || activeSubMenuItems.length === 0) {
        return undefined;
    }
    // Pathname includes one sub menu item href - return it
    if (activeSubMenuItems.length === 1) {
        return activeSubMenuItems[0];
    }
    // Pathname includes multiple sub menu item hrefs - find the most specific match
    const mostSpecificMatch = activeSubMenuItems.sort((subMenuItem1, subMenuItem2)=>subMenuItem2.href.length - subMenuItem1.href.length
    )[0];
    return mostSpecificMatch;
};


/***/ }),

/***/ 3629:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "a": () => (/* binding */ NextLinkFromReactRouter)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);




const A = styled_components__WEBPACK_IMPORTED_MODULE_2___default().a.withConfig({
    componentId: "sc-c6707b7e-0"
})``;
/**
 * temporary solution for migrating React Router to Next.js Link
 */ const NextLinkFromReactRouter = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.forwardRef)(({ to , replace , children , prefetch , ...props }, ref)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_3__["default"], {
        href: to,
        replace: replace,
        passHref: true,
        prefetch: prefetch,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(A, {
            ref: ref,
            ...props,
            children: children
        })
    })
);


/***/ }),

/***/ 6134:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9150);
/* harmony import */ var state_user_hooks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8605);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([state_user_hooks__WEBPACK_IMPORTED_MODULE_5__]);
state_user_hooks__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];






const Container = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex).withConfig({
    componentId: "sc-7432473c-0"
})`
  overflow: hidden;
  height: 100%;
  padding: 12px;
  align-items: center;
  background: linear-gradient(0deg, rgba(39, 38, 44, 0.4), rgba(39, 38, 44, 0.4)),
    linear-gradient(180deg, #8051d6 0%, #492286 100%);
  ${({ theme  })=>theme.mediaQueries.md
} {
    padding: 0px;
    background: linear-gradient(180deg, #8051d6 0%, #492286 100%);
  }
`;
const InnerContainer = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex).withConfig({
    componentId: "sc-7432473c-1"
})`
  width: 100%;
  height: 100%;
  justify-content: center;
  align-items: center;
`;
const SpeechBubble = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-7432473c-2"
})`
  background: rgba(39, 38, 44, 0.4);
  border-radius: 16px;
  padding: 8px;
  width: 60%;
  height: 80%;
  display: flex;
  align-items: center;
  flex-wrap: wrap;

  & ${_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text} {
    flex-shrink: 0;
    margin-right: 4px;
  }
`;
const PhishingWarningBanner = ()=>{
    const { t  } = useTranslation();
    const [, hideBanner] = usePhishingBannerManager();
    const { isMobile , isMd  } = useMatchBreakpoints();
    const warningText = t("please make sure you're visiting https://pancakeswap.finance - check the URL carefully.");
    const warningTextAsParts = warningText.split(/(https:\/\/pancakeswap.finance)/g);
    const warningTextComponent = /*#__PURE__*/ _jsxs(_Fragment, {
        children: [
            /*#__PURE__*/ _jsx(Text, {
                as: "span",
                color: "warning",
                small: true,
                bold: true,
                textTransform: "uppercase",
                children: t('Phishing warning: ')
            }),
            warningTextAsParts.map((text, i)=>/*#__PURE__*/ _jsx(Text, {
                    small: true,
                    as: "span",
                    bold: text === 'https://pancakeswap.finance',
                    color: text === 'https://pancakeswap.finance' ? '#FFFFFF' : '#BDC2C4',
                    children: text
                }, i)
            )
        ]
    });
    return(/*#__PURE__*/ _jsx(Container, {
        children: isMobile || isMd ? /*#__PURE__*/ _jsxs(_Fragment, {
            children: [
                /*#__PURE__*/ _jsx(Box, {
                    children: warningTextComponent
                }),
                /*#__PURE__*/ _jsx(IconButton, {
                    onClick: hideBanner,
                    variant: "text",
                    children: /*#__PURE__*/ _jsx(CloseIcon, {
                        color: "#FFFFFF"
                    })
                })
            ]
        }) : /*#__PURE__*/ _jsxs(_Fragment, {
            children: [
                /*#__PURE__*/ _jsxs(InnerContainer, {
                    children: [
                        /*#__PURE__*/ _jsxs("picture", {
                            children: [
                                /*#__PURE__*/ _jsx("source", {
                                    type: "image/webp",
                                    srcSet: "/images/decorations/phishing-warning-bunny.webp"
                                }),
                                /*#__PURE__*/ _jsx("source", {
                                    type: "image/png",
                                    srcSet: "/images/decorations/phishing-warning-bunny.png"
                                }),
                                /*#__PURE__*/ _jsx("img", {
                                    src: "/images/decorations/phishing-warning-bunny.png",
                                    alt: "phishing-warning",
                                    width: "92px"
                                })
                            ]
                        }),
                        /*#__PURE__*/ _jsx(SpeechBubble, {
                            children: warningTextComponent
                        })
                    ]
                }),
                /*#__PURE__*/ _jsx(IconButton, {
                    onClick: hideBanner,
                    variant: "text",
                    children: /*#__PURE__*/ _jsx(CloseIcon, {
                        color: "#FFFFFF"
                    })
                })
            ]
        })
    }));
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (PhishingWarningBanner)));

});

/***/ }),

/***/ 5061:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);




const QuestionWrapper = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
    componentId: "sc-3ffb2e33-0"
})`
  :hover,
  :focus {
    opacity: 0.7;
  }
`;
const QuestionHelper = ({ text , placement ='right-end' , size ='16px' , ...props })=>{
    const { targetRef , tooltip , tooltipVisible  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.useTooltip)(text, {
        placement,
        trigger: 'hover'
    });
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Box, {
        ...props,
        children: [
            tooltipVisible && tooltip,
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(QuestionWrapper, {
                ref: targetRef,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.HelpIcon, {
                    color: "textSubtle",
                    width: size
                })
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (QuestionHelper);


/***/ }),

/***/ 7910:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* unused harmony exports filterTokens, useSortedTokensByQuery */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8328);


function filterTokens(tokens, search) {
    if (search.length === 0) return tokens;
    const searchingAddress = isAddress(search);
    if (searchingAddress) {
        return tokens.filter((token)=>token.address === searchingAddress
        );
    }
    const lowerSearchParts = search.toLowerCase().split(/\s+/).filter((s)=>s.length > 0
    );
    if (lowerSearchParts.length === 0) {
        return tokens;
    }
    const matchesSearch = (s)=>{
        const sParts = s.toLowerCase().split(/\s+/).filter((s_)=>s_.length > 0
        );
        return lowerSearchParts.every((p)=>p.length === 0 || sParts.some((sp)=>sp.startsWith(p) || sp.endsWith(p)
            )
        );
    };
    return tokens.filter((token)=>{
        const { symbol , name  } = token;
        return symbol && matchesSearch(symbol) || name && matchesSearch(name);
    });
}
function useSortedTokensByQuery(tokens, searchQuery) {
    return useMemo(()=>{
        if (!tokens) {
            return [];
        }
        const symbolMatch = searchQuery.toLowerCase().split(/\s+/).filter((s)=>s.length > 0
        );
        if (symbolMatch.length > 1) {
            return tokens;
        }
        const exactMatches = [];
        const symbolSubstrings = [];
        const rest = [];
        // sort tokens by exact match -> substring on symbol match -> rest
        tokens.forEach((token)=>{
            if (token.symbol?.toLowerCase() === symbolMatch[0]) {
                return exactMatches.push(token);
            }
            if (token.symbol?.toLowerCase().startsWith(searchQuery.toLowerCase().trim())) {
                return symbolSubstrings.push(token);
            }
            return rest.push(token);
        });
        return [
            ...exactMatches,
            ...symbolSubstrings,
            ...rest
        ];
    }, [
        tokens,
        searchQuery
    ]);
}


/***/ }),

/***/ 2606:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3206);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9150);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var state_user_hooks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8605);
/* harmony import */ var hooks_useSubgraphHealth__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9901);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks_useSubgraphHealth__WEBPACK_IMPORTED_MODULE_7__, state_user_hooks__WEBPACK_IMPORTED_MODULE_6__]);
([hooks_useSubgraphHealth__WEBPACK_IMPORTED_MODULE_7__, state_user_hooks__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);









const StyledCard = styled_components__WEBPACK_IMPORTED_MODULE_4___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Card).withConfig({
    componentId: "sc-36ae2c02-0"
})`
  border-radius: 8px;
  > div {
    border-radius: 8px;
  }
`;
const IndicatorWrapper = styled_components__WEBPACK_IMPORTED_MODULE_4___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Box).withConfig({
    componentId: "sc-36ae2c02-1"
})`
  display: flex;
  align-items: center;
  gap: 7px;
`;
const Dot = styled_components__WEBPACK_IMPORTED_MODULE_4___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Box).withConfig({
    componentId: "sc-36ae2c02-2"
})`
  width: 12px;
  height: 12px;
  border-radius: 50%;
  background: ${({ $color , theme  })=>theme.colors[$color]
};
`;
const indicator = (t)=>({
        delayed: {
            label: t('Delayed'),
            color: 'failure',
            description: t('Subgraph is currently experiencing delays due to BSC issues. Performance may suffer until subgraph is restored.')
        },
        slow: {
            label: t('Slight delay'),
            color: 'warning',
            description: t('Subgraph is currently experiencing delays due to BSC issues. Performance may suffer until subgraph is restored.')
        },
        healthy: {
            label: t('Fast'),
            color: 'success',
            description: t('No issues with the subgraph.')
        }
    })
;
const getIndicator = (sgStatus)=>{
    if (sgStatus === hooks_useSubgraphHealth__WEBPACK_IMPORTED_MODULE_7__/* .SubgraphStatus.NOT_OK */ .r.NOT_OK) {
        return 'delayed';
    }
    if (sgStatus === hooks_useSubgraphHealth__WEBPACK_IMPORTED_MODULE_7__/* .SubgraphStatus.WARNING */ .r.WARNING) {
        return 'slow';
    }
    return 'healthy';
};
const SubgraphHealthIndicator = ()=>{
    const { pathname  } = (0,next_router__WEBPACK_IMPORTED_MODULE_8__.useRouter)();
    const isOnNftPages = pathname.includes('nfts');
    return isOnNftPages ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SubgraphHealth, {}) : null;
};
const SubgraphHealth = ()=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_2__/* .useTranslation */ .$G)();
    const { status , currentBlock , blockDifference , latestBlock  } = (0,hooks_useSubgraphHealth__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
    const [alwaysShowIndicator] = (0,state_user_hooks__WEBPACK_IMPORTED_MODULE_6__/* .useSubgraphHealthIndicatorManager */ .YF)();
    const forceIndicatorDisplay = status === hooks_useSubgraphHealth__WEBPACK_IMPORTED_MODULE_7__/* .SubgraphStatus.WARNING */ .r.WARNING || status === hooks_useSubgraphHealth__WEBPACK_IMPORTED_MODULE_7__/* .SubgraphStatus.NOT_OK */ .r.NOT_OK;
    const showIndicator = alwaysShowIndicator || forceIndicatorDisplay;
    const indicatorProps = indicator(t);
    const secondRemainingBlockSync = blockDifference * config__WEBPACK_IMPORTED_MODULE_1__/* .BSC_BLOCK_TIME */ .hJ;
    const indicatorValue = getIndicator(status);
    const current = indicatorProps[indicatorValue];
    const { targetRef , tooltipVisible , tooltip  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.useTooltip)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TooltipContent, {
        currentBlock: currentBlock,
        secondRemainingBlockSync: secondRemainingBlockSync,
        blockNumberFromSubgraph: latestBlock,
        ...current
    }), {
        placement: 'top'
    });
    if (!latestBlock || !currentBlock || !showIndicator) {
        return null;
    }
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Box, {
        position: "fixed",
        bottom: "55px",
        right: "5%",
        ref: targetRef,
        "data-test": "subgraph-health-indicator",
        children: [
            tooltipVisible && tooltip,
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledCard, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(IndicatorWrapper, {
                    p: "10px",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Dot, {
                            $color: current.color
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Text, {
                            children: current.label
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.InfoIcon, {})
                    ]
                })
            })
        ]
    }));
};
const TooltipContent = ({ color , label , description , currentBlock , secondRemainingBlockSync , blockNumberFromSubgraph ,  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_2__/* .useTranslation */ .$G)();
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Box, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(IndicatorWrapper, {
                pb: "10px",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Dot, {
                        $color: color
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Text, {
                        children: label
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Text, {
                pb: "24px",
                children: description
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Text, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("strong", {
                        children: [
                            t('Chain Head Block'),
                            ":"
                        ]
                    }),
                    " ",
                    currentBlock
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Text, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("strong", {
                        children: [
                            t('Latest Subgraph Block'),
                            ":"
                        ]
                    }),
                    " ",
                    blockNumberFromSubgraph
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Text, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("strong", {
                        children: [
                            t('Delay'),
                            ":"
                        ]
                    }),
                    " ",
                    currentBlock - blockNumberFromSubgraph,
                    " (",
                    secondRemainingBlockSync,
                    "s)"
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SubgraphHealthIndicator);

});

/***/ }),

/***/ 3937:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Ix": () => (/* reexport */ Toast_ToastContainer),
  "YO": () => (/* reexport */ Toast_DescriptionWithTx),
  "m$": () => (/* reexport */ types)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-transition-group"
var external_react_transition_group_ = __webpack_require__(4466);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(7518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: external "@pancakeswap/uikit"
var uikit_ = __webpack_require__(2829);
;// CONCATENATED MODULE: ./src/components/Toast/types.ts
const types = {
    SUCCESS: 'success',
    DANGER: 'danger',
    WARNING: 'warning',
    INFO: 'info'
};

;// CONCATENATED MODULE: ./src/components/Toast/Toast.tsx






const alertTypeMap = {
    [types.INFO]: uikit_.alertVariants.INFO,
    [types.SUCCESS]: uikit_.alertVariants.SUCCESS,
    [types.DANGER]: uikit_.alertVariants.DANGER,
    [types.WARNING]: uikit_.alertVariants.WARNING
};
const StyledToast = external_styled_components_default().div.withConfig({
    componentId: "sc-4cea16a-0"
})`
  right: 16px;
  position: fixed;
  max-width: calc(100% - 32px);
  transition: all 250ms ease-in;
  width: 100%;

  ${({ theme  })=>theme.mediaQueries.sm
} {
    max-width: 400px;
  }
`;
const Toast = ({ toast , onRemove , style , ttl , ...props })=>{
    const timer = (0,external_react_.useRef)();
    const ref = (0,external_react_.useRef)(null);
    const removeHandler = (0,external_react_.useRef)(onRemove);
    const { id , title , description , type  } = toast;
    const handleRemove = (0,external_react_.useCallback)(()=>removeHandler.current(id)
    , [
        id,
        removeHandler
    ]);
    const handleMouseEnter = ()=>{
        clearTimeout(timer.current);
    };
    const handleMouseLeave = ()=>{
        if (timer.current) {
            clearTimeout(timer.current);
        }
        timer.current = window.setTimeout(()=>{
            handleRemove();
        }, ttl);
    };
    (0,external_react_.useEffect)(()=>{
        if (timer.current) {
            clearTimeout(timer.current);
        }
        timer.current = window.setTimeout(()=>{
            handleRemove();
        }, ttl);
        return ()=>{
            clearTimeout(timer.current);
        };
    }, [
        timer,
        ttl,
        handleRemove
    ]);
    return(/*#__PURE__*/ jsx_runtime_.jsx(external_react_transition_group_.CSSTransition, {
        nodeRef: ref,
        timeout: 250,
        style: style,
        ...props,
        children: /*#__PURE__*/ jsx_runtime_.jsx(StyledToast, {
            ref: ref,
            onMouseEnter: handleMouseEnter,
            onMouseLeave: handleMouseLeave,
            children: /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Alert, {
                title: title,
                variant: alertTypeMap[type],
                onClick: handleRemove,
                children: description
            })
        })
    }));
};
/* harmony default export */ const Toast_Toast = (Toast);

;// CONCATENATED MODULE: ./src/components/Toast/ToastContainer.tsx





const ZINDEX = 1000;
const TOP_POSITION = 80 // Initial position from the top
;
const StyledToastContainer = external_styled_components_default().div.withConfig({
    componentId: "sc-d2f82d86-0"
})`
  .enter,
  .appear {
    opacity: 0.01;
  }

  .enter.enter-active,
  .appear.appear-active {
    opacity: 1;
    transition: opacity 250ms ease-in;
  }

  .exit {
    opacity: 1;
  }

  .exit.exit-active {
    opacity: 0.01;
    transition: opacity 250ms ease-out;
  }
`;
const ToastContainer = ({ toasts , onRemove , ttl =6000 , stackSpacing =24  })=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx(StyledToastContainer, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_transition_group_.TransitionGroup, {
            children: toasts.map((toast, index)=>{
                const zIndex = (ZINDEX - index).toString();
                const top = TOP_POSITION + index * stackSpacing;
                return(/*#__PURE__*/ jsx_runtime_.jsx(Toast_Toast, {
                    toast: toast,
                    onRemove: onRemove,
                    ttl: ttl,
                    style: {
                        top: `${top}px`,
                        zIndex
                    }
                }, toast.id));
            })
        })
    }));
};
/* harmony default export */ const Toast_ToastContainer = (ToastContainer);

// EXTERNAL MODULE: ./src/utils/index.ts + 1 modules
var utils = __webpack_require__(8328);
// EXTERNAL MODULE: ./src/hooks/useActiveWeb3React.ts
var useActiveWeb3React = __webpack_require__(4011);
// EXTERNAL MODULE: ./src/contexts/Localization/index.tsx + 3 modules
var Localization = __webpack_require__(9150);
// EXTERNAL MODULE: ./src/utils/truncateHash.ts
var truncateHash = __webpack_require__(3467);
;// CONCATENATED MODULE: ./src/components/Toast/DescriptionWithTx.tsx







const DescriptionWithTx = ({ txHash , children  })=>{
    const { chainId  } = (0,useActiveWeb3React/* default */.Z)();
    const { t  } = (0,Localization/* useTranslation */.$G)();
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            typeof children === 'string' ? /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Text, {
                as: "p",
                children: children
            }) : children,
            txHash && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(uikit_.Link, {
                external: true,
                href: (0,utils/* getBscScanLink */.s6)(txHash, 'transaction', chainId),
                children: [
                    t('View on BscScan'),
                    ": ",
                    (0,truncateHash/* default */.Z)(txHash, 8, 0)
                ]
            })
        ]
    }));
};
/* harmony default export */ const Toast_DescriptionWithTx = (DescriptionWithTx);

;// CONCATENATED MODULE: ./src/components/Toast/index.tsx





/***/ }),

/***/ 5906:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "v5": () => (/* binding */ GRAPH_API_PREDICTION),
/* harmony export */   "Kt": () => (/* binding */ GRAPH_API_PREDICTION_V1),
/* harmony export */   "JY": () => (/* binding */ INFO_CLIENT),
/* harmony export */   "I0": () => (/* binding */ BLOCKS_CLIENT),
/* harmony export */   "AM": () => (/* binding */ GRAPH_HEALTH)
/* harmony export */ });
/* unused harmony exports GRAPH_API_PROFILE, GRAPH_API_LOTTERY, SNAPSHOT_VOTING_API, SNAPSHOT_BASE_URL, API_PROFILE, API_NFT, SNAPSHOT_API, SNAPSHOT_HUB_API, GRAPH_API_NFTMARKET */
const GRAPH_API_PROFILE = (/* unused pure expression or super */ null && ("https://api.thegraph.com/subgraphs/name/pancakeswap/profile"));
const GRAPH_API_PREDICTION = "https://api.thegraph.com/subgraphs/name/pancakeswap/prediction-v2";
const GRAPH_API_LOTTERY = (/* unused pure expression or super */ null && ("https://api.thegraph.com/subgraphs/name/pancakeswap/lottery"));
const SNAPSHOT_VOTING_API = (/* unused pure expression or super */ null && ("https://voting-api.pancakeswap.info/api"));
const SNAPSHOT_BASE_URL = "https://hub.snapshot.org";
const API_PROFILE = (/* unused pure expression or super */ null && ("https://profile.pancakeswap.com"));
const API_NFT = (/* unused pure expression or super */ null && ("https://nft.pancakeswap.com/api/v1"));
const SNAPSHOT_API = `${SNAPSHOT_BASE_URL}/graphql`;
const SNAPSHOT_HUB_API = `${SNAPSHOT_BASE_URL}/api/message`;
/**
 * V1 will be deprecated but is still used to claim old rounds
 */ const GRAPH_API_PREDICTION_V1 = 'https://api.thegraph.com/subgraphs/name/pancakeswap/prediction';
const INFO_CLIENT = 'https://bsc.streamingfast.io/subgraphs/name/pancakeswap/exchange-v2';
const BLOCKS_CLIENT = 'https://api.thegraph.com/subgraphs/name/pancakeswap/blocks';
const GRAPH_API_NFTMARKET = (/* unused pure expression or super */ null && ("https://api.thegraph.com/subgraphs/name/pancakeswap/nft-market"));
const GRAPH_HEALTH = 'https://api.thegraph.com/index-node/graphql';


/***/ }),

/***/ 1115:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _tokens__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9748);

const serializedTokens = (0,_tokens__WEBPACK_IMPORTED_MODULE_0__/* .serializeTokens */ .uO)();
const farms = [
    /**
   * These 3 farms (PID 0, 251, 252) should always be at the top of the file.
   */ {
        pid: 0,
        lpSymbol: 'CAKE',
        lpAddresses: {
            1666700000: '0x9C21123D94b93361a29B2C2EFB3d5CD8B17e0A9e',
            1666600000: '0x0e09fabb73bd3ade0a17ecc321fd13a19e81ce82'
        },
        token: serializedTokens.syrup,
        quoteToken: serializedTokens.wbnb
    },
    {
        pid: 251,
        lpSymbol: 'CAKE-BNB LP',
        lpAddresses: {
            1666700000: '0x3ed8936cAFDF85cfDBa29Fbe5940A5b0524824F4',
            1666600000: '0x0eD7e52944161450477ee417DE9Cd3a859b14fD0'
        },
        token: serializedTokens.cake,
        quoteToken: serializedTokens.wbnb
    },
    {
        pid: 252,
        lpSymbol: 'BUSD-BNB LP',
        lpAddresses: {
            1666700000: '',
            1666600000: '0x58F876857a02D6762E0101bb5C46A8c1ED44Dc16'
        },
        token: serializedTokens.busd,
        quoteToken: serializedTokens.wbnb
    }
];
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (farms);


/***/ }),

/***/ 7829:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* unused harmony export cakeBnbLpToken */
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2877);
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _farms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1115);


const cakeBnbLpToken = new _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, _farms__WEBPACK_IMPORTED_MODULE_1__/* ["default"][1].lpAddresses */ .Z[1].lpAddresses[_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET], 18, _farms__WEBPACK_IMPORTED_MODULE_1__/* ["default"][1].lpSymbol */ .Z[1].lpSymbol);
const ifos = (/* unused pure expression or super */ null && ([]));
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (ifos)));


/***/ }),

/***/ 1311:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "mj": () => (/* binding */ BLOCKED_ADDRESSES),
  "PY": () => (/* binding */ DEFAULT_DEADLINE_FROM_NOW),
  "sR": () => (/* binding */ FAST_INTERVAL),
  "gv": () => (/* binding */ INITIAL_ALLOWED_SLIPPAGE),
  "KI": () => (/* binding */ SLOW_INTERVAL)
});

// UNUSED EXPORTS: ADDITIONAL_BASES, ALLOWED_PRICE_IMPACT_HIGH, ALLOWED_PRICE_IMPACT_LOW, ALLOWED_PRICE_IMPACT_MEDIUM, BASES_TO_CHECK_TRADES_AGAINST, BASES_TO_TRACK_LIQUIDITY_FOR, BETTER_TRADE_LESS_HOPS_THRESHOLD, BIG_INT_ZERO, BIPS_BASE, BLOCKED_PRICE_IMPACT_NON_EXPERT, CUSTOM_BASES, MIN_BNB, NetworkContextName, ONE_BIPS, ONE_HUNDRED_PERCENT, PINNED_PAIRS, PRICE_IMPACT_WITHOUT_FEE_CONFIRM_MIN, ROUTER_ADDRESS, SUGGESTED_BASES, ZERO_PERCENT, farmsConfig, ifosConfig, poolsConfig

// EXTERNAL MODULE: external "@mdemouchy/sdk"
var sdk_ = __webpack_require__(2877);
// EXTERNAL MODULE: ./src/config/constants/tokens.ts
var tokens = __webpack_require__(9748);
// EXTERNAL MODULE: ./src/config/constants/farms.ts
var farms = __webpack_require__(1115);
// EXTERNAL MODULE: ./src/state/types.ts
var types = __webpack_require__(5101);
// EXTERNAL MODULE: ./src/config/constants/types.ts
var constants_types = __webpack_require__(7971);
;// CONCATENATED MODULE: ./src/config/constants/pools.ts



const serializedTokens = (0,tokens/* serializeTokens */.uO)();
const vaultPoolConfig = {
    [types/* VaultKey.CakeVault */.om.CakeVault]: {
        name: 'Auto CAKE',
        description: 'Automatic restaking',
        autoCompoundFrequency: 5000,
        gasLimit: 380000,
        tokenImage: {
            primarySrc: `/images/tokens/${tokens/* default.cake.address */.ZP.cake.address}.svg`,
            secondarySrc: '/images/tokens/autorenew.svg'
        }
    },
    [types/* VaultKey.IfoPool */.om.IfoPool]: {
        name: 'IFO CAKE',
        description: 'Stake CAKE to participate in IFOs',
        autoCompoundFrequency: 1,
        gasLimit: 500000,
        tokenImage: {
            primarySrc: `/images/tokens/${tokens/* default.cake.address */.ZP.cake.address}.svg`,
            secondarySrc: `/images/tokens/ifo-pool-icon.svg`
        }
    }
};
const pools = [
    {
        sousId: 0,
        stakingToken: serializedTokens.cake,
        earningToken: serializedTokens.cake,
        contractAddress: {
            1666700000: '0xd3af5fe61dbaf8f73149bfcfa9fb653ff096029a',
            1666600000: '0x73feaa1eE314F8c655E354234017bE2193C9E24E'
        },
        poolCategory: constants_types/* PoolCategory.CORE */.jh.CORE,
        harvest: true,
        tokenPerBlock: '10',
        sortOrder: 1,
        isFinished: false
    }, 
];
/* harmony default export */ const constants_pools = ((/* unused pure expression or super */ null && (pools)));

// EXTERNAL MODULE: ./src/config/constants/ifo.ts
var ifo = __webpack_require__(7829);
;// CONCATENATED MODULE: ./src/config/constants/index.ts


const ROUTER_ADDRESS = '0x10ED43C718714eb63d5aA57B78B54704E256024E';
// used to construct intermediary pairs for trading
const BASES_TO_CHECK_TRADES_AGAINST = {
    [sdk_.ChainId.MAINNET]: [
        tokens/* mainnetTokens.wbnb */.ke.wbnb,
        tokens/* mainnetTokens.cake */.ke.cake,
        tokens/* mainnetTokens.busd */.ke.busd
    ],
    [sdk_.ChainId.TESTNET]: [
        tokens/* testnetTokens.wbnb */.ux.wbnb,
        tokens/* testnetTokens.cake */.ux.cake,
        tokens/* testnetTokens.busd */.ux.busd
    ]
};
/**
 * Addittional bases for specific tokens
 * @example { [WBTC.address]: [renBTC], [renBTC.address]: [WBTC] }
 */ const ADDITIONAL_BASES = {
    [sdk_.ChainId.MAINNET]: {}
};
/**
 * Some tokens can only be swapped via certain pairs, so we override the list of bases that are considered for these
 * tokens.
 * @example [AMPL.address]: [DAI, WETH[ChainId.MAINNET]]
 */ const CUSTOM_BASES = {
    [sdk_.ChainId.MAINNET]: {}
};
// used for display in the default list when adding liquidity
const SUGGESTED_BASES = {
    [sdk_.ChainId.MAINNET]: [
        tokens/* mainnetTokens.busd */.ke.busd,
        tokens/* mainnetTokens.cake */.ke.cake,
        tokens/* mainnetTokens.wbnb */.ke.wbnb
    ],
    [sdk_.ChainId.TESTNET]: [
        tokens/* testnetTokens.wbnb */.ux.wbnb,
        tokens/* testnetTokens.cake */.ux.cake,
        tokens/* testnetTokens.wbnb */.ux.wbnb
    ]
};
// used to construct the list of all pairs we consider by default in the frontend
const BASES_TO_TRACK_LIQUIDITY_FOR = {
    [sdk_.ChainId.MAINNET]: [
        tokens/* mainnetTokens.wbnb */.ke.wbnb,
        tokens/* mainnetTokens.wbnb */.ke.wbnb,
        tokens/* mainnetTokens.busd */.ke.busd,
        tokens/* mainnetTokens.wbnb */.ke.wbnb
    ],
    [sdk_.ChainId.TESTNET]: [
        tokens/* testnetTokens.wbnb */.ux.wbnb,
        tokens/* testnetTokens.cake */.ux.cake,
        tokens/* testnetTokens.busd */.ux.busd
    ]
};
const PINNED_PAIRS = {
    [sdk_.ChainId.MAINNET]: [
        [
            tokens/* mainnetTokens.cake */.ke.cake,
            tokens/* mainnetTokens.wbnb */.ke.wbnb
        ],
        [
            tokens/* mainnetTokens.busd */.ke.busd,
            tokens/* mainnetTokens.wbnb */.ke.wbnb
        ],
        [
            tokens/* mainnetTokens.wbnb */.ke.wbnb,
            tokens/* mainnetTokens.wbnb */.ke.wbnb
        ], 
    ]
};
const NetworkContextName = 'NETWORK';
// default allowed slippage, in bips
const INITIAL_ALLOWED_SLIPPAGE = 50;
// 20 minutes, denominated in seconds
const DEFAULT_DEADLINE_FROM_NOW = 60 * 20;
const BIG_INT_ZERO = sdk_.JSBI.BigInt(0);
// one basis point
const ONE_BIPS = new sdk_.Percent(sdk_.JSBI.BigInt(1), sdk_.JSBI.BigInt(10000));
const BIPS_BASE = sdk_.JSBI.BigInt(10000);
// used for warning states
const ALLOWED_PRICE_IMPACT_LOW = new sdk_.Percent(sdk_.JSBI.BigInt(100), BIPS_BASE) // 1%
;
const ALLOWED_PRICE_IMPACT_MEDIUM = new sdk_.Percent(sdk_.JSBI.BigInt(300), BIPS_BASE) // 3%
;
const ALLOWED_PRICE_IMPACT_HIGH = new sdk_.Percent(sdk_.JSBI.BigInt(500), BIPS_BASE) // 5%
;
// if the price slippage exceeds this number, force the user to type 'confirm' to execute
const PRICE_IMPACT_WITHOUT_FEE_CONFIRM_MIN = new sdk_.Percent(sdk_.JSBI.BigInt(1000), BIPS_BASE) // 10%
;
// for non expert mode disable swaps above this
const BLOCKED_PRICE_IMPACT_NON_EXPERT = new sdk_.Percent(sdk_.JSBI.BigInt(1500), BIPS_BASE) // 15%
;
// used to ensure the user doesn't send so much BNB so they end up with <.01
const MIN_BNB = sdk_.JSBI.exponentiate(sdk_.JSBI.BigInt(10), sdk_.JSBI.BigInt(16)) // .01 BNB
;
const BETTER_TRADE_LESS_HOPS_THRESHOLD = new sdk_.Percent(sdk_.JSBI.BigInt(50), sdk_.JSBI.BigInt(10000));
const ZERO_PERCENT = new sdk_.Percent('0');
const ONE_HUNDRED_PERCENT = new sdk_.Percent('1');
// SDN OFAC addresses
const BLOCKED_ADDRESSES = [
    '0x7F367cC41522cE07553e823bf3be79A889DEbe1B',
    '0xd882cFc20F52f2599D84b8e8D58C7FB62cfE344b',
    '0x901bb9583b24D97e995513C6778dc6888AB6870e',
    '0xA7e5d5A720f06526557c513402f2e6B5fA20b008',
    '0x8576aCC5C05D6Ce88f4e49bf65BdF0C62F91353C', 
];



const FAST_INTERVAL = 10000;
const SLOW_INTERVAL = 60000;


/***/ }),

/***/ 428:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "US": () => (/* binding */ UNSUPPORTED_LIST_URLS),
/* harmony export */   "Lx": () => (/* binding */ DEFAULT_LIST_OF_LISTS),
/* harmony export */   "c8": () => (/* binding */ DEFAULT_ACTIVE_LIST_URLS)
/* harmony export */ });
const PANCAKE_EXTENDED = 'https://tokens.pancakeswap.finance/pancakeswap-extended.json';
const PANCAKE_TOP100 = 'https://tokens.pancakeswap.finance/pancakeswap-top-100.json';
const UNSUPPORTED_LIST_URLS = [];
// lower index == higher priority for token import
const DEFAULT_LIST_OF_LISTS = [
    PANCAKE_TOP100,
    PANCAKE_EXTENDED,
    ...UNSUPPORTED_LIST_URLS
];
// default lists to be 'active' aka searched across
const DEFAULT_ACTIVE_LIST_URLS = [];


/***/ }),

/***/ 7521:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "k": () => (/* binding */ DEFAULT_META),
/* harmony export */   "S": () => (/* binding */ getCustomMeta)
/* harmony export */ });
const DEFAULT_META = {
    title: 'PancakeSwap',
    description: 'The most popular AMM on BSC by user count! Earn CAKE through yield farming or win it in the Lottery, then stake it in Syrup Pools to earn more tokens! Initial Farm Offerings (new token launch model pioneered by PancakeSwap), NFTs, and more, on a platform you can trust.',
    image: 'https://pancakeswap.finance/images/hero.png'
};
const getCustomMeta = (path, t)=>{
    let basePath;
    if (path.startsWith('/swap')) {
        basePath = '/swap';
    } else if (path.startsWith('/add')) {
        basePath = '/add';
    } else if (path.startsWith('/remove')) {
        basePath = '/remove';
    } else if (path.startsWith('/teams')) {
        basePath = '/teams';
    } else if (path.startsWith('/voting/proposal') && path !== '/voting/proposal/create') {
        basePath = '/voting/proposal';
    } else if (path.startsWith('/nfts/collections')) {
        basePath = '/nfts/collections';
    } else if (path.startsWith('/nfts/profile')) {
        basePath = '/nfts/profile';
    } else if (path.startsWith('/pancake-squad')) {
        basePath = '/pancake-squad';
    } else {
        basePath = path;
    }
    switch(basePath){
        case '/':
            return {
                title: `${t('Home')} | ${t('PancakeSwap')}`
            };
        case '/swap':
            return {
                title: `${t('Exchange')} | ${t('PancakeSwap')}`
            };
        case '/add':
            return {
                title: `${t('Add Liquidity')} | ${t('PancakeSwap')}`
            };
        case '/remove':
            return {
                title: `${t('Remove Liquidity')} | ${t('PancakeSwap')}`
            };
        case '/liquidity':
            return {
                title: `${t('Liquidity')} | ${t('PancakeSwap')}`
            };
        case '/find':
            return {
                title: `${t('Import Pool')} | ${t('PancakeSwap')}`
            };
        case '/competition':
            return {
                title: `${t('Trading Battle')} | ${t('PancakeSwap')}`
            };
        case '/prediction':
            return {
                title: `${t('Prediction')} | ${t('PancakeSwap')}`
            };
        case '/prediction/leaderboard':
            return {
                title: `${t('Leaderboard')} | ${t('PancakeSwap')}`
            };
        case '/farms':
            return {
                title: `${t('Farms')} | ${t('PancakeSwap')}`
            };
        case '/farms/auction':
            return {
                title: `${t('Farm Auctions')} | ${t('PancakeSwap')}`
            };
        case '/pools':
            return {
                title: `${t('Pools')} | ${t('PancakeSwap')}`
            };
        case '/lottery':
            return {
                title: `${t('Lottery')} | ${t('PancakeSwap')}`
            };
        case '/ifo':
            return {
                title: `${t('Initial Farm Offering')} | ${t('PancakeSwap')}`
            };
        case '/teams':
            return {
                title: `${t('Leaderboard')} | ${t('PancakeSwap')}`
            };
        case '/voting':
            return {
                title: `${t('Voting')} | ${t('PancakeSwap')}`
            };
        case '/voting/proposal':
            return {
                title: `${t('Proposals')} | ${t('PancakeSwap')}`
            };
        case '/voting/proposal/create':
            return {
                title: `${t('Make a Proposal')} | ${t('PancakeSwap')}`
            };
        case '/info':
            return {
                title: `${t('Overview')} | ${t('PancakeSwap Info & Analytics')}`,
                description: 'View statistics for Pancakeswap exchanges.'
            };
        case '/info/pools':
            return {
                title: `${t('Pools')} | ${t('PancakeSwap Info & Analytics')}`,
                description: 'View statistics for Pancakeswap exchanges.'
            };
        case '/info/tokens':
            return {
                title: `${t('Tokens')} | ${t('PancakeSwap Info & Analytics')}`,
                description: 'View statistics for Pancakeswap exchanges.'
            };
        case '/nfts':
            return {
                title: `${t('Overview')} | ${t('PancakeSwap')}`
            };
        case '/nfts/collections':
            return {
                title: `${t('Collections')} | ${t('PancakeSwap')}`
            };
        case '/nfts/activity':
            return {
                title: `${t('Activity')} | ${t('PancakeSwap')}`
            };
        case '/nfts/profile':
            return {
                title: `${t('Profile')} | ${t('PancakeSwap')}`
            };
        case '/pancake-squad':
            return {
                title: `${t('Pancake Squad')} | ${t('PancakeSwap')}`
            };
        default:
            return null;
    }
};


/***/ }),

/***/ 9748:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ke": () => (/* binding */ mainnetTokens),
/* harmony export */   "ux": () => (/* binding */ testnetTokens),
/* harmony export */   "uO": () => (/* binding */ serializeTokens),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2877);
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var state_user_hooks_helpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(787);


const { MAINNET , TESTNET  } = _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId;
const defineTokens = (t)=>t
;
const mainnetTokens = defineTokens({
    wbnb: new _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(MAINNET, '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c', 18, 'WBNB', 'Wrapped BNB', 'https://www.binance.com/'),
    // bnb here points to the wbnb contract. Wherever the currency BNB is required, conditional checks for the symbol 'BNB' can be used
    bnb: new _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(MAINNET, '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c', 18, 'BNB', 'BNB', 'https://www.binance.com/'),
    cake: new _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(MAINNET, '0x0E09FaBB73Bd3Ade0a17ECC321fD13a19e81cE82', 18, 'CAKE', 'PancakeSwap Token', 'https://pancakeswap.finance/'),
    busd: new _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(MAINNET, '0xeD24FC36d5Ee211Ea25A80239Fb8C4Cfd80f12Ee', 18, 'BUSD', 'Binance USD', 'https://www.paxos.com/busd/'),
    tlos: new _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(MAINNET, '0xb6C53431608E626AC81a9776ac3e999c5556717c', 18, 'TLOS', 'Telos', 'https://www.telos.net/'),
    beta: new _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(MAINNET, '0xBe1a001FE942f96Eea22bA08783140B9Dcc09D28', 18, 'BETA', 'Beta Finance', 'https://betafinance.org'),
    syrup: new _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(MAINNET, '0xBe1a001FE942f96Eea22bA08783140B9Dcc09D28', 18, 'BETA', 'Beta Finance', 'https://betafinance.org')
});
const testnetTokens = defineTokens({
    wbnb: new _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(TESTNET, '0x094616F0BdFB0b526bD735Bf66Eca0Ad254ca81F', 18, 'WBNB', 'Wrapped BNB', 'https://www.binance.com/'),
    cake: new _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(TESTNET, '0xa35062141Fa33BCA92Ce69FeD37D0E8908868AAe', 18, 'CAKE', 'PancakeSwap Token', 'https://pancakeswap.finance/'),
    busd: new _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(TESTNET, '0xeD24FC36d5Ee211Ea25A80239Fb8C4Cfd80f12Ee', 18, 'BUSD', 'Binance USD', 'https://www.paxos.com/busd/'),
    syrup: new _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(TESTNET, '0xfE1e507CeB712BDe086f3579d2c03248b2dB77f9', 18, 'SYRUP', 'SyrupBar Token', 'https://pancakeswap.finance/'),
    bake: new _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(TESTNET, '0xE02dF9e3e622DeBdD69fb838bB799E3F168902c5', 18, 'BAKE', 'Bakeryswap Token', 'https://www.bakeryswap.org/')
});
const tokens = ()=>{
    const chainId = "1666700000";
    // If testnet - return list comprised of testnetTokens wherever they exist, and mainnetTokens where they don't
    if (parseInt(chainId, 10) === _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.TESTNET) {
        return Object.keys(mainnetTokens).reduce((accum, key)=>{
            return {
                ...accum,
                [key]: testnetTokens[key] || mainnetTokens[key]
            };
        }, {});
    }
    return mainnetTokens;
};
const unserializedTokens = tokens();
const serializeTokens = ()=>{
    const serializedTokens = Object.keys(unserializedTokens).reduce((accum, key)=>{
        return {
            ...accum,
            [key]: (0,state_user_hooks_helpers__WEBPACK_IMPORTED_MODULE_1__/* .serializeToken */ .Mq)(unserializedTokens[key])
        };
    }, {});
    return serializedTokens;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (unserializedTokens);


/***/ }),

/***/ 7971:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "jh": () => (/* binding */ PoolCategory),
/* harmony export */   "iF": () => (/* binding */ FetchStatus)
/* harmony export */ });
/* unused harmony exports PoolIds, LotteryStatus, AuctionStatus */
var PoolIds;
(function(PoolIds) {
    PoolIds["poolBasic"] = "poolBasic";
    PoolIds["poolUnlimited"] = "poolUnlimited";
})(PoolIds || (PoolIds = {}));
var PoolCategory;
(function(PoolCategory) {
    PoolCategory['COMMUNITY'] = 'Community';
    PoolCategory['CORE'] = 'Core';
    PoolCategory['BINANCE'] = 'Binance';
    PoolCategory['AUTO'] = 'Auto';
})(PoolCategory || (PoolCategory = {}));
var LotteryStatus;
(function(LotteryStatus) {
    LotteryStatus["PENDING"] = 'pending';
    LotteryStatus["OPEN"] = 'open';
    LotteryStatus["CLOSE"] = 'close';
    LotteryStatus["CLAIMABLE"] = 'claimable';
})(LotteryStatus || (LotteryStatus = {}));
var AuctionStatus;
(function(AuctionStatus) {
    AuctionStatus[AuctionStatus["ToBeAnnounced"] = 0] = "ToBeAnnounced";
    AuctionStatus[AuctionStatus["Pending"] = 1] = "Pending";
    AuctionStatus[AuctionStatus["Open"] = 2] = "Open";
    AuctionStatus[AuctionStatus["Finished"] = 3] = "Finished";
    AuctionStatus[AuctionStatus["Closed"] = 4] = "Closed";
})(AuctionStatus || (AuctionStatus = {}));
var FetchStatus;
(function(FetchStatus) {
    FetchStatus["Idle"] = 'IDLE';
    FetchStatus["Fetching"] = 'FETCHING';
    FetchStatus["Fetched"] = 'FETCHED';
    FetchStatus["Failed"] = 'FAILED';
})(FetchStatus || (FetchStatus = {}));


/***/ }),

/***/ 3206:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "hJ": () => (/* binding */ BSC_BLOCK_TIME),
/* harmony export */   "st": () => (/* binding */ BASE_BSC_SCAN_URLS),
/* harmony export */   "OS": () => (/* binding */ BASE_BSC_SCAN_URL)
/* harmony export */ });
/* unused harmony exports CAKE_PER_BLOCK, BLOCKS_PER_YEAR, CAKE_PER_YEAR, BASE_URL, BASE_ADD_LIQUIDITY_URL, DEFAULT_TOKEN_DECIMAL, DEFAULT_GAS_LIMIT, AUCTION_BIDDERS_TO_FETCH, RECLAIM_AUCTIONS_TO_FETCH, AUCTION_WHITELISTED_BIDDERS_TO_FETCH, IPFS_GATEWAY, PANCAKE_BUNNIES_UPDATE_FREQUENCY */
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2877);
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var bignumber_js_bignumber__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(899);
/* harmony import */ var bignumber_js_bignumber__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(bignumber_js_bignumber__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var utils_bigNumber__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5128);



bignumber_js_bignumber__WEBPACK_IMPORTED_MODULE_1___default().config({
    EXPONENTIAL_AT: 1000,
    DECIMAL_PLACES: 80
});
const BSC_BLOCK_TIME = 3;
const BASE_BSC_SCAN_URLS = {
    [_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET]: 'https://bscscan.com',
    [_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.TESTNET]: 'https://testnet.bscscan.com'
};
// CAKE_PER_BLOCK details
// 40 CAKE is minted per block
// 20 CAKE per block is sent to Burn pool (A farm just for burning cake)
// 10 CAKE per block goes to CAKE syrup pool
// 9 CAKE per block goes to Yield farms and lottery
// CAKE_PER_BLOCK in config/index.ts = 40 as we only change the amount sent to the burn pool which is effectively a farm.
// CAKE/Block in src/views/Home/components/CakeDataRow.tsx = 15 (40 - Amount sent to burn pool)
const CAKE_PER_BLOCK = 40;
const BLOCKS_PER_YEAR = 60 / BSC_BLOCK_TIME * 60 * 24 * 365 // 10512000
;
const CAKE_PER_YEAR = CAKE_PER_BLOCK * BLOCKS_PER_YEAR;
const BASE_URL = 'https://pancakeswap.finance';
const BASE_ADD_LIQUIDITY_URL = `${BASE_URL}/add`;
const BASE_BSC_SCAN_URL = BASE_BSC_SCAN_URLS[_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET];
const DEFAULT_TOKEN_DECIMAL = utils_bigNumber__WEBPACK_IMPORTED_MODULE_2__/* .BIG_TEN.pow */ .xp.pow(18);
const DEFAULT_GAS_LIMIT = 200000;
const AUCTION_BIDDERS_TO_FETCH = 500;
const RECLAIM_AUCTIONS_TO_FETCH = 500;
const AUCTION_WHITELISTED_BIDDERS_TO_FETCH = 500;
const IPFS_GATEWAY = 'https://ipfs.io/ipfs';
// In reality its 10000 because of fast refresh, a bit less here to cover for possible long request times
const PANCAKE_BUNNIES_UPDATE_FREQUENCY = 8000;


/***/ }),

/***/ 9821:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EN": () => (/* binding */ EN),
/* harmony export */   "Mj": () => (/* binding */ languages),
/* harmony export */   "s0": () => (/* binding */ languageList)
/* harmony export */ });
/* unused harmony exports AR, BN, DE, EL, ESES, FI, FIL, FR, HI, HU, ID, IT, JA, KO, NL, PL, PTBR, PTPT, RO, RU, SVSE, TA, TR, UK, VI, ZHCN, ZHTW */
const AR = {
    locale: 'ar-SA',
    language: 'العربية',
    code: 'ar'
};
const BN = {
    locale: 'bn-BD',
    language: 'বাংলা',
    code: 'bn'
};
const EN = {
    locale: 'en-US',
    language: 'English',
    code: 'en'
};
const DE = {
    locale: 'de-DE',
    language: 'Deutsch',
    code: 'de'
};
const EL = {
    locale: 'el-GR',
    language: 'Ελληνικά',
    code: 'el'
};
const ESES = {
    locale: 'es-ES',
    language: 'Espa\xf1ol',
    code: 'es-ES'
};
const FI = {
    locale: 'fi-FI',
    language: 'Suomalainen',
    code: 'fi'
};
const FIL = {
    locale: 'fil-PH',
    language: 'Filipino',
    code: 'fil'
};
const FR = {
    locale: 'fr-FR',
    language: 'Fran\xe7ais',
    code: 'fr'
};
const HI = {
    locale: 'hi-IN',
    language: 'हिंदी',
    code: 'hi'
};
const HU = {
    locale: 'hu-HU',
    language: 'Magyar',
    code: 'hu'
};
const ID = {
    locale: 'id-ID',
    language: 'Bahasa Indonesia',
    code: 'id'
};
const IT = {
    locale: 'it-IT',
    language: 'Italiano',
    code: 'it'
};
const JA = {
    locale: 'ja-JP',
    language: '日本語',
    code: 'ja'
};
const KO = {
    locale: 'ko-KR',
    language: '한국어',
    code: 'ko'
};
const NL = {
    locale: 'nl-NL',
    language: 'Nederlands',
    code: 'nl'
};
const PL = {
    locale: 'pl-PL',
    language: 'Polski',
    code: 'pl'
};
const PTBR = {
    locale: 'pt-BR',
    language: 'Portugu\xeas (Brazil)',
    code: 'pt-br'
};
const PTPT = {
    locale: 'pt-PT',
    language: 'Portugu\xeas',
    code: 'pt-pt'
};
const RO = {
    locale: 'ro-RO',
    language: 'Rom\xe2nă',
    code: 'ro'
};
const RU = {
    locale: 'ru-RU',
    language: 'Русский',
    code: 'ru'
};
const SVSE = {
    locale: 'sv-SE',
    language: 'Svenska',
    code: 'sv'
};
const TA = {
    locale: 'ta-IN',
    language: 'தமிழ்',
    code: 'ta'
};
const TR = {
    locale: 'tr-TR',
    language: 'T\xfcrk\xe7e',
    code: 'tr'
};
const UK = {
    locale: 'uk-UA',
    language: 'Українська',
    code: 'uk'
};
const VI = {
    locale: 'vi-VN',
    language: 'Tiếng Việt',
    code: 'vi'
};
const ZHCN = {
    locale: 'zh-CN',
    language: '简体中文',
    code: 'zh-cn'
};
const ZHTW = {
    locale: 'zh-TW',
    language: '繁體中文',
    code: 'zh-tw'
};
const languages = {
    'ar-SA': AR,
    'bn-BD': BN,
    'en-US': EN,
    'de-DE': DE,
    'el-GR': EL,
    'es-ES': ESES,
    'fi-FI': FI,
    'fil-PH': FIL,
    'fr-FR': FR,
    'hi-IN': HI,
    'hu-HU': HU,
    'id-ID': ID,
    'it-IT': IT,
    'ja-JP': JA,
    'ko-KR': KO,
    'nl-NL': NL,
    'pl-PL': PL,
    'pt-BR': PTBR,
    'pt-PT': PTPT,
    'ro-RO': RO,
    'ru-RU': RU,
    'sv-SE': SVSE,
    'ta-IN': TA,
    'tr-TR': TR,
    'uk-UA': UK,
    'vi-VN': VI,
    'zh-CN': ZHCN,
    'zh-TW': ZHTW
};
const languageList = Object.values(languages);


/***/ }),

/***/ 5290:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SH": () => (/* binding */ LS_KEY),
/* harmony export */   "w2": () => (/* binding */ fetchLocale),
/* harmony export */   "jq": () => (/* binding */ getLanguageCodeFromLS)
/* harmony export */ });
/* harmony import */ var config_localization_languages__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9821);

const publicUrl = process.env.PUBLIC_URL || '';
const LS_KEY = 'pancakeswap_language';
const fetchLocale = async (locale)=>{
    const response = await fetch(`${publicUrl}/locales/${locale}.json`);
    const data = await response.json();
    return data;
};
const getLanguageCodeFromLS = ()=>{
    try {
        const codeFromStorage = localStorage.getItem(LS_KEY);
        return codeFromStorage || config_localization_languages__WEBPACK_IMPORTED_MODULE_0__.EN.locale;
    } catch  {
        return config_localization_languages__WEBPACK_IMPORTED_MODULE_0__.EN.locale;
    }
};


/***/ }),

/***/ 9150:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "iL": () => (/* reexport */ LanguageProvider),
  "$G": () => (/* reexport */ Localization_useTranslation)
});

// UNUSED EXPORTS: LanguageContext, languageMap

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./src/config/localization/languages.ts
var languages = __webpack_require__(9821);
;// CONCATENATED MODULE: ./src/config/localization/translations.json
const translations_namespaceObject = JSON.parse('{"Farm":"Farm","Staking":"Staking","Syrup Pool":"Syrup Pool","Exchange":"Exchange","Docs":"Docs","Voting":"Voting","Lottery":"Lottery","Connect Wallet":"Connect Wallet","Your %asset% Balance":"Your %asset% Balance","Total %asset% Supply":"Total %asset% Supply","Locked":"Locked","Pending harvest":"Pending harvest","New rewards per block":"New rewards per block","Total CAKE burned since launch":"Total CAKE burned since launch","See the Kitchen":"See the Kitchen","Telegram":"Telegram","Blog":"Blog","Github":"Github","Twitter":"Twitter","Deposit":"Deposit","Earn":"Earn","Stake LP tokens to stack CAKE":"Stake LP tokens to stack CAKE","You can swap back anytime":"You can swap back anytime","%asset% Earned":"%asset% Earned","Tokens Staked":"Tokens Staked","Every time you stake and unstake CAKE tokens, the contract will automagically harvest CAKE rewards for you!":"Every time you stake and unstake CAKE tokens, the contract will automagically harvest CAKE rewards for you!","XVS Tokens Earned":"XVS Tokens Earned","Rewards will be calculated per block and total rewards will be distributed automatically at the end of each project’s farming period.":"Rewards will be calculated per block and total rewards will be distributed automatically at the end of each project’s farming period.","Pool":"Pool","Coming Soon":"Coming Soon","APY":"APY","Total Liquidity":"Total Liquidity","View on BscScan":"View on BscScan","Cake price":"Cake price","%asset% Tokens Earned":"%asset% Tokens Earned","%num% blocks until farming ends":"%num% blocks until farming ends","Coming Soon...":"Coming Soon...","Your Stake":"Your Stake","Farming starts in %num% Blocks":"Farming starts in %num% Blocks","Finished":"Finished","Farming ends in %num% Blocks":"Farming ends in %num% Blocks","Project site":"Project site","Project Site":"Project Site","See Token Info":"See Token Info","You can unstake at any time.":"You can unstake at any time.","Rewards are calculated per block.":"Rewards are calculated per block.","Total":"Total","End":"End","View Project Site":"View Project Site","Your Project? 👀":"Your Project? 👀","Create a pool for your token":"Create a pool for your token","Apply now":"Apply now","Round 1: BUYING":"Round 1: BUYING","%num% CAKE":"%num% CAKE","Spend CAKE to buy tickets, contributing to the lottery pot. Ticket purchases end approx. 30 minutes before lottery. Win prizes if 2, 3, or 4 of your ticket numbers match the winning numbers and their positions! Good luck!":"Spend CAKE to buy tickets, contributing to the lottery pot. Ticket purchases end approx. 30 minutes before lottery. Win prizes if 2, 3, or 4 of your ticket numbers match the winning numbers and their positions! Good luck!","Your total tickets for this round":"Your total tickets for this round","Buy ticket":"Buy ticket","View your tickets":"View your tickets","Approx. time left to buy tickets":"Approx. time left to buy tickets","My Tickets (Total: %TICKETS%)":"My Tickets (Total: %TICKETS%)","Close":"Close","Latest Winning Numbers":"Latest Winning Numbers","Ticket":"Ticket","Tickets matching 4 numbers:":"Tickets matching 4 numbers:","Tickets matching 3 numbers:":"Tickets matching 3 numbers:","Tickets matching 2 numbers:":"Tickets matching 2 numbers:","Export recent winning numbers":"Export recent winning numbers","Enter amount of tickets to buy":"Enter amount of tickets to buy","Max":"Max","%num% CAKE Available":"%num% CAKE Available","%num% %symbol% Available":"%num% %symbol% Available","Your amount must be a multiple of 10 CAKE":"Your amount must be a multiple of 10 CAKE","1 Ticket = %lotteryPrice% CAKE":"1 Ticket = %lotteryPrice% CAKE","Until ticket sale:":"Until ticket sale:","You will spend: %num% CAKE":"You will spend: %num% CAKE","Cancel":"Cancel","Confirm":"Confirm","Warning":"Warning","Lottery ticket purchases are final.":"Lottery ticket purchases are final.","Your CAKE will not be returned to you after you spend it to buy tickets.":"Your CAKE will not be returned to you after you spend it to buy tickets.","Tickets are only valid for one lottery draw, and will be burned after the draw.":"Tickets are only valid for one lottery draw, and will be burned after the draw.","Buying tickets does not guarantee you will win anything. Please only participate once you understand the risks.":"Buying tickets does not guarantee you will win anything. Please only participate once you understand the risks.","I understand":"I understand","Ticket purchases are final. Your CAKE cannot be returned to you after buying tickets.":"Ticket purchases are final. Your CAKE cannot be returned to you after buying tickets.","Claim prizes":"Claim prizes","CAKE prizes to be claimed":"CAKE prizes to be claimed","Round 2: CLAIMING":"Round 2: CLAIMING","Pending Confirmation":"Pending Confirmation","Approx. time before next lottery start":"Approx. time before next lottery start","Enable CAKE":"Enable CAKE","IFO: Initial Farm Offerings":"IFO: Initial Farm Offerings","Buy new tokens launching on Binance Smart Chain":"Buy new tokens launching on Binance Smart Chain","You’ll pay for the new tokens using CAKE-BNB LP tokens, which means you need to stake equal amounts of CAKE and BNB in a liquidity pool to take part.":"You’ll pay for the new tokens using CAKE-BNB LP tokens, which means you need to stake equal amounts of CAKE and BNB in a liquidity pool to take part.","Get CAKE-BNB LP >":"Get CAKE-BNB LP >","The project gets the BNB, PancakeSwap burns the CAKE.":"The project gets the BNB, PancakeSwap burns the CAKE.","You get the tokens.":"You get the tokens.","Want to launch your own IFO?":"Want to launch your own IFO?","Launch your project with PancakeSwap, Binance Smart Chain’s most-used AMM project and liquidity provider, to bring your token directly to the most active and rapidly growing community on BSC.":"Launch your project with PancakeSwap, Binance Smart Chain’s most-used AMM project and liquidity provider, to bring your token directly to the most active and rapidly growing community on BSC.","Apply to launch":"Apply to launch","Community":"Community","Core":"Core","Available":"Available","My Wallet":"My Wallet","Sign out":"Sign out","Harvest all (%count%)":"Harvest all (%count%)","Cake Stats":"Cake Stats","Total CAKE Supply":"Total CAKE Supply","Total CAKE Burned":"Total CAKE Burned","New CAKE/block":"New CAKE/block","Farms & Staking":"Farms & Staking","CAKE to Harvest":"CAKE to Harvest","CAKE in Wallet":"CAKE in Wallet","Collecting CAKE":"Collecting CAKE","Your Lottery Winnings":"Your Lottery Winnings","CAKE to Collect":"CAKE to Collect","Total jackpot this round":"Total jackpot this round","Collect Winnings":"Collect Winnings","Buy Tickets":"Buy Tickets","Harvest":"Harvest","Select":"Select","Winning Numbers This Round":"Winning Numbers This Round","Winning numbers":"Winning numbers","Total prizes":"Total prizes","Round #%num%":"Round #%num%","Total Pot:":"Total Pot:","Staking Pool":"Staking Pool","PancakeSwap":"PancakeSwap","The #1 AMM and yield farm on Binance Smart Chain.":"The #1 AMM and yield farm on Binance Smart Chain.","Stake CAKE to earn new tokens.":"Stake CAKE to earn new tokens.","Launch Time":"Launch Time","For Sale":"For Sale","CAKE to burn (USD)":"CAKE to burn (USD)","CAKE to burn:":"CAKE to burn:","Unstake":"Unstake","⭐️ Every time you stake and unstake LP tokens, the contract will automagically harvest CAKE rewards for you!":"⭐️ Every time you stake and unstake LP tokens, the contract will automagically harvest CAKE rewards for you!","How to take part":"How to take part","Before Sale":"Before Sale","Buy CAKE and BNB tokens":"Buy CAKE and BNB tokens","Get CAKE-BNB LP tokens by adding CAKE and BNB liquidity":"Get CAKE-BNB LP tokens by adding CAKE and BNB liquidity","During Sale":"During Sale","While the sale is live, commit your CAKE-LP tokens to buy the IFO tokens":"While the sale is live, commit your CAKE-LP tokens to buy the IFO tokens","After Sale":"After Sale","Claim the tokens you bought, along with any unspent funds.":"Claim the tokens you bought, along with any unspent funds.","Done!":"Done!","Read more":"Read more","Connect":"Connect","Trade in for CAKE, or keep for your collection!":"Trade in for CAKE, or keep for your collection!","Register your interest in winning an NFT below.":"Register your interest in winning an NFT below.","Register for a chance to win":"Register for a chance to win","Learn more":"Learn more","Trade in NFT":"Trade in NFT","Trade in":"Trade in","You will receive":"You will receive","When you trade in this NFT to receive CAKE, you will lose access to it forever!":"When you trade in this NFT to receive CAKE, you will lose access to it forever!","Claim NFT":"Claim NFT","How it works":"How it works","Winners will be able to claim an NFT on this page once the claiming period starts.":"Winners will be able to claim an NFT on this page once the claiming period starts.","If you’re not selected, you won’t be able to claim. Better luck next time!":"If you’re not selected, you won’t be able to claim. Better luck next time!","Winners can trade in their NFTs for a CAKE value until the expiry date written below. If you don\'t trade in your NFT by then, don’t worry: you’ll still keep it in your wallet!":"Winners can trade in their NFTs for a CAKE value until the expiry date written below. If you don\'t trade in your NFT by then, don’t worry: you’ll still keep it in your wallet!","How are winners selected?":"How are winners selected?","Winners are selected at random! Good luck!":"Winners are selected at random! Good luck!","Value if traded in":"Value if traded in","Number minted":"Number minted","Number burned":"Number burned","Claim this NFT":"Claim this NFT","Trade in for CAKE":"Trade in for CAKE","Loading…":"Loading…","Details":"Details","You won!":"You won!","Claim an NFT from the options below!":"Claim an NFT from the options below!","Can be traded until":"Can be traded until","Wallet Disconnected":"Wallet Disconnected","Connect to see if you have won an NFT!":"Connect to see if you have won an NFT!","Home":"Home","Trade":"Trade","Farms":"Farms","Pools":"Pools","NFT":"NFT","Info":"Info","IFO":"IFO","More":"More","Liquidity":"Liquidity","Overview":"Overview","Token":"Token","Pairs":"Pairs","Accounts":"Accounts","Stake LP tokens to earn CAKE":"Stake LP tokens to earn CAKE","Active":"Active","Inactive":"Inactive","Dual":"Dual","Compound":"Compound","Unstake %asset%":"Unstake %asset%","The CAKE Lottery":"The CAKE Lottery","Buy tickets with CAKE":"Buy tickets with CAKE","Win if 2, 3 or 4 of your ticket numbers match!":"Win if 2, 3 or 4 of your ticket numbers match!","%time% Until lottery draw":"%time% Until lottery draw","Next draw":"Next draw","Past draws":"Past draws","Round %num%":"Round %num%","Total Pot":"Total Pot","Your tickets for this round":"Your tickets for this round","Sorry, no prizes to collect":"Sorry, no prizes to collect","In Wallet":"In Wallet","Loading...":"Loading...","Next IFO":"Next IFO","Past IFOs":"Past IFOs","APR":"APR","APR (incl. LP rewards)":"APR (incl. LP rewards)","Select lottery number:":"Select lottery number:","Search":"Search","History":"History","Pool Size":"Pool Size","Burned":"Burned","To burn":"To burn","Show Last":"Show Last","Prize Pot":"Prize Pot","Winners":"Winners","No. Matched":"No. Matched","Enable Contract":"Enable Contract","%asset% staked":"%asset% staked","Total Value Locked":"Total Value Locked","Across all LPs and Syrup Pools":"Across all LPs and Syrup Pools","Your wallet":"Your wallet","Logout":"Logout","Profile Setup":"Profile Setup","Show off your stats and collectibles with your unique profile.":"Show off your stats and collectibles with your unique profile.","Total cost: 10 CAKE":"Total cost: 10 CAKE","Get Starter Collectible":"Get Starter Collectible","Set Profile Picture":"Set Profile Picture","Join Team":"Join Team","Set Name":"Set Name","Step 1":"Step 1","Every profile starts by making a \\"starter\\" collectible (NFT).":"Every profile starts by making a \\"starter\\" collectible (NFT).","This starter will also become your first profile picture.":"This starter will also become your first profile picture.","You can change your profile pic later if you get another approved Pancake Collectible,":"You can change your profile pic later if you get another approved Pancake Collectible,","Choose your Starter!":"Choose your Starter!","Choose wisely: you can only ever make one starter collectible!":"Choose wisely: you can only ever make one starter collectible!","Cost: 5 CAKE":"Cost: 5 CAKE","Next Step":"Next Step","Confirming":"Confirming","Enabled":"Enabled","Confirmed":"Confirmed","Insufficient CAKE balance":"Insufficient CAKE balance","Step 2":"Step 2","Choose collectible":"Choose collectible","Choose a profile picture from the eligible collectibles (NFT) in your wallet, shown below.":"Choose a profile picture from the eligible collectibles (NFT) in your wallet, shown below.","Only approved Pancake Collectibles can be used.":"Only approved Pancake Collectibles can be used.","Allow collectible to be locked":"Allow collectible to be locked","The collectible you\'ve chosen will be locked in a smart contract while it\'s being used as your profile picture. ":"The collectible you\'ve chosen will be locked in a smart contract while it\'s being used as your profile picture. ","Don\'t worry - you\'ll be able to get it back at any time.":"Don\'t worry - you\'ll be able to get it back at any time.","Step 3":"Step 3","Join a Team":"Join a Team","It won\'t be possible to undo the choice you make for the foreseeable future!":"It won\'t be possible to undo the choice you make for the foreseeable future!","There\'s currently no big difference between teams, and no benefit of joining one team over another for now.":"There\'s currently no big difference between teams, and no benefit of joining one team over another for now.","So pick whichever you like!":"So pick whichever you like!","%count% Members":"%count% Members","Step 4":"Step 4","This name will be shown in team leaderboards and search results as long as your profile is active.":"This name will be shown in team leaderboards and search results as long as your profile is active.","Your name must be at least 3 and at most 15 standards letters and numbers long.":"Your name must be at least 3 and at most 15 standards letters and numbers long.","Complete Profile":"Complete Profile","Maximum length: 15 characters":"Maximum length: 15 characters","Minimum length: 3 characters":"Minimum length: 3 characters","No spaces or special characters":"No spaces or special characters","Submitting NFT to contract and confirming User Name and Team":"Submitting NFT to contract and confirming User Name and Team","Oops!":"Oops!","We couldn\'t find any Pancake Collectibles in your wallet.":"We couldn\'t find any Pancake Collectibles in your wallet.","You need a Pancake Collectible to finish setting up your profile. If you sold or transferred your starter collectible to another wallet, you\'ll need to get it back or acquire a new one somehow. You can\'t make a new starter with this wallet address.":"You need a Pancake Collectible to finish setting up your profile. If you sold or transferred your starter collectible to another wallet, you\'ll need to get it back or acquire a new one somehow. You can\'t make a new starter with this wallet address.","ROI Calculator":"ROI Calculator","Timeframe":"Timeframe","CAKE per $1000":"CAKE per $1000","Calculated based on current rates.":"Calculated based on current rates.","Compounding %freq%x daily.":"Compounding %freq%x daily.","All figures are estimates provided for your convenience only, and by no means represent guaranteed returns.":"All figures are estimates provided for your convenience only, and by no means represent guaranteed returns.","You can\'t change this once you click Confirm.":"You can\'t change this once you click Confirm.","Until ticket sale":"Until ticket sale","To burn:":"To burn:","On sale soon":"On sale soon","On sale":"On sale","Teams Overview":"Teams Overview","Teams":"Teams","See More":"See More","Team Achievements":"Team Achievements","Team Points":"Team Points","Active Members":"Active Members","Set up now":"Set up now","You haven’t set up your profile yet!":"You haven’t set up your profile yet!","You can do this at any time by clicking on your profile picture in the menu":"You can do this at any time by clicking on your profile picture in the menu","Collect":"Collect","Compounding":"Compounding","Harvesting":"Harvesting","Buy CAKE":"Buy CAKE","Show":"Show","Hide":"Hide","Stake LP tokens":"Stake LP tokens","Stake":"Stake","Earned":"Earned","Staked":"Staked","The lottery number you provided does not exist":"The lottery number you provided does not exist","Error fetching data":"Error fetching data","Teams & Profiles":"Teams & Profiles","Earn more points for completing larger quests!":"Earn more points for completing larger quests!","Collecting points for these tasks makes them available again.":"Collecting points for these tasks makes them available again.","Earn points by completing regular tasks!":"Earn points by completing regular tasks!","Task Center":"Task Center","Achievements":"Achievements","Enter your name...":"Enter your name...","I understand that people can view my wallet if they know my username":"I understand that people can view my wallet if they know my username","A minimum of %num% CAKE is required":"A minimum of %num% CAKE is required","Only reuse a name from other social media if you\'re OK with people viewing your wallet. You can\'t change your name once you click Confirm.":"Only reuse a name from other social media if you\'re OK with people viewing your wallet. You can\'t change your name once you click Confirm.","Please connect your wallet to continue":"Please connect your wallet to continue","Public Profile":"Public Profile","Show off your stats and collectibles with your unique profile. Team features will be revealed soon!":"Show off your stats and collectibles with your unique profile. Team features will be revealed soon!","Points":"Points","Set Your Name":"Set Your Name","Step %num%":"Step %num%","See the list >":"See the list >","Staked only":"Staked only","Get %symbol%":"Get %symbol%","Get %symbol1% or %symbol2%":"Get %symbol1% or %symbol2%","Balance":"Balance","Oops, page not found.":"Oops, page not found.","Click here to reset!":"Click here to reset!","Oops, something wrong.":"Oops, something wrong.","Back Home":"Back Home","Unstake LP tokens":"Unstake LP tokens","Get ready":"Get ready","Live":"Live","Start":"Start","Finish":"Finish","Connect wallet to view":"Connect wallet to view","Sorry, you needed to register during the “entry” period!":"Sorry, you needed to register during the “entry” period!","Check your Rank":"Check your Rank","You’re not participating this time.":"You’re not participating this time.","Rank in team":"Rank in team","Your volume":"Your volume","Since start":"Since start","Your Score":"Your Score","Enable":"Enable","Enabling":"Enabling","%amount% CAKE":"%amount% CAKE","IFO Shopper: %title%":"IFO Shopper: %title%","%num% of total":"%num% of total","All estimated rates take into account this pool’s %fee%% performance fee":"All estimated rates take into account this pool’s %fee%% performance fee","Sorry, you didn’t contribute enough CAKE to meet the minimum threshold. You didn’t buy anything in this sale, but you can still reclaim your CAKE.":"Sorry, you didn’t contribute enough CAKE to meet the minimum threshold. You didn’t buy anything in this sale, but you can still reclaim your CAKE.","Only applies within 3 days of staking. Unstaking after 3 days will not include a fee. Timer resets every time you stake new CAKE in the pool.":"Only applies within 3 days of staking. Unstaking after 3 days will not include a fee. Timer resets every time you stake new CAKE in the pool.","Unstaking Fee":"Unstaking Fee","unstaking fee until":"unstaking fee until","unstaking fee if withdrawn within 72h":"unstaking fee if withdrawn within 72h","Unstaking fee: %fee%%":"Unstaking fee: %fee%%","Performance Fee":"Performance Fee","Compound: collect and restake CAKE into pool.":"Compound: collect and restake CAKE into pool.","Harvest: collect CAKE and send to wallet":"Harvest: collect CAKE and send to wallet","%position% Entered":"%position% Entered","Sort by":"Sort by","Expired":"Expired","Calculating":"Calculating","Next":"Next","Later":"Later","Up":"Up","Down":"Down","%multiplier% Payout":"%multiplier% Payout","Enter %direction%":"Enter %direction%","Prize Pool:":"Prize Pool:","Charts":"Charts","Your history":"Your history","All":"All","Collected":"Collected","Uncollected":"Uncollected","Round":"Round","Rounds":"Rounds","PNL":"PNL","Your Result":"Your Result","Your direction":"Your direction","Your position":"Your position","Lose":"Lose","Entry starts":"Entry starts","Locked Price":"Locked Price","Last Price":"Last Price","Closed Price":"Closed Price","Win":"Win","Opening Block":"Opening Block","Closing Block":"Closing Block","Total Value Locked (TVL)":"Total Value Locked (TVL)","Automatic restaking":"Automatic restaking","Manual CAKE":"Manual CAKE","Auto CAKE":"Auto CAKE","Auto CAKE Bounty":"Auto CAKE Bounty","Claim":"Claim","Any funds you stake in this pool will be automagically harvested and restaked (compounded) for you.":"Any funds you stake in this pool will be automagically harvested and restaked (compounded) for you.","Total staked":"Total staked","Just stake some tokens to earn.":"Just stake some tokens to earn.","High APR, low risk.":"High APR, low risk.","Stake LP tokens to earn.":"Stake LP tokens to earn.","Basic Sale":"Basic Sale","Everyone can only commit a limited amount, but may expect a higher return per token committed.":"Everyone can only commit a limited amount, but may expect a higher return per token committed.","Unlimited Sale":"Unlimited Sale","No limits on the amount you can commit. Additional fee applies when claiming.":"No limits on the amount you can commit. Additional fee applies when claiming.","Every person can only commit a limited amount, but may expect a higher return per token committed.":"Every person can only commit a limited amount, but may expect a higher return per token committed.","You didn’t participate in this sale!":"You didn’t participate in this sale!","Max. token entry":"Max. token entry","Max. CAKE entry":"Max. CAKE entry","How to Take Part":"How to Take Part","Activate your Profile":"Activate your Profile","You’ll need an active PancakeSwap Profile to take part in an IFO!":"You’ll need an active PancakeSwap Profile to take part in an IFO!","Profile Active!":"Profile Active!","Get CAKE Tokens":"Get CAKE Tokens","Stake CAKE and BNB in the liquidity pool to get LP tokens.":"Stake CAKE and BNB in the liquidity pool to get LP tokens.","You’ll spend them to buy IFO sale tokens.":"You’ll spend them to buy IFO sale tokens.","Commit CAKE":"Commit CAKE","When the IFO sales are live, you can “commit” your CAKE to buy the tokens being sold.":"When the IFO sales are live, you can “commit” your CAKE to buy the tokens being sold.","We recommend committing to the Basic Sale first, but you can do both if you like.":"We recommend committing to the Basic Sale first, but you can do both if you like.","Claim your tokens and achievement":"Claim your tokens and achievement","After the IFO sales finish, you can claim any IFO tokens that you bought, and any unspent CAKE tokens will be returned to your wallet.":"After the IFO sales finish, you can claim any IFO tokens that you bought, and any unspent CAKE tokens will be returned to your wallet.","This round’s closing transaction has been submitted to the blockchain, and is awaiting confirmation.":"This round’s closing transaction has been submitted to the blockchain, and is awaiting confirmation.","No prediction history available":"No prediction history available","If you are sure you should see history here, make sure you’re connected to the correct wallet and try again.":"If you are sure you should see history here, make sure you’re connected to the correct wallet and try again.","Last price from Chainlink Oracle":"Last price from Chainlink Oracle","%num% Points to Collect":"%num% Points to Collect","Net results":"Net results","Average return / round":"Average return / round","Average position entered / round":"Average position entered / round","Won":"Won","Lost":"Lost","Entered":"Entered","Connect your wallet to view your prediction history":"Connect your wallet to view your prediction history","Best round: %roundId%":"Best round: %roundId%","You’ve already staked the maximum amount you can stake in this pool!":"You’ve already staked the maximum amount you can stake in this pool!","Markets Paused":"Markets Paused","Prediction markets have been paused due to an error.":"Prediction markets have been paused due to an error.","All open positions have been canceled.":"All open positions have been canceled.","You can reclaim any funds entered into existing positions via the History tab on this page.":"You can reclaim any funds entered into existing positions via the History tab on this page.","Show History":"Show History","Welcome!":"Welcome!","This product is still in beta (testing) phase.":"This product is still in beta (testing) phase.","Before you use this product, make sure you fully understand the risks involved.":"Before you use this product, make sure you fully understand the risks involved.","Once you enter a position, you cannot cancel or adjust it.":"Once you enter a position, you cannot cancel or adjust it.","All losses are final.":"All losses are final.","I understand that I am using this product at my own risk. Any loss incurred due to my actions are my own responsibility.":"I understand that I am using this product at my own risk. Any loss incurred due to my actions are my own responsibility.","You’ll spend CAKE to buy IFO sale tokens.":"You’ll spend CAKE to buy IFO sale tokens.","You\'ll need an active PancakeSwap Profile to take part in an IFO!":"You\'ll need an active PancakeSwap Profile to take part in an IFO!","Your LP tokens committed":"Your LP tokens committed","Max. Committed":"Max. Committed","Total committed:":"Total committed:","Additional fee:":"Additional fee:","Learn more about %symbol%":"Learn more about %symbol%","Earned since your last action":"Earned since your last action","Commit ~%amount% %symbol% in total to earn!":"Commit ~%amount% %symbol% in total to earn!","Learn more about %title%":"Learn more about %title%","365d (APY)":"365d (APY)","%num%d":"%num%d","d":"d","h":"h","m":"m","Hide or show expandable content":"Hide or show expandable content","No tokens to stake":"No tokens to stake","Successfully claimed!":"Successfully claimed!","Unable to claim NFT":"Unable to claim NFT","Unable to claim NFT, please try again.":"Unable to claim NFT, please try again.","Error":"Error","1x %nftName% Collectible":"1x %nftName% Collectible","1x %nftName% NFT":"1x %nftName% NFT","NFT successfully transferred!":"NFT successfully transferred!","View Contract":"View Contract","View IFO Contract":"View IFO Contract","See Pair Info":"See Pair Info","Stake LP":"Stake LP","Multiplier":"Multiplier","Start Farming":"Start Farming","Farming":"Farming","Enable Farm":"Enable Farm","Search Farms":"Search Farms","To Top":"To Top","Total value of the funds in this farm’s liquidity pool":"Total value of the funds in this farm’s liquidity pool","The Multiplier represents the proportion of CAKE rewards each farm receives, as a proportion of the CAKE produced each block.":"The Multiplier represents the proportion of CAKE rewards each farm receives, as a proportion of the CAKE produced each block.","For example, if a 1x farm received 1 CAKE per block, a 40x farm would receive 40 CAKE per block.":"For example, if a 1x farm received 1 CAKE per block, a 40x farm would receive 40 CAKE per block.","This amount is already included in all APR calculations for the farm.":"This amount is already included in all APR calculations for the farm.","Hot":"Hot","Success!":"Success!","You have successfully claimed your rewards.":"You have successfully claimed your rewards.","Commit":"Commit","If you don’t commit enough CAKE, you may not receive any IFO tokens at all and will only receive a full refund of your CAKE.":"If you don’t commit enough CAKE, you may not receive any IFO tokens at all and will only receive a full refund of your CAKE.","CAKE required":"CAKE required","Get CAKE, or make sure your tokens aren’t staked somewhere else.":"Get CAKE, or make sure your tokens aren’t staked somewhere else.","Funds to raise:":"Funds to raise:","Price per %symbol%:":"Price per %symbol%:","Price per %symbol% with fee:":"Price per %symbol% with fee:","You need an active PancakeSwap Profile to take part in an IFO!":"You need an active PancakeSwap Profile to take part in an IFO!","Achievement":"Achievement","Commit ~%minLp% LP in total to earn!":"Commit ~%minLp% LP in total to earn!","What’s the difference between a Basic Sale and Unlimited Sale?":"What’s the difference between a Basic Sale and Unlimited Sale?","In the Basic Sale, every user can commit a maximum of about 100 USD worth of CAKE. We calculate the maximum CAKE amount about 30 minutes before each IFO. The Basic Sale has no participation fee.":"In the Basic Sale, every user can commit a maximum of about 100 USD worth of CAKE. We calculate the maximum CAKE amount about 30 minutes before each IFO. The Basic Sale has no participation fee.","In the Unlimited Sale, there’s no limit to the amount of CAKE you can commit. However, there’s a fee for participation: see below.":"In the Unlimited Sale, there’s no limit to the amount of CAKE you can commit. However, there’s a fee for participation: see below.","Which sale should I commit to? Can I do both?":"Which sale should I commit to? Can I do both?","You can choose one or both at the same time! If you’re only committing a small amount, we recommend the Basic Sale first. Just remember you need a PancakeSwap Profile in order to participate.":"You can choose one or both at the same time! If you’re only committing a small amount, we recommend the Basic Sale first. Just remember you need a PancakeSwap Profile in order to participate.","How much is the participation fee?":"How much is the participation fee?","There’s only a participation fee for the Unlimited Sale: there’s no fee for the Basic Sale.":"There’s only a participation fee for the Unlimited Sale: there’s no fee for the Basic Sale.","The fee will start at 1%.":"The fee will start at 1%.","The 1% participation fee decreases in cliffs, based on the percentage of overflow from the “Unlimited” portion of the sale.":"The 1% participation fee decreases in cliffs, based on the percentage of overflow from the “Unlimited” portion of the sale.","Where does the participation fee go?":"Where does the participation fee go?","The CAKE from the participation fee will be thrown into the weekly token burn.":"The CAKE from the participation fee will be thrown into the weekly token burn.","How can I get an achievement for participating in the IFO?":"How can I get an achievement for participating in the IFO?","You need to contribute a minimum of about 10 USD worth of CAKE to either sale.":"You need to contribute a minimum of about 10 USD worth of CAKE to either sale.","You can contribute to one or both, it doesn’t matter. Only your overall contribution is counted for the achievement.":"You can contribute to one or both, it doesn’t matter. Only your overall contribution is counted for the achievement.","The Lottery Is Changing!":"The Lottery Is Changing!","Come back soon!":"Come back soon!","Staked (compounding)":"Staked (compounding)","Contract Enabled":"Contract Enabled","You can now stake in the %symbol% vault!":"You can now stake in the %symbol% vault!","You can now stake in the %symbol% pool!":"You can now stake in the %symbol% pool!","Please try again. Confirm the transaction and make sure you are paying enough gas!":"Please try again. Confirm the transaction and make sure you are paying enough gas!","Start earning":"Start earning","Recent CAKE profit":"Recent CAKE profit","Unstaked!":"Unstaked!","Unstaked":"Unstaked","Staked!":"Staked!","Your funds have been staked in the pool":"Your funds have been staked in the pool","Your earnings have also been harvested to your wallet":"Your earnings have also been harvested to your wallet","%error% - Please try again.":"%error% - Please try again.","Stake in Pool":"Stake in Pool","Balance: %balance%":"Balance: %balance%","%day%d : %hour%h : %minute%m":"%day%d : %hour%h : %minute%m","%day%d %hour%h %minute%m":"%day%d %hour%h %minute%m","Subtracted automatically from each yield harvest and burned.":"Subtracted automatically from each yield harvest and burned.","Blocks":"Blocks","Add to Metamask":"Add to Metamask","Compounded":"Compounded","Canceled":"Canceled","Please try again and confirm the transaction.":"Please try again and confirm the transaction.","Harvested":"Harvested","Close Window":"Close Window","Insufficient %symbol% balance":"Insufficient %symbol% balance","You’ll need %symbol% to stake in this pool!":"You’ll need %symbol% to stake in this pool!","Buy some %symbol%, or make sure your %symbol% isn’t in another pool or LP.":"Buy some %symbol%, or make sure your %symbol% isn’t in another pool or LP.","Buy":"Buy","Locate Assets":"Locate Assets","%symbol% required":"%symbol% required","Your %symbol% earnings have also been harvested to your wallet!":"Your %symbol% earnings have also been harvested to your wallet!","Your %symbol% funds have been staked in the pool!":"Your %symbol% funds have been staked in the pool!","Max stake for this pool: %amount% %token%":"Max stake for this pool: %amount% %token%","Maximum total stake: %amount% %token%":"Maximum total stake: %amount% %token%","APY includes compounding, APR doesn’t. This pool’s CAKE is compounded automatically, so we show APY.":"APY includes compounding, APR doesn’t. This pool’s CAKE is compounded automatically, so we show APY.","This pool’s rewards aren’t compounded automatically, so we show APR":"This pool’s rewards aren’t compounded automatically, so we show APR","Auto":"Auto","Manual":"Manual","Earn CAKE, stake CAKE":"Earn CAKE, stake CAKE","This bounty is given as a reward for providing a service to other users.":"This bounty is given as a reward for providing a service to other users.","Whenever you successfully claim the bounty, you’re also helping out by activating the Auto CAKE Pool’s compounding function for everyone.":"Whenever you successfully claim the bounty, you’re also helping out by activating the Auto CAKE Pool’s compounding function for everyone.","Auto-Compound Bounty: %fee%% of all Auto CAKE pool users pending yield":"Auto-Compound Bounty: %fee%% of all Auto CAKE pool users pending yield","Bounty collected!":"Bounty collected!","CAKE bounty has been sent to your wallet.":"CAKE bounty has been sent to your wallet.","Could not be collected":"Could not be collected","There may be an issue with your transaction, or another user claimed the bounty first.":"There may be an issue with your transaction, or another user claimed the bounty first.","Claim Bounty":"Claim Bounty","You’ll claim":"You’ll claim","Pool total pending yield":"Pool total pending yield","Bounty":"Bounty","What’s this?":"What’s this?","Help":"Help","Syrup Pools":"Syrup Pools","Best round: #%roundId%":"Best round: #%roundId%","View Reclaimed & Won":"View Reclaimed & Won","This round was automatically canceled due to an error. If you entered a position, please reclaim your funds below.":"This round was automatically canceled due to an error. If you entered a position, please reclaim your funds below.","Round History":"Round History","Your History":"Your History","Filter":"Filter","Starting Soon":"Starting Soon","Live Now":"Live Now","Reclaim":"Reclaim","This page can’t be displayed right now due to an error. Please check back soon.":"This page can’t be displayed right now due to an error. Please check back soon.","Round Canceled":"Round Canceled","Learn More":"Learn More","Payout":"Payout","%position% position entered":"%position% position entered","Enter UP":"Enter UP","Enter DOWN":"Enter DOWN","An error occurred, unable to enter your position":"An error occurred, unable to enter your position","Set Position":"Set Position","Insufficient BNB balance":"Insufficient BNB balance","A minimum amount of %num% %token% is required":"A minimum amount of %num% %token% is required","Enter an amount":"Enter an amount","You won’t be able to remove or change your position once you enter it.":"You won’t be able to remove or change your position once you enter it.","Prize Pool":"Prize Pool","Winnings collected!":"Winnings collected!","Your prizes have been sent to your wallet":"Your prizes have been sent to your wallet","Collecting":"Collecting","Closing":"Closing","Position reclaimed!":"Position reclaimed!","Reclaim Position":"Reclaim Position","This Product is in beta.":"This Product is in beta.","I understand that I am using this product at my own risk. Any losses incurred due to my actions are my own responsibility.":"I understand that I am using this product at my own risk. Any losses incurred due to my actions are my own responsibility.","I understand that this product is still in beta. I am participating at my own risk":"I understand that this product is still in beta. I am participating at my own risk","Continue":"Continue","Points Collected!":"Points Collected!","%num% points":"%num% points","Cost to update:":"Cost to update:","Cost to reactivate:":"Cost to reactivate:","Profile Updated!":"Profile Updated!","Choose a new Collectible to use as your profile pic.":"Choose a new Collectible to use as your profile pic.","Sorry! You don’t have any eligible Collectibles in your wallet to use!":"Sorry! You don’t have any eligible Collectibles in your wallet to use!","Make sure you have a Pancake Collectible in your wallet and try again!":"Make sure you have a Pancake Collectible in your wallet and try again!","Edit Profile":"Edit Profile","Change Profile Pic":"Change Profile Pic","Remove Profile Pic":"Remove Profile Pic","Profile Paused!":"Profile Paused!","This will suspend your profile and send your Collectible back to your wallet":"This will suspend your profile and send your Collectible back to your wallet","While your profile is suspended, you won\'t be able to earn points, but your achievements and points will stay associated with your profile":"While your profile is suspended, you won\'t be able to earn points, but your achievements and points will stay associated with your profile","Cost to reactivate in the future: %cost% CAKE":"Cost to reactivate in the future: %cost% CAKE","%minimum% CAKE required to change profile pic":"%minimum% CAKE required to change profile pic","Reactivate Profile":"Reactivate Profile","No achievements yet!":"No achievements yet!","Claim your Gift!":"Claim your Gift!","Thank you for being a day-one user of Pancake Profiles!":"Thank you for being a day-one user of Pancake Profiles!","If you haven\'t already noticed, we made a mistake and the starter bunny you chose got mixed up and changed into another bunny. Oops!":"If you haven\'t already noticed, we made a mistake and the starter bunny you chose got mixed up and changed into another bunny. Oops!","To make it up to you, we’ll refund you the full 4 CAKE it cost to make your bunny.":"To make it up to you, we’ll refund you the full 4 CAKE it cost to make your bunny.","We’re also preparing an all-new collectible for you to claim (for free!) in the near future.":"We’re also preparing an all-new collectible for you to claim (for free!) in the near future.","Once you claim the refund, you can make another account with another wallet, mint a new bunny, and send it to your main account via the NFT page.":"Once you claim the refund, you can make another account with another wallet, mint a new bunny, and send it to your main account via the NFT page.","Claim Your CAKE":"Claim Your CAKE","Pancake Collectibles":"Pancake Collectibles","Pancake Collectibles are special ERC-721 NFTs that can be used on the PancakeSwap platform.":"Pancake Collectibles are special ERC-721 NFTs that can be used on the PancakeSwap platform.","NFTs in this user’s wallet that aren’t approved Pancake Collectibles won’t be shown here.":"NFTs in this user’s wallet that aren’t approved Pancake Collectibles won’t be shown here.","No NFTs Found":"No NFTs Found","See all approved Pancake Collectibles":"See all approved Pancake Collectibles","Coming Soon!":"Coming Soon!","Profile created!":"Profile created!","Submitting NFT to contract and confirming User Name and Team.":"Submitting NFT to contract and confirming User Name and Team.","Cost":"Cost","Your Profile":"Your Profile","Check your stats and collect achievements":"Check your stats and collect achievements","You’ve got a gift to claim!":"You’ve got a gift to claim!","Show off your stats and collectibles with your unique profile":"Show off your stats and collectibles with your unique profile","Total cost: 1.5 CAKE":"Total cost: 1.5 CAKE","Cost: %num% CAKE":"Cost: %num% CAKE","You can change your profile pic later if you get another approved Pancake Collectible.":"You can change your profile pic later if you get another approved Pancake Collectible.","Every profile starts by making a “starter” collectible (NFT).":"Every profile starts by making a “starter” collectible (NFT).","We couldn’t find any Pancake Collectibles in your wallet.":"We couldn’t find any Pancake Collectibles in your wallet.","You need a Pancake Collectible to finish setting up your profile. If you sold or transferred your starter collectible to another wallet, you’ll need to get it back or acquire a new one somehow. You can’t make a new starter with this wallet address.":"You need a Pancake Collectible to finish setting up your profile. If you sold or transferred your starter collectible to another wallet, you’ll need to get it back or acquire a new one somehow. You can’t make a new starter with this wallet address.","The collectible you\'ve chosen will be locked in a smart contract while it’s being used as your profile picture. Don\'t worry - you\'ll be able to get it back at any time.":"The collectible you\'ve chosen will be locked in a smart contract while it’s being used as your profile picture. Don\'t worry - you\'ll be able to get it back at any time.","It won’t be possible to undo the choice you make for the foreseeable future!":"It won’t be possible to undo the choice you make for the foreseeable future!","There’s currently no big difference between teams, and no benefit of joining one team over another for now. So pick whichever one you like!":"There’s currently no big difference between teams, and no benefit of joining one team over another for now. So pick whichever one you like!","Your name must be at least 3 and at most 15 standard letters and numbers long. You can’t change this once you click Confirm.":"Your name must be at least 3 and at most 15 standard letters and numbers long. You can’t change this once you click Confirm.","Unable to verify username":"Unable to verify username","Created %dateCreated% ago":"Created %dateCreated% ago","Paused":"Paused","April":"April","Easter Battle":"Easter Battle","$120,000 in Prizes!":"$120,000 in Prizes!","Compete with other teams to win CAKE, collectible NFTs, achievements & more!":"Compete with other teams to win CAKE, collectible NFTs, achievements & more!","Now Live!":"Now Live!","Calculating prizes":"Calculating prizes","I want to Battle!":"I want to Battle!","Trade Now":"Trade Now","Claim period over":"Claim period over","Prizes Claimed!":"Prizes Claimed!","Nothing to claim":"Nothing to claim","Registered!":"Registered!","Congratulations! You won":"Congratulations! You won","Collectible NFT":"Collectible NFT","All prizes will be sent directly to your wallet and user account.":"All prizes will be sent directly to your wallet and user account.","How Can I Join?":"How Can I Join?","Set up your":"Set up your","Pancake Profile":"Pancake Profile","then register for the competition by clicking “I WANT TO BATTLE” button above.":"then register for the competition by clicking “I WANT TO BATTLE” button above.","Battle Time":"Battle Time","Trade BNB/BUSD, CAKE/BNB, ETH/BNB and BTCB/BNB during the battle period to raise both your and your team’s score. See the Rules section below for more.":"Trade BNB/BUSD, CAKE/BNB, ETH/BNB and BTCB/BNB during the battle period to raise both your and your team’s score. See the Rules section below for more.","Prize Claim":"Prize Claim","Teams and traders will be ranked in the order of trading volume. Collect your prizes and celebrate!":"Teams and traders will be ranked in the order of trading volume. Collect your prizes and celebrate!","Registration starting April 5":"Registration starting April 5","Tier":"Tier","Token Prizes (Split)":"Token Prizes (Split)","Gold":"Gold","Silver":"Silver","Bronze":"Bronze","Purple":"Purple","Teal":"Teal","#%team% Team":"#%team% Team","Prizes by Team":"Prizes by Team","Higher trading volume = higher rank!":"Higher trading volume = higher rank!","Prizes to be distributed in CAKE and shared by all members of a tier. CAKE price in USD to be determined on the day of distribution. Details below.":"Prizes to be distributed in CAKE and shared by all members of a tier. CAKE price in USD to be determined on the day of distribution. Details below.","Every eligible participant will win prizes at the end of the competition.":"Every eligible participant will win prizes at the end of the competition.","The better your team performs, the better prizes you will get!":"The better your team performs, the better prizes you will get!","The final winning team will be the team with the highest total volume score at the end of the competition period.":"The final winning team will be the team with the highest total volume score at the end of the competition period.","Make a profile!":"Make a profile!","It looks like you’ve disabled your account by removing your Pancake Collectible (NFT) profile picture.":"It looks like you’ve disabled your account by removing your Pancake Collectible (NFT) profile picture.","Reactivate your profile!":"Reactivate your profile!","You need to reactivate your profile by replacing your profile picture in order to join the competition.":"You need to reactivate your profile by replacing your profile picture in order to join the competition.","Go to my profile":"Go to my profile","You have registered for the competition!":"You have registered for the competition!","Registering for the competition will make your wallet address publicly visible on the leaderboard.":"Registering for the competition will make your wallet address publicly visible on the leaderboard.","This decision cannot be reversed.":"This decision cannot be reversed.","I understand that my address may be displayed publicly throughout the competition.":"I understand that my address may be displayed publicly throughout the competition.","Eligible trading pairs":"Eligible trading pairs","Only trades on SANTOS/BNB, PORTO/BNB, LAZIO/BNB, SANTOS/BUSD, PORTO/BUSD, LAZIO/BUSD, CAKE/BNB and CAKE/BUSD pairs will be included in volume calculations.":"Only trades on SANTOS/BNB, PORTO/BNB, LAZIO/BNB, SANTOS/BUSD, PORTO/BUSD, LAZIO/BUSD, CAKE/BNB and CAKE/BUSD pairs will be included in volume calculations.","Calculating team ranks and winners":"Calculating team ranks and winners","Team ranks are calculated by the total combined volume of the top 500 members of each respective team.":"Team ranks are calculated by the total combined volume of the top 500 members of each respective team.","Prize distribution":"Prize distribution","Prizes to be distributed in CAKE, LAZIO, PORTO and SANTOS in a distribution of 3:1:1:1 and shared by all members of each respective tier.":"Prizes to be distributed in CAKE, LAZIO, PORTO and SANTOS in a distribution of 3:1:1:1 and shared by all members of each respective tier.","The price of token prizes (CAKE, LAZIO, PORTO and SANTOS) in USD will be determined as per their BUSD pair price during the tally period.":"The price of token prizes (CAKE, LAZIO, PORTO and SANTOS) in USD will be determined as per their BUSD pair price during the tally period.","Every participant will win at least one prize at the end of the competition.":"Every participant will win at least one prize at the end of the competition.","Fine print":"Fine print","In the event of a disagreement concerning the final winning team or rank, PancakeSwap will have the final say.":"In the event of a disagreement concerning the final winning team or rank, PancakeSwap will have the final say.","PancakeSwap can and will disqualify any team or specific members that are proven to have taken malicious action or attempt to “cheat” in any way.":"PancakeSwap can and will disqualify any team or specific members that are proven to have taken malicious action or attempt to “cheat” in any way.","Can I join the battle after it starts?":"Can I join the battle after it starts?","Sorry, no. You need to register during the registration period, before the start of the event.":"Sorry, no. You need to register during the registration period, before the start of the event.","How do I know if I successfully registered?":"How do I know if I successfully registered?","At the top of the page, the text in the button “I Want to Battle” will change to “Registered”.":"At the top of the page, the text in the button “I Want to Battle” will change to “Registered”.","How can I see my current rank?":"How can I see my current rank?","Check Your Score section on the event page. You’ll need to connect your wallet, of course.":"Check Your Score section on the event page. You’ll need to connect your wallet, of course.","How do I claim my prize(s)?":"How do I claim my prize(s)?","After the battle ends, visit the event page and click the “Claim Prizes” button in the top section or in “Your Score” section. Once you claim your prizes successfully, the button text will change to “Prizes Claimed”.":"After the battle ends, visit the event page and click the “Claim Prizes” button in the top section or in “Your Score” section. Once you claim your prizes successfully, the button text will change to “Prizes Claimed”.","Trade to increase your rank":"Trade to increase your rank","Eligible pairs: SANTOS/BNB, PORTO/BNB, LAZIO/BNB, SANTOS/BUSD, PORTO/BUSD, LAZIO/BUSD, CAKE/BNB and CAKE/BUSD":"Eligible pairs: SANTOS/BNB, PORTO/BNB, LAZIO/BNB, SANTOS/BUSD, PORTO/BUSD, LAZIO/BUSD, CAKE/BNB and CAKE/BUSD","Play as a team":"Play as a team","The higher your team’s rank, the better your prizes":"The higher your team’s rank, the better your prizes","Top Traders":"Top Traders","Since start of the competition":"Since start of the competition","Show More":"Show More","Share Score":"Share Score","Your tier: gold":"Your tier: gold","Love, The Chefs x":"Love, The Chefs x","HECK YEAH!":"HECK YEAH!","Next tier":"Next tier","to become #%rank% in team":"to become #%rank% in team","#%global% Overall":"#%global% Overall","Token Prizes":"Token Prizes","Share Your Score":"Share Your Score","Brag to your friends and annoy your rivals with your custom scorecard!":"Brag to your friends and annoy your rivals with your custom scorecard!","Download Image":"Download Image","Screenshot or press & hold the image to share!":"Screenshot or press & hold the image to share!","Block %num%":"Block %num%","%max% %symbol% Available":"%max% %symbol% Available","Profile Pic":"Profile Pic","Transfer":"Transfer","Congratulations!":"Congratulations!","You won a collectible!":"You won a collectible!","Claim now":"Claim now","Claiming...":"Claiming...","NFT in wallet":"NFT in wallet","Trade in your NFT for CAKE, or just keep it for your collection.":"Trade in your NFT for CAKE, or just keep it for your collection.","No NFTs to claim":"No NFTs to claim","You have no NFTs to claim at this time, but you can still see the NFTs in this series below.":"You have no NFTs to claim at this time, but you can still see the NFTs in this series below.","Please wait...":"Please wait...","The claiming period hasn’t started yet. Check back soon.":"The claiming period hasn’t started yet. Check back soon.","Please enter a valid wallet address":"Please enter a valid wallet address","Unable to transfer NFT":"Unable to transfer NFT","Transfer NFT":"Transfer NFT","Transferring":"Transferring","Receiving address":"Receiving address","Paste address":"Paste address","Could not retrieve CAKE costs for profile":"Could not retrieve CAKE costs for profile","An error occurred approving transaction":"An error occurred approving transaction","Provider Error":"Provider Error","No provider was found":"No provider was found","Authorization Error":"Authorization Error","Please authorize to access your account":"Please authorize to access your account","Unable to find connector":"Unable to find connector","The connector config is wrong":"The connector config is wrong","You have contributed %amount% CAKE to this IFO!":"You have contributed %amount% CAKE to this IFO!","You’ll need CAKE tokens to participate in the IFO!":"You’ll need CAKE tokens to participate in the IFO!","Your %symbol% committed":"Your %symbol% committed","Your %symbol% RECLAIMED":"Your %symbol% RECLAIMED","Your %symbol% TO RECLAIM":"Your %symbol% TO RECLAIM","%symbol% received":"%symbol% received","%symbol% to receive":"%symbol% to receive","Stories were told, and songs were sung about Chef Mixie’s pancakes and her big Syrup gun.":"Stories were told, and songs were sung about Chef Mixie’s pancakes and her big Syrup gun.","Eggscellent! Celebrating Syrup Storm winning the Easter Battle!":"Eggscellent! Celebrating Syrup Storm winning the Easter Battle!","Melting Easter eggs and melting hearts!":"Melting Easter eggs and melting hearts!","Watch out for Flipsie’s spatula smash!":"Watch out for Flipsie’s spatula smash!","Do you like chocolate with your syrup? Go long!":"Do you like chocolate with your syrup? Go long!","Happy Niu Year! This bunny’s excited for the year of the bull (market!)":"Happy Niu Year! This bunny’s excited for the year of the bull (market!)","Oopsie daisy! Hiccup\'s had a bit of an accident. Poor little fella.":"Oopsie daisy! Hiccup\'s had a bit of an accident. Poor little fella.","Aww, looks like eating pancakes all day is not easy. Sweet dreams!":"Aww, looks like eating pancakes all day is not easy. Sweet dreams!","Sunny is always cheerful when there are pancakes around. Smile!":"Sunny is always cheerful when there are pancakes around. Smile!","Don\'t let that dopey smile deceive you... Churro\'s a master CAKE chef!":"Don\'t let that dopey smile deceive you... Churro\'s a master CAKE chef!","Nommm... Oh hi, I\'m just meditating on the meaning of CAKE.":"Nommm... Oh hi, I\'m just meditating on the meaning of CAKE.","Three guesses what\'s put that twinkle in those eyes! (Hint: it\'s CAKE)":"Three guesses what\'s put that twinkle in those eyes! (Hint: it\'s CAKE)","These bunnies love nothing more than swapping pancakes. Especially on BSC.":"These bunnies love nothing more than swapping pancakes. Especially on BSC.","It\'s raining syrup on this bunny, but he doesn\'t seem to mind. Can you blame him?":"It\'s raining syrup on this bunny, but he doesn\'t seem to mind. Can you blame him?","These bunnies like their pancakes with blueberries. What\'s your favorite topping?":"These bunnies like their pancakes with blueberries. What\'s your favorite topping?","Love makes the world go \'round... but so do pancakes. And these bunnies know it.":"Love makes the world go \'round... but so do pancakes. And these bunnies know it.","It’s sparkling syrup, pancakes, and even lottery tickets! This bunny really loves it.":"It’s sparkling syrup, pancakes, and even lottery tickets! This bunny really loves it.","The storm\'s a-comin! Watch out! These bulls are stampeding in a syrupy surge!":"The storm\'s a-comin! Watch out! These bulls are stampeding in a syrupy surge!","The flippening is coming. Don\'t get in these bunnies\' way, or you\'ll get flipped, too!":"The flippening is coming. Don\'t get in these bunnies\' way, or you\'ll get flipped, too!","Can you stand the heat? Stay out of the kitchen or you might get burned to a crisp!":"Can you stand the heat? Stay out of the kitchen or you might get burned to a crisp!","%ratio%% of total sale":"%ratio%% of total sale","Your %symbol% earnings have been sent to your wallet!":"Your %symbol% earnings have been sent to your wallet!","Your %symbol% earnings have been re-invested into the pool!":"Your %symbol% earnings have been re-invested into the pool!","Stake %symbol%":"Stake %symbol%","You must harvest and compound your earnings from this pool manually.":"You must harvest and compound your earnings from this pool manually.","Register":"Register","Contribute %symbol%":"Contribute %symbol%","Volume":"Volume","%symbol% per $1,000":"%symbol% per $1,000","Prediction (BETA)":"Prediction (BETA)","Collectibles":"Collectibles","Team Battle":"Team Battle","Teams & Profile":"Teams & Profile","Leaderboard":"Leaderboard","Tokens":"Tokens","Contact":"Contact","Merch":"Merch","LP Migration":"LP Migration","V1 Liquidity (Old)":"V1 Liquidity (Old)","Claim Collectible":"Claim Collectible","The higher your team’s rank, the better your prizes!":"The higher your team’s rank, the better your prizes!","Get Ready":"Get Ready","Earn up to %highestApr% APR in Farms":"Earn up to %highestApr% APR in Farms","Earn %assets% in Pools":"Earn %assets% in Pools","Activate PancakeSwap Profile to take part in next IFO‘s!":"Activate PancakeSwap Profile to take part in next IFO‘s!","Trading Battle":"Trading Battle","Prediction":"Prediction","Initial Farm Offering":"Initial Farm Offering","An error occurred confirming transaction":"An error occurred confirming transaction","Successfully Enabled!":"Successfully Enabled!","You can now participate in the %symbol% IFO.":"You can now participate in the %symbol% IFO.","Team Ranks":"Team Ranks","Prizes":"Prizes","Rules":"Rules","Entry":"Entry","Enable pool":"Enable pool","Start staking":"Start staking","Search Pools":"Search Pools","Ends in":"Ends in","Starts in":"Starts in","Total amount of %symbol% staked in this pool":"Total amount of %symbol% staked in this pool","These pools are no longer distributing rewards. Please unstake your tokens.":"These pools are no longer distributing rewards. Please unstake your tokens.","Max. stake per user":"Max. stake per user","You have claimed your rewards!":"You have claimed your rewards!","Already Collected":"Already Collected","Predictions Now Live":"Predictions Now Live","Beta Version":"Beta Version","Over %amount% in BNB won so far":"Over %amount% in BNB won so far","Try Now":"Try Now","New":"New","LP rewards: 0.17% trading fees, distributed proportionally among LP token holders.":"LP rewards: 0.17% trading fees, distributed proportionally among LP token holders.","CAKE + Fees":"CAKE + Fees","Prediction Markets":"Prediction Markets","Now Live":"Now Live","in Beta":"in Beta","Ended %date%":"Ended %date%","Starts %date%":"Starts %date%","Ends %date%":"Ends %date%","Closed":"Closed","Vote Now":"Vote Now","Soon":"Soon","No proposals found":"No proposals found","Creator":"Creator","Proposals":"Proposals","Make a Proposal":"Make a Proposal","Have your say in the future of the PancakeSwap Ecosystem":"Have your say in the future of the PancakeSwap Ecosystem","Got a suggestion?":"Got a suggestion?","Community proposals are a great way to see how the community feels about your ideas.":"Community proposals are a great way to see how the community feels about your ideas.","They won\'t necessarily be implemented if the community votes successful, but suggestions with a lot of community support may be made into Core proposals.":"They won\'t necessarily be implemented if the community votes successful, but suggestions with a lot of community support may be made into Core proposals.","%field% is required":"%field% is required","Please create a minimum of %num% choices":"Please create a minimum of %num% choices","Choices must not be empty":"Choices must not be empty","Please select a valid date":"Please select a valid date","Please select a valid time":"Please select a valid time","End date must be after the start date":"End date must be after the start date","Invalid snapshot":"Invalid snapshot","Proposal created!":"Proposal created!","Voted":"Voted","Time":"Time","Input choice text":"Input choice text","Start Time":"Start Time","Back to Vote Overview":"Back to Vote Overview","Voting For":"Voting For","Your Voting Power":"Your Voting Power","Confirm Vote":"Confirm Vote","Add Choice":"Add Choice","Title":"Title","Content":"Content","End Date":"End Date","Start Date":"Start Date","Actions":"Actions","End Time":"End Time","Publish":"Publish","No votes found":"No votes found","Vote Weight":"Vote Weight","Decision":"Decision","Voter":"Voter","Votes (%count%)":"Votes (%count%)","Snapshot":"Snapshot","Choices":"Choices","Unable to sign payload":"Unable to sign payload","Identifier":"Identifier","Current Results":"Current Results","Vote cast!":"Vote cast!","Are you sure you want to vote for the above choice? This action cannot be undone.":"Are you sure you want to vote for the above choice? This action cannot be undone.","Tip: write in Markdown!":"Tip: write in Markdown!","Cast your vote":"Cast your vote","Preview":"Preview","%total% Votes":"%total% Votes","Cast Vote":"Cast Vote","See All":"See All","Your voting power is determined by the amount of CAKE you held at the block detailed below. CAKE held in other places does not contribute to your voting power.":"Your voting power is determined by the amount of CAKE you held at the block detailed below. CAKE held in other places does not contribute to your voting power.","Your Cake Held Now":"Your Cake Held Now","Wallet":"Wallet","Manual CAKE Pool":"Manual CAKE Pool","Auto CAKE Pool":"Auto CAKE Pool","CAKE BNB LP":"CAKE BNB LP","Other Syrup Pools":"Other Syrup Pools","Voting Power":"Voting Power","You need at least %count% voting power to publish a proposal.":"You need at least %count% voting power to publish a proposal.","Check voting power":"Check voting power","Amount to collect":"Amount to collect","Your winnings":"Your winnings","Includes your original position and your winnings, minus the %fee% fee.":"Includes your original position and your winnings, minus the %fee% fee.","Your funds have been staked in the farm":"Your funds have been staked in the farm","Base APR (CAKE yield only)":"Base APR (CAKE yield only)","View/Edit Numbers":"View/Edit Numbers","Edit Numbers":"Edit Numbers","Total cost":"Total cost","Numbers are randomized, with no duplicates among your tickets. Tap a number to edit it. Available digits: 0-9":"Numbers are randomized, with no duplicates among your tickets. Tap a number to edit it. Available digits: 0-9","Randomize":"Randomize","Confirm and buy":"Confirm and buy","Go back":"Go back","Duplicate":"Duplicate","Get your tickets now!":"Get your tickets now!","Finished Rounds":"Finished Rounds","Only showing data for Lottery V2":"Only showing data for Lottery V2","Connect your wallet":"Connect your wallet","to check if you\'ve won":"to check if you\'ve won","No prizes to collect":"No prizes to collect","Better luck next time!":"Better luck next time!","Why not play again":"Why not play again","Are you a winner?":"Are you a winner?","Checking":"Checking","Check Now":"Check Now","On sale soon!":"On sale soon!","Date":"Date","Your Tickets":"Your Tickets","in prizes!":"in prizes!","Tickets on sale soon":"Tickets on sale soon","The PancakeSwap Lottery":"The PancakeSwap Lottery","All History":"All History","Winning Number":"Winning Number","tickets":"tickets","Prize pot":"Prize pot","Total players this round":"Total players this round","Draw":"Draw","Next Draw":"Next Draw","Your tickets":"Your tickets","Match the winning number in the same order to share prizes.":"Match the winning number in the same order to share prizes.","Current prizes up for grabs:":"Current prizes up for grabs:","Burn":"Burn","Match all %numberMatch%":"Match all %numberMatch%","Match first %numberMatch%":"Match first %numberMatch%","Matched first":"Matched first","Drawn":"Drawn","Connect your wallet to check your history":"Connect your wallet to check your history","Buy tickets for the next round!":"Buy tickets for the next round!","No lottery history found":"No lottery history found","Contract enabled - you can now purchase tickets":"Contract enabled - you can now purchase tickets","Lottery tickets purchased!":"Lottery tickets purchased!","The maximum number of tickets you can buy in one transaction is %maxTickets%":"The maximum number of tickets you can buy in one transaction is %maxTickets%","Bulk discount":"Bulk discount","Buy Instantly":"Buy Instantly","\\"Buy Instantly\\" chooses random numbers, with no duplicates among your tickets. Prices are set before each round starts, equal to $5 at that time. Purchases are final.":"\\"Buy Instantly\\" chooses random numbers, with no duplicates among your tickets. Prices are set before each round starts, equal to $5 at that time. Purchases are final.","Prizes Collected!":"Prizes Collected!","Your CAKE prizes for round %lotteryId% have been sent to your wallet":"Your CAKE prizes for round %lotteryId% have been sent to your wallet","Claim %claimNum% of %claimTotal% for round %lotteryId% was successful. Please confirm the next transaction":"Claim %claimNum% of %claimTotal% for round %lotteryId% was successful. Please confirm the next transaction","Claiming":"Claiming","Tickets must match the winning number in the exact same order, starting from the first digit.":"Tickets must match the winning number in the exact same order, starting from the first digit.","If the winning number is “123456”:":"If the winning number is “123456”:","“120000” matches the first 2 digits.":"“120000” matches the first 2 digits.","“000006” matches the last digit, but since the first five digits are wrong, it doesn’t win any prizes.":"“000006” matches the last digit, but since the first five digits are wrong, it doesn’t win any prizes.","Winning number":"Winning number","Total tickets":"Total tickets","Winning tickets":"Winning tickets","until the draw":"until the draw","Winners announced in":"Winners announced in","Tickets on sale in":"Tickets on sale in","to check if you\'ve won!":"to check if you\'ve won!","Why didn\'t I win?":"Why didn\'t I win?","How to Play":"How to Play","If the digits on your tickets match the winning numbers in the correct order, you win a portion of the prize pool.":"If the digits on your tickets match the winning numbers in the correct order, you win a portion of the prize pool.","Simple!":"Simple!","Prices are set when the round starts, equal to 5 USD in CAKE per ticket.":"Prices are set when the round starts, equal to 5 USD in CAKE per ticket.","Wait for the Draw":"Wait for the Draw","There are two draws every day: one every 12 hours.":"There are two draws every day: one every 12 hours.","Check for Prizes":"Check for Prizes","Once the round’s over, come back to the page and check to see if you’ve won!":"Once the round’s over, come back to the page and check to see if you’ve won!","Step %number%":"Step %number%","Winning Criteria":"Winning Criteria","The digits on your ticket must match in the correct order to win.":"The digits on your ticket must match in the correct order to win.","Here’s an example lottery draw, with two tickets, A and B.":"Here’s an example lottery draw, with two tickets, A and B.","Ticket A: The first 3 digits and the last 2 digits match, but the 4th digit is wrong, so this ticket only wins a “Match first 3” prize.":"Ticket A: The first 3 digits and the last 2 digits match, but the 4th digit is wrong, so this ticket only wins a “Match first 3” prize.","A":"A","Ticket B: Even though the last 5 digits match, the first digit is wrong, so this ticket doesn’t win a prize.":"Ticket B: Even though the last 5 digits match, the first digit is wrong, so this ticket doesn’t win a prize.","B":"B","Prize Funds":"Prize Funds","The prizes for each lottery round come from three sources:":"The prizes for each lottery round come from three sources:","Ticket Purchases":"Ticket Purchases","100% of the CAKE paid by people buying tickets that round goes back into the prize pools.":"100% of the CAKE paid by people buying tickets that round goes back into the prize pools.","Rollover Prizes":"Rollover Prizes","After every round, if nobody wins in one of the prize brackets, the unclaimed CAKE for that bracket rolls over into the next round and are redistributed among the prize pools.":"After every round, if nobody wins in one of the prize brackets, the unclaimed CAKE for that bracket rolls over into the next round and are redistributed among the prize pools.","CAKE Injections":"CAKE Injections","An average total of 35,000 CAKE from the treasury is added to lottery rounds over the course of a week. This CAKE is of course also included in rollovers! Read more in our guide to ":"An average total of 35,000 CAKE from the treasury is added to lottery rounds over the course of a week. This CAKE is of course also included in rollovers! Read more in our guide to ","CAKE Tokenomics":"CAKE Tokenomics","Digits matched":"Digits matched","Prize pool allocation":"Prize pool allocation","Matches first %digits%":"Matches first %digits%","Matches all 6":"Matches all 6","Burn Pool":"Burn Pool","Still got questions?":"Still got questions?","Check our in-depth guide on":"Check our in-depth guide on","how to play the PancakeSwap lottery!":"how to play the PancakeSwap lottery!","Prize brackets don’t ‘stack’: if you match the first 3 digits in order, you’ll only win prizes from the ‘Match 3’ bracket, and not from ‘Match 1’ and ‘Match 2’.":"Prize brackets don’t ‘stack’: if you match the first 3 digits in order, you’ll only win prizes from the ‘Match 3’ bracket, and not from ‘Match 1’ and ‘Match 2’.","Coming soon!":"Coming soon!","Tickets":"Tickets","Edit numbers":"Edit numbers","each":"each","Collect Prizes":"Collect Prizes","You won":"You won","Calculating rewards":"Calculating rewards","Buying multiple tickets in a single transaction gives a discount. The discount increases in a linear way, up to the maximum of 100 tickets:":"Buying multiple tickets in a single transaction gives a discount. The discount increases in a linear way, up to the maximum of 100 tickets:","2 tickets: 0.05%":"2 tickets: 0.05%","50 tickets: 2.45%":"50 tickets: 2.45%","100 tickets: 4.95%":"100 tickets: 4.95%","You pay":"You pay","Lottery Now Live":"Lottery Now Live","Play Now":"Play Now","Over %amount% in Prizes!":"Over %amount% in Prizes!","Next Auction":"Next Auction","Auction Schedule":"Auction Schedule","%numHours% hours":"%numHours% hours","To be announced":"To be announced","Auction Leaderboard":"Auction Leaderboard","How does it work?":"How does it work?","Step 1: Submit application":"Step 1: Submit application","Projects can submit an application to sponsor a yield farm and/or pool on PancakeSwap via the ":"Projects can submit an application to sponsor a yield farm and/or pool on PancakeSwap via the ","Application Form":"Application Form","Step 2: Await whitelisting":"Step 2: Await whitelisting","The PancakeSwap team will try to respond within a week.":"The PancakeSwap team will try to respond within a week.","Community Farm qualifiers will be asked to provide the address of the wallet which you’ll use for bidding CAKE in the auction.":"Community Farm qualifiers will be asked to provide the address of the wallet which you’ll use for bidding CAKE in the auction.","Core Farm/Pool qualifiers will receive further directions separately.":"Core Farm/Pool qualifiers will receive further directions separately.","Step 3: During the auction":"Step 3: During the auction","During the auction period, if you connect your project’s whitelisted wallet to the Auction page, you’ll see a “Place Bid” button during when the auction is live.":"During the auction period, if you connect your project’s whitelisted wallet to the Auction page, you’ll see a “Place Bid” button during when the auction is live.","You can then commit CAKE to bid during the auction, competing against other project for one of the available farms.":"You can then commit CAKE to bid during the auction, competing against other project for one of the available farms.","Step 4: After the auction":"Step 4: After the auction","If your bid was not successful, you can reclaim your CAKE on this page.":"If your bid was not successful, you can reclaim your CAKE on this page.","If your bid was successful, your farm will begin at the specified time. The CAKE you bid will not be returned to you and will be added to our weekly CAKE burn.":"If your bid was successful, your farm will begin at the specified time. The CAKE you bid will not be returned to you and will be added to our weekly CAKE burn.","So long as you are whitelisted, you’ll be able to participate in each new auction.":"So long as you are whitelisted, you’ll be able to participate in each new auction.","If two or more projects bid the exact same CAKE amount and are contending for a spot in the winning bidders, their bids may be invalidated.":"If two or more projects bid the exact same CAKE amount and are contending for a spot in the winning bidders, their bids may be invalidated.","Community Farm Auction":"Community Farm Auction","Each week, qualifying projects can bid CAKE for the right to host a 7-day Farm on PancakeSwap.":"Each week, qualifying projects can bid CAKE for the right to host a 7-day Farm on PancakeSwap.","Apply for a Farm/Pool":"Apply for a Farm/Pool","Community Auctions":"Community Auctions","FAQs":"FAQs","Auction duration":"Auction duration","Terms & Conditions":"Terms & Conditions","in Prizes!":"in Prizes!","Output is estimated. If the price changes by more than %slippage%% your transaction will revert.":"Output is estimated. If the price changes by more than %slippage%% your transaction will revert.","Supplying %amountA% %symbolA% and %amountB% %symbolB%":"Supplying %amountA% %symbolA% and %amountB% %symbolB%","Removing %amountA% %symbolA% and %amountB% %symbolB%":"Removing %amountA% %symbolA% and %amountB% %symbolB%","Swapping %amountA% %symbolA% for %amountB% %symbolB%":"Swapping %amountA% %symbolA% for %amountB% %symbolB%","Add Liquidity":"Add Liquidity","Add liquidity to receive LP tokens":"Add liquidity to receive LP tokens","Liquidity providers earn a 0.17% trading fee on all trades made for that token pair, proportional to their share of the liquidity pool.":"Liquidity providers earn a 0.17% trading fee on all trades made for that token pair, proportional to their share of the liquidity pool.","You are creating a pool":"You are creating a pool","You are the first liquidity provider.":"You are the first liquidity provider.","The ratio of tokens you add will set the price of this pool.":"The ratio of tokens you add will set the price of this pool.","Once you are happy with the rate click supply to review.":"Once you are happy with the rate click supply to review.","Initial prices and pool share":"Initial prices and pool share","Prices and pool share":"Prices and pool share","Unsupported Asset":"Unsupported Asset","Enabling %asset%":"Enabling %asset%","Enable %asset%":"Enable %asset%","Share of Pool":"Share of Pool","%assetA% per %assetB%":"%assetA% per %assetB%","%asset% Deposited":"%asset% Deposited","Rates":"Rates","Create Pool & Supply":"Create Pool & Supply","Confirm Supply":"Confirm Supply","Confirm Swap":"Confirm Swap","Connect to a wallet to view your liquidity.":"Connect to a wallet to view your liquidity.","Connect to a wallet to find pools":"Connect to a wallet to find pools","Select a token to find your liquidity.":"Select a token to find your liquidity.","No liquidity found.":"No liquidity found.","Don\'t see a pool you joined?":"Don\'t see a pool you joined?","Find other LP tokens":"Find other LP tokens","Import Pool":"Import Pool","Import an existing pool":"Import an existing pool","Select a Token":"Select a Token","Pool Found!":"Pool Found!","No pool found.":"No pool found.","Create pool.":"Create pool.","Manage this pool.":"Manage this pool.","Invalid pair.":"Invalid pair.","You don’t have liquidity in this pool yet.":"You don’t have liquidity in this pool yet.","%assetA%/%assetB% Burned":"%assetA%/%assetB% Burned","Price":"Price","Prices":"Prices","Remove %assetA%-%assetB% liquidity":"Remove %assetA%-%assetB% liquidity","Amount":"Amount","Simple":"Simple","Detailed":"Detailed","Receive WBNB":"Receive WBNB","Receive BNB":"Receive BNB","Remove":"Remove","Input":"Input","Output":"Output","Trade tokens in an instant":"Trade tokens in an instant","From (estimated)":"From (estimated)","From":"From","To (estimated)":"To (estimated)","To":"To","+ Add a send (optional)":"+ Add a send (optional)","- Remove send":"- Remove send","Slippage Tolerance":"Slippage Tolerance","Insufficient liquidity for this trade.":"Insufficient liquidity for this trade.","Try enabling multi-hop trades.":"Try enabling multi-hop trades.","Price Impact High":"Price Impact High","Swap":"Swap","Swap Anyway":"Swap Anyway","Recent Transactions":"Recent Transactions","clear all":"clear all","Clear all":"Clear all","No recent transactions":"No recent transactions","Are you sure?":"Are you sure?","Expert mode turns off the \'Confirm\' transaction prompt, and allows high slippage trades that often result in bad rates and lost funds.":"Expert mode turns off the \'Confirm\' transaction prompt, and allows high slippage trades that often result in bad rates and lost funds.","Only use this mode if you know what you’re doing.":"Only use this mode if you know what you’re doing.","Turn On Expert Mode":"Turn On Expert Mode","Disable Multihops":"Disable Multihops","Restricts swaps to direct pairs only.":"Restricts swaps to direct pairs only.","Enter a valid slippage percentage":"Enter a valid slippage percentage","Your transaction may fail":"Your transaction may fail","Your transaction may be frontrun":"Your transaction may be frontrun","Your transaction will revert if it is pending for more than this long.":"Your transaction will revert if it is pending for more than this long.","minutes":"minutes","Token Amount":"Token Amount","LP tokens in your wallet":"LP tokens in your wallet","Pooled %asset%":"Pooled %asset%","By adding liquidity you\'ll earn 0.17% of all trades on this pair proportional to your share of the pool. Fees are added to the pool, accrue in real time and can be claimed by withdrawing your liquidity.":"By adding liquidity you\'ll earn 0.17% of all trades on this pair proportional to your share of the pool. Fees are added to the pool, accrue in real time and can be claimed by withdrawing your liquidity.","Common bases":"Common bases","These tokens are commonly paired with other tokens.":"These tokens are commonly paired with other tokens.","Expanded results from inactive Token Lists":"Expanded results from inactive Token Lists","Tokens from inactive lists. Import specific tokens below or click \'Manage\' to activate more lists.":"Tokens from inactive lists. Import specific tokens below or click \'Manage\' to activate more lists.","No results found.":"No results found.","Manage":"Manage","Manage Tokens":"Manage Tokens","Import Tokens":"Import Tokens","Import List":"Import List","Import at your own risk":"Import at your own risk","By adding this list you are implicitly trusting that the data is correct. Anyone can create a list, including creating fake versions of existing lists and lists that claim to represent projects that do not have one.":"By adding this list you are implicitly trusting that the data is correct. Anyone can create a list, including creating fake versions of existing lists and lists that claim to represent projects that do not have one.","If you purchase a token from this list, you may not be able to sell it back.":"If you purchase a token from this list, you may not be able to sell it back.","Import":"Import","via":"via","Anyone can create a BEP20 token on BSC with any name, including creating fake versions of existing tokens and tokens that claim to represent projects that do not have a token.":"Anyone can create a BEP20 token on BSC with any name, including creating fake versions of existing tokens and tokens that claim to represent projects that do not have a token.","If you purchase an arbitrary token, you may be unable to sell it back.":"If you purchase an arbitrary token, you may be unable to sell it back.","Unknown Source":"Unknown Source","Lists":"Lists","See":"See","Update list":"Update list","https:// or ipfs:// or ENS name":"https:// or ipfs:// or ENS name","Loaded":"Loaded","Loading":"Loading","Enter valid token address":"Enter valid token address","Custom Token":"Custom Token","Custom Tokens":"Custom Tokens","Unknown Error":"Unknown Error","Select a currency":"Select a currency","Search name or paste address":"Search name or paste address","Add %asset% to Metamask":"Add %asset% to Metamask","Added %asset%":"Added %asset%","Transaction Submitted":"Transaction Submitted","Wallet Address or ENS name":"Wallet Address or ENS name","Recipient":"Recipient","Waiting For Confirmation":"Waiting For Confirmation","Confirm this transaction in your wallet":"Confirm this transaction in your wallet","Dismiss":"Dismiss","Latest":"Latest","Notice for trading %symbol%":"Notice for trading %symbol%","Warning: BONDLY has been compromised. Please remove liquidity until further notice.":"Warning: BONDLY has been compromised. Please remove liquidity until further notice.","Claimed":"Claimed","Settings":"Settings","Transaction deadline":"Transaction deadline","Convert ERC-20 to BEP-20":"Convert ERC-20 to BEP-20","Need help ?":"Need help ?","Select a token":"Select a token","Enter a recipient":"Enter a recipient","Invalid recipient":"Invalid recipient","Supply":"Supply","Your Liquidity":"Your Liquidity","Remove liquidity to receive tokens back":"Remove liquidity to receive tokens back","Trade anything. No registration, no hassle.":"Trade anything. No registration, no hassle.","Trade any token on Binance Smart Chain in seconds, just by connecting your wallet.":"Trade any token on Binance Smart Chain in seconds, just by connecting your wallet.","Learn":"Learn","BNB token":"BNB token","CAKE token":"CAKE token","BTC token":"BTC token","Earn passive income with crypto.":"Earn passive income with crypto.","PancakeSwap makes it easy to make your crypto work for you.":"PancakeSwap makes it easy to make your crypto work for you.","Explore":"Explore","Pie chart":"Pie chart","Stocks chart":"Stocks chart","Folder with cake token":"Folder with cake token","CAKE makes our world go round.":"CAKE makes our world go round.","CAKE token is at the heart of the PancakeSwap ecosystem. Buy it, win it, farm it, spend it, stake it... heck, you can even vote with it!":"CAKE token is at the heart of the PancakeSwap ecosystem. Buy it, win it, farm it, spend it, stake it... heck, you can even vote with it!","Small 3d pancake":"Small 3d pancake","%cakePrizeInUsd% in CAKE prizes this round":"%cakePrizeInUsd% in CAKE prizes this round","Buy tickets with CAKE, win CAKE if your numbers match":"Buy tickets with CAKE, win CAKE if your numbers match","$%bnbWonInUsd% in BNB won so far":"$%bnbWonInUsd% in BNB won so far","Will BNB price rise or fall? guess correctly to win!":"Will BNB price rise or fall? guess correctly to win!","And those users are now entrusting the platform with over $%tvl% in funds.":"And those users are now entrusting the platform with over $%tvl% in funds.","Trusted with billions.":"Trusted with billions.","PancakeSwap has the most users of any decentralized platform, ever.":"PancakeSwap has the most users of any decentralized platform, ever.","Will you join them?":"Will you join them?","$%tvl% staked":"$%tvl% staked","The moon is made of pancakes.":"The moon is made of pancakes.","Trade, earn, and win crypto on the most popular decentralized platform in the galaxy.":"Trade, earn, and win crypto on the most popular decentralized platform in the galaxy.","Lunar bunny":"Lunar bunny","Total supply":"Total supply","Burned to date":"Burned to date","Market cap":"Market cap","Current emissions":"Current emissions","$%marketCap%":"$%marketCap%","%cakeEmissions%/block":"%cakeEmissions%/block","%earningsBusd% to collect from %count% farm":"%earningsBusd% to collect from %count% farm","%earningsBusd% to collect from %count% farms":"%earningsBusd% to collect from %count% farms","%earningsBusd% to collect from %count% farm and CAKE pool":"%earningsBusd% to collect from %count% farm and CAKE pool","%earningsBusd% to collect from %count% farms and CAKE pool":"%earningsBusd% to collect from %count% farms and CAKE pool","%earningsBusd% to collect from CAKE pool":"%earningsBusd% to collect from CAKE pool","%earningsBusd% to collect":"%earningsBusd% to collect","Harvest all":"Harvest all","Start in seconds.":"Start in seconds.","Used by millions.":"Used by millions.","Hi, %userName%!":"Hi, %userName%!","Play":"Play","Connected with %address%":"Connected with %address%","Win millions in prizes":"Win millions in prizes","%users% users":"%users% users","Connect your crypto wallet to start using the app in seconds.":"Connect your crypto wallet to start using the app in seconds.","in the last 30 days":"in the last 30 days","No registration needed.":"No registration needed.","Learn how to start":"Learn how to start","%trades% trades":"%trades% trades","Provably fair, on-chain games.":"Provably fair, on-chain games.","made in the last 30 days":"made in the last 30 days","Win big with PancakeSwap.":"Win big with PancakeSwap.","Copied":"Copied","Make a Profile":"Make a Profile","Your Address":"Your Address","Your Wallet":"Your Wallet","Transactions":"Transactions","BNB Balance Low":"BNB Balance Low","BNB Balance":"BNB Balance","CAKE Balance":"CAKE Balance","You need BNB for transaction fees.":"You need BNB for transaction fees.","Disconnect":"Disconnect","Disconnect Wallet":"Disconnect Wallet","Ending in":"Ending in","Next auction":"Next auction","Contract approved - you can now place your bid!":"Contract approved - you can now place your bid!","Contract approved - you can now reclaim your bid!":"Contract approved - you can now reclaim your bid!","Bid placed!":"Bid placed!","Bid reclaimed!":"Bid reclaimed!","Reclaim Bid":"Reclaim Bid","Place a Bid":"Place a Bid","Reclaim your CAKE now.":"Reclaim your CAKE now.","Your total bid":"Your total bid","Your bid in Auction #%auctionId% was unsuccessful.":"Your bid in Auction #%auctionId% was unsuccessful.","Current Auction":"Current Auction","Farm schedule":"Farm schedule","Farm duration":"Farm duration","%num% days":"%num% days","Only whitelisted project wallets can bid in the auction to create Community Farms.":"Only whitelisted project wallets can bid in the auction to create Community Farms.","Bidding is only possible while the auction is live.":"Bidding is only possible while the auction is live.","If you’re sure your project should be able to bid in this auction, make sure you’re connected with the correct (whitelisted) wallet.":"If you’re sure your project should be able to bid in this auction, make sure you’re connected with the correct (whitelisted) wallet.","Why cant I bid for a farm?":"Why cant I bid for a farm?","Archive":"Archive","Auction #":"Auction #","Auction #%auctionId%":"Auction #%auctionId%","LP Info":"LP Info","Bidder Address":"Bidder Address","Top %num% bidders at the end of the auction will successfully create a community farm.":"Top %num% bidders at the end of the auction will successfully create a community farm.","Position":"Position","CAKE bid":"CAKE bid","Showing top 10 bids only.":"Showing top 10 bids only.","See all whitelisted bidders":"See all whitelisted bidders","Your existing bid":"Your existing bid","Bid a multiple of 10":"Bid a multiple of 10","Bid must be a multiple of 10":"Bid must be a multiple of 10","First bid must be %initialBidAmount% CAKE or more.":"First bid must be %initialBidAmount% CAKE or more.","If your bid is unsuccessful, you’ll be able to reclaim your CAKE after the auction.":"If your bid is unsuccessful, you’ll be able to reclaim your CAKE after the auction.","Notice":"Notice","This page is a functional page, for projects to bid for farms.":"This page is a functional page, for projects to bid for farms.","If you’re not a whitelisted project, you won’t be able to participate, but you can still view the auction bids in real time!":"If you’re not a whitelisted project, you won’t be able to participate, but you can still view the auction bids in real time!","Connect a whitelisted project wallet to participate in Auctions.":"Connect a whitelisted project wallet to participate in Auctions.","Your bid in Auction #%auctionId% was successful.":"Your bid in Auction #%auctionId% was successful.","Your Farm will be launched as follows:":"Your Farm will be launched as follows:","Multiplier per farm":"Multiplier per farm","Total whitelisted bidders":"Total whitelisted bidders","Please specify auction ID":"Please specify auction ID","No history yet":"No history yet","Connected as %projectName%":"Connected as %projectName%","Place bid":"Place bid","Farms available":"Farms available","top %num% bidders":"top %num% bidders","All Whitelisted Project Wallets":"All Whitelisted Project Wallets","Search address or token":"Search address or token","This page is for projects to bid for farms.":"This page is for projects to bid for farms.","If you’re not a whitelisted project, you won’t be able to participate, but you can still view what’s going on!":"If you’re not a whitelisted project, you won’t be able to participate, but you can still view what’s going on!","through community auctions so far!":"through community auctions so far!","%num% Winners":"%num% Winners","%num% Contenders...":"%num% Contenders...","Farm Auctions":"Farm Auctions","auction bunny":"auction bunny","Burnt CAKE":"Burnt CAKE","Stake %stakingSymbol% - Earn %earningSymbol%":"Stake %stakingSymbol% - Earn %earningSymbol%","Top Farms":"Top Farms","Top Syrup Pools":"Top Syrup Pools","Expert Mode":"Expert Mode","Don’t show this again":"Don’t show this again","Global":"Global","Tx deadline (mins)":"Tx deadline (mins)","Flippy sounds":"Flippy sounds","Your transaction will revert if it is left confirming for longer than this time.":"Your transaction will revert if it is left confirming for longer than this time.","Fun sounds to make a truly immersive pancake-flipping trading":"Fun sounds to make a truly immersive pancake-flipping trading","Found unknown key Setting a high slippage tolerance can help transactions succeed, but you may not get such a good price. Use with caution.":"Found unknown key Setting a high slippage tolerance can help transactions succeed, but you may not get such a good price. Use with caution.","Swaps & Liquidity":"Swaps & Liquidity","Setting a high slippage tolerance can help transactions succeed, but you may not get such a good price. Use with caution.":"Setting a high slippage tolerance can help transactions succeed, but you may not get such a good price. Use with caution.","Bypasses confirmation modals and allows high slippage trades. Use at your own risk.":"Bypasses confirmation modals and allows high slippage trades. Use at your own risk.","Fun sounds to make a truly immersive pancake-flipping trading experience":"Fun sounds to make a truly immersive pancake-flipping trading experience","ROI at current rates":"ROI at current rates","Farm Multiplier":"Farm Multiplier","“My Balance” here includes both LP Tokens in your wallet, and LP Tokens already staked in this farm.":"“My Balance” here includes both LP Tokens in your wallet, and LP Tokens already staked in this farm.","“My Balance” here includes both %assetSymbol% in your wallet, and %assetSymbol% already staked in this pool.":"“My Balance” here includes both %assetSymbol% in your wallet, and %assetSymbol% already staked in this pool.","APY (%compoundTimes%x daily compound)":"APY (%compoundTimes%x daily compound)","My Balance":"My Balance","Staked for":"Staked for","Compounding every":"Compounding every","1D":"1D","7D":"7D","14D":"14D","30D":"30D","1Y":"1Y","5Y":"5Y","Annual ROI at current rates":"Annual ROI at current rates","Calling all BSC projects":"Calling all BSC projects","Apply for whitelisting now!":"Apply for whitelisting now!","Default Transaction Speed (GWEI)":"Default Transaction Speed (GWEI)","Adjusts the gas price (transaction fee) for your transaction. Higher GWEI = higher speed = higher fees":"Adjusts the gas price (transaction fee) for your transaction. Higher GWEI = higher speed = higher fees","Standard (%gasPrice%)":"Standard (%gasPrice%)","Fast (%gasPrice%)":"Fast (%gasPrice%)","Instant (%gasPrice%)":"Instant (%gasPrice%)","You won multiple collectibles!":"You won multiple collectibles!","Prices shown on cards and charts are different":"Prices shown on cards and charts are different","The price you see come from difference places":"The price you see come from difference places","Prices on cards come from Chainlink’s verifiable price oracle.":"Prices on cards come from Chainlink’s verifiable price oracle.","Prices on charts come from Binance.com. Chart\'s are provided for your reference only.":"Prices on charts come from Binance.com. Chart\'s are provided for your reference only.","Only the price from Chainlink (shown on the cards) determines the round\'s result.":"Only the price from Chainlink (shown on the cards) determines the round\'s result.","Showing history for Prediction v0.2":"Showing history for Prediction v0.2","Check for unclaimed v0.1 winnings":"Check for unclaimed v0.1 winnings","You have no unclaimed v0.1 prizes.":"You have no unclaimed v0.1 prizes.","Nothing to collect":"Nothing to collect","Download .CSV":"Download .CSV","Download your v0.1 Prediction history below.":"Download your v0.1 Prediction history below.","Nothing to Collect":"Nothing to Collect","From round %round%":"From round %round%","From rounds %rounds%":"From rounds %rounds%","View More":"View More","User":"User","Net Winnings (BNB)":"Net Winnings (BNB)","Win Rate":"Win Rate","Rounds Won":"Rounds Won","Rank By":"Rank By","Net Winnings":"Net Winnings","Total BNB":"Total BNB","%num%m":"%num%m","Rounds Played":"Rounds Played","Winnings (BNB)":"Winnings (BNB)","Direction":"Direction","My Rankings":"My Rankings","View Stats":"View Stats","Last %num% Bets":"Last %num% Bets","Search %subject%":"Search %subject%","Address":"Address","Learn How to Connect":"Learn How to Connect","Haven’t got a crypto wallet yet?":"Haven’t got a crypto wallet yet?","Neither side wins this round":"Neither side wins this round","The Locked Price & Closed Price are exactly the same (within 8 decimals), so neither side wins. All funds entered into UP and DOWN positions will go to the weekly CAKE burn.":"The Locked Price & Closed Price are exactly the same (within 8 decimals), so neither side wins. All funds entered into UP and DOWN positions will go to the weekly CAKE burn.","To Burn":"To Burn","Account":"Account","PancakeSwap Info & Analytics":"PancakeSwap Info & Analytics","Top Tokens":"Top Tokens","Top Pools":"Top Pools","Your Watchlist":"Your Watchlist","Saved pools will appear here":"Saved pools will appear here","All Pools":"All Pools","All Tokens":"All Tokens","Saved tokens will appear here":"Saved tokens will appear here","Transactions 24H":"Transactions 24H","Volume 24H":"Volume 24H","Volume 7D":"Volume 7D","Total Tokens Locked":"Total Tokens Locked","LP reward fees 24H":"LP reward fees 24H","LP reward fees 7D":"LP reward fees 7D","No pool has been created with this token yet. Create one":"No pool has been created with this token yet. Create one","here.":"here.","Price Change":"Price Change","Page %page% of %maxPage%":"Page %page% of %maxPage%","Name":"Name","Swaps":"Swaps","Adds":"Adds","Removes":"Removes","No Transactions":"No Transactions","Action":"Action","Total Value":"Total Value","Add %token0% and %token1%":"Add %token0% and %token1%","Remove %token0% and %token1%":"Remove %token0% and %token1%","Swap %token0% for %token1%":"Swap %token0% for %token1%","Search pools or tokens":"Search pools or tokens","Watchlist":"Watchlist","See more...":"See more...","No results":"No results","Error occurred, please try again":"Error occurred, please try again","LP reward APR":"LP reward APR","out of $%totalFees% total fees":"out of $%totalFees% total fees","24H":"24H","7D performance":"7D performance","Based on last 7 days\' performance. Does not account for impermanent loss":"Based on last 7 days\' performance. Does not account for impermanent loss","View token on CoinMarketCap":"View token on CoinMarketCap","Top Movers":"Top Movers","Loading chart data...":"Loading chart data...","You have %amount% tickets this round":"You have %amount% tickets this round","You have %amount% ticket this round":"You have %amount% ticket this round","You had %amount% tickets this round":"You had %amount% tickets this round","You had %amount% ticket this round":"You had %amount% ticket this round","Remove Liquidity":"Remove Liquidity","Minimum received":"Minimum received","Maximum sold":"Maximum sold","The difference between the market price and estimated price due to trade size.":"The difference between the market price and estimated price due to trade size.","The difference between the market price and your price due to trade size.":"The difference between the market price and your price due to trade size.","Liquidity Provider Fee":"Liquidity Provider Fee","Import Token":"Import Token","Output is estimated. You will receive at least %amount% %symbol% or the transaction will revert.":"Output is estimated. You will receive at least %amount% %symbol% or the transaction will revert.","Input is estimated. You will sell at most %amount% %symbol% or the transaction will revert.":"Input is estimated. You will sell at most %amount% %symbol% or the transaction will revert.","Output will be sent to %recipient%":"Output will be sent to %recipient%","Price Updated":"Price Updated","Accept":"Accept","For each trade a %amount% fee is paid":"For each trade a %amount% fee is paid","%amount% to LP token holders":"%amount% to LP token holders","%amount% to the Treasury":"%amount% to the Treasury","%amount% towards CAKE buyback and burn":"%amount% towards CAKE buyback and burn","Routing through these tokens resulted in the best price for your trade.":"Routing through these tokens resulted in the best price for your trade.","Your transaction will revert if there is a large, unfavorable price movement before it is confirmed.":"Your transaction will revert if there is a large, unfavorable price movement before it is confirmed.","Route":"Route","Price Impact":"Price Impact","This swap has a price impact of at least %amount%%. Please type the word \\"%word%\\" to continue with this swap.":"This swap has a price impact of at least %amount%%. Please type the word \\"%word%\\" to continue with this swap.","This swap has a price impact of at least %amount%%. Please confirm that you would like to continue with this swap.":"This swap has a price impact of at least %amount%%. Please confirm that you would like to continue with this swap.","To receive %assetA% and %assetB%":"To receive %assetA% and %assetB%","Price Impact Too High":"Price Impact Too High","About":"About","Online Store":"Online Store","Customer Support":"Customer Support","Troubleshooting":"Troubleshooting","Guides":"Guides","Developers":"Developers","Documentation":"Documentation","Bug Bounty":"Bug Bounty","Audits":"Audits","Careers":"Careers","Dark mode":"Dark mode","Invalid pair":"Invalid pair","V1 (old)":"V1 (old)","Transaction receipt":"Transaction receipt","You won points for joining PancakeSwap during the first year of our journey!":"You won points for joining PancakeSwap during the first year of our journey!","NFT Collected":"NFT Collected","User profile picture":"User profile picture","User team banner":"User team banner","Items":"Items","Items listed":"Items listed","Lowest (%symbol%)":"Lowest (%symbol%)","Vol. (%symbol%)":"Vol. (%symbol%)","Profile":"Profile","Selling":"Selling","View BscScan for user address":"View BscScan for user address","Back to profile":"Back to profile","Activate Profile":"Activate Profile","Lowest price":"Lowest price","Your price":"Your price","Not on sale":"Not on sale","For Sale (%num%)":"For Sale (%num%)","Owner":"Owner","Contract address":"Contract address","Token id":"Token id","Token ID":"Token ID","Manage Yours":"Manage Yours","Properties":"Properties","Bunny id":"Bunny id","More from this collection":"More from this collection","Apply (%num%)":"Apply (%num%)","Apply":"Apply","Attributes":"Attributes","Min":"Min","Not enough %symbol% to purchase this NFT":"Not enough %symbol% to purchase this NFT","Convert between BNB and WBNB for free":"Convert between BNB and WBNB for free","Convert":"Convert","Checkout":"Checkout","%symbol% in wallet":"%symbol% in wallet","Total payment":"Total payment","Pay with":"Pay with","Please enable WBNB spending in your wallet":"Please enable WBNB spending in your wallet","Please confirm the transaction in your wallet":"Please confirm the transaction in your wallet","Your NFTs":"Your NFTs","Contract approved - you can now buy NFT with WBNB!":"Contract approved - you can now buy NFT with WBNB!","Your NFT has been sent to your wallet":"Your NFT has been sent to your wallet","Transaction Confirmed":"Transaction Confirmed","Activity":"Activity","For sale":"For sale","View Item":"View Item","The NFT will be removed from your wallet and put on sale at this price.":"The NFT will be removed from your wallet and put on sale at this price.","Sales are in WBNB. You can swap WBNB to BNB 1:1 for free with PancakeSwap.":"Sales are in WBNB. You can swap WBNB to BNB 1:1 for free with PancakeSwap.","Enable Listing":"Enable Listing","Please enable your NFT to be sent to the market":"Please enable your NFT to be sent to the market","Contract approved - you can now put your NFT for sale!":"Contract approved - you can now put your NFT for sale!","Adjust Sale Price":"Adjust Sale Price","Set Price":"Set Price","Input New Sale Price":"Input New Sale Price","Your NFT has been listed for sale!":"Your NFT has been listed for sale!","Your NFT listing has been changed.":"Your NFT listing has been changed.","Your NFT has been returned to your wallet":"Your NFT has been returned to your wallet","Removing this NFT from the marketplace will return it to your wallet.":"Removing this NFT from the marketplace will return it to your wallet.","Continue?":"Continue?","Paste BSC address":"Paste BSC address","That’s not a Binance Smart Chain wallet address.":"That’s not a Binance Smart Chain wallet address.","This action will send your NFT to the address you have indicated above. Make sure it’s the correct":"This action will send your NFT to the address you have indicated above. Make sure it’s the correct","This address is the one that is currently connected":"This address is the one that is currently connected","Recently Listed":"Recently Listed","Please progress to the next step.":"Please progress to the next step.","Press \'confirm\' to mint this NFT":"Press \'confirm\' to mint this NFT","You have minted your starter NFT":"You have minted your starter NFT","Go to your profile page to continue.":"Go to your profile page to continue.","Select All":"Select All","Clear":"Clear","Clear All":"Clear All","All Items":"All Items","Sort By":"Sort By","Collections":"Collections","View All":"View All","All Collections":"All Collections","Recently listed":"Recently listed","Hot Collections":"Hot Collections","Remove from Market":"Remove from Market","Lowest price on market":"Lowest price on market","Transfer to New Wallet":"Transfer to New Wallet","Less":"Less","No results found":"No results found","More Collections are on their way!":"More Collections are on their way!","Removing it will suspend your profile, and you won’t be able to earn points, participate in team activities, or be eligible for new NFT drops.":"Removing it will suspend your profile, and you won’t be able to earn points, participate in team activities, or be eligible for new NFT drops.","Traits":"Traits","Trait":"Trait","Count":"Count","Rarity":"Rarity","Lowest":"Lowest","You don’t have any of this item.":"You don’t have any of this item.","You don’t have this item.":"You don’t have this item.","Manage/Sell":"Manage/Sell","NFT Market":"NFT Market","Delisted":"Delisted","No NFTs found":"No NFTs found","Listed":"Listed","Transaction Details":"Transaction Details","Buy and Sell NFTs on Binance Smart Chain":"Buy and Sell NFTs on Binance Smart Chain","Modified":"Modified","From/To":"From/To","Item":"Item","Bought":"Bought","Event":"Event","Sold":"Sold","No NFT market history found":"No NFT market history found","Edit":"Edit","Token ID:":"Token ID:","Token ID: %id%":"Token ID: %id%","When selling NFTs from this collection, a portion of the BNB paid will be diverted before reaching the seller:":"When selling NFTs from this collection, a portion of the BNB paid will be diverted before reaching the seller:","%percentage%% royalties to the collection owner":"%percentage%% royalties to the collection owner","%percentage%% trading fee will be used to buy & burn CAKE":"%percentage%% trading fee will be used to buy & burn CAKE","Sell":"Sell","Set as Profile Pic":"Set as Profile Pic","Allowed price range is between %minPrice% and %maxPrice% WBNB":"Allowed price range is between %minPrice% and %maxPrice% WBNB","Seller pays %percentage%% platform fee on sale":"Seller pays %percentage%% platform fee on sale","Platform fee if sold":"Platform fee if sold","Click to view NFT":"Click to view NFT","Asking price":"Asking price","Please enter a valid address, or connect your wallet to view your profile":"Please enter a valid address, or connect your wallet to view your profile","No items for sale":"No items for sale","Load more":"Load more","Your NFT has been transferred to another wallet":"Your NFT has been transferred to another wallet","Back":"Back","Confirm transaction":"Confirm transaction","Collection":"Collection","Items in the table update every 10 seconds":"Items in the table update every 10 seconds","Pancake Squad":"Pancake Squad","Meet the Artist":"Meet the Artist","Please confirm your transaction in wallet.":"Please confirm your transaction in wallet.","View market":"View market","Mint":"Mint","Max purchased":"Max purchased","Fair, Random, Rare":"Fair, Random, Rare","Activate your profile":"Activate your profile","Sounds great, how can I get one?":"Sounds great, how can I get one?","View the smart contract address on BscScan":"View the smart contract address on BscScan","Your Claim Tickets: ":"Your Claim Tickets: ","Claiming Complete!":"Claiming Complete!","Buy how many?":"Buy how many?","Activate your profile and make sure you have at least the cost of 1 NFT in your wallet to buy a Squad Ticket.":"Activate your profile and make sure you have at least the cost of 1 NFT in your wallet to buy a Squad Ticket.","Sold Out!":"Sold Out!","Follow on Twitter":"Follow on Twitter","Confirming...":"Confirming...","Your Squad (%tokens%)":"Your Squad (%tokens%)","Minting...":"Minting...","Not eligible":"Not eligible","Out of the 10,000 total NFTs in the squad,":"Out of the 10,000 total NFTs in the squad,","You’ll need an active PancakeSwap Profile to buy Minting Tickets and mint a Pancake Squad NFT!":"You’ll need an active PancakeSwap Profile to buy Minting Tickets and mint a Pancake Squad NFT!","The minting period is now over: all 10,000 bunnies have now been minted.":"The minting period is now over: all 10,000 bunnies have now been minted.","View the":"View the","All 10,000 Pancake Squad NFTs have now been minted!":"All 10,000 Pancake Squad NFTs have now been minted!","Mint Cost: %minCost% CAKE each":"Mint Cost: %minCost% CAKE each","Cost per Ticket":"Cost per Ticket","Follow on Instagram":"Follow on Instagram","Please enable CAKE spending in your wallet":"Please enable CAKE spending in your wallet","Mint NFTs (%tickets%)":"Mint NFTs (%tickets%)","490 are available in the pre-sale for owners of Gen 0 Pancake Bunnies (bunnyID 0, 1, 2, 3, 4)":"490 are available in the pre-sale for owners of Gen 0 Pancake Bunnies (bunnyID 0, 1, 2, 3, 4)","Hold CAKE":"Hold CAKE","Head to the NFT Market to buy!":"Head to the NFT Market to buy!","documentation on our site":"documentation on our site","Max per wallet: %maxPerWallet%":"Max per wallet: %maxPerWallet%","Your CAKE Balance":"Your CAKE Balance","Public Sale: Any wallet with an active Pancake Profile can purchase up to 10 Squad Tickets, while stocks last.":"Public Sale: Any wallet with an active Pancake Profile can purchase up to 10 Squad Tickets, while stocks last.","Enabling...":"Enabling...","Gen 0 Pancake Bunnies":"Gen 0 Pancake Bunnies","Each NFT costs CAKE to mint. Remember you also need BNB to cover transaction fees too!":"Each NFT costs CAKE to mint. Remember you also need BNB to cover transaction fees too!","Check the rarity of each NFT’s traits on the":"Check the rarity of each NFT’s traits on the","PancakeSwap’s first official generative NFT collection.":"PancakeSwap’s first official generative NFT collection.","Your remaining limit":"Your remaining limit","During this phase, any wallet holding a Squad Ticket can redeem their ticket to mint a Pancake Squad NFT.":"During this phase, any wallet holding a Squad Ticket can redeem their ticket to mint a Pancake Squad NFT.","120 are reserved by the team for community giveaways, etc;":"120 are reserved by the team for community giveaways, etc;","Buy Squad Tickets":"Buy Squad Tickets","Pancake Squad page in the NFT Market":"Pancake Squad page in the NFT Market","Join the squad.":"Join the squad.","Total Cost":"Total Cost","Buy Minting Tickets":"Buy Minting Tickets","and the remaining NFTs can be minted by anyone with a ":"and the remaining NFTs can be minted by anyone with a ","Buy Squad Tickets, while stocks last. You’ll use them in step 4.":"Buy Squad Tickets, while stocks last. You’ll use them in step 4.","For more details, check the":"For more details, check the","The network may become busy during the sale period. Consider setting a high gas fee (GWEI).":"The network may become busy during the sale period. Consider setting a high gas fee (GWEI).","Pancake Profile!":"Pancake Profile!","Phase Complete!":"Phase Complete!","randomization documentation on our docs site":"randomization documentation on our docs site","All Pancake Squad NFTs are allocated to Minting Ticket holders through a provably-fair system based on ChainLink at the time of minting.":"All Pancake Squad NFTs are allocated to Minting Ticket holders through a provably-fair system based on ChainLink at the time of minting.","Claim Phase":"Claim Phase","by clicking the “Filter” view. The number of bunnies with a specific trait is displayed next to the trait name.":"by clicking the “Filter” view. The number of bunnies with a specific trait is displayed next to the trait name.","During this phase, any wallet holding a Squad Ticket can redeem their ticket to claim a Pancake Squad NFT.":"During this phase, any wallet holding a Squad Ticket can redeem their ticket to claim a Pancake Squad NFT.","Wait for the Reveal":"Wait for the Reveal","It’ll take a few days before your bunny’s image is revealed. Just hold tight and wait for the final image!":"It’ll take a few days before your bunny’s image is revealed. Just hold tight and wait for the final image!","Trading will open before the images are live, but you’ll still be able to check the bunnies’ stats.":"Trading will open before the images are live, but you’ll still be able to check the bunnies’ stats.","Pre-sale: Wallets which held “Gen 0” Pancake Bunnies NFTs (bunnyID 0,1,2,3,4) at a snapshot taken some time between 12 and 2 hours before the presale begins can purchase one Squad Ticket per Gen 0 NFT.":"Pre-sale: Wallets which held “Gen 0” Pancake Bunnies NFTs (bunnyID 0,1,2,3,4) at a snapshot taken some time between 12 and 2 hours before the presale begins can purchase one Squad Ticket per Gen 0 NFT.","Transaction has succeeded!":"Transaction has succeeded!","Gen 0 Pancake Bunnies (bunnyID 0, 1, 2, 3, 4)":"Gen 0 Pancake Bunnies (bunnyID 0, 1, 2, 3, 4)","The birthplace of Cecy is truly unknown":"The birthplace of Cecy is truly unknown","But legend tells us, she was sailing alone":"But legend tells us, she was sailing alone","Beyond the mountains, across the sea":"Beyond the mountains, across the sea","When she found an island, said “this is for me!”":"When she found an island, said “this is for me!”","‘Twas full of rabbits, who caught her attention":"‘Twas full of rabbits, who caught her attention","Making neat stuff beyond her comprehension":"Making neat stuff beyond her comprehension","The bunnies were working in a big ol’ kitchen":"The bunnies were working in a big ol’ kitchen","Cooking hot pancakes for their big ol’ mission:":"Cooking hot pancakes for their big ol’ mission:","To drizzle in syrup and hand them out soon":"To drizzle in syrup and hand them out soon","So that bunnies worldwide may fly to the moon.":"So that bunnies worldwide may fly to the moon.","All Pancake Squad NFTs are allocated to Squad Ticket holders through a provably-fair system based on ChainLink at the time of minting.":"All Pancake Squad NFTs are allocated to Squad Ticket holders through a provably-fair system based on ChainLink at the time of minting.","Coming Oct. 7":"Coming Oct. 7","Presale:":"Presale:","Public Sale:":"Public Sale:","Review":"Review","Not for sale":"Not for sale","This NFT is your profile picture, you must change it to some other NFT if you want to sell this one.":"This NFT is your profile picture, you must change it to some other NFT if you want to sell this one.","Owner information is not available for this item":"Owner information is not available for this item","List for sale":"List for sale","Adjust price":"Adjust price","starts in":"starts in","Presale max purchased":"Presale max purchased","end in":"end in","Insufficient Balance":"Insufficient Balance","Bunnies":"Bunnies","Squad":"Squad","Highest price":"Highest price","10,000 bunnies":"10,000 bunnies","10,000 bunnies.":"10,000 bunnies.","ZERO duplicates.":"ZERO duplicates.","Every Pancake Squad bunny is different.":"Every Pancake Squad bunny is different.","On top of that, there are a very small number of ultra-rare special unique bunnies as well...!":"On top of that, there are a very small number of ultra-rare special unique bunnies as well...!","View in Market":"View in Market","They’re all randomly generated from over 200 different features, with over eight BILLION possible combinations, so that no bunny is ever exactly alike.":"They’re all randomly generated from over 200 different features, with over eight BILLION possible combinations, so that no bunny is ever exactly alike.","View Documentation":"View Documentation","What’s the Smart Contract?":"What’s the Smart Contract?","Redeem Tickets to claim NFTs":"Redeem Tickets to claim NFTs","Are you ready?":"Are you ready?","%remaining% of %total% remaining":"%remaining% of %total% remaining","%remaining% of %total% claimed":"%remaining% of %total% claimed","Presale":"Presale","Ready for Pre-Sale!":"Ready for Pre-Sale!","I can’t see my NFT’s picture!":"I can’t see my NFT’s picture!","Sorry, you can’t claim any NFTs! Better luck next time.":"Sorry, you can’t claim any NFTs! Better luck next time.","You need a profile to participate!":"You need a profile to participate!","Randomizing NFT allocation with Chainlink":"Randomizing NFT allocation with Chainlink","Public Sale":"Public Sale","You’re all set!":"You’re all set!","How many can I mint?":"How many can I mint?","Ready for Public Sale!":"Ready for Public Sale!","The max limit per wallet is 10 NFTs.":"The max limit per wallet is 10 NFTs.","Where do the fees go?":"Where do the fees go?","100% of CAKE spent on Pancake Squad NFTs will be burned as part of our weekly CAKE burn.":"100% of CAKE spent on Pancake Squad NFTs will be burned as part of our weekly CAKE burn.","How are the NFTs randomly distributed?":"How are the NFTs randomly distributed?","What’s the value of each NFT?":"What’s the value of each NFT?","Wait for the reveal! After all 10,000 members of the Pancake Squad have been minted, their images will remain hidden for a few days. Just be patient :)":"Wait for the reveal! After all 10,000 members of the Pancake Squad have been minted, their images will remain hidden for a few days. Just be patient :)","Users holding Gen 0 Pancake Bunny NFTs at the snapshot may also purchase one additional Pancake Squad NFT in the presale for each Pancake Bunny they hold.":"Users holding Gen 0 Pancake Bunny NFTs at the snapshot may also purchase one additional Pancake Squad NFT in the presale for each Pancake Bunny they hold.","For example, if you have 5 Gen 0 bunnies, you can buy 5 minting tickets in the presale, then max. 10 in the public sale.":"For example, if you have 5 Gen 0 bunnies, you can buy 5 minting tickets in the presale, then max. 10 in the public sale.","Once all 10,000 Squad Tickets have been bought, Chainlink VRF will be used to randomly allocate the pre-generated NFTs to the purchased Tickets. Squad Tickets are allocated IDs numbered in order of their purchase.":"Once all 10,000 Squad Tickets have been bought, Chainlink VRF will be used to randomly allocate the pre-generated NFTs to the purchased Tickets. Squad Tickets are allocated IDs numbered in order of their purchase.","Once all 10,000 have been sold, VRF will pick numbers from 0 to 9999, which will be used to shift the Squad Ticket ID. This will ensure that the distribution of rare NFTs will be randomized, and prevents “sniping” of specific NFTs during the pre-sale or public sale phases.":"Once all 10,000 have been sold, VRF will pick numbers from 0 to 9999, which will be used to shift the Squad Ticket ID. This will ensure that the distribution of rare NFTs will be randomized, and prevents “sniping” of specific NFTs during the pre-sale or public sale phases.","Value is subjective, but since different traits have different levels of rarity, you can expect bunnies with rarer traits to trade for higher prices than others. If you’re planning to sell, check the NFT market for the price of bunnies with a similarly rare traits to yours.":"Value is subjective, but since different traits have different levels of rarity, you can expect bunnies with rarer traits to trade for higher prices than others. If you’re planning to sell, check the NFT market for the price of bunnies with a similarly rare traits to yours.","Bunny Id":"Bunny Id","Filter by":"Filter by","On Sale":"On Sale","Results":"Results","Newest Arrivals":"Newest Arrivals","I sold an NFT, where’s my BNB?":"I sold an NFT, where’s my BNB?","Trades are settled in WBNB, which is a wrapped version of BNB used on Binance Smart Chain. That means that when you sell an item, WBNB is sent to your wallet instead of BNB.":"Trades are settled in WBNB, which is a wrapped version of BNB used on Binance Smart Chain. That means that when you sell an item, WBNB is sent to your wallet instead of BNB.","You can instantly swap your WBNB for BNB with no trading fees on PancakeSwap.":"You can instantly swap your WBNB for BNB with no trading fees on PancakeSwap.","When can I trade other NFT Collections?":"When can I trade other NFT Collections?","Soon! The current NFT Market is a basic version (phase 1), with early access to trading PancakeSwap NFTs only.":"Soon! The current NFT Market is a basic version (phase 1), with early access to trading PancakeSwap NFTs only.","Other collections will be coming soon. We’ll make an announcement soon about the launch of the V2 Market.":"Other collections will be coming soon. We’ll make an announcement soon about the launch of the V2 Market.","How can I list my NFT collection on the Market?":"How can I list my NFT collection on the Market?","In Phase 2 of the NFT Marketplace, collections must be whitelisted before they may be listed.":"In Phase 2 of the NFT Marketplace, collections must be whitelisted before they may be listed.","We are now accepting applications from NFT collection owners seeking to list their collections. Please apply here: https://docs.pancakeswap.finance/contact-us/nft-market-applications":"We are now accepting applications from NFT collection owners seeking to list their collections. Please apply here: https://docs.pancakeswap.finance/contact-us/nft-market-applications","What are the fees?":"What are the fees?","100% of all platform fees taken by PancakeSwap from sales are used to buy back and BURN CAKE tokens in our weekly CAKE burns.":"100% of all platform fees taken by PancakeSwap from sales are used to buy back and BURN CAKE tokens in our weekly CAKE burns.","Platform fees: 2% is subtracted from NFT sales on the market. Subject to change.Collection fees: Additional fees may be taken by collection creators, once those collections are live. These will not contribute to the CAKE burns.":"Platform fees: 2% is subtracted from NFT sales on the market. Subject to change.Collection fees: Additional fees may be taken by collection creators, once those collections are live. These will not contribute to the CAKE burns.","Mint Cost: To Be Announced":"Mint Cost: To Be Announced","The smart contract address will be released soon before the sale starts.":"The smart contract address will be released soon before the sale starts.","Supply Count":"Supply Count","Brand":"Brand","Success":"Success","Wrap":"Wrap","Unwrap":"Unwrap","Go to IFO":"Go to IFO","Phishing warning: ":"Phishing warning: ","please make sure you\'re visiting https://pancakeswap.finance - check the URL carefully.":"please make sure you\'re visiting https://pancakeswap.finance - check the URL carefully.","No bids yet":"No bids yet","Please specify Round":"Please specify Round","1W":"1W","1M":"1M","Failed to load price chart for this pair":"Failed to load price chart for this pair","You can swap WBNB for BNB (and vice versa) with no trading fees.":"You can swap WBNB for BNB (and vice versa) with no trading fees.","Exchange rate is always 1 to 1.":"Exchange rate is always 1 to 1.","You can contribute to one or both, it doesn’t matter: only your overall contribution is counted for the achievement.":"You can contribute to one or both, it doesn’t matter: only your overall contribution is counted for the achievement.","You’ll need %symbol% tokens to participate in the IFO!":"You’ll need %symbol% tokens to participate in the IFO!","Get %symbol%, or make sure your tokens aren’t staked somewhere else.":"Get %symbol%, or make sure your tokens aren’t staked somewhere else.","Refresh":"Refresh","Basic":"Basic","TradingView chart not available":"TradingView chart not available","Everyone’s a winner!":"Everyone’s a winner!","Sign up for battle and you’re guaranteed a prize!":"Sign up for battle and you’re guaranteed a prize!","Binance Fan Token Trading Competition":"Binance Fan Token Trading Competition","Compete with other teams for the highest trading volume!":"Compete with other teams for the highest trading volume!","Trading Competition":"Trading Competition","Trade SANTOS/BNB, PORTO/BNB, LAZIO/BNB, SANTOS/BUSD, PORTO/BUSD, LAZIO/BUSD, CAKE/BNB and CAKE/BUSD during the battle period to raise both your and your team’s score. See the Rules section below for more.":"Trade SANTOS/BNB, PORTO/BNB, LAZIO/BNB, SANTOS/BUSD, PORTO/BUSD, LAZIO/BUSD, CAKE/BNB and CAKE/BUSD during the battle period to raise both your and your team’s score. See the Rules section below for more.","To participate in the next IFO, stake some CAKE in the IFO CAKE pool!":"To participate in the next IFO, stake some CAKE in the IFO CAKE pool!","IFO Credit":"IFO Credit","Stake CAKE in IFO pool":"Stake CAKE in IFO pool","The maximum amount of CAKE user can commit to all the sales combined, is equal to the average CAKE balance in the IFO CAKE pool prior to the IFO. Stake more CAKE to increase the maximum CAKE you can commit to the sale. Missed this IFO? You can keep staking in the IFO CAKE Pool to join the next IFO sale.":"The maximum amount of CAKE user can commit to all the sales combined, is equal to the average CAKE balance in the IFO CAKE pool prior to the IFO. Stake more CAKE to increase the maximum CAKE you can commit to the sale. Missed this IFO? You can keep staking in the IFO CAKE Pool to join the next IFO sale.","How does the IFO credit calculated?":"How does the IFO credit calculated?","IFO credit is calculated by average block balance in the IFO pool in over the staking period announced with each IFO proposal.":"IFO credit is calculated by average block balance in the IFO pool in over the staking period announced with each IFO proposal.","Please refer to our blog post for more details.":"Please refer to our blog post for more details.","Your max CAKE entry":"Your max CAKE entry","For the basic sale, Max CAKE entry is capped by minimum between your average CAKE balance in the IFO CAKE pool, or the pool’s hard cap. To increase the max entry, Stake more CAKE into the IFO CAKE pool":"For the basic sale, Max CAKE entry is capped by minimum between your average CAKE balance in the IFO CAKE pool, or the pool’s hard cap. To increase the max entry, Stake more CAKE into the IFO CAKE pool","For the unlimited sale, Max CAKE entry is capped by your average CAKE balance in the IFO CAKE pool. To increase the max entry, Stake more CAKE into the IFO CAKE pool":"For the unlimited sale, Max CAKE entry is capped by your average CAKE balance in the IFO CAKE pool. To increase the max entry, Stake more CAKE into the IFO CAKE pool","You don’t have any average CAKE balance available to commit in the IFO CAKE pool.":"You don’t have any average CAKE balance available to commit in the IFO CAKE pool.","Sale Finished!":"Sale Finished!","Start in":"Start in","Your entry limit in the next IFO sale is determined by your IFO credit. This is calculated by the average CAKE balance of the principal amount in the IFO pool during the last credit calculation period.":"Your entry limit in the next IFO sale is determined by your IFO credit. This is calculated by the average CAKE balance of the principal amount in the IFO pool during the last credit calculation period.","Please note: even the pool is auto compounding. Amount of profits will not be included during IFO credit calculations.":"Please note: even the pool is auto compounding. Amount of profits will not be included during IFO credit calculations.","Exceeded max CAKE entry":"Exceeded max CAKE entry","Only applies within %num% days of staking. Unstaking after %num% days will not include a fee. Timer resets every time you stake new CAKE in the pool.":"Only applies within %num% days of staking. Unstaking after %num% days will not include a fee. Timer resets every time you stake new CAKE in the pool.","unstaking fee if withdrawn within %num%h":"unstaking fee if withdrawn within %num%h","Earn %asset%":"Earn %asset%","Credit calculation starts:":"Credit calculation starts:","Credit calculation ended:":"Credit calculation ended:","The start block of the current calculation period. Your average IFO CAKE Pool staking balance is calculated throughout this period.":"The start block of the current calculation period. Your average IFO CAKE Pool staking balance is calculated throughout this period.","The latest credit calculation period has ended. After the coming IFO, credits will be reset and the calculation will resume.":"The latest credit calculation period has ended. After the coming IFO, credits will be reset and the calculation will resume.","Follow us on Twitter to catch the latest news about the coming IFO.":"Follow us on Twitter to catch the latest news about the coming IFO.","Check out our Medium article for more details.":"Check out our Medium article for more details.","IFO Pool":"IFO Pool","Chart":"Chart","by":"by","You’ve successfully claimed tokens back.":"You’ve successfully claimed tokens back.","Stake CAKE to participate in IFOs":"Stake CAKE to participate in IFOs","Celebrate Christmas and New Year with us! Enjoy this wonderful NFT crafted by Chef Cecy and the winner from our #PancakeChristmas event.":"Celebrate Christmas and New Year with us! Enjoy this wonderful NFT crafted by Chef Cecy and the winner from our #PancakeChristmas event.","Chain Head Block":"Chain Head Block","Latest Subgraph Block":"Latest Subgraph Block","Slight delay":"Slight delay","Delayed":"Delayed","Fast":"Fast","Subgraph is currently experiencing delays due to BSC issues. Performance may suffer until subgraph is restored.":"Subgraph is currently experiencing delays due to BSC issues. Performance may suffer until subgraph is restored.","No issues with the subgraph.":"No issues with the subgraph.","Turn on NFT market subgraph health indicator all the time. Default is to show the indicator only when the network is delayed":"Turn on NFT market subgraph health indicator all the time. Default is to show the indicator only when the network is delayed","Subgraph Health Indicator":"Subgraph Health Indicator","Delay":"Delay","Add liquidity instead":"Add liquidity instead","The latest credit calculation period has ended. Calculation will resume upon the next period starts.":"The latest credit calculation period has ended. Calculation will resume upon the next period starts.","If the amount you commit is too small, you may not receive a meaningful amount of IFO tokens.":"If the amount you commit is too small, you may not receive a meaningful amount of IFO tokens.","SAFEMOON has been migrated to":"SAFEMOON has been migrated to","a new contract address.":"a new contract address.","Trading on the old address may result in the complete loss of your assets. For more information please refer to":"Trading on the old address may result in the complete loss of your assets. For more information please refer to","Safemoon\'s announcement":"Safemoon\'s announcement","Newest Collections":"Newest Collections","Your average per hour":"Your average per hour","At this rate, you would earn":"At this rate, you would earn","CAKE per hour: %amount%":"CAKE per hour: %amount%","per hour: ~$%amount%":"per hour: ~$%amount%","per 1d: ~$%amount%":"per 1d: ~$%amount%","per 7d: ~$%amount%":"per 7d: ~$%amount%","per 30d: ~$%amount%":"per 30d: ~$%amount%","per 365d: ~$%amount%":"per 365d: ~$%amount%","Remember that you will pay the gas fee.":"Remember that you will pay the gas fee.","ITAM has been rebranded as ITAM CUBE.":"ITAM has been rebranded as ITAM CUBE.","Please proceed to ITAM bridge to conduct a one-way swap of your ITAM tokens.":"Please proceed to ITAM bridge to conduct a one-way swap of your ITAM tokens.","All transfers of the old ITAM token will be disabled after the swap.":"All transfers of the old ITAM token will be disabled after the swap.","Crypto Cars (CCAR) has been migrated to":"Crypto Cars (CCAR) has been migrated to","the announcement.":"the announcement.","Apply to NFT Market!":"Apply to NFT Market!"}');
// EXTERNAL MODULE: ./src/contexts/Localization/helpers.ts
var helpers = __webpack_require__(5290);
;// CONCATENATED MODULE: ./src/contexts/Localization/Provider.tsx





const initialState = {
    isFetching: true,
    currentLanguage: languages.EN
};
// Export the translations directly
const languageMap = new Map();
languageMap.set(languages.EN.locale, translations_namespaceObject);
const LanguageContext = /*#__PURE__*/ (0,external_react_.createContext)(undefined);
const LanguageProvider = ({ children  })=>{
    const { 0: state , 1: setState  } = (0,external_react_.useState)(()=>{
        const codeFromStorage = (0,helpers/* getLanguageCodeFromLS */.jq)();
        return {
            ...initialState,
            currentLanguage: languages/* languages */.Mj[codeFromStorage]
        };
    });
    const { currentLanguage  } = state;
    (0,external_react_.useEffect)(()=>{
        const fetchInitialLocales = async ()=>{
            const codeFromStorage = (0,helpers/* getLanguageCodeFromLS */.jq)();
            if (codeFromStorage !== languages.EN.locale) {
                const enLocale = languageMap.get(languages.EN.locale);
                const currentLocale = await (0,helpers/* fetchLocale */.w2)(codeFromStorage);
                languageMap.set(codeFromStorage, {
                    ...enLocale,
                    ...currentLocale
                });
            }
            setState((prevState)=>({
                    ...prevState,
                    isFetching: false
                })
            );
        };
        fetchInitialLocales();
    }, [
        setState
    ]);
    const setLanguage = (0,external_react_.useCallback)(async (language)=>{
        if (!languageMap.has(language.locale)) {
            setState((prevState)=>({
                    ...prevState,
                    isFetching: true
                })
            );
            const locale = await (0,helpers/* fetchLocale */.w2)(language.locale);
            const enLocale = languageMap.get(languages.EN.locale);
            // Merge the EN locale to ensure that any locale fetched has all the keys
            languageMap.set(language.locale, {
                ...enLocale,
                ...locale
            });
            localStorage.setItem(helpers/* LS_KEY */.SH, language.locale);
            setState((prevState)=>({
                    ...prevState,
                    isFetching: false,
                    currentLanguage: language
                })
            );
        } else {
            localStorage.setItem(helpers/* LS_KEY */.SH, language.locale);
            setState((prevState)=>({
                    ...prevState,
                    isFetching: false,
                    currentLanguage: language
                })
            );
        }
    }, []);
    const translate = (0,external_react_.useCallback)((key, data)=>{
        const translationSet = languageMap.has(currentLanguage.locale) ? languageMap.get(currentLanguage.locale) : languageMap.get(languages.EN.locale);
        const translatedText = translationSet[key] || key;
        // Check the existence of at least one combination of %%, separated by 1 or more non space characters
        const includesVariable = translatedText.match(/%\S+?%/gm);
        if (includesVariable && data) {
            let interpolatedText = translatedText;
            Object.keys(data).forEach((dataKey)=>{
                const templateKey = new RegExp(`%${dataKey}%`, 'g');
                interpolatedText = interpolatedText.replace(templateKey, data[dataKey].toString());
            });
            return interpolatedText;
        }
        return translatedText;
    }, [
        currentLanguage
    ]);
    return(/*#__PURE__*/ jsx_runtime_.jsx(LanguageContext.Provider, {
        value: {
            ...state,
            setLanguage,
            t: translate
        },
        children: children
    }));
};

;// CONCATENATED MODULE: ./src/contexts/Localization/useTranslation.ts


const useTranslation = ()=>{
    const languageContext = (0,external_react_.useContext)(LanguageContext);
    if (languageContext === undefined) {
        throw new Error('Language context is undefined');
    }
    return languageContext;
};
/* harmony default export */ const Localization_useTranslation = (useTranslation);

;// CONCATENATED MODULE: ./src/contexts/Localization/index.tsx




/***/ }),

/***/ 5083:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "IG": () => (/* reexport */ Listener),
  "iv": () => (/* reexport */ ToastsContext),
  "d0": () => (/* reexport */ ToastsProvider)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "lodash/kebabCase"
var kebabCase_ = __webpack_require__(1546);
var kebabCase_default = /*#__PURE__*/__webpack_require__.n(kebabCase_);
// EXTERNAL MODULE: ./src/components/Toast/index.tsx + 4 modules
var Toast = __webpack_require__(3937);
;// CONCATENATED MODULE: ./src/contexts/ToastsContext/Provider.tsx




const ToastsContext = /*#__PURE__*/ (0,external_react_.createContext)(undefined);
const ToastsProvider = ({ children  })=>{
    const { 0: toasts , 1: setToasts  } = (0,external_react_.useState)([]);
    const toast = (0,external_react_.useCallback)(({ title , description , type  })=>{
        setToasts((prevToasts)=>{
            const id = kebabCase_default()(title);
            // Remove any existing toasts with the same id
            const currentToasts = prevToasts.filter((prevToast)=>prevToast.id !== id
            );
            return [
                {
                    id,
                    title,
                    description,
                    type
                },
                ...currentToasts, 
            ];
        });
    }, [
        setToasts
    ]);
    const toastError = (title, description)=>{
        return toast({
            title,
            description,
            type: Toast/* toastTypes.DANGER */.m$.DANGER
        });
    };
    const toastInfo = (title, description)=>{
        return toast({
            title,
            description,
            type: Toast/* toastTypes.INFO */.m$.INFO
        });
    };
    const toastSuccess = (title, description)=>{
        return toast({
            title,
            description,
            type: Toast/* toastTypes.SUCCESS */.m$.SUCCESS
        });
    };
    const toastWarning = (title, description)=>{
        return toast({
            title,
            description,
            type: Toast/* toastTypes.WARNING */.m$.WARNING
        });
    };
    const clear = ()=>setToasts([])
    ;
    const remove = (id)=>{
        setToasts((prevToasts)=>prevToasts.filter((prevToast)=>prevToast.id !== id
            )
        );
    };
    return(/*#__PURE__*/ jsx_runtime_.jsx(ToastsContext.Provider, {
        value: {
            toasts,
            clear,
            remove,
            toastError,
            toastInfo,
            toastSuccess,
            toastWarning
        },
        children: children
    }));
};

// EXTERNAL MODULE: ./src/hooks/useToast.ts
var useToast = __webpack_require__(789);
;// CONCATENATED MODULE: ./src/contexts/ToastsContext/Listener.tsx




const ToastListener = ()=>{
    const { toasts , remove  } = (0,useToast/* default */.Z)();
    const handleRemove = (id)=>remove(id)
    ;
    return(/*#__PURE__*/ jsx_runtime_.jsx(Toast/* ToastContainer */.Ix, {
        toasts: toasts,
        onRemove: handleRemove
    }));
};
/* harmony default export */ const Listener = (ToastListener);

;// CONCATENATED MODULE: ./src/contexts/ToastsContext/index.tsx




/***/ }),

/***/ 6435:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EK": () => (/* binding */ useAllInactiveTokens)
/* harmony export */ });
/* unused harmony exports useDefaultTokens, useAllTokens, useUnsupportedTokens, useIsTokenActive, useFoundOnInactiveList, useIsUserAddedToken, useToken, useCurrency */
/* harmony import */ var _ethersproject_strings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9213);
/* harmony import */ var _ethersproject_strings__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_strings__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2877);
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ethersproject_bytes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9935);
/* harmony import */ var _ethersproject_bytes__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_bytes__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4011);
/* harmony import */ var _state_lists_hooks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7952);
/* harmony import */ var _state_multicall_hooks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1001);
/* harmony import */ var _state_user_hooks_useUserAddedTokens__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4797);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8328);
/* harmony import */ var _useContract__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5882);
/* harmony import */ var _components_SearchModal_filtering__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7910);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_6__]);
_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];
/* eslint-disable no-param-reassign */ 










// reduce token map into standard address <-> Token mapping, optionally include user added tokens
function useTokensFromMap(tokenMap, includeUserAdded) {
    const { chainId  } = (0,hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)();
    const userAddedTokens = (0,_state_user_hooks_useUserAddedTokens__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
    return (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        if (!chainId) return {};
        // reduce to just tokens
        const mapWithoutUrls = Object.keys(tokenMap[chainId]).reduce((newMap, address)=>{
            newMap[address] = tokenMap[chainId][address].token;
            return newMap;
        }, {});
        if (includeUserAdded) {
            return userAddedTokens// reduce into all ALL_TOKENS filtered by the current chain
            .reduce((tokenMap_, token)=>{
                tokenMap_[token.address] = token;
                return tokenMap_;
            }, // must make a copy because reduce modifies the map, and we do not
            // want to make a copy in every iteration
            {
                ...mapWithoutUrls
            });
        }
        return mapWithoutUrls;
    }, [
        chainId,
        userAddedTokens,
        tokenMap,
        includeUserAdded
    ]);
}
function useDefaultTokens() {
    const defaultList = useDefaultTokenList();
    return useTokensFromMap(defaultList, false);
}
function useAllTokens(includeDefaultLists = false) {
    const allTokens = (0,_state_lists_hooks__WEBPACK_IMPORTED_MODULE_5__/* .useCombinedActiveList */ .z0)(includeDefaultLists);
    return useTokensFromMap(allTokens, true);
}
function useAllInactiveTokens() {
    // get inactive tokens
    const inactiveTokensMap = (0,_state_lists_hooks__WEBPACK_IMPORTED_MODULE_5__/* .useCombinedInactiveList */ .qB)();
    const inactiveTokens = useTokensFromMap(inactiveTokensMap, false);
    // filter out any token that are on active list
    const activeTokensAddresses = Object.keys(useAllTokens());
    const filteredInactive = activeTokensAddresses ? Object.keys(inactiveTokens).reduce((newMap, address)=>{
        if (!activeTokensAddresses.includes(address)) {
            newMap[address] = inactiveTokens[address];
        }
        return newMap;
    }, {}) : inactiveTokens;
    return filteredInactive;
}
function useUnsupportedTokens() {
    const unsupportedTokensMap = useUnsupportedTokenList();
    return useTokensFromMap(unsupportedTokensMap, false);
}
function useIsTokenActive(token) {
    const activeTokens = useAllTokens();
    if (!activeTokens || !token) {
        return false;
    }
    return !!activeTokens[token.address];
}
// used to detect extra search results
function useFoundOnInactiveList(searchQuery) {
    const { chainId  } = useActiveWeb3React();
    const inactiveTokens = useAllInactiveTokens();
    return useMemo(()=>{
        if (!chainId || searchQuery === '') {
            return undefined;
        }
        const tokens = filterTokens(Object.values(inactiveTokens), searchQuery);
        return tokens;
    }, [
        chainId,
        inactiveTokens,
        searchQuery
    ]);
}
// Check if currency is included in custom list from user storage
function useIsUserAddedToken(currency) {
    const userAddedTokens = useUserAddedTokens();
    if (!currency) {
        return false;
    }
    return !!userAddedTokens.find((token)=>currencyEquals(currency, token)
    );
}
// parse a name or symbol from a token response
const BYTES32_REGEX = /^0x[a-fA-F0-9]{64}$/;
function parseStringOrBytes32(str, bytes32, defaultValue) {
    return str && str.length > 0 ? str : bytes32 && BYTES32_REGEX.test(bytes32) && arrayify(bytes32)[31] === 0 ? parseBytes32String(bytes32) : defaultValue;
}
// undefined if invalid or does not exist
// null if loading
// otherwise returns the token
function useToken(tokenAddress) {
    const { chainId  } = useActiveWeb3React();
    const tokens = useAllTokens();
    const address = isAddress(tokenAddress);
    const tokenContract = useTokenContract(address || undefined, false);
    const tokenContractBytes32 = useBytes32TokenContract(address || undefined, false);
    const token = address ? tokens[address] : undefined;
    const tokenName = useSingleCallResult(token ? undefined : tokenContract, 'name', undefined, NEVER_RELOAD);
    const tokenNameBytes32 = useSingleCallResult(token ? undefined : tokenContractBytes32, 'name', undefined, NEVER_RELOAD);
    const symbol = useSingleCallResult(token ? undefined : tokenContract, 'symbol', undefined, NEVER_RELOAD);
    const symbolBytes32 = useSingleCallResult(token ? undefined : tokenContractBytes32, 'symbol', undefined, NEVER_RELOAD);
    const decimals = useSingleCallResult(token ? undefined : tokenContract, 'decimals', undefined, NEVER_RELOAD);
    return useMemo(()=>{
        if (token) return token;
        if (!chainId || !address) return undefined;
        if (decimals.loading || symbol.loading || tokenName.loading) return null;
        if (decimals.result) {
            return new Token(chainId, address, decimals.result[0], parseStringOrBytes32(symbol.result?.[0], symbolBytes32.result?.[0], 'UNKNOWN'), parseStringOrBytes32(tokenName.result?.[0], tokenNameBytes32.result?.[0], 'Unknown Token'));
        }
        return undefined;
    }, [
        address,
        chainId,
        decimals.loading,
        decimals.result,
        symbol.loading,
        symbol.result,
        symbolBytes32.result,
        token,
        tokenName.loading,
        tokenName.result,
        tokenNameBytes32.result, 
    ]);
}
function useCurrency(currencyId) {
    const isBNB = currencyId?.toUpperCase() === 'BNB';
    const token = useToken(isBNB ? undefined : currencyId);
    return isBNB ? ETHER : token;
}

});

/***/ }),

/***/ 4011:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var utils_providers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5922);



/**
 * Provides a web3 provider with or without user's signer
 * Recreate web3 instance only if the provider change
 */ const useActiveWeb3React = ()=>{
    const { library , chainId , ...web3React } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_1__.useWeb3React)();
    const refEth = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(library);
    const { 0: provider , 1: setProvider  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(library || utils_providers__WEBPACK_IMPORTED_MODULE_2__/* .simpleRpcProvider */ .J);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        if (library !== refEth.current) {
            setProvider(library || utils_providers__WEBPACK_IMPORTED_MODULE_2__/* .simpleRpcProvider */ .J);
            refEth.current = library;
        }
    }, [
        library
    ]);
    return {
        library: provider,
        chainId: chainId ?? parseInt("1666700000", 10),
        ...web3React
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useActiveWeb3React);


/***/ }),

/***/ 1222:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ hooks_useAuth)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "@web3-react/core"
var core_ = __webpack_require__(8054);
// EXTERNAL MODULE: external "@binance-chain/bsc-connector"
var bsc_connector_ = __webpack_require__(8454);
// EXTERNAL MODULE: external "@web3-react/injected-connector"
var injected_connector_ = __webpack_require__(6590);
// EXTERNAL MODULE: external "@web3-react/walletconnect-connector"
var walletconnect_connector_ = __webpack_require__(9795);
// EXTERNAL MODULE: external "@pancakeswap/uikit"
var uikit_ = __webpack_require__(2829);
// EXTERNAL MODULE: ./src/utils/web3React.ts
var web3React = __webpack_require__(2338);
// EXTERNAL MODULE: ./src/config/index.ts
var config = __webpack_require__(3206);
// EXTERNAL MODULE: ./src/utils/getRpcUrl.ts
var getRpcUrl = __webpack_require__(7308);
;// CONCATENATED MODULE: ./src/utils/wallet.ts
// Set of helper functions to facilitate wallet setup


/**
 * Prompt the user to add BSC as a network on Metamask, or switch to BSC if the wallet is on a different network
 * @returns {boolean} true if the setup succeeded, false otherwise
 */ const setupNetwork = async ()=>{
    const provider = window.ethereum;
    if (provider) {
        const chainId = parseInt("1666700000", 10);
        try {
            await provider.request({
                method: 'wallet_addEthereumChain',
                params: [
                    {
                        chainId: `0x${chainId.toString(16)}`,
                        chainName: 'Binance Smart Chain Mainnet',
                        nativeCurrency: {
                            name: 'BNB',
                            symbol: 'bnb',
                            decimals: 18
                        },
                        rpcUrls: getRpcUrl/* nodes */.t,
                        blockExplorerUrls: [
                            `${config/* BASE_BSC_SCAN_URL */.OS}/`
                        ]
                    }, 
                ]
            });
            return true;
        } catch (error) {
            console.error('Failed to setup the network in Metamask:', error);
            return false;
        }
    } else {
        console.error("Can't setup the BSC network on metamask because window.ethereum is undefined");
        return false;
    }
};
/**
 * Prompt the user to add a custom token to metamask
 * @param tokenAddress
 * @param tokenSymbol
 * @param tokenDecimals
 * @returns {boolean} true if the token has been added, false otherwise
 */ const registerToken = async (tokenAddress, tokenSymbol, tokenDecimals)=>{
    const tokenAdded = await window.ethereum.request({
        method: 'wallet_watchAsset',
        params: {
            type: 'ERC20',
            options: {
                address: tokenAddress,
                symbol: tokenSymbol,
                decimals: tokenDecimals,
                image: `${BASE_URL}/images/tokens/${tokenAddress}.png`
            }
        }
    });
    return tokenAdded;
};

// EXTERNAL MODULE: ./src/hooks/useToast.ts
var useToast = __webpack_require__(789);
// EXTERNAL MODULE: ./src/state/index.ts + 6 modules
var state = __webpack_require__(4861);
// EXTERNAL MODULE: ./src/contexts/Localization/index.tsx + 3 modules
var Localization = __webpack_require__(9150);
// EXTERNAL MODULE: ./src/utils/clearUserStates.ts
var clearUserStates = __webpack_require__(8382);
;// CONCATENATED MODULE: ./src/hooks/useAuth.ts












const useAuth = ()=>{
    const { t  } = (0,Localization/* useTranslation */.$G)();
    const dispatch = (0,state/* useAppDispatch */.TL)();
    const { chainId , activate , deactivate  } = (0,core_.useWeb3React)();
    const { toastError  } = (0,useToast/* default */.Z)();
    const login = (0,external_react_.useCallback)((connectorID)=>{
        const connector = web3React/* connectorsByName */.BA[connectorID];
        if (connector) {
            activate(connector, async (error)=>{
                if (error instanceof core_.UnsupportedChainIdError) {
                    const hasSetup = await setupNetwork();
                    if (hasSetup) {
                        activate(connector);
                    }
                } else {
                    window.localStorage.removeItem(uikit_.connectorLocalStorageKey);
                    if (error instanceof injected_connector_.NoEthereumProviderError || error instanceof bsc_connector_.NoBscProviderError) {
                        toastError(t('Provider Error'), t('No provider was found'));
                    } else if (error instanceof injected_connector_.UserRejectedRequestError || error instanceof walletconnect_connector_.UserRejectedRequestError) {
                        if (connector instanceof walletconnect_connector_.WalletConnectConnector) {
                            const walletConnector = connector;
                            walletConnector.walletConnectProvider = null;
                        }
                        toastError(t('Authorization Error'), t('Please authorize to access your account'));
                    } else {
                        toastError(error.name, error.message);
                    }
                }
            });
        } else {
            toastError(t('Unable to find connector'), t('The connector config is wrong'));
        }
    }, [
        t,
        activate,
        toastError
    ]);
    const logout = (0,external_react_.useCallback)(()=>{
        deactivate();
        (0,clearUserStates/* clearUserStates */.J)(dispatch, chainId);
    }, [
        deactivate,
        dispatch,
        chainId
    ]);
    return {
        login,
        logout
    };
};
/* harmony default export */ const hooks_useAuth = (useAuth);


/***/ }),

/***/ 834:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "S9": () => (/* binding */ useCakeBusdPrice),
/* harmony export */   "Hf": () => (/* binding */ useBNBBusdPrice)
/* harmony export */ });
/* unused harmony exports default, useBUSDCurrencyAmount, useBUSDCakeAmount */
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2877);
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var config_constants_tokens__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9748);
/* harmony import */ var hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4011);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var utils_prices__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7879);
/* harmony import */ var _utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3854);
/* harmony import */ var _usePairs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4915);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_usePairs__WEBPACK_IMPORTED_MODULE_6__]);
_usePairs__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];







const BUSD_MAINNET = config_constants_tokens__WEBPACK_IMPORTED_MODULE_1__/* .mainnetTokens.busd */ .ke.busd;
const { wbnb: WBNB  } = config_constants_tokens__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP;
/**
 * Returns the price in BUSD of the input currency
 * @param currency currency to compute the BUSD price of
 */ function useBUSDPrice(currency) {
    const { chainId  } = (0,hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)();
    const wrapped = (0,_utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_5__/* .wrappedCurrency */ .pu)(currency, chainId);
    const tokenPairs = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>[
            [
                chainId && wrapped && (0,_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.currencyEquals)(WBNB, wrapped) ? undefined : currency,
                chainId ? WBNB : undefined
            ],
            [
                wrapped?.equals(BUSD_MAINNET) ? undefined : wrapped,
                chainId === _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET ? BUSD_MAINNET : undefined
            ],
            [
                chainId ? WBNB : undefined,
                chainId === _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET ? BUSD_MAINNET : undefined
            ], 
        ]
    , [
        chainId,
        currency,
        wrapped
    ]);
    const [[ethPairState, ethPair], [busdPairState, busdPair], [busdEthPairState, busdEthPair]] = (0,_usePairs__WEBPACK_IMPORTED_MODULE_6__/* .usePairs */ .z$)(tokenPairs);
    return (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        if (!currency || !wrapped || !chainId) {
            return undefined;
        }
        // handle weth/eth
        if (wrapped.equals(WBNB)) {
            if (busdPair) {
                const price = busdPair.priceOf(WBNB);
                return new _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.Price(currency, BUSD_MAINNET, price.denominator, price.numerator);
            }
            return undefined;
        }
        // handle busd
        if (wrapped.equals(BUSD_MAINNET)) {
            return new _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.Price(BUSD_MAINNET, BUSD_MAINNET, '1', '1');
        }
        const ethPairETHAmount = ethPair?.reserveOf(WBNB);
        const ethPairETHBUSDValue = ethPairETHAmount && busdEthPair ? busdEthPair.priceOf(WBNB).quote(ethPairETHAmount).raw : _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(0);
        // all other tokens
        // first try the busd pair
        if (busdPairState === _usePairs__WEBPACK_IMPORTED_MODULE_6__/* .PairState.EXISTS */ ._G.EXISTS && busdPair && busdPair.reserveOf(BUSD_MAINNET).greaterThan(ethPairETHBUSDValue)) {
            const price = busdPair.priceOf(wrapped);
            return new _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.Price(currency, BUSD_MAINNET, price.denominator, price.numerator);
        }
        if (ethPairState === _usePairs__WEBPACK_IMPORTED_MODULE_6__/* .PairState.EXISTS */ ._G.EXISTS && ethPair && busdEthPairState === _usePairs__WEBPACK_IMPORTED_MODULE_6__/* .PairState.EXISTS */ ._G.EXISTS && busdEthPair) {
            if (busdEthPair.reserveOf(BUSD_MAINNET).greaterThan('0') && ethPair.reserveOf(WBNB).greaterThan('0')) {
                const ethBusdPrice = busdEthPair.priceOf(BUSD_MAINNET);
                const currencyEthPrice = ethPair.priceOf(WBNB);
                const busdPrice = ethBusdPrice.multiply(currencyEthPrice).invert();
                return new _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.Price(currency, BUSD_MAINNET, busdPrice.denominator, busdPrice.numerator);
            }
        }
        return undefined;
    }, [
        chainId,
        currency,
        ethPair,
        ethPairState,
        busdEthPair,
        busdEthPairState,
        busdPair,
        busdPairState,
        wrapped
    ]);
};
const useCakeBusdPrice = ()=>{
    const cakeBusdPrice = useBUSDPrice(config_constants_tokens__WEBPACK_IMPORTED_MODULE_1__/* ["default"].cake */ .ZP.cake);
    return cakeBusdPrice;
};
const useBUSDCurrencyAmount = (currency, amount)=>{
    const { chainId  } = useActiveWeb3React();
    const busdPrice = useBUSDPrice(currency);
    const wrapped = wrappedCurrency(currency, chainId);
    if (busdPrice) {
        return multiplyPriceByAmount(busdPrice, amount, wrapped.decimals);
    }
    return undefined;
};
const useBUSDCakeAmount = (amount)=>{
    const cakeBusdPrice = useCakeBusdPrice();
    if (cakeBusdPrice) {
        return multiplyPriceByAmount(cakeBusdPrice, amount);
    }
    return undefined;
};
const useBNBBusdPrice = ()=>{
    const bnbBusdPrice = useBUSDPrice(config_constants_tokens__WEBPACK_IMPORTED_MODULE_1__/* ["default"].wbnb */ .ZP.wbnb);
    return bnbBusdPrice;
};

});

/***/ }),

/***/ 5882:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "gq": () => (/* binding */ useMulticallContract),
  "Tu": () => (/* binding */ usePredictionsContract),
  "Ib": () => (/* binding */ useTokenContract)
});

// UNUSED EXPORTS: useAnniversaryAchievementContract, useBunnyFactory, useBunnySpecialContract, useBunnySpecialLotteryContract, useBunnySpecialXmasContract, useBytes32TokenContract, useCake, useCakeVaultContract, useChainlinkOracleContract, useClaimRefundContract, useENSRegistrarContract, useENSResolverContract, useERC20, useERC721, useErc721CollectionContract, useFarmAuctionContract, useIfoPoolContract, useIfoV1Contract, useIfoV2Contract, useLotteryV2Contract, useMasterchef, usePairContract, usePancakeRabbits, usePancakeSquadContract, usePointCenterIfoContract, useProfileContract, useSousChef, useSousChefV2, useSpecialBunnyCakeVaultContract, useSpecialBunnyPredictionContract, useTradingCompetitionContract, useTradingCompetitionContractV2, useVaultPoolContract, useWETHContract

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./src/hooks/useActiveWeb3React.ts
var hooks_useActiveWeb3React = __webpack_require__(4011);
// EXTERNAL MODULE: ./src/utils/contractHelpers.ts + 27 modules
var contractHelpers = __webpack_require__(4765);
// EXTERNAL MODULE: ./src/utils/addressHelpers.ts + 1 modules
var addressHelpers = __webpack_require__(5878);
// EXTERNAL MODULE: ./src/state/types.ts
var types = __webpack_require__(5101);
// EXTERNAL MODULE: external "@mdemouchy/sdk"
var sdk_ = __webpack_require__(2877);
// EXTERNAL MODULE: ./src/config/abi/IPancakePair.json
var IPancakePair = __webpack_require__(3725);
;// CONCATENATED MODULE: ./src/config/abi/ens-public-resolver.json
const ens_public_resolver_namespaceObject = [];
;// CONCATENATED MODULE: ./src/config/abi/ens-registrar.json
const ens_registrar_namespaceObject = [];
// EXTERNAL MODULE: external "@ethersproject/abi"
var abi_ = __webpack_require__(6187);
// EXTERNAL MODULE: ./src/config/abi/erc20.json
var erc20 = __webpack_require__(3324);
;// CONCATENATED MODULE: ./src/config/abi/erc20_bytes32.json
const erc20_bytes32_namespaceObject = JSON.parse('[{"constant":true,"inputs":[],"name":"name","outputs":[{"name":"","type":"bytes32"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"symbol","outputs":[{"name":"","type":"bytes32"}],"payable":false,"stateMutability":"view","type":"function"}]');
;// CONCATENATED MODULE: ./src/config/abi/erc20.ts



const ERC20_INTERFACE = new abi_.Interface(erc20);
const ERC20_BYTES32_INTERFACE = new abi_.Interface(erc20_bytes32_namespaceObject);
/* harmony default export */ const abi_erc20 = ((/* unused pure expression or super */ null && (ERC20_INTERFACE)));


;// CONCATENATED MODULE: ./src/config/abi/weth.json
const weth_namespaceObject = [];
// EXTERNAL MODULE: ./src/config/abi/Multicall.json
var Multicall = __webpack_require__(3373);
// EXTERNAL MODULE: ./src/utils/index.ts + 1 modules
var utils = __webpack_require__(8328);
;// CONCATENATED MODULE: ./src/hooks/useContract.ts














/**
 * Helper hooks to get specific contracts (by ABI)
 */ const useIfoV1Contract = (address)=>{
    const { library  } = useActiveWeb3React();
    return useMemo(()=>getIfoV1Contract(address, library.getSigner())
    , [
        address,
        library
    ]);
};
const useIfoV2Contract = (address)=>{
    const { library  } = useActiveWeb3React();
    return useMemo(()=>getIfoV2Contract(address, library.getSigner())
    , [
        address,
        library
    ]);
};
const useERC20 = (address, withSignerIfPossible = true)=>{
    const { library , account  } = useActiveWeb3React();
    return useMemo(()=>getBep20Contract(address, withSignerIfPossible ? getProviderOrSigner(library, account) : null)
    , [
        account,
        address,
        library,
        withSignerIfPossible
    ]);
};
/**
 * @see https://docs.openzeppelin.com/contracts/3.x/api/token/erc721
 */ const useERC721 = (address)=>{
    const { library  } = useActiveWeb3React();
    return useMemo(()=>getErc721Contract(address, library.getSigner())
    , [
        address,
        library
    ]);
};
const useCake = ()=>{
    const { library  } = useActiveWeb3React();
    return useMemo(()=>getCakeContract(library.getSigner())
    , [
        library
    ]);
};
const useBunnyFactory = ()=>{
    const { library  } = useActiveWeb3React();
    return useMemo(()=>getBunnyFactoryContract(library.getSigner())
    , [
        library
    ]);
};
const usePancakeRabbits = ()=>{
    const { library  } = useActiveWeb3React();
    return useMemo(()=>getPancakeRabbitContract(library.getSigner())
    , [
        library
    ]);
};
const useProfileContract = (withSignerIfPossible = true)=>{
    const { library , account  } = useActiveWeb3React();
    return useMemo(()=>getProfileContract(withSignerIfPossible ? getProviderOrSigner(library, account) : null)
    , [
        withSignerIfPossible,
        account,
        library
    ]);
};
const useLotteryV2Contract = ()=>{
    const { library  } = useActiveWeb3React();
    return useMemo(()=>getLotteryV2Contract(library.getSigner())
    , [
        library
    ]);
};
const useMasterchef = ()=>{
    const { library  } = useActiveWeb3React();
    return useMemo(()=>getMasterchefContract(library.getSigner())
    , [
        library
    ]);
};
const useSousChef = (id)=>{
    const { library  } = useActiveWeb3React();
    return useMemo(()=>getSouschefContract(id, library.getSigner())
    , [
        id,
        library
    ]);
};
const useSousChefV2 = (id)=>{
    const { library  } = useActiveWeb3React();
    return useMemo(()=>getSouschefV2Contract(id, library.getSigner())
    , [
        id,
        library
    ]);
};
const usePointCenterIfoContract = ()=>{
    const { library  } = useActiveWeb3React();
    return useMemo(()=>getPointCenterIfoContract(library.getSigner())
    , [
        library
    ]);
};
const useBunnySpecialContract = ()=>{
    const { library  } = useActiveWeb3React();
    return useMemo(()=>getBunnySpecialContract(library.getSigner())
    , [
        library
    ]);
};
const useClaimRefundContract = ()=>{
    const { library  } = useActiveWeb3React();
    return useMemo(()=>getClaimRefundContract(library.getSigner())
    , [
        library
    ]);
};
const useTradingCompetitionContract = ()=>{
    const { library  } = useActiveWeb3React();
    return useMemo(()=>getTradingCompetitionContract(library.getSigner())
    , [
        library
    ]);
};
const useTradingCompetitionContractV2 = (withSignerIfPossible = true)=>{
    const { library , account  } = useActiveWeb3React();
    return useMemo(()=>getTradingCompetitionContractV2(withSignerIfPossible ? getProviderOrSigner(library, account) : null)
    , [
        library,
        withSignerIfPossible,
        account
    ]);
};
const useVaultPoolContract = (vaultKey)=>{
    const { library  } = useActiveWeb3React();
    return useMemo(()=>{
        return vaultKey === VaultKey.CakeVault ? getCakeVaultContract(library.getSigner()) : getIfoPoolContract(library.getSigner());
    }, [
        library,
        vaultKey
    ]);
};
const useCakeVaultContract = ()=>{
    const { library  } = useActiveWeb3React();
    return useMemo(()=>getCakeVaultContract(library.getSigner())
    , [
        library
    ]);
};
const useIfoPoolContract = ()=>{
    const { library  } = useActiveWeb3React();
    return useMemo(()=>getIfoPoolContract(library.getSigner())
    , [
        library
    ]);
};
const usePredictionsContract = ()=>{
    const { library  } = (0,hooks_useActiveWeb3React/* default */.Z)();
    return (0,external_react_.useMemo)(()=>(0,contractHelpers/* getPredictionsContract */.qi)(library.getSigner())
    , [
        library
    ]);
};
const useChainlinkOracleContract = ()=>{
    const { library  } = useActiveWeb3React();
    return useMemo(()=>getChainlinkOracleContract(library.getSigner())
    , [
        library
    ]);
};
const useSpecialBunnyCakeVaultContract = ()=>{
    const { library  } = useActiveWeb3React();
    return useMemo(()=>getBunnySpecialCakeVaultContract(library.getSigner())
    , [
        library
    ]);
};
const useSpecialBunnyPredictionContract = ()=>{
    const { library  } = useActiveWeb3React();
    return useMemo(()=>getBunnySpecialPredictionContract(library.getSigner())
    , [
        library
    ]);
};
const useBunnySpecialLotteryContract = ()=>{
    const { library  } = useActiveWeb3React();
    return useMemo(()=>getBunnySpecialLotteryContract(library.getSigner())
    , [
        library
    ]);
};
const useBunnySpecialXmasContract = ()=>{
    const { library  } = useActiveWeb3React();
    return useMemo(()=>getBunnySpecialXmasContract(library.getSigner())
    , [
        library
    ]);
};
const useAnniversaryAchievementContract = ()=>{
    const { library  } = useActiveWeb3React();
    return useMemo(()=>getAnniversaryAchievementContract(library.getSigner())
    , [
        library
    ]);
};
const usePancakeSquadContract = ()=>{
    const { library  } = useActiveWeb3React();
    return useMemo(()=>getPancakeSquadContract(library.getSigner())
    , [
        library
    ]);
};
const useFarmAuctionContract = (withSignerIfPossible = true)=>{
    const { account , library  } = useActiveWeb3React();
    return useMemo(()=>getFarmAuctionContract(withSignerIfPossible ? getProviderOrSigner(library, account) : null)
    , [
        library,
        account,
        withSignerIfPossible
    ]);
};
const useErc721CollectionContract = (collectionAddress, withSignerIfPossible = true)=>{
    const { library , account  } = useActiveWeb3React();
    return useMemo(()=>{
        return getErc721CollectionContract(withSignerIfPossible ? getProviderOrSigner(library, account) : null, collectionAddress);
    }, [
        account,
        library,
        collectionAddress,
        withSignerIfPossible
    ]);
};
// Code below migrated from Exchange useContract.ts
// returns null on errors
function useContract(address, ABI, withSignerIfPossible = true) {
    const { library , account  } = (0,hooks_useActiveWeb3React/* default */.Z)();
    return (0,external_react_.useMemo)(()=>{
        if (!address || !ABI || !library) return null;
        try {
            return (0,utils/* getContract */.uN)(address, ABI, withSignerIfPossible ? (0,utils/* getProviderOrSigner */.TY)(library, account) : null);
        } catch (error) {
            console.error('Failed to get contract', error);
            return null;
        }
    }, [
        address,
        ABI,
        library,
        withSignerIfPossible,
        account
    ]);
}
function useTokenContract(tokenAddress, withSignerIfPossible) {
    return useContract(tokenAddress, erc20, withSignerIfPossible);
}
function useWETHContract(withSignerIfPossible) {
    const { chainId  } = useActiveWeb3React();
    return useContract(chainId ? WETH[chainId].address : undefined, WETH_ABI, withSignerIfPossible);
}
function useENSRegistrarContract(withSignerIfPossible) {
    const { chainId  } = useActiveWeb3React();
    let address;
    if (chainId) {
        // eslint-disable-next-line default-case
        switch(chainId){
            case ChainId.MAINNET:
            case ChainId.TESTNET:
                address = '0x00000000000C2E074eC69A0dFb2997BA6C7d2e1e';
                break;
        }
    }
    return useContract(address, ENS_ABI, withSignerIfPossible);
}
function useENSResolverContract(address, withSignerIfPossible) {
    return useContract(address, ENS_PUBLIC_RESOLVER_ABI, withSignerIfPossible);
}
function useBytes32TokenContract(tokenAddress, withSignerIfPossible) {
    return useContract(tokenAddress, ERC20_BYTES32_ABI, withSignerIfPossible);
}
function usePairContract(pairAddress, withSignerIfPossible) {
    return useContract(pairAddress, IPancakePairABI, withSignerIfPossible);
}
function useMulticallContract() {
    return useContract((0,addressHelpers/* getMulticallAddress */.I8)(), Multicall, false);
}


/***/ }),

/***/ 5999:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useDebounce)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

// modified from https://usehooks.com/useDebounce/
function useDebounce(value, delay) {
    const { 0: debouncedValue , 1: setDebouncedValue  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(value);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        // Update debounced value after delay
        const handler = setTimeout(()=>{
            setDebouncedValue(value);
        }, delay);
        // Cancel the timeout if value changes (also on delay change or unmount)
        // This is how we prevent debounced value from updating if value is changed ...
        // .. within the delay period. Timeout gets cleared and restarted.
        return ()=>{
            clearTimeout(handler);
        };
    }, [
        value,
        delay
    ]);
    return debouncedValue;
};


/***/ }),

/***/ 2987:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var hooks_useAuth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1222);



const _binanceChainListener = async ()=>new Promise((resolve)=>Object.defineProperty(window, 'BinanceChain', {
            get () {
                return this.bsc;
            },
            set (bsc) {
                this.bsc = bsc;
                resolve();
            }
        })
    )
;
const useEagerConnect = ()=>{
    const { login  } = (0,hooks_useAuth__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)();
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        const connectorId = window.localStorage.getItem(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.connectorLocalStorageKey);
        if (connectorId) {
            const isConnectorBinanceChain = connectorId === _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.ConnectorNames.BSC;
            const isBinanceChainDefined = Reflect.has(window, 'BinanceChain');
            // Currently BSC extension doesn't always inject in time.
            // We must check to see if it exists, and if not, wait for it before proceeding.
            if (isConnectorBinanceChain && !isBinanceChainDefined) {
                _binanceChainListener().then(()=>login(connectorId)
                );
                return;
            }
            login(connectorId);
        }
    }, [
        login
    ]);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useEagerConnect);


/***/ }),

/***/ 8339:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ hooks_useFetchListCallback)
});

// EXTERNAL MODULE: external "@reduxjs/toolkit"
var toolkit_ = __webpack_require__(5184);
// EXTERNAL MODULE: external "@mdemouchy/sdk"
var sdk_ = __webpack_require__(2877);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: ./src/hooks/useActiveWeb3React.ts
var useActiveWeb3React = __webpack_require__(4011);
// EXTERNAL MODULE: ./src/state/lists/actions.ts
var actions = __webpack_require__(8412);
// EXTERNAL MODULE: external "@ethersproject/contracts"
var contracts_ = __webpack_require__(2792);
// EXTERNAL MODULE: external "@ethersproject/hash"
var hash_ = __webpack_require__(750);
;// CONCATENATED MODULE: ./src/utils/ENS/resolveENSContentHash.ts


const REGISTRAR_ABI = [
    {
        constant: true,
        inputs: [
            {
                name: 'node',
                type: 'bytes32'
            }, 
        ],
        name: 'resolver',
        outputs: [
            {
                name: 'resolverAddress',
                type: 'address'
            }, 
        ],
        payable: false,
        stateMutability: 'view',
        type: 'function'
    }, 
];
const REGISTRAR_ADDRESS = '0x00000000000C2E074eC69A0dFb2997BA6C7d2e1e';
const RESOLVER_ABI = [
    {
        constant: true,
        inputs: [
            {
                internalType: 'bytes32',
                name: 'node',
                type: 'bytes32'
            }, 
        ],
        name: 'contenthash',
        outputs: [
            {
                internalType: 'bytes',
                name: '',
                type: 'bytes'
            }, 
        ],
        payable: false,
        stateMutability: 'view',
        type: 'function'
    }, 
];
// cache the resolver contracts since most of them are the public resolver
function resolverContract(resolverAddress, provider) {
    return new contracts_.Contract(resolverAddress, RESOLVER_ABI, provider);
}
/**
 * Fetches and decodes the result of an ENS contenthash lookup on mainnet to a URI
 * @param ensName to resolve
 * @param provider provider to use to fetch the data
 */ async function resolveENSContentHash(ensName, provider) {
    const ensRegistrarContract = new contracts_.Contract(REGISTRAR_ADDRESS, REGISTRAR_ABI, provider);
    const hash = (0,hash_.namehash)(ensName);
    const resolverAddress = await ensRegistrarContract.resolver(hash);
    return resolverContract(resolverAddress, provider).contenthash(hash);
};

;// CONCATENATED MODULE: ./src/hooks/useFetchListCallback.ts








function useFetchListCallback() {
    const { library  } = (0,useActiveWeb3React/* default */.Z)();
    const { chainId  } = (0,useActiveWeb3React/* default */.Z)();
    const dispatch = (0,external_react_redux_.useDispatch)();
    const ensResolver = (0,external_react_.useCallback)((ensName)=>{
        if (chainId !== sdk_.ChainId.MAINNET) {
            throw new Error('Could not construct mainnet ENS resolver');
        }
        return resolveENSContentHash(ensName, library);
    }, [
        chainId,
        library
    ]);
    // note: prevent dispatch if using for list search or unsupported list
    return (0,external_react_.useCallback)(async (listUrl, sendDispatch = true)=>{
        const requestId = (0,toolkit_.nanoid)();
        if (sendDispatch) {
            dispatch(actions/* fetchTokenList.pending */.Dn.pending({
                requestId,
                url: listUrl
            }));
        }
        // lazy load avj and token list schema
        const getTokenList = (await Promise.all(/* import() */[__webpack_require__.e(475), __webpack_require__.e(432)]).then(__webpack_require__.bind(__webpack_require__, 4432))).default;
        return getTokenList(listUrl, ensResolver).then((tokenList)=>{
            if (sendDispatch) {
                dispatch(actions/* fetchTokenList.fulfilled */.Dn.fulfilled({
                    url: listUrl,
                    tokenList,
                    requestId
                }));
            }
            return tokenList;
        }).catch((error)=>{
            console.error(`Failed to get list at url ${listUrl}`, error);
            if (sendDispatch) {
                dispatch(actions/* fetchTokenList.rejected */.Dn.rejected({
                    url: listUrl,
                    requestId,
                    errorMessage: error.message
                }));
            }
            throw error;
        });
    }, [
        dispatch,
        ensResolver
    ]);
}
/* harmony default export */ const hooks_useFetchListCallback = (useFetchListCallback);


/***/ }),

/***/ 3353:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "f": () => (/* binding */ useInactiveListener)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _state__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4861);
/* harmony import */ var _utils_clearUserStates__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8382);




const useInactiveListener = ()=>{
    const { account , chainId , connector  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_1__.useWeb3React)();
    const dispatch = (0,_state__WEBPACK_IMPORTED_MODULE_2__/* .useAppDispatch */ .TL)();
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        if (account && connector) {
            const handleDeactivate = ()=>{
                (0,_utils_clearUserStates__WEBPACK_IMPORTED_MODULE_3__/* .clearUserStates */ .J)(dispatch, chainId);
            };
            connector.addListener('Web3ReactDeactivate', handleDeactivate);
            return ()=>{
                connector.removeListener('Web3ReactDeactivate', handleDeactivate);
            };
        }
        return undefined;
    }, [
        account,
        chainId,
        dispatch,
        connector
    ]);
};


/***/ }),

/***/ 6159:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useInterval)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

function useInterval(callback, delay, leading = true) {
    const savedCallback = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
    // Remember the latest callback.
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        savedCallback.current = callback;
    }, [
        callback
    ]);
    // Set up the interval.
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        function tick() {
            const { current  } = savedCallback;
            if (current) {
                current();
            }
        }
        if (delay !== null) {
            if (leading) tick();
            const id = setInterval(tick, delay);
            return ()=>clearInterval(id)
            ;
        }
        return undefined;
    }, [
        delay,
        leading
    ]);
};


/***/ }),

/***/ 4587:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useIsWindowVisible)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

function isWindowVisible() {
    if (!(typeof document !== 'undefined' && 'visibilityState' in document)) {
        return true;
    }
    return document.visibilityState === 'visible';
}
/**
 * Returns whether the window is currently visible to the user.
 */ function useIsWindowVisible() {
    const { 0: isVisible , 1: setIsVisible  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(isWindowVisible());
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        if (!('visibilityState' in document)) return undefined;
        const handleVisibilityChange = ()=>{
            setIsVisible(isWindowVisible());
        };
        document.addEventListener('visibilitychange', handleVisibilityChange);
        return ()=>{
            document.removeEventListener('visibilitychange', handleVisibilityChange);
        };
    }, [
        setIsVisible
    ]);
    return isVisible;
};


/***/ }),

/***/ 4915:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "_G": () => (/* binding */ PairState),
/* harmony export */   "z$": () => (/* binding */ usePairs)
/* harmony export */ });
/* unused harmony export usePair */
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2877);
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var config_abi_IPancakePair_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3725);
/* harmony import */ var _ethersproject_abi__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6187);
/* harmony import */ var _ethersproject_abi__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_abi__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4011);
/* harmony import */ var _state_multicall_hooks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1001);
/* harmony import */ var _utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3854);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_5__]);
_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];







const PAIR_INTERFACE = new _ethersproject_abi__WEBPACK_IMPORTED_MODULE_3__.Interface(config_abi_IPancakePair_json__WEBPACK_IMPORTED_MODULE_2__);
var PairState;
(function(PairState) {
    PairState[PairState["LOADING"] = 0] = "LOADING";
    PairState[PairState["NOT_EXISTS"] = 1] = "NOT_EXISTS";
    PairState[PairState["EXISTS"] = 2] = "EXISTS";
    PairState[PairState["INVALID"] = 3] = "INVALID";
})(PairState || (PairState = {}));
function usePairs(currencies) {
    const { chainId  } = (0,hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)();
    const tokens = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>currencies.map(([currencyA, currencyB])=>[
                (0,_utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_6__/* .wrappedCurrency */ .pu)(currencyA, chainId),
                (0,_utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_6__/* .wrappedCurrency */ .pu)(currencyB, chainId), 
            ]
        )
    , [
        chainId,
        currencies
    ]);
    const pairAddresses = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>tokens.map(([tokenA, tokenB])=>{
            return tokenA && tokenB && !tokenA.equals(tokenB) ? _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.Pair.getAddress(tokenA, tokenB) : undefined;
        })
    , [
        tokens
    ]);
    const results = (0,_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_5__/* .useMultipleContractSingleData */ ._Y)(pairAddresses, PAIR_INTERFACE, 'getReserves');
    return (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        return results.map((result, i)=>{
            const { result: reserves , loading  } = result;
            const tokenA = tokens[i][0];
            const tokenB = tokens[i][1];
            if (loading) return [
                PairState.LOADING,
                null
            ];
            if (!tokenA || !tokenB || tokenA.equals(tokenB)) return [
                PairState.INVALID,
                null
            ];
            if (!reserves) return [
                PairState.NOT_EXISTS,
                null
            ];
            const { reserve0 , reserve1  } = reserves;
            const [token0, token1] = tokenA.sortsBefore(tokenB) ? [
                tokenA,
                tokenB
            ] : [
                tokenB,
                tokenA
            ];
            return [
                PairState.EXISTS,
                new _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.Pair(new _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.TokenAmount(token0, reserve0.toString()), new _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.TokenAmount(token1, reserve1.toString())), 
            ];
        });
    }, [
        results,
        tokens
    ]);
}
function usePair(tokenA, tokenB) {
    return usePairs([
        [
            tokenA,
            tokenB
        ]
    ])[0];
}

});

/***/ }),

/***/ 7892:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "X": () => (/* binding */ useSlowRefreshEffect)
/* harmony export */ });
/* unused harmony export useFastRefreshEffect */
/* harmony import */ var config_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1311);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5941);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swr__WEBPACK_IMPORTED_MODULE_2__]);
swr__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];



function useFastRefreshEffect(effect, deps) {
    const { data =0  } = useSWR([
        FAST_INTERVAL,
        'blockNumber'
    ]);
    const depsMemo = useMemo(()=>[
            data,
            ...deps || []
        ]
    , [
        data,
        deps
    ]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    useEffect(effect, depsMemo);
}
function useSlowRefreshEffect(effect, deps) {
    const { data =0  } = (0,swr__WEBPACK_IMPORTED_MODULE_2__["default"])([
        config_constants__WEBPACK_IMPORTED_MODULE_0__/* .SLOW_INTERVAL */ .KI,
        'blockNumber'
    ]);
    const depsMemo = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>[
            data,
            ...deps || []
        ]
    , [
        data,
        deps
    ]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(effect, depsMemo);
}

});

/***/ }),

/***/ 8472:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "qf": () => (/* binding */ fetchStatusMiddleware),
/* harmony export */   "Av": () => (/* binding */ useSWRContract)
/* harmony export */ });
/* unused harmony exports immutableMiddleware, useSWRMulticall, loggerMiddleware */
/* harmony import */ var config_constants_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7971);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ethersproject_abi__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6187);
/* harmony import */ var _ethersproject_abi__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_abi__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5941);
/* harmony import */ var utils_multicall__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1144);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swr__WEBPACK_IMPORTED_MODULE_3__]);
swr__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];
/* eslint-disable no-param-reassign */ 




const fetchStatusMiddleware = (useSWRNext)=>{
    return (key, fetcher, config)=>{
        const swr = useSWRNext(key, fetcher, config);
        let status = config_constants_types__WEBPACK_IMPORTED_MODULE_0__/* .FetchStatus.Idle */ .iF.Idle;
        if (!swr.isValidating && !swr.error && !swr.data) {
            status = config_constants_types__WEBPACK_IMPORTED_MODULE_0__/* .FetchStatus.Idle */ .iF.Idle;
        } else if (swr.isValidating && !swr.error && !swr.data) {
            status = config_constants_types__WEBPACK_IMPORTED_MODULE_0__/* .FetchStatus.Fetching */ .iF.Fetching;
        } else if (swr.data) {
            status = config_constants_types__WEBPACK_IMPORTED_MODULE_0__/* .FetchStatus.Fetched */ .iF.Fetched;
        } else if (swr.error && !swr.data) {
            status = config_constants_types__WEBPACK_IMPORTED_MODULE_0__/* .FetchStatus.Failed */ .iF.Failed;
        }
        return {
            status,
            ...swr
        };
    };
};
const getContractKey = (key)=>{
    if (Array.isArray(key)) {
        const [contract, methodName, params] = key || [];
        return {
            contract,
            methodName,
            params
        };
    }
    return key;
};
const serializesContractKey = (key)=>{
    const { contract , methodName , params  } = getContractKey(key) || {};
    const serializedKeys = key && contract && methodName ? {
        address: contract.address,
        interfaceFormat: contract.interface.format(_ethersproject_abi__WEBPACK_IMPORTED_MODULE_2__.FormatTypes.full),
        methodName,
        callData: contract.interface.encodeFunctionData(methodName, params)
    } : null;
    return serializedKeys;
};
/**
 * @example
 * const key = [contract, 'methodName', [params]]
 * const key = { contract, methodName, params }
 * const { data, error, mutate } = useSWRContract(key)
 */ function useSWRContract(key, config = {}) {
    const { contract , methodName , params  } = getContractKey(key) || {};
    const serializedKeys = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>serializesContractKey(key)
    , [
        key
    ]);
    return (0,swr__WEBPACK_IMPORTED_MODULE_3__["default"])(serializedKeys, async ()=>{
        if (!contract || !methodName) return null;
        if (!params) return contract[methodName]();
        return contract[methodName](...params);
    }, config);
}
const immutableMiddleware = (useSWRNext)=>(key, fetcher, config)=>{
        config.revalidateOnFocus = false;
        config.revalidateIfStale = false;
        config.revalidateOnReconnect = false;
        return useSWRNext(key, fetcher, config);
    }
;
function useSWRMulticall(abi, calls, options = {
    requireSuccess: true
}) {
    return useSWR(calls, ()=>multicallv2(abi, calls, options)
    , {
        revalidateIfStale: false,
        revalidateOnFocus: false
    });
}
// dev only
const loggerMiddleware = (useSWRNext)=>{
    return (key, fetcher, config)=>{
        // Add logger to the original fetcher.
        const extendedFetcher = fetcher ? (...args)=>{
            console.debug('SWR Request:', key);
            return fetcher(...args);
        } : null;
        // Execute the hook with the new fetcher.
        return useSWRNext(key, extendedFetcher, config);
    };
};

});

/***/ }),

/***/ 9667:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _sentry_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5427);
/* harmony import */ var _sentry_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_sentry_react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _useActiveWeb3React__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4011);



function useSentryUser() {
    const { account  } = (0,_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (account) {
            _sentry_react__WEBPACK_IMPORTED_MODULE_0__.setUser({
                account
            });
        }
    }, [
        account
    ]);
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useSentryUser);


/***/ }),

/***/ 9901:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "r": () => (/* binding */ SubgraphStatus),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var graphql_request__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5805);
/* harmony import */ var graphql_request__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(graphql_request__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var config_constants_endpoints__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5906);
/* harmony import */ var utils_providers__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5922);
/* harmony import */ var _useRefreshEffect__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7892);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_useRefreshEffect__WEBPACK_IMPORTED_MODULE_4__]);
_useRefreshEffect__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];





var SubgraphStatus;
(function(SubgraphStatus) {
    SubgraphStatus[SubgraphStatus["OK"] = 0] = "OK";
    SubgraphStatus[SubgraphStatus["WARNING"] = 1] = "WARNING";
    SubgraphStatus[SubgraphStatus["NOT_OK"] = 2] = "NOT_OK";
    SubgraphStatus[SubgraphStatus["UNKNOWN"] = 3] = "UNKNOWN";
})(SubgraphStatus || (SubgraphStatus = {}));
const NOT_OK_BLOCK_DIFFERENCE = 200 // ~15 minutes delay
;
const WARNING_BLOCK_DIFFERENCE = 50 // ~2.5 minute delay
;
const useSubgraphHealth = ()=>{
    const { 0: sgHealth , 1: setSgHealth  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({
        status: SubgraphStatus.UNKNOWN,
        currentBlock: 0,
        chainHeadBlock: 0,
        latestBlock: 0,
        blockDifference: 0
    });
    (0,_useRefreshEffect__WEBPACK_IMPORTED_MODULE_4__/* .useSlowRefreshEffect */ .X)(()=>{
        const getSubgraphHealth = async ()=>{
            try {
                const { indexingStatusForCurrentVersion  } = await (0,graphql_request__WEBPACK_IMPORTED_MODULE_1__.request)(config_constants_endpoints__WEBPACK_IMPORTED_MODULE_2__/* .GRAPH_HEALTH */ .AM, graphql_request__WEBPACK_IMPORTED_MODULE_1__.gql`
            query getNftMarketSubgraphHealth {
              indexingStatusForCurrentVersion(subgraphName: "pancakeswap/nft-market") {
                synced
                health
                chains {
                  chainHeadBlock {
                    number
                  }
                  latestBlock {
                    number
                  }
                }
              }
            }
          `);
                const currentBlock = await utils_providers__WEBPACK_IMPORTED_MODULE_3__/* .simpleRpcProvider.getBlockNumber */ .J.getBlockNumber();
                const isHealthy = indexingStatusForCurrentVersion.health === 'healthy';
                const chainHeadBlock = parseInt(indexingStatusForCurrentVersion.chains[0].chainHeadBlock.number);
                const latestBlock = parseInt(indexingStatusForCurrentVersion.chains[0].latestBlock.number);
                const blockDifference = currentBlock - latestBlock;
                // Sometimes subgraph might report old block as chainHeadBlock, so its important to compare
                // it with block retrieved from simpleRpcProvider.getBlockNumber()
                const chainHeadBlockDifference = currentBlock - chainHeadBlock;
                if (!isHealthy || blockDifference > NOT_OK_BLOCK_DIFFERENCE || chainHeadBlockDifference > NOT_OK_BLOCK_DIFFERENCE) {
                    setSgHealth({
                        status: SubgraphStatus.NOT_OK,
                        currentBlock,
                        chainHeadBlock,
                        latestBlock,
                        blockDifference
                    });
                } else if (blockDifference > WARNING_BLOCK_DIFFERENCE || chainHeadBlockDifference > WARNING_BLOCK_DIFFERENCE) {
                    setSgHealth({
                        status: SubgraphStatus.WARNING,
                        currentBlock,
                        chainHeadBlock,
                        latestBlock,
                        blockDifference
                    });
                } else {
                    setSgHealth({
                        status: SubgraphStatus.OK,
                        currentBlock,
                        chainHeadBlock,
                        latestBlock,
                        blockDifference
                    });
                }
            } catch (error) {
                console.error('Failed to perform health check for NFT Market subgraph', error);
            }
        };
        getSubgraphHealth();
    }, []);
    return sgHealth;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useSubgraphHealth);

});

/***/ }),

/***/ 3917:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var state_user_hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8605);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([state_user_hooks__WEBPACK_IMPORTED_MODULE_2__]);
state_user_hooks__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];



const useTheme = ()=>{
    const [isDark, toggleTheme] = (0,state_user_hooks__WEBPACK_IMPORTED_MODULE_2__/* .useThemeManager */ .HY)();
    const theme = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(styled_components__WEBPACK_IMPORTED_MODULE_1__.ThemeContext);
    return {
        isDark,
        theme,
        toggleTheme
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useTheme);

});

/***/ }),

/***/ 789:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var contexts_ToastsContext__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5083);


const useToast = ()=>{
    const toastContext = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(contexts_ToastsContext__WEBPACK_IMPORTED_MODULE_1__/* .ToastsContext */ .iv);
    if (toastContext === undefined) {
        throw new Error('Toasts context undefined');
    }
    return toastContext;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useToast);


/***/ }),

/***/ 4319:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "nu": () => (/* binding */ useGetBnbBalance),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports useTotalSupply, useBurnedBalance, useGetCakeBalance */
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4215);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(bignumber_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var config_constants_tokens__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9748);
/* harmony import */ var config_constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1311);
/* harmony import */ var _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5757);
/* harmony import */ var _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _ethersproject_constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6644);
/* harmony import */ var _ethersproject_constants__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_constants__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5941);
/* harmony import */ var utils_bigNumber__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5128);
/* harmony import */ var utils_providers__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5922);
/* harmony import */ var _useContract__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5882);
/* harmony import */ var _useSWRContract__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8472);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swr__WEBPACK_IMPORTED_MODULE_6__, _useSWRContract__WEBPACK_IMPORTED_MODULE_10__]);
([swr__WEBPACK_IMPORTED_MODULE_6__, _useSWRContract__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);











const useTokenBalance = (tokenAddress)=>{
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_0__.useWeb3React)();
    const contract = (0,_useContract__WEBPACK_IMPORTED_MODULE_9__/* .useTokenContract */ .Ib)(tokenAddress, false);
    const { data , status , ...rest } = (0,_useSWRContract__WEBPACK_IMPORTED_MODULE_10__/* .useSWRContract */ .Av)(account ? {
        contract,
        methodName: 'balanceOf',
        params: [
            account
        ]
    } : null, {
        refreshInterval: config_constants__WEBPACK_IMPORTED_MODULE_3__/* .FAST_INTERVAL */ .sR
    });
    return {
        ...rest,
        fetchStatus: status,
        balance: data ? new (bignumber_js__WEBPACK_IMPORTED_MODULE_1___default())(data.toString()) : utils_bigNumber__WEBPACK_IMPORTED_MODULE_7__/* .BIG_ZERO */ .HW
    };
};
const useTotalSupply = ()=>{
    const cakeContract = useCake();
    const { data  } = useSWRContract([
        cakeContract,
        'totalSupply'
    ], {
        refreshInterval: SLOW_INTERVAL
    });
    return data ? new BigNumber(data.toString()) : null;
};
const useBurnedBalance = (tokenAddress)=>{
    const contract = useTokenContract(tokenAddress, false);
    const { data  } = useSWRContract([
        contract,
        'balanceOf',
        [
            '0x000000000000000000000000000000000000dEaD'
        ]
    ], {
        refreshInterval: SLOW_INTERVAL
    });
    return data ? new BigNumber(data.toString()) : BIG_ZERO;
};
const useGetBnbBalance = ()=>{
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_0__.useWeb3React)();
    const { status , data , mutate  } = (0,swr__WEBPACK_IMPORTED_MODULE_6__["default"])([
        account,
        'bnbBalance'
    ], async ()=>{
        return utils_providers__WEBPACK_IMPORTED_MODULE_8__/* .simpleRpcProvider.getBalance */ .J.getBalance(account);
    });
    return {
        balance: data || _ethersproject_constants__WEBPACK_IMPORTED_MODULE_5__.Zero,
        fetchStatus: status,
        refresh: mutate
    };
};
const useGetCakeBalance = ()=>{
    const { balance , fetchStatus  } = useTokenBalance(tokens.cake.address);
    // TODO: Remove ethers conversion once useTokenBalance is converted to ethers.BigNumber
    return {
        balance: EthersBigNumber.from(balance.toString()),
        fetchStatus
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useTokenBalance);

});

/***/ }),

/***/ 7604:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const useUserAgent = ()=>{
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        document.documentElement.setAttribute('data-useragent', navigator.userAgent);
    }, []);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useUserAgent);


/***/ }),

/***/ 8677:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "y": () => (/* binding */ Updaters),
/* harmony export */   "P": () => (/* binding */ Blocklist)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _config_constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1311);
/* harmony import */ var _hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4011);
/* harmony import */ var _state_lists_updater__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6681);
/* harmony import */ var _state_multicall_updater__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1710);
/* harmony import */ var _state_transactions_updater__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6573);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_state_multicall_updater__WEBPACK_IMPORTED_MODULE_5__, _state_transactions_updater__WEBPACK_IMPORTED_MODULE_6__, _state_lists_updater__WEBPACK_IMPORTED_MODULE_4__]);
([_state_multicall_updater__WEBPACK_IMPORTED_MODULE_5__, _state_transactions_updater__WEBPACK_IMPORTED_MODULE_6__, _state_lists_updater__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);







function Updaters() {
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_state_lists_updater__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_state_transactions_updater__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_state_multicall_updater__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP, {})
        ]
    }));
}
function Blocklist({ children  }) {
    const { account  } = (0,_hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)();
    const blocked = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>Boolean(account && _config_constants__WEBPACK_IMPORTED_MODULE_2__/* .BLOCKED_ADDRESSES.indexOf */ .mj.indexOf(account) !== -1)
    , [
        account
    ]);
    if (blocked) {
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            children: "Blocked address"
        }));
    }
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: children
    }));
}

});

/***/ }),

/***/ 9622:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _views_NotFound__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2006);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_views_NotFound__WEBPACK_IMPORTED_MODULE_0__]);
_views_NotFound__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_views_NotFound__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);

});

/***/ }),

/***/ 2957:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_script__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4780);
/* harmony import */ var next_script__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_script__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4215);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(bignumber_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var components_EasterEgg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6301);
/* harmony import */ var components_GlobalCheckClaimStatus__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7580);
/* harmony import */ var components_SubgraphHealthIndicator__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2606);
/* harmony import */ var contexts_ToastsContext__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5083);
/* harmony import */ var hooks_useEagerConnect__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2987);
/* harmony import */ var hooks_useInactiveListener__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3353);
/* harmony import */ var hooks_useSentryUser__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9667);
/* harmony import */ var hooks_useUserAgent__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7604);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var redux_persist_integration_react__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(1127);
/* harmony import */ var redux_persist_integration_react__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(redux_persist_integration_react__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var state__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(4861);
/* harmony import */ var state_block_hooks__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(7063);
/* harmony import */ var state_profile_hooks__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(9424);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(8677);
/* harmony import */ var _components_ErrorBoundary__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(3408);
/* harmony import */ var _components_Menu__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(2485);
/* harmony import */ var _Providers__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(3442);
/* harmony import */ var _style_Global__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(1055);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([components_SubgraphHealthIndicator__WEBPACK_IMPORTED_MODULE_6__, _components_Menu__WEBPACK_IMPORTED_MODULE_20__, _components_ErrorBoundary__WEBPACK_IMPORTED_MODULE_19__, ___WEBPACK_IMPORTED_MODULE_18__, _Providers__WEBPACK_IMPORTED_MODULE_21__, state_profile_hooks__WEBPACK_IMPORTED_MODULE_17__, state_block_hooks__WEBPACK_IMPORTED_MODULE_16__]);
([components_SubgraphHealthIndicator__WEBPACK_IMPORTED_MODULE_6__, _components_Menu__WEBPACK_IMPORTED_MODULE_20__, _components_ErrorBoundary__WEBPACK_IMPORTED_MODULE_19__, ___WEBPACK_IMPORTED_MODULE_18__, _Providers__WEBPACK_IMPORTED_MODULE_21__, state_profile_hooks__WEBPACK_IMPORTED_MODULE_17__, state_block_hooks__WEBPACK_IMPORTED_MODULE_16__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);























// This config is required for number formatting
bignumber_js__WEBPACK_IMPORTED_MODULE_3___default().config({
    EXPONENTIAL_AT: 1000,
    DECIMAL_PLACES: 80
});
function GlobalHooks() {
    (0,state_block_hooks__WEBPACK_IMPORTED_MODULE_16__/* .usePollBlockNumber */ .hd)();
    (0,hooks_useEagerConnect__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
    (0,state_profile_hooks__WEBPACK_IMPORTED_MODULE_17__/* .useFetchProfile */ .Q5)();
    (0,hooks_useUserAgent__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z)();
    (0,hooks_useInactiveListener__WEBPACK_IMPORTED_MODULE_9__/* .useInactiveListener */ .f)();
    (0,hooks_useSentryUser__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)();
    return null;
}
function MyApp(props) {
    const { pageProps  } = props;
    const store = (0,state__WEBPACK_IMPORTED_MODULE_15__/* .useStore */ .oR)(pageProps.initialReduxState);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_12___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1, maximum-scale=5, minimum-scale=1, viewport-fit=cover"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "description",
                        content: "Cheaper and faster than Uniswap? Discover PancakeSwap, the leading DEX on Binance Smart Chain (BSC) with the best farms in DeFi and a lottery for CAKE."
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "theme-color",
                        content: "#1FC7D4"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "twitter:image",
                        content: "https://pancakeswap.finance/images/hero.png"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "twitter:description",
                        content: "The most popular AMM on BSC! Earn CAKE through yield farming or win it in the Lottery, then stake it in Syrup Pools to earn more tokens! Initial Farm Offerings (new token launch model pioneered by PancakeSwap), NFTs, and more, on a platform you can trust."
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "twitter:card",
                        content: "summary_large_image"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "twitter:title",
                        content: "🥞 PancakeSwap - A next evolution DeFi exchange on Binance Smart Chain (BSC)"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: "PancakeSwap"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Providers__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .Z, {
                store: store,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(___WEBPACK_IMPORTED_MODULE_18__/* .Blocklist */ .P, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(GlobalHooks, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(___WEBPACK_IMPORTED_MODULE_18__/* .Updaters */ .y, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.ResetCSS, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_style_Global__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .Z, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_GlobalCheckClaimStatus__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            excludeLocations: []
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(redux_persist_integration_react__WEBPACK_IMPORTED_MODULE_14__.PersistGate, {
                            loading: null,
                            persistor: state__WEBPACK_IMPORTED_MODULE_15__/* .persistor */ .Dj,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(App, {
                                ...props
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_script__WEBPACK_IMPORTED_MODULE_2___default()), {
                strategy: "afterInteractive",
                id: "google-tag",
                dangerouslySetInnerHTML: {
                    __html: `
            (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
            new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
            j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
            'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
            })(window,document,'script','dataLayer', '${"GTM-PXLD3XW"}');
          `
                }
            })
        ]
    }));
}
const App = ({ Component , pageProps  })=>{
    // Use the layout defined at the page level, if available
    const Layout = Component.Layout || react__WEBPACK_IMPORTED_MODULE_13__.Fragment;
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ErrorBoundary__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Menu__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Layout, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                        ...pageProps
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_EasterEgg__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                iterations: 2
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(contexts_ToastsContext__WEBPACK_IMPORTED_MODULE_7__/* .ToastListener */ .IG, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_SubgraphHealthIndicator__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);

});

/***/ }),

/***/ 5641:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_document__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6859);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var utils_getRpcUrl__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7308);

/* eslint-disable jsx-a11y/iframe-has-title */ 



class MyDocument extends next_document__WEBPACK_IMPORTED_MODULE_1__["default"] {
    static async getInitialProps(ctx) {
        const sheet = new styled_components__WEBPACK_IMPORTED_MODULE_2__.ServerStyleSheet();
        const originalRenderPage = ctx.renderPage;
        try {
            // eslint-disable-next-line no-param-reassign
            ctx.renderPage = ()=>originalRenderPage({
                    enhanceApp: (App)=>(props)=>sheet.collectStyles(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(App, {
                                ...props
                            }))
                })
            ;
            const initialProps = await next_document__WEBPACK_IMPORTED_MODULE_1__["default"].getInitialProps(ctx);
            return {
                ...initialProps,
                styles: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: [
                        initialProps.styles,
                        sheet.getStyleElement()
                    ]
                })
            };
        } finally{
            sheet.seal();
        }
    }
    render() {
        return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(next_document__WEBPACK_IMPORTED_MODULE_1__.Html, {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(next_document__WEBPACK_IMPORTED_MODULE_1__.Head, {
                    children: [
                        utils_getRpcUrl__WEBPACK_IMPORTED_MODULE_4__/* .nodes.map */ .t.map((node)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                                rel: "preconnect",
                                href: node
                            }, node)
                        ),
                        process.env.NEXT_PUBLIC_NODE_PRODUCTION && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                            rel: "preconnect",
                            href: process.env.NEXT_PUBLIC_NODE_PRODUCTION
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                            rel: "preconnect",
                            href: "https://fonts.gstatic.com"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                            href: "https://fonts.googleapis.com/css2?family=Kanit:wght@400;600&display=swap",
                            rel: "stylesheet"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                            rel: "shortcut icon",
                            href: "/favicon.ico"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                            rel: "apple-touch-icon",
                            href: "/logo.png"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                            rel: "manifest",
                            href: "/manifest.json"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("body", {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("noscript", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("iframe", {
                                src: `https://www.googletagmanager.com/ns.html?id=${"GTM-PXLD3XW"}`,
                                height: "0",
                                width: "0",
                                style: {
                                    display: 'none',
                                    visibility: 'hidden'
                                }
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_document__WEBPACK_IMPORTED_MODULE_1__.Main, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_document__WEBPACK_IMPORTED_MODULE_1__.NextScript, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            id: "portal-root"
                        })
                    ]
                })
            ]
        }));
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyDocument);


/***/ }),

/***/ 4141:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_error__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5566);
/* harmony import */ var next_error__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_error__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _sentry_nextjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8097);
/* harmony import */ var _sentry_nextjs__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_sentry_nextjs__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _views_NotFound__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2006);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_views_NotFound__WEBPACK_IMPORTED_MODULE_4__]);
_views_NotFound__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];





const MyError = ({ hasGetInitialPropsRun , err  })=>{
    if (!hasGetInitialPropsRun && err) {
        // getInitialProps is not called in case of
        // https://github.com/vercel/next.js/issues/8592. As a workaround, we pass
        // err via _app.js so it can be captured
        _sentry_nextjs__WEBPACK_IMPORTED_MODULE_3__.captureException(err);
    // Flushing is not required in this case as it only happens on the client
    }
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_views_NotFound__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {}));
};
MyError.getInitialProps = async (context)=>{
    const errorInitialProps = await next_error__WEBPACK_IMPORTED_MODULE_1___default().getInitialProps(context);
    const { res , err , asPath  } = context;
    // Workaround for https://github.com/vercel/next.js/issues/8592, mark when
    // getInitialProps has run
    // @ts-ignore
    errorInitialProps.hasGetInitialPropsRun = true;
    // Returning early because we don't want to log 404 errors to Sentry.
    if (res?.statusCode === 404) {
        return errorInitialProps;
    }
    // Running on the server, the response object (`res`) is available.
    //
    // Next.js will pass an err on the server if a page's data fetching methods
    // threw or returned a Promise that rejected
    //
    // Running on the client (browser), Next.js will provide an err if:
    //
    //  - a page's `getInitialProps` threw or returned a Promise that rejected
    //  - an exception was thrown somewhere in the React lifecycle (render,
    //    componentDidMount, etc) that was caught by Next.js's React Error
    //    Boundary. Read more about what types of exceptions are caught by Error
    //    Boundaries: https://reactjs.org/docs/error-boundaries.html
    if (err) {
        _sentry_nextjs__WEBPACK_IMPORTED_MODULE_3__.captureException(err);
        // Flushing before returning is necessary if deploying to Vercel, see
        // https://vercel.com/docs/platform/limits#streaming-responses
        await _sentry_nextjs__WEBPACK_IMPORTED_MODULE_3__.flush(2000);
        return errorInitialProps;
    }
    // If this point is reached, getInitialProps was called without any
    // information about what the error might be. This is unexpected and may
    // indicate a bug introduced in Next.js, so record it in Sentry
    _sentry_nextjs__WEBPACK_IMPORTED_MODULE_3__.captureException(new Error(`_error.js getInitialProps missing data at path: ${asPath}`));
    await _sentry_nextjs__WEBPACK_IMPORTED_MODULE_3__.flush(2000);
    return errorInitialProps;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyError);

});

/***/ }),

/***/ 8543:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {


// UNUSED EXPORTS: getAchievements, getUserPointIncreaseEvents

// EXTERNAL MODULE: external "graphql-request"
var external_graphql_request_ = __webpack_require__(5805);
;// CONCATENATED MODULE: ./src/config/constants/campaigns.ts
/**
 * id: The campaign id (required)
 * type: The type of the achievement
 * title: A string or an object to be translated.
 * Note: If the value is a string it is likely used as data in a translation object
 *
 * badge: Achievement avatar
 */ const campaigns = [
    {
        id: '511110000',
        type: 'ifo',
        title: 'Kalmar',
        badge: 'ifo-kalm.svg'
    },
    {
        id: '511100000',
        type: 'ifo',
        title: 'Hotcross',
        badge: 'ifo-hotcross.svg'
    },
    {
        id: '511090000',
        type: 'ifo',
        title: 'Horizon Protocol',
        badge: 'ifo-hzn.svg'
    },
    {
        id: '511080000',
        type: 'ifo',
        title: 'Belt',
        badge: 'ifo-belt.svg'
    },
    {
        id: '511070000',
        type: 'ifo',
        title: 'Yieldwatch',
        badge: 'ifo-watch.svg'
    },
    {
        id: '511060000',
        type: 'ifo',
        title: 'Berry',
        badge: 'ifo-bry.svg'
    },
    {
        id: '511050000',
        type: 'ifo',
        title: 'Soteria',
        badge: 'ifo-wsote.svg'
    },
    {
        id: '511040000',
        type: 'ifo',
        title: 'Helmet',
        badge: 'ifo-helmet.svg'
    },
    {
        id: '511030000',
        type: 'ifo',
        title: 'Tenet',
        badge: 'ifo-ten.svg'
    },
    {
        id: '511020000',
        type: 'ifo',
        title: 'Ditto',
        badge: 'ifo-ditto.svg'
    },
    {
        id: '511010000',
        type: 'ifo',
        title: 'Blink',
        badge: 'ifo-blink.svg'
    },
    {
        id: '512010001',
        type: 'teambattle',
        title: 'Easter Champion: Gold',
        badge: 'easter-champion-gold.svg'
    },
    {
        id: '512010002',
        type: 'teambattle',
        title: 'Easter Top 500: Gold',
        badge: 'easter-top-500-gold.svg'
    },
    {
        id: '512010003',
        type: 'teambattle',
        title: 'Easter Top 500: Gold',
        badge: 'easter-top-500-gold.svg'
    },
    {
        id: '512010004',
        type: 'teambattle',
        title: 'Easter Top 500: Gold',
        badge: 'easter-top-500-gold.svg'
    },
    {
        id: '512010005',
        type: 'teambattle',
        title: 'Easter Participant: Gold',
        badge: 'easter-participant-gold.svg'
    },
    {
        id: '512010006',
        type: 'teambattle',
        title: 'Easter Champion: Silver',
        badge: 'easter-champion-silver.svg'
    },
    {
        id: '512010007',
        type: 'teambattle',
        title: 'Easter Top 500: Silver',
        badge: 'easter-top-500-silver.svg'
    },
    {
        id: '512010008',
        type: 'teambattle',
        title: 'Easter Top 500: Silver',
        badge: 'easter-top-500-silver.svg'
    },
    {
        id: '512010009',
        type: 'teambattle',
        title: 'Easter Top 500: Silver',
        badge: 'easter-top-500-silver.svg'
    },
    {
        id: '512010010',
        type: 'teambattle',
        title: 'Easter Participant: Silver',
        badge: 'easter-participant-silver.svg'
    },
    {
        id: '512010011',
        type: 'teambattle',
        title: 'Easter Champion: Bronze',
        badge: 'easter-champion-bronze.svg'
    },
    {
        id: '512010012',
        type: 'teambattle',
        title: 'Easter Top 500: Bronze',
        badge: 'easter-top-500-bronze.svg'
    },
    {
        id: '512010013',
        type: 'teambattle',
        title: 'Easter Top 500: Bronze',
        badge: 'easter-top-500-bronze.svg'
    },
    {
        id: '512010014',
        type: 'teambattle',
        title: 'Easter Top 500: Bronze',
        badge: 'easter-top-500-bronze.svg'
    },
    {
        id: '512010015',
        type: 'teambattle',
        title: 'Easter Participant: Bronze',
        badge: 'easter-participant-bronze.svg'
    },
    {
        id: '513010001',
        type: 'participation',
        title: 'Syrup Soaker',
        description: 'Took a dip in the early days of the Auto CAKE Pool',
        badge: 'syrup-soaker.svg'
    },
    {
        id: '514010001',
        type: 'participation',
        title: 'Clairvoyant',
        description: 'Played a round of Prediction before round 12,120',
        badge: 'clairvoyant.svg'
    },
    {
        id: '515010001',
        type: 'participation',
        title: 'Lottie',
        description: 'Joined a round in the early days of Lottery V2',
        badge: 'lottie.svg'
    },
    {
        id: '515020001',
        type: 'participation',
        title: 'Lucky',
        description: 'Won a round in the early days of Lottery V2',
        badge: 'lucky.svg'
    },
    {
        id: '515030001',
        type: 'participation',
        title: 'Baller',
        description: 'Top 100 ticket buyer in the early days of Lottery V2',
        badge: 'baller.svg'
    },
    {
        id: '516010001',
        type: 'participation',
        title: '1 Year',
        description: 'Joined PancakeSwap during the first year of our journey!',
        badge: '1-year.svg'
    },
    {
        id: '511120000',
        type: 'ifo',
        title: 'Duelist King',
        badge: 'ifo-dkt.svg'
    },
    {
        id: '511130000',
        type: 'ifo',
        title: 'Mines of Dalarnia',
        badge: 'ifo-dar.svg'
    },
    {
        id: '511140000',
        type: 'ifo',
        title: 'FC Porto Fan Token',
        badge: 'ifo-porto.svg'
    },
    {
        id: '511150000',
        type: 'ifo',
        title: 'FC Santos Fan Token',
        badge: 'ifo-santos.svg'
    },
    {
        id: '512020001',
        type: 'teambattle',
        title: 'Fan Token Champion: Gold',
        badge: 'fan-token-champion-gold.svg'
    },
    {
        id: '512020002',
        type: 'teambattle',
        title: 'Fan Token Top 10: Gold',
        badge: 'fan-token-top-10-gold.svg'
    },
    {
        id: '512020003',
        type: 'teambattle',
        title: 'Fan Token Top 100: Gold',
        badge: 'fan-token-top-100-gold.svg'
    },
    {
        id: '512020004',
        type: 'teambattle',
        title: 'Fan Token Top 500: Gold',
        badge: 'fan-token-top-500-gold.svg'
    },
    {
        id: '512020005',
        type: 'teambattle',
        title: 'Fan Token Participant: Gold',
        badge: 'fan-token-participant-gold.svg'
    },
    {
        id: '512020006',
        type: 'teambattle',
        title: 'Fan Token Champion: Silver',
        badge: 'fan-token-champion-silver.svg'
    },
    {
        id: '512020007',
        type: 'teambattle',
        title: 'Fan Token Top 10: Silver',
        badge: 'fan-token-top-10-silver.svg'
    },
    {
        id: '512020008',
        type: 'teambattle',
        title: 'Fan Token Top 100: Silver',
        badge: 'fan-token-top-100-silver.svg'
    },
    {
        id: '512020009',
        type: 'teambattle',
        title: 'Fan Token Top 500: Silver',
        badge: 'fan-token-top-500-silver.svg'
    },
    {
        id: '512020010',
        type: 'teambattle',
        title: 'Fan Token Participant: Silver',
        badge: 'fan-token-participant-silver.svg'
    },
    {
        id: '512020011',
        type: 'teambattle',
        title: 'Fan Token Champion: Bronze',
        badge: 'fan-token-champion-bronze.svg'
    },
    {
        id: '512020012',
        type: 'teambattle',
        title: 'Fan Token Top 10: Bronze',
        badge: 'fan-token-top-10-bronze.svg'
    },
    {
        id: '512020013',
        type: 'teambattle',
        title: 'Fan Token Top 100: Bronze',
        badge: 'fan-token-top-100-bronze.svg'
    },
    {
        id: '512020014',
        type: 'teambattle',
        title: 'Fan Token Top 500: Bronze',
        badge: 'fan-token-top-500-bronze.svg'
    },
    {
        id: '512020015',
        type: 'teambattle',
        title: 'Fan Token Participant: Bronze',
        badge: 'fan-token-participant-bronze.svg'
    },
    {
        id: '511160000',
        type: 'ifo',
        title: 'Diviner Protocol',
        badge: 'ifo-dpt.svg'
    },
    {
        id: '511170000',
        type: 'ifo',
        title: 'Froyo Games',
        badge: 'ifo-froyo.svg'
    }, 
];
/**
 * Transform the campaign config into a map. Keeps the config the same
 * as the others and allows easy access to a campaign by id
 */ const campaigns_campaignMap = new Map();
campaigns.forEach((campaign)=>{
    campaigns_campaignMap.set(campaign.id, campaign);
});
/* harmony default export */ const constants_campaigns = ((/* unused pure expression or super */ null && (campaigns)));

// EXTERNAL MODULE: ./src/config/constants/endpoints.ts
var endpoints = __webpack_require__(5906);
// EXTERNAL MODULE: ./src/config/constants/ifo.ts
var ifo = __webpack_require__(7829);
// EXTERNAL MODULE: ./src/utils/multicall.ts
var multicall = __webpack_require__(1144);
// EXTERNAL MODULE: ./src/utils/addressHelpers.ts + 1 modules
var addressHelpers = __webpack_require__(5878);
// EXTERNAL MODULE: ./src/config/abi/pointCenterIfo.json
var pointCenterIfo = __webpack_require__(8750);
;// CONCATENATED MODULE: ./src/utils/achievements.ts





const achievements_getAchievementTitle = (campaign)=>{
    switch(campaign.type){
        case 'ifo':
            return {
                key: 'IFO Shopper: %title%',
                data: {
                    title: campaign.title
                }
            };
        default:
            return campaign.title;
    }
};
const achievements_getAchievementDescription = (campaign)=>{
    switch(campaign.type){
        case 'ifo':
            return {
                key: 'Committed more than $5 worth of LP in the %title% IFO',
                data: {
                    title: campaign.title
                }
            };
        default:
            return campaign.description;
    }
};
/**
 * Checks if a wallet is eligible to claim points from valid IFO's
 */ const getClaimableIfoData = async (account)=>{
    const ifoCampaigns = ifosList.filter((ifoItem)=>ifoItem.campaignId !== undefined
    );
    // Returns the claim status of every IFO with a campaign ID
    const claimStatusCalls = ifoCampaigns.map(({ address  })=>{
        return {
            address: getPointCenterIfoAddress(),
            name: 'checkClaimStatus',
            params: [
                account,
                address
            ]
        };
    });
    const claimStatuses = await multicallv2(pointCenterIfoABI, claimStatusCalls, {
        requireSuccess: false
    });
    // Get IFO data for all IFO's that are eligible to claim
    const claimableIfoData = await multicallv2(pointCenterIfoABI, claimStatuses.reduce((accum, claimStatusArr, index)=>{
        if (claimStatusArr === null) {
            return accum;
        }
        const [claimStatus] = claimStatusArr;
        if (claimStatus === true) {
            return [
                ...accum,
                {
                    address: getPointCenterIfoAddress(),
                    name: 'ifos',
                    params: [
                        ifoCampaigns[index].address
                    ]
                }
            ];
        }
        return accum;
    }, []));
    // Transform response to an Achievement
    return claimableIfoData.reduce((accum, claimableIfoDataItem)=>{
        const claimableCampaignId = claimableIfoDataItem.campaignId.toString();
        if (!campaignMap.has(claimableCampaignId)) {
            return accum;
        }
        const campaignMeta = campaignMap.get(claimableCampaignId);
        const { address  } = ifoCampaigns.find((ifoCampaign)=>ifoCampaign.campaignId === claimableCampaignId
        );
        return [
            ...accum,
            {
                address,
                id: claimableCampaignId,
                type: 'ifo',
                title: achievements_getAchievementTitle(campaignMeta),
                description: achievements_getAchievementDescription(campaignMeta),
                badge: campaignMeta.badge,
                points: claimableIfoDataItem.numberPoints.toNumber()
            }, 
        ];
    }, []);
};

;// CONCATENATED MODULE: ./src/state/achievements/helpers.ts




/**
 * Gets all user point increase events on the profile filtered by wallet address
 */ const getUserPointIncreaseEvents = async (account)=>{
    try {
        const { user  } = await request(GRAPH_API_PROFILE, gql`
        query getUserPointIncreaseEvents($account: ID!) {
          user(id: $account) {
            points {
              id
              campaignId
              points
            }
          }
        }
      `, {
            account: account.toLowerCase()
        });
        return user.points;
    } catch (error) {
        return null;
    }
};
/**
 * Gets all user point increase events and adds achievement meta
 */ const getAchievements = async (account)=>{
    const pointIncreaseEvents = await getUserPointIncreaseEvents(account);
    if (!pointIncreaseEvents) {
        return [];
    }
    return pointIncreaseEvents.reduce((accum, userPoint)=>{
        if (!campaignMap.has(userPoint.campaignId)) {
            return accum;
        }
        const campaignMeta = campaignMap.get(userPoint.campaignId);
        return [
            ...accum,
            {
                id: userPoint.campaignId,
                type: campaignMeta.type,
                address: userPoint.id,
                title: getAchievementTitle(campaignMeta),
                description: getAchievementDescription(campaignMeta),
                badge: campaignMeta.badge,
                points: Number(userPoint.points)
            }, 
        ];
    }, []);
};


/***/ }),

/***/ 7063:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "hd": () => (/* binding */ usePollBlockNumber),
/* harmony export */   "je": () => (/* binding */ useCurrentBlock),
/* harmony export */   "Xh": () => (/* binding */ useInitialBlock)
/* harmony export */ });
/* unused harmony export useBlock */
/* harmony import */ var config_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1311);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var state__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4861);
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5941);
/* harmony import */ var utils_providers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5922);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3139);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swr__WEBPACK_IMPORTED_MODULE_3__]);
swr__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];






const REFRESH_BLOCK_INTERVAL = 6000;
const usePollBlockNumber = ()=>{
    const dispatch = (0,state__WEBPACK_IMPORTED_MODULE_2__/* .useAppDispatch */ .TL)();
    const { data  } = (0,swr__WEBPACK_IMPORTED_MODULE_3__["default"])([
        'blockNumber'
    ], async ()=>{
        const blockNumber = await utils_providers__WEBPACK_IMPORTED_MODULE_4__/* .simpleRpcProvider.getBlockNumber */ .J.getBlockNumber();
        dispatch((0,___WEBPACK_IMPORTED_MODULE_5__/* .setBlock */ .sk)(blockNumber));
        return blockNumber;
    }, {
        refreshInterval: REFRESH_BLOCK_INTERVAL
    });
    (0,swr__WEBPACK_IMPORTED_MODULE_3__["default"])([
        config_constants__WEBPACK_IMPORTED_MODULE_0__/* .FAST_INTERVAL */ .sR,
        'blockNumber'
    ], async ()=>{
        return data;
    }, {
        refreshInterval: config_constants__WEBPACK_IMPORTED_MODULE_0__/* .FAST_INTERVAL */ .sR
    });
    (0,swr__WEBPACK_IMPORTED_MODULE_3__["default"])([
        config_constants__WEBPACK_IMPORTED_MODULE_0__/* .SLOW_INTERVAL */ .KI,
        'blockNumber'
    ], async ()=>{
        return data;
    }, {
        refreshInterval: config_constants__WEBPACK_IMPORTED_MODULE_0__/* .SLOW_INTERVAL */ .KI
    });
};
const useBlock = ()=>{
    return useSelector((state)=>state.block
    );
};
const useCurrentBlock = ()=>{
    return (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.block.currentBlock
    );
};
const useInitialBlock = ()=>{
    return (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.block.initialBlock
    );
};

});

/***/ }),

/***/ 3139:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "sk": () => (/* binding */ setBlock),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export blockSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    currentBlock: 0,
    initialBlock: 0
};
const blockSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: 'Block',
    initialState,
    reducers: {
        setBlock: (state, action)=>{
            if (state.initialBlock === 0) {
                state.initialBlock = action.payload;
            }
            state.currentBlock = action.payload;
        }
    }
});
// Actions
const { setBlock  } = blockSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (blockSlice.reducer);


/***/ }),

/***/ 4861:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Dj": () => (/* binding */ persistor),
  "TL": () => (/* binding */ useAppDispatch),
  "oR": () => (/* binding */ useStore)
});

// UNUSED EXPORTS: default, initializeStore

// EXTERNAL MODULE: external "@reduxjs/toolkit"
var toolkit_ = __webpack_require__(5184);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: external "redux-persist"
var external_redux_persist_ = __webpack_require__(4161);
// EXTERNAL MODULE: external "redux-persist/lib/storage"
var storage_ = __webpack_require__(8936);
var storage_default = /*#__PURE__*/__webpack_require__.n(storage_);
// EXTERNAL MODULE: ./src/state/block/index.ts
var block = __webpack_require__(3139);
;// CONCATENATED MODULE: ./src/state/global/actions.ts

// fired once when the app reloads but before the app renders
// allows any updates to be applied to store data loaded from localStorage
const updateVersion = (0,toolkit_.createAction)('global/updateVersion');
/* harmony default export */ const actions = ((/* unused pure expression or super */ null && (updateVersion)));

// EXTERNAL MODULE: ./src/state/info/actions.ts
var info_actions = __webpack_require__(4522);
;// CONCATENATED MODULE: ./src/state/info/index.ts
/* eslint-disable no-param-reassign */ 

const initialState = {
    protocol: {
        overview: undefined,
        chartData: undefined,
        transactions: undefined
    },
    pools: {
        byAddress: {}
    },
    tokens: {
        byAddress: {}
    }
};
/* harmony default export */ const info = ((0,toolkit_.createReducer)(initialState, (builder)=>builder// Protocol actions
    .addCase(info_actions/* updateProtocolData */.Uo, (state, { payload: { protocolData  }  })=>{
        state.protocol.overview = protocolData;
    }).addCase(info_actions/* updateProtocolChartData */.bj, (state, { payload: { chartData  }  })=>{
        state.protocol.chartData = chartData;
    }).addCase(info_actions/* updateProtocolTransactions */.oz, (state, { payload: { transactions  }  })=>{
        state.protocol.transactions = transactions;
    })// Pools actions
    .addCase(info_actions/* updatePoolData */.Bp, (state, { payload: { pools  }  })=>{
        pools.forEach((poolData)=>{
            state.pools.byAddress[poolData.address] = {
                ...state.pools.byAddress[poolData.address],
                data: poolData
            };
        });
    }).addCase(info_actions/* addPoolKeys */.iF, (state, { payload: { poolAddresses  }  })=>{
        poolAddresses.forEach((address)=>{
            if (!state.pools.byAddress[address]) {
                state.pools.byAddress[address] = {
                    data: undefined,
                    chartData: undefined,
                    transactions: undefined
                };
            }
        });
    }).addCase(info_actions/* updatePoolChartData */.jw, (state, { payload: { poolAddress , chartData  }  })=>{
        state.pools.byAddress[poolAddress] = {
            ...state.pools.byAddress[poolAddress],
            chartData
        };
    }).addCase(info_actions/* updatePoolTransactions */.oG, (state, { payload: { poolAddress , transactions  }  })=>{
        state.pools.byAddress[poolAddress] = {
            ...state.pools.byAddress[poolAddress],
            transactions
        };
    })// Tokens actions
    .addCase(info_actions/* updateTokenData */.I6, (state, { payload: { tokens  }  })=>{
        tokens.forEach((tokenData)=>{
            state.tokens.byAddress[tokenData.address] = {
                ...state.tokens.byAddress[tokenData.address],
                data: tokenData
            };
        });
    }).addCase(info_actions/* addTokenKeys */.uP, (state, { payload: { tokenAddresses  }  })=>{
        tokenAddresses.forEach((address)=>{
            if (!state.tokens.byAddress[address]) {
                state.tokens.byAddress[address] = {
                    poolAddresses: undefined,
                    data: undefined,
                    chartData: undefined,
                    priceData: {},
                    transactions: undefined
                };
            }
        });
    }).addCase(info_actions/* addTokenPoolAddresses */.TV, (state, { payload: { tokenAddress , poolAddresses  }  })=>{
        state.tokens.byAddress[tokenAddress] = {
            ...state.tokens.byAddress[tokenAddress],
            poolAddresses
        };
    }).addCase(info_actions/* updateTokenChartData */.fo, (state, { payload: { tokenAddress , chartData  }  })=>{
        state.tokens.byAddress[tokenAddress] = {
            ...state.tokens.byAddress[tokenAddress],
            chartData
        };
    }).addCase(info_actions/* updateTokenTransactions */.Mw, (state, { payload: { tokenAddress , transactions  }  })=>{
        state.tokens.byAddress[tokenAddress] = {
            ...state.tokens.byAddress[tokenAddress],
            transactions
        };
    }).addCase(info_actions/* updateTokenPriceData */.Db, (state, { payload: { tokenAddress , secondsInterval , priceData , oldestFetchedTimestamp  }  })=>{
        state.tokens.byAddress[tokenAddress] = {
            ...state.tokens.byAddress[tokenAddress],
            priceData: {
                ...state.tokens.byAddress[tokenAddress]?.priceData,
                [secondsInterval]: priceData,
                oldestFetchedTimestamp
            }
        };
    })
));

// EXTERNAL MODULE: external "@uniswap/token-lists"
var token_lists_ = __webpack_require__(1554);
// EXTERNAL MODULE: ./src/config/constants/lists.ts
var lists = __webpack_require__(428);
// EXTERNAL MODULE: ./src/state/lists/actions.ts
var lists_actions = __webpack_require__(8412);
;// CONCATENATED MODULE: ./src/state/lists/reducer.ts





const NEW_LIST_STATE = {
    error: null,
    current: null,
    loadingRequestId: null,
    pendingUpdate: null
};
const reducer_initialState = {
    lastInitializedDefaultListOfLists: lists/* DEFAULT_LIST_OF_LISTS */.Lx,
    byUrl: {
        ...lists/* DEFAULT_LIST_OF_LISTS.concat */.Lx.concat(...lists/* UNSUPPORTED_LIST_URLS */.US).reduce((memo, listUrl)=>{
            memo[listUrl] = NEW_LIST_STATE;
            return memo;
        }, {})
    },
    activeListUrls: lists/* DEFAULT_ACTIVE_LIST_URLS */.c8
};
/* harmony default export */ const reducer = ((0,toolkit_.createReducer)(reducer_initialState, (builder)=>builder.addCase(lists_actions/* fetchTokenList.pending */.Dn.pending, (state, { payload: { requestId , url  }  })=>{
        state.byUrl[url] = {
            current: null,
            pendingUpdate: null,
            ...state.byUrl[url],
            loadingRequestId: requestId,
            error: null
        };
    }).addCase(lists_actions/* fetchTokenList.fulfilled */.Dn.fulfilled, (state, { payload: { requestId , tokenList , url  }  })=>{
        const current = state.byUrl[url]?.current;
        const loadingRequestId = state.byUrl[url]?.loadingRequestId;
        // no-op if update does nothing
        if (current) {
            const upgradeType = (0,token_lists_.getVersionUpgrade)(current.version, tokenList.version);
            if (upgradeType === token_lists_.VersionUpgrade.NONE) return;
            if (loadingRequestId === null || loadingRequestId === requestId) {
                state.byUrl[url] = {
                    ...state.byUrl[url],
                    loadingRequestId: null,
                    error: null,
                    current,
                    pendingUpdate: tokenList
                };
            }
        } else {
            // activate if on default active
            if (lists/* DEFAULT_ACTIVE_LIST_URLS.includes */.c8.includes(url)) {
                state.activeListUrls?.push(url);
            }
            state.byUrl[url] = {
                ...state.byUrl[url],
                loadingRequestId: null,
                error: null,
                current: tokenList,
                pendingUpdate: null
            };
        }
    }).addCase(lists_actions/* fetchTokenList.rejected */.Dn.rejected, (state, { payload: { url , requestId , errorMessage  }  })=>{
        if (state.byUrl[url]?.loadingRequestId !== requestId) {
            // no-op since it's not the latest request
            return;
        }
        state.byUrl[url] = {
            ...state.byUrl[url],
            loadingRequestId: null,
            error: errorMessage,
            current: null,
            pendingUpdate: null
        };
    }).addCase(lists_actions/* addList */.$8, (state, { payload: url  })=>{
        if (!state.byUrl[url]) {
            state.byUrl[url] = NEW_LIST_STATE;
        }
    }).addCase(lists_actions/* removeList */.J_, (state, { payload: url  })=>{
        if (state.byUrl[url]) {
            delete state.byUrl[url];
        }
        // remove list from active urls if needed
        if (state.activeListUrls && state.activeListUrls.includes(url)) {
            state.activeListUrls = state.activeListUrls.filter((u)=>u !== url
            );
        }
    }).addCase(lists_actions/* enableList */.ic, (state, { payload: url  })=>{
        if (!state.byUrl[url]) {
            state.byUrl[url] = NEW_LIST_STATE;
        }
        if (state.activeListUrls && !state.activeListUrls.includes(url)) {
            state.activeListUrls.push(url);
        }
        if (!state.activeListUrls) {
            state.activeListUrls = [
                url
            ];
        }
    }).addCase(lists_actions/* disableList */.K$, (state, { payload: url  })=>{
        if (state.activeListUrls && state.activeListUrls.includes(url)) {
            state.activeListUrls = state.activeListUrls.filter((u)=>u !== url
            );
        }
    }).addCase(lists_actions/* acceptListUpdate */.xJ, (state, { payload: url  })=>{
        if (!state.byUrl[url]?.pendingUpdate) {
            throw new Error('accept list update called without pending update');
        }
        state.byUrl[url] = {
            ...state.byUrl[url],
            pendingUpdate: null,
            current: state.byUrl[url].pendingUpdate
        };
    }).addCase(updateVersion, (state)=>{
        // state loaded from localStorage, but new lists have never been initialized
        if (!state.lastInitializedDefaultListOfLists) {
            state.byUrl = reducer_initialState.byUrl;
            state.activeListUrls = reducer_initialState.activeListUrls;
        } else if (state.lastInitializedDefaultListOfLists) {
            const lastInitializedSet = state.lastInitializedDefaultListOfLists.reduce((s, l)=>s.add(l)
            , new Set());
            const newListOfListsSet = lists/* DEFAULT_LIST_OF_LISTS.reduce */.Lx.reduce((s, l)=>s.add(l)
            , new Set());
            lists/* DEFAULT_LIST_OF_LISTS.forEach */.Lx.forEach((listUrl)=>{
                if (!lastInitializedSet.has(listUrl)) {
                    state.byUrl[listUrl] = NEW_LIST_STATE;
                }
            });
            state.lastInitializedDefaultListOfLists.forEach((listUrl)=>{
                if (!newListOfListsSet.has(listUrl)) {
                    delete state.byUrl[listUrl];
                }
            });
        }
        state.lastInitializedDefaultListOfLists = lists/* DEFAULT_LIST_OF_LISTS */.Lx;
        // if no active lists, activate defaults
        if (!state.activeListUrls) {
            state.activeListUrls = lists/* DEFAULT_ACTIVE_LIST_URLS */.c8;
            // for each list on default list, initialize if needed
            lists/* DEFAULT_ACTIVE_LIST_URLS.forEach */.c8.forEach((listUrl)=>{
                if (!state.byUrl[listUrl]) {
                    state.byUrl[listUrl] = NEW_LIST_STATE;
                }
                return true;
            });
        }
    })
));

// EXTERNAL MODULE: ./src/state/multicall/actions.ts
var multicall_actions = __webpack_require__(3884);
;// CONCATENATED MODULE: ./src/state/multicall/reducer.ts


const multicall_reducer_initialState = {
    callResults: {}
};
/* harmony default export */ const multicall_reducer = ((0,toolkit_.createReducer)(multicall_reducer_initialState, (builder)=>builder.addCase(multicall_actions/* addMulticallListeners */.Dd, (state, { payload: { calls , chainId , options: { blocksPerFetch =1  } = {}  }  })=>{
        const listeners = state.callListeners ? state.callListeners : state.callListeners = {};
        listeners[chainId] = listeners[chainId] ?? {};
        calls.forEach((call)=>{
            const callKey = (0,multicall_actions/* toCallKey */.kG)(call);
            listeners[chainId][callKey] = listeners[chainId][callKey] ?? {};
            listeners[chainId][callKey][blocksPerFetch] = (listeners[chainId][callKey][blocksPerFetch] ?? 0) + 1;
        });
    }).addCase(multicall_actions/* removeMulticallListeners */.$x, (state, { payload: { chainId , calls , options: { blocksPerFetch =1  } = {}  }  })=>{
        const listeners = state.callListeners ? state.callListeners : state.callListeners = {};
        if (!listeners[chainId]) return;
        calls.forEach((call)=>{
            const callKey = (0,multicall_actions/* toCallKey */.kG)(call);
            if (!listeners[chainId][callKey]) return;
            if (!listeners[chainId][callKey][blocksPerFetch]) return;
            if (listeners[chainId][callKey][blocksPerFetch] === 1) {
                delete listeners[chainId][callKey][blocksPerFetch];
            } else {
                listeners[chainId][callKey][blocksPerFetch]--;
            }
        });
    }).addCase(multicall_actions/* fetchingMulticallResults */.nu, (state, { payload: { chainId , fetchingBlockNumber , calls  }  })=>{
        state.callResults[chainId] = state.callResults[chainId] ?? {};
        calls.forEach((call)=>{
            const callKey = (0,multicall_actions/* toCallKey */.kG)(call);
            const current = state.callResults[chainId][callKey];
            if (!current) {
                state.callResults[chainId][callKey] = {
                    fetchingBlockNumber
                };
            } else {
                if ((current.fetchingBlockNumber ?? 0) >= fetchingBlockNumber) return;
                state.callResults[chainId][callKey].fetchingBlockNumber = fetchingBlockNumber;
            }
        });
    }).addCase(multicall_actions/* errorFetchingMulticallResults */.wC, (state, { payload: { fetchingBlockNumber , chainId , calls  }  })=>{
        state.callResults[chainId] = state.callResults[chainId] ?? {};
        calls.forEach((call)=>{
            const callKey = (0,multicall_actions/* toCallKey */.kG)(call);
            const current = state.callResults[chainId][callKey];
            if (!current) return; // only should be dispatched if we are already fetching
            if (current.fetchingBlockNumber === fetchingBlockNumber) {
                delete current.fetchingBlockNumber;
                current.data = null;
                current.blockNumber = fetchingBlockNumber;
            }
        });
    }).addCase(multicall_actions/* updateMulticallResults */.zT, (state, { payload: { chainId , results , blockNumber  }  })=>{
        state.callResults[chainId] = state.callResults[chainId] ?? {};
        Object.keys(results).forEach((callKey)=>{
            const current = state.callResults[chainId][callKey];
            if ((current?.blockNumber ?? 0) > blockNumber) return;
            state.callResults[chainId][callKey] = {
                data: results[callKey],
                blockNumber
            };
        });
    })
));

// EXTERNAL MODULE: ./src/state/predictions/index.ts
var predictions = __webpack_require__(7774);
// EXTERNAL MODULE: ./src/state/profile/index.tsx
var profile = __webpack_require__(5952);
// EXTERNAL MODULE: ./src/state/transactions/actions.ts
var transactions_actions = __webpack_require__(1564);
;// CONCATENATED MODULE: ./src/state/transactions/reducer.ts
/* eslint-disable no-param-reassign */ 

const now = ()=>new Date().getTime()
;
const transactions_reducer_initialState = {};
/* harmony default export */ const transactions_reducer = ((0,toolkit_.createReducer)(transactions_reducer_initialState, (builder)=>builder.addCase(transactions_actions/* addTransaction */.dT, (transactions, { payload: { chainId , from , hash , approval , summary , claim  }  })=>{
        if (transactions[chainId]?.[hash]) {
            throw Error('Attempted to add existing transaction.');
        }
        const txs = transactions[chainId] ?? {};
        txs[hash] = {
            hash,
            approval,
            summary,
            claim,
            from,
            addedTime: now()
        };
        transactions[chainId] = txs;
    }).addCase(transactions_actions/* clearAllTransactions */.fY, (transactions, { payload: { chainId  }  })=>{
        if (!transactions[chainId]) return;
        transactions[chainId] = {};
    }).addCase(transactions_actions/* checkedTransaction */.LN, (transactions, { payload: { chainId , hash , blockNumber  }  })=>{
        const tx = transactions[chainId]?.[hash];
        if (!tx) {
            return;
        }
        if (!tx.lastCheckedBlockNumber) {
            tx.lastCheckedBlockNumber = blockNumber;
        } else {
            tx.lastCheckedBlockNumber = Math.max(blockNumber, tx.lastCheckedBlockNumber);
        }
    }).addCase(transactions_actions/* finalizeTransaction */.Aw, (transactions, { payload: { hash , chainId , receipt  }  })=>{
        const tx = transactions[chainId]?.[hash];
        if (!tx) {
            return;
        }
        tx.receipt = receipt;
        tx.confirmedTime = now();
    })
));

// EXTERNAL MODULE: ./src/config/constants/index.ts + 1 modules
var constants = __webpack_require__(1311);
// EXTERNAL MODULE: ./src/state/user/actions.ts
var user_actions = __webpack_require__(6245);
// EXTERNAL MODULE: ./src/state/user/hooks/helpers.ts
var helpers = __webpack_require__(787);
;// CONCATENATED MODULE: ./src/state/user/reducer.ts





const currentTimestamp = ()=>new Date().getTime()
;
function pairKey(token0Address, token1Address) {
    return `${token0Address};${token1Address}`;
}
const user_reducer_initialState = {
    userExpertMode: false,
    userSingleHopOnly: false,
    userSlippageTolerance: constants/* INITIAL_ALLOWED_SLIPPAGE */.gv,
    userDeadline: constants/* DEFAULT_DEADLINE_FROM_NOW */.PY,
    tokens: {},
    pairs: {},
    timestamp: currentTimestamp(),
    audioPlay: true,
    isDark: false,
    isExchangeChartDisplayed: true,
    isSubgraphHealthIndicatorDisplayed: false,
    userChartViewMode: user_actions/* ChartViewMode.BASIC */.UU.BASIC,
    userFarmStakedOnly: user_actions/* FarmStakedOnly.ON_FINISHED */.GR.ON_FINISHED,
    userPoolStakedOnly: false,
    userPoolsViewMode: user_actions/* ViewMode.TABLE */.wO.TABLE,
    userFarmsViewMode: user_actions/* ViewMode.TABLE */.wO.TABLE,
    userPredictionAcceptedRisk: false,
    userPredictionChartDisclaimerShow: true,
    userExpertModeAcknowledgementShow: true,
    userUsernameVisibility: false,
    gasPrice: helpers/* GAS_PRICE_GWEI.default */.j4["default"],
    watchlistTokens: [],
    watchlistPools: [],
    hideTimestampPhishingWarningBanner: null
};
/* harmony default export */ const user_reducer = ((0,toolkit_.createReducer)(user_reducer_initialState, (builder)=>builder.addCase(updateVersion, (state)=>{
        // slippage isnt being tracked in local storage, reset to default
        // noinspection SuspiciousTypeOfGuard
        if (typeof state.userSlippageTolerance !== 'number') {
            state.userSlippageTolerance = constants/* INITIAL_ALLOWED_SLIPPAGE */.gv;
        }
        // deadline isnt being tracked in local storage, reset to default
        // noinspection SuspiciousTypeOfGuard
        if (typeof state.userDeadline !== 'number') {
            state.userDeadline = constants/* DEFAULT_DEADLINE_FROM_NOW */.PY;
        }
        state.lastUpdateVersionTimestamp = currentTimestamp();
    }).addCase(user_actions/* updateUserExpertMode */.zv, (state, action)=>{
        state.userExpertMode = action.payload.userExpertMode;
        state.timestamp = currentTimestamp();
    }).addCase(user_actions/* updateUserSlippageTolerance */.rQ, (state, action)=>{
        state.userSlippageTolerance = action.payload.userSlippageTolerance;
        state.timestamp = currentTimestamp();
    }).addCase(user_actions/* updateUserDeadline */.gw, (state, action)=>{
        state.userDeadline = action.payload.userDeadline;
        state.timestamp = currentTimestamp();
    }).addCase(user_actions/* updateUserSingleHopOnly */.fO, (state, action)=>{
        state.userSingleHopOnly = action.payload.userSingleHopOnly;
    }).addCase(user_actions/* addSerializedToken */.eg, (state, { payload: { serializedToken  }  })=>{
        if (!state.tokens) {
            state.tokens = {};
        }
        state.tokens[serializedToken.chainId] = state.tokens[serializedToken.chainId] || {};
        state.tokens[serializedToken.chainId][serializedToken.address] = serializedToken;
        state.timestamp = currentTimestamp();
    }).addCase(user_actions/* removeSerializedToken */.zQ, (state, { payload: { address , chainId  }  })=>{
        if (!state.tokens) {
            state.tokens = {};
        }
        state.tokens[chainId] = state.tokens[chainId] || {};
        delete state.tokens[chainId][address];
        state.timestamp = currentTimestamp();
    }).addCase(user_actions/* addSerializedPair */.f9, (state, { payload: { serializedPair  }  })=>{
        if (serializedPair.token0.chainId === serializedPair.token1.chainId && serializedPair.token0.address !== serializedPair.token1.address) {
            const { chainId  } = serializedPair.token0;
            state.pairs[chainId] = state.pairs[chainId] || {};
            state.pairs[chainId][pairKey(serializedPair.token0.address, serializedPair.token1.address)] = serializedPair;
        }
        state.timestamp = currentTimestamp();
    }).addCase(user_actions/* removeSerializedPair */.cd, (state, { payload: { chainId , tokenAAddress , tokenBAddress  }  })=>{
        if (state.pairs[chainId]) {
            // just delete both keys if either exists
            delete state.pairs[chainId][pairKey(tokenAAddress, tokenBAddress)];
            delete state.pairs[chainId][pairKey(tokenBAddress, tokenAAddress)];
        }
        state.timestamp = currentTimestamp();
    }).addCase(user_actions/* muteAudio */.B8, (state)=>{
        state.audioPlay = false;
    }).addCase(user_actions/* unmuteAudio */.u7, (state)=>{
        state.audioPlay = true;
    }).addCase(user_actions/* toggleTheme */.X8, (state)=>{
        state.isDark = !state.isDark;
    }).addCase(user_actions/* updateUserFarmStakedOnly */.Gs, (state, { payload: { userFarmStakedOnly  }  })=>{
        state.userFarmStakedOnly = userFarmStakedOnly;
    }).addCase(user_actions/* updateUserPoolStakedOnly */.mm, (state, { payload: { userPoolStakedOnly  }  })=>{
        state.userPoolStakedOnly = userPoolStakedOnly;
    }).addCase(user_actions/* updateUserPoolsViewMode */.d4, (state, { payload: { userPoolsViewMode  }  })=>{
        state.userPoolsViewMode = userPoolsViewMode;
    }).addCase(user_actions/* updateUserFarmsViewMode */.gk, (state, { payload: { userFarmsViewMode  }  })=>{
        state.userFarmsViewMode = userFarmsViewMode;
    }).addCase(user_actions/* updateUserPredictionAcceptedRisk */.RC, (state, { payload: { userAcceptedRisk  }  })=>{
        state.userPredictionAcceptedRisk = userAcceptedRisk;
    }).addCase(user_actions/* updateUserPredictionChartDisclaimerShow */.c4, (state, { payload: { userShowDisclaimer  }  })=>{
        state.userPredictionChartDisclaimerShow = userShowDisclaimer;
    }).addCase(user_actions/* updateUserExpertModeAcknowledgementShow */._C, (state, { payload: { userExpertModeAcknowledgementShow  }  })=>{
        state.userExpertModeAcknowledgementShow = userExpertModeAcknowledgementShow;
    }).addCase(user_actions/* updateUserUsernameVisibility */.zk, (state, { payload: { userUsernameVisibility  }  })=>{
        state.userUsernameVisibility = userUsernameVisibility;
    }).addCase(user_actions/* updateGasPrice */.dy, (state, action)=>{
        state.gasPrice = action.payload.gasPrice;
    }).addCase(user_actions/* addWatchlistToken */.zS, (state, { payload: { address  }  })=>{
        // state.watchlistTokens can be undefined for pre-loaded localstorage user state
        const tokenWatchlist = state.watchlistTokens ?? [];
        if (!tokenWatchlist.includes(address)) {
            state.watchlistTokens = [
                ...tokenWatchlist,
                address
            ];
        } else {
            // Remove token from watchlist
            const newTokens = state.watchlistTokens.filter((x)=>x !== address
            );
            state.watchlistTokens = newTokens;
        }
    }).addCase(user_actions/* addWatchlistPool */.Dn, (state, { payload: { address  }  })=>{
        // state.watchlistPools can be undefined for pre-loaded localstorage user state
        const poolsWatchlist = state.watchlistPools ?? [];
        if (!poolsWatchlist.includes(address)) {
            state.watchlistPools = [
                ...poolsWatchlist,
                address
            ];
        } else {
            // Remove pool from watchlist
            const newPools = state.watchlistPools.filter((x)=>x !== address
            );
            state.watchlistPools = newPools;
        }
    }).addCase(user_actions/* hidePhishingWarningBanner */.l5, (state)=>{
        state.hideTimestampPhishingWarningBanner = currentTimestamp();
    }).addCase(user_actions/* setIsExchangeChartDisplayed */.hN, (state, { payload  })=>{
        state.isExchangeChartDisplayed = payload;
    }).addCase(user_actions/* setChartViewMode */.p9, (state, { payload  })=>{
        state.userChartViewMode = payload;
    }).addCase(user_actions/* setSubgraphHealthIndicatorDisplayed */.Hr, (state, { payload  })=>{
        state.isSubgraphHealthIndicatorDisplayed = payload;
    })
));

;// CONCATENATED MODULE: ./src/state/index.ts














const PERSISTED_KEYS = [
    'user',
    'transactions',
    'lists',
    'profile'
];
const persistConfig = {
    key: 'primary',
    whitelist: PERSISTED_KEYS,
    storage: (storage_default())
};
const persistedReducer = (0,external_redux_persist_.persistReducer)(persistConfig, (0,toolkit_.combineReducers)({
    block: block/* default */.ZP,
    predictions: predictions/* default */.ZP,
    profile: profile/* default */.ZP,
    info: info,
    // Exchange
    user: user_reducer,
    transactions: transactions_reducer,
    multicall: multicall_reducer,
    lists: reducer
}));
// eslint-disable-next-line import/no-mutable-exports
let store;
function makeStore(preloadedState = undefined) {
    return (0,toolkit_.configureStore)({
        reducer: persistedReducer,
        middleware: (getDefaultMiddleware)=>getDefaultMiddleware({
                thunk: true,
                serializableCheck: {
                    ignoredActions: [
                        external_redux_persist_.FLUSH,
                        external_redux_persist_.REHYDRATE,
                        external_redux_persist_.PAUSE,
                        external_redux_persist_.PERSIST,
                        external_redux_persist_.PURGE,
                        external_redux_persist_.REGISTER
                    ]
                }
            })
        ,
        devTools: "production" === 'development',
        preloadedState
    });
}
const initializeStore = (preloadedState = undefined)=>{
    let _store = store ?? makeStore(preloadedState);
    // After navigating to a page with an initial Redux state, merge that state
    // with the current state in the store, and create a new store
    if (preloadedState && store) {
        _store = makeStore({
            ...store.getState(),
            ...preloadedState
        });
        // Reset the current store
        store = undefined;
    }
    // For SSG and SSR always create a new store
    if (true) return _store;
    // Create the store once in the client
    if (!store) {
        store = _store;
        store.dispatch(updateVersion());
    }
    return _store;
};
store = initializeStore();
const useAppDispatch = ()=>(0,external_react_redux_.useDispatch)()
;
/* harmony default export */ const state = ((/* unused pure expression or super */ null && (store)));
const persistor = (0,external_redux_persist_.persistStore)(store);
function useStore(initialState) {
    return (0,external_react_.useMemo)(()=>initializeStore(initialState)
    , [
        initialState
    ]);
}


/***/ }),

/***/ 4522:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Uo": () => (/* binding */ updateProtocolData),
/* harmony export */   "bj": () => (/* binding */ updateProtocolChartData),
/* harmony export */   "oz": () => (/* binding */ updateProtocolTransactions),
/* harmony export */   "Bp": () => (/* binding */ updatePoolData),
/* harmony export */   "iF": () => (/* binding */ addPoolKeys),
/* harmony export */   "jw": () => (/* binding */ updatePoolChartData),
/* harmony export */   "oG": () => (/* binding */ updatePoolTransactions),
/* harmony export */   "I6": () => (/* binding */ updateTokenData),
/* harmony export */   "uP": () => (/* binding */ addTokenKeys),
/* harmony export */   "TV": () => (/* binding */ addTokenPoolAddresses),
/* harmony export */   "fo": () => (/* binding */ updateTokenChartData),
/* harmony export */   "Mw": () => (/* binding */ updateTokenTransactions),
/* harmony export */   "Db": () => (/* binding */ updateTokenPriceData)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const updateProtocolData = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('info/protocol/updateProtocolData');
const updateProtocolChartData = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('info/protocol/updateProtocolChartData');
const updateProtocolTransactions = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('info/protocol/updateProtocolTransactions');
const updatePoolData = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('info/pools/updatePoolData');
const addPoolKeys = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('info/pools/addPoolKeys');
const updatePoolChartData = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('info/pools/updatePoolChartData');
const updatePoolTransactions = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('info/pools/updatePoolTransactions');
const updateTokenData = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('info/tokens/updateTokenData');
const addTokenKeys = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('info/tokens/addTokenKeys');
const addTokenPoolAddresses = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('info/tokens/addTokenPoolAddresses');
const updateTokenChartData = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('info/tokens/updateTokenChartData');
const updateTokenTransactions = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('info/tokens/updateTokenTransactions');
const updateTokenPriceData = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('info/tokens/updateTokenPriceData');


/***/ }),

/***/ 8412:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Dn": () => (/* binding */ fetchTokenList),
/* harmony export */   "$8": () => (/* binding */ addList),
/* harmony export */   "J_": () => (/* binding */ removeList),
/* harmony export */   "ic": () => (/* binding */ enableList),
/* harmony export */   "K$": () => (/* binding */ disableList),
/* harmony export */   "xJ": () => (/* binding */ acceptListUpdate)
/* harmony export */ });
/* unused harmony export rejectVersionUpdate */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const fetchTokenList = {
    pending: (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('lists/fetchTokenList/pending'),
    fulfilled: (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('lists/fetchTokenList/fulfilled'),
    rejected: (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('lists/fetchTokenList/rejected')
};
// add and remove from list options
const addList = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('lists/addList');
const removeList = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('lists/removeList');
// select which lists to search across from loaded lists
const enableList = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('lists/enableList');
const disableList = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('lists/disableList');
// versioning
const acceptListUpdate = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('lists/acceptListUpdate');
const rejectVersionUpdate = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('lists/rejectVersionUpdate');


/***/ }),

/***/ 7952:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "v0": () => (/* binding */ useActiveListUrls),
  "R0": () => (/* binding */ useAllLists),
  "z0": () => (/* binding */ useCombinedActiveList),
  "qB": () => (/* binding */ useCombinedInactiveList)
});

// UNUSED EXPORTS: WrappedTokenInfo, listToTokenMap, useDefaultTokenList, useInactiveListUrls, useIsListActive, useUnsupportedTokenList

// EXTERNAL MODULE: external "@mdemouchy/sdk"
var sdk_ = __webpack_require__(2877);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: ./src/config/constants/lists.ts
var constants_lists = __webpack_require__(428);
;// CONCATENATED MODULE: ./src/config/constants/tokenLists/pancake-default.tokenlist.json
const pancake_default_tokenlist_namespaceObject = JSON.parse('{"name":"PancakeSwap Default List","timestamp":"2022-01-26T11:45:09Z","version":{"major":4,"minor":0,"patch":0},"tags":{},"logoURI":"https://pancakeswap.finance/logo.png","keywords":["pancake","default"],"tokens":[{"name":"WBNB Token","symbol":"WBNB","address":"0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c","chainId":1666600000,"decimals":18,"logoURI":"https://pancakeswap.finance/images/tokens/0xbb4cdb9cbd36b01bd1cbaebf2de08d9173bc095c.png"}]}');
;// CONCATENATED MODULE: ./src/config/constants/tokenLists/pancake-unsupported.tokenlist.json
const pancake_unsupported_tokenlist_namespaceObject = {};
;// CONCATENATED MODULE: ./src/state/lists/hooks.ts







// use ordering of default list of lists to assign priority
function sortByListPriority(urlA, urlB) {
    const first = constants_lists/* DEFAULT_LIST_OF_LISTS.includes */.Lx.includes(urlA) ? constants_lists/* DEFAULT_LIST_OF_LISTS.indexOf */.Lx.indexOf(urlA) : Number.MAX_SAFE_INTEGER;
    const second = constants_lists/* DEFAULT_LIST_OF_LISTS.includes */.Lx.includes(urlB) ? constants_lists/* DEFAULT_LIST_OF_LISTS.indexOf */.Lx.indexOf(urlB) : Number.MAX_SAFE_INTEGER;
    // need reverse order to make sure mapping includes top priority last
    if (first < second) return 1;
    if (first > second) return -1;
    return 0;
}
/**
 * Token instances created from token info.
 */ class WrappedTokenInfo extends sdk_.Token {
    constructor(tokenInfo, tags){
        super(tokenInfo.chainId, tokenInfo.address, tokenInfo.decimals, tokenInfo.symbol, tokenInfo.name);
        this.tokenInfo = tokenInfo;
        this.tags = tags;
    }
    get logoURI() {
        return this.tokenInfo.logoURI;
    }
}
/**
 * An empty result, useful as a default.
 */ const EMPTY_LIST = {
    [sdk_.ChainId.MAINNET]: {},
    [sdk_.ChainId.TESTNET]: {}
};
const listCache = typeof WeakMap !== 'undefined' ? new WeakMap() : null;
function listToTokenMap(list) {
    const result = listCache?.get(list);
    if (result) return result;
    const map = list.tokens.reduce((tokenMap, tokenInfo)=>{
        const tags = tokenInfo.tags?.map((tagId)=>{
            if (!list.tags?.[tagId]) return undefined;
            return {
                ...list.tags[tagId],
                id: tagId
            };
        })?.filter((x)=>Boolean(x)
        ) ?? [];
        const token = new WrappedTokenInfo(tokenInfo, tags);
        if (tokenMap[token.chainId][token.address] !== undefined) throw Error('Duplicate tokens.');
        return {
            ...tokenMap,
            [token.chainId]: {
                ...tokenMap[token.chainId],
                [token.address]: {
                    token,
                    list
                }
            }
        };
    }, {
        ...EMPTY_LIST
    });
    listCache?.set(list, map);
    return map;
}
function useAllLists() {
    return (0,external_react_redux_.useSelector)((state)=>state.lists.byUrl
    );
}
function combineMaps(map1, map2) {
    return {
        [sdk_.ChainId.MAINNET]: {
            ...map1[sdk_.ChainId.MAINNET],
            ...map2[sdk_.ChainId.MAINNET]
        },
        [sdk_.ChainId.TESTNET]: {
            ...map1[sdk_.ChainId.TESTNET],
            ...map2[sdk_.ChainId.TESTNET]
        }
    };
}
// merge tokens contained within lists from urls
function useCombinedTokenMapFromUrls(urls) {
    const lists = useAllLists();
    return (0,external_react_.useMemo)(()=>{
        if (!urls) return EMPTY_LIST;
        return urls.slice()// sort by priority so top priority goes last
        .sort(sortByListPriority).reduce((allTokens, currentUrl)=>{
            const current = lists[currentUrl]?.current;
            if (!current) return allTokens;
            try {
                const newTokens = Object.assign(listToTokenMap(current));
                return combineMaps(allTokens, newTokens);
            } catch (error) {
                console.error('Could not show token list due to error', error);
                return allTokens;
            }
        }, EMPTY_LIST);
    }, [
        lists,
        urls
    ]);
}
// filter out unsupported lists
function useActiveListUrls(includeDefaultLists = false) {
    const defaultList = includeDefaultLists ? constants_lists/* DEFAULT_LIST_OF_LISTS.filter */.Lx.filter((url)=>!constants_lists/* UNSUPPORTED_LIST_URLS.includes */.US.includes(url)
    ) : [];
    const stateList = (0,external_react_redux_.useSelector)((state)=>state.lists.activeListUrls
    )?.filter((url)=>!constants_lists/* UNSUPPORTED_LIST_URLS.includes */.US.includes(url)
    );
    return [
        ...new Set(defaultList.concat(stateList ?? []))
    ];
}
function useInactiveListUrls() {
    const lists = useAllLists();
    const allActiveListUrls = useActiveListUrls();
    return Object.keys(lists).filter((url)=>!allActiveListUrls?.includes(url) && !constants_lists/* UNSUPPORTED_LIST_URLS.includes */.US.includes(url)
    );
}
// get all the tokens from active lists, combine with local default tokens
function useCombinedActiveList(includeDefaultLists = false) {
    const activeListUrls = useActiveListUrls(includeDefaultLists);
    const activeTokens = useCombinedTokenMapFromUrls(activeListUrls);
    const defaultTokenMap = listToTokenMap(pancake_default_tokenlist_namespaceObject);
    return combineMaps(activeTokens, defaultTokenMap);
}
// all tokens from inactive lists
function useCombinedInactiveList() {
    const allInactiveListUrls = useInactiveListUrls();
    return useCombinedTokenMapFromUrls(allInactiveListUrls);
}
// used to hide warnings on import for default tokens
function useDefaultTokenList() {
    return listToTokenMap(DEFAULT_TOKEN_LIST);
}
// list of tokens not supported on interface, used to show warnings and prevent swaps and adds
function useUnsupportedTokenList() {
    // get hard coded unsupported tokens
    const localUnsupportedListMap = listToTokenMap(UNSUPPORTED_TOKEN_LIST);
    // get any loaded unsupported tokens
    const loadedUnsupportedListMap = useCombinedTokenMapFromUrls(UNSUPPORTED_LIST_URLS);
    // format into one token address map
    return combineMaps(localUnsupportedListMap, loadedUnsupportedListMap);
}
function useIsListActive(url) {
    const activeListUrls = useActiveListUrls();
    return Boolean(activeListUrls?.includes(url));
}


/***/ }),

/***/ 6681:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Updater)
/* harmony export */ });
/* harmony import */ var state_lists_hooks__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7952);
/* harmony import */ var _uniswap_token_lists__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1554);
/* harmony import */ var _uniswap_token_lists__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_uniswap_token_lists__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var hooks_Tokens__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6435);
/* harmony import */ var config_constants_lists__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(428);
/* harmony import */ var hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4011);
/* harmony import */ var hooks_useFetchListCallback__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8339);
/* harmony import */ var hooks_useInterval__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6159);
/* harmony import */ var hooks_useIsWindowVisible__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4587);
/* harmony import */ var _actions__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8412);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks_Tokens__WEBPACK_IMPORTED_MODULE_4__]);
hooks_Tokens__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];












function Updater() {
    const { library  } = (0,hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)();
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useDispatch)();
    const isWindowVisible = (0,hooks_useIsWindowVisible__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)();
    // get all loaded lists, and the active urls
    const lists = (0,state_lists_hooks__WEBPACK_IMPORTED_MODULE_0__/* .useAllLists */ .R0)();
    const activeListUrls = (0,state_lists_hooks__WEBPACK_IMPORTED_MODULE_0__/* .useActiveListUrls */ .v0)();
    // initiate loading
    (0,hooks_Tokens__WEBPACK_IMPORTED_MODULE_4__/* .useAllInactiveTokens */ .EK)();
    const fetchList = (0,hooks_useFetchListCallback__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
    const fetchAllListsCallback = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)(()=>{
        if (!isWindowVisible) return;
        Object.keys(lists).forEach((url)=>fetchList(url).catch((error)=>console.debug('interval list fetching error', error)
            )
        );
    }, [
        fetchList,
        isWindowVisible,
        lists
    ]);
    // fetch all lists every 10 minutes, but only after we initialize library
    (0,hooks_useInterval__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)(fetchAllListsCallback, library ? 1000 * 60 * 10 : null);
    // whenever a list is not loaded and not loading, try again to load it
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        Object.keys(lists).forEach((listUrl)=>{
            const list = lists[listUrl];
            if (!list.current && !list.loadingRequestId && !list.error) {
                fetchList(listUrl).catch((error)=>console.debug('list added fetching error', error)
                );
            }
        });
    }, [
        dispatch,
        fetchList,
        library,
        lists
    ]);
    // if any lists from unsupported lists are loaded, check them too (in case new updates since last visit)
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        Object.keys(config_constants_lists__WEBPACK_IMPORTED_MODULE_5__/* .UNSUPPORTED_LIST_URLS */ .US).forEach((listUrl)=>{
            const list = lists[listUrl];
            if (!list || !list.current && !list.loadingRequestId && !list.error) {
                fetchList(listUrl).catch((error)=>console.debug('list added fetching error', error)
                );
            }
        });
    }, [
        dispatch,
        fetchList,
        library,
        lists
    ]);
    // automatically update lists if versions are minor/patch
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        Object.keys(lists).forEach((listUrl)=>{
            const list = lists[listUrl];
            if (list.current && list.pendingUpdate) {
                const bump = (0,_uniswap_token_lists__WEBPACK_IMPORTED_MODULE_1__.getVersionUpgrade)(list.current.version, list.pendingUpdate.version);
                // eslint-disable-next-line default-case
                switch(bump){
                    case _uniswap_token_lists__WEBPACK_IMPORTED_MODULE_1__.VersionUpgrade.NONE:
                        throw new Error('unexpected no version bump');
                    // update any active or inactive lists
                    case _uniswap_token_lists__WEBPACK_IMPORTED_MODULE_1__.VersionUpgrade.PATCH:
                    case _uniswap_token_lists__WEBPACK_IMPORTED_MODULE_1__.VersionUpgrade.MINOR:
                    case _uniswap_token_lists__WEBPACK_IMPORTED_MODULE_1__.VersionUpgrade.MAJOR:
                        dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_10__/* .acceptListUpdate */ .xJ)(listUrl));
                }
            }
        });
    }, [
        dispatch,
        lists,
        activeListUrls
    ]);
    return null;
};

});

/***/ }),

/***/ 3884:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "kG": () => (/* binding */ toCallKey),
/* harmony export */   "gl": () => (/* binding */ parseCallKey),
/* harmony export */   "Dd": () => (/* binding */ addMulticallListeners),
/* harmony export */   "$x": () => (/* binding */ removeMulticallListeners),
/* harmony export */   "nu": () => (/* binding */ fetchingMulticallResults),
/* harmony export */   "wC": () => (/* binding */ errorFetchingMulticallResults),
/* harmony export */   "zT": () => (/* binding */ updateMulticallResults)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const ADDRESS_REGEX = /^0x[a-fA-F0-9]{40}$/;
const LOWER_HEX_REGEX = /^0x[a-f0-9]*$/;
function toCallKey(call) {
    if (!ADDRESS_REGEX.test(call.address)) {
        throw new Error(`Invalid address: ${call.address}`);
    }
    if (!LOWER_HEX_REGEX.test(call.callData)) {
        throw new Error(`Invalid hex: ${call.callData}`);
    }
    return `${call.address}-${call.callData}`;
}
function parseCallKey(callKey) {
    const pcs = callKey.split('-');
    if (pcs.length !== 2) {
        throw new Error(`Invalid call key: ${callKey}`);
    }
    return {
        address: pcs[0],
        callData: pcs[1]
    };
}
const addMulticallListeners = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('multicall/addMulticallListeners');
const removeMulticallListeners = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('multicall/removeMulticallListeners');
const fetchingMulticallResults = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('multicall/fetchingMulticallResults');
const errorFetchingMulticallResults = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('multicall/errorFetchingMulticallResults');
const updateMulticallResults = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('multicall/updateMulticallResults');


/***/ }),

/***/ 6390:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ chunkArray)
/* harmony export */ });
// chunks array into chunks of maximum size
// evenly distributes items among the chunks
function chunkArray(items, maxChunkSize) {
    if (maxChunkSize < 1) throw new Error('maxChunkSize must be gte 1');
    if (items.length <= maxChunkSize) return [
        items
    ];
    const numChunks = Math.ceil(items.length / maxChunkSize);
    const chunkSize = Math.ceil(items.length / numChunks);
    return [
        ...Array(numChunks).keys()
    ].map((ix)=>items.slice(ix * chunkSize, ix * chunkSize + chunkSize)
    );
};


/***/ }),

/***/ 1001:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "_Y": () => (/* binding */ useMultipleContractSingleData)
/* harmony export */ });
/* unused harmony exports NEVER_RELOAD, useSingleContractMultipleData, useSingleCallResult */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4011);
/* harmony import */ var state_block_hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7063);
/* harmony import */ var _actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3884);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([state_block_hooks__WEBPACK_IMPORTED_MODULE_3__]);
state_block_hooks__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];





function isMethodArg(x) {
    return [
        'string',
        'number'
    ].indexOf(typeof x) !== -1;
}
function isValidMethodArgs(x) {
    return x === undefined || Array.isArray(x) && x.every((xi)=>isMethodArg(xi) || Array.isArray(xi) && xi.every(isMethodArg)
    );
}
const INVALID_RESULT = {
    valid: false,
    blockNumber: undefined,
    data: undefined
};
// use this options object
const NEVER_RELOAD = {
    blocksPerFetch: Infinity
};
// the lowest level call for subscribing to contract data
function useCallsData(calls1, options) {
    const { chainId  } = (0,hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)();
    const callResults = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.multicall.callResults
    );
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useDispatch)();
    const serializedCallKeys = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>JSON.stringify(calls1?.filter((c)=>Boolean(c)
        )?.map(_actions__WEBPACK_IMPORTED_MODULE_4__/* .toCallKey */ .kG)?.sort() ?? [])
    , [
        calls1
    ]);
    // update listeners when there is an actual change that persists for at least 100ms
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        const callKeys = JSON.parse(serializedCallKeys);
        if (!chainId || callKeys.length === 0) return undefined;
        // eslint-disable-next-line @typescript-eslint/no-shadow
        const calls = callKeys.map((key)=>(0,_actions__WEBPACK_IMPORTED_MODULE_4__/* .parseCallKey */ .gl)(key)
        );
        dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_4__/* .addMulticallListeners */ .Dd)({
            chainId,
            calls,
            options
        }));
        return ()=>{
            dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_4__/* .removeMulticallListeners */ .$x)({
                chainId,
                calls,
                options
            }));
        };
    }, [
        chainId,
        dispatch,
        options,
        serializedCallKeys
    ]);
    return (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>calls1.map((call)=>{
            if (!chainId || !call) return INVALID_RESULT;
            const result = callResults[chainId]?.[(0,_actions__WEBPACK_IMPORTED_MODULE_4__/* .toCallKey */ .kG)(call)];
            let data;
            if (result?.data && result?.data !== '0x') {
                // eslint-disable-next-line prefer-destructuring
                data = result.data;
            }
            return {
                valid: true,
                data,
                blockNumber: result?.blockNumber
            };
        })
    , [
        callResults,
        calls1,
        chainId
    ]);
}
const INVALID_CALL_STATE = {
    valid: false,
    result: undefined,
    loading: false,
    syncing: false,
    error: false
};
const LOADING_CALL_STATE = {
    valid: true,
    result: undefined,
    loading: true,
    syncing: true,
    error: false
};
function toCallState(callResult, contractInterface, fragment, latestBlockNumber) {
    if (!callResult) return INVALID_CALL_STATE;
    const { valid , data , blockNumber  } = callResult;
    if (!valid) return INVALID_CALL_STATE;
    if (valid && !blockNumber) return LOADING_CALL_STATE;
    if (!contractInterface || !fragment || !latestBlockNumber) return LOADING_CALL_STATE;
    const success = data && data.length > 2;
    const syncing = (blockNumber ?? 0) < latestBlockNumber;
    let result;
    if (success && data) {
        try {
            result = contractInterface.decodeFunctionResult(fragment, data);
        } catch (error) {
            console.debug('Result data parsing failed', fragment, data);
            return {
                valid: true,
                loading: false,
                error: true,
                syncing,
                result
            };
        }
    }
    return {
        valid: true,
        loading: false,
        syncing,
        result,
        error: !success
    };
}
function useSingleContractMultipleData(contract, methodName, callInputs, options) {
    const fragment = useMemo(()=>contract?.interface?.getFunction(methodName)
    , [
        contract,
        methodName
    ]);
    const calls = useMemo(()=>contract && fragment && callInputs && callInputs.length > 0 ? callInputs.map((inputs)=>{
            return {
                address: contract.address,
                callData: contract.interface.encodeFunctionData(fragment, inputs)
            };
        }) : []
    , [
        callInputs,
        contract,
        fragment
    ]);
    const results = useCallsData(calls, options);
    const currentBlock = useCurrentBlock();
    return useMemo(()=>{
        return results.map((result)=>toCallState(result, contract?.interface, fragment, currentBlock)
        );
    }, [
        fragment,
        contract,
        results,
        currentBlock
    ]);
}
function useMultipleContractSingleData(addresses, contractInterface, methodName, callInputs, options) {
    const fragment = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>contractInterface.getFunction(methodName)
    , [
        contractInterface,
        methodName
    ]);
    const callData = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>fragment && isValidMethodArgs(callInputs) ? contractInterface.encodeFunctionData(fragment, callInputs) : undefined
    , [
        callInputs,
        contractInterface,
        fragment
    ]);
    const calls = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>fragment && addresses && addresses.length > 0 && callData ? addresses.map((address)=>{
            return address && callData ? {
                address,
                callData
            } : undefined;
        }) : []
    , [
        addresses,
        callData,
        fragment
    ]);
    const results = useCallsData(calls, options);
    const currentBlock = (0,state_block_hooks__WEBPACK_IMPORTED_MODULE_3__/* .useCurrentBlock */ .je)();
    return (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        return results.map((result)=>toCallState(result, contractInterface, fragment, currentBlock)
        );
    }, [
        fragment,
        results,
        contractInterface,
        currentBlock
    ]);
}
function useSingleCallResult(contract, methodName, inputs, options) {
    const fragment = useMemo(()=>contract?.interface?.getFunction(methodName)
    , [
        contract,
        methodName
    ]);
    const calls = useMemo(()=>{
        return contract && fragment && isValidMethodArgs(inputs) ? [
            {
                address: contract.address,
                callData: contract.interface.encodeFunctionData(fragment, inputs)
            }, 
        ] : [];
    }, [
        contract,
        fragment,
        inputs
    ]);
    const result = useCallsData(calls, options)[0];
    const currentBlock = useCurrentBlock();
    return useMemo(()=>{
        return toCallState(result, contract?.interface, fragment, currentBlock);
    }, [
        result,
        contract,
        fragment,
        currentBlock
    ]);
}

});

/***/ }),

/***/ 9228:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "p8": () => (/* binding */ CancelledError),
/* harmony export */   "s1": () => (/* binding */ RetryableError),
/* harmony export */   "XD": () => (/* binding */ retry)
/* harmony export */ });
/* eslint-disable */ function wait(ms) {
    return new Promise((resolve)=>setTimeout(resolve, ms)
    );
}
function waitRandom(min, max) {
    return wait(min + Math.round(Math.random() * Math.max(0, max - min)));
}
/**
 * This error is thrown if the function is cancelled before completing
 */ class CancelledError extends Error {
    constructor(){
        super('Cancelled');
    }
}
/**
 * Throw this error if the function should retry
 */ class RetryableError extends Error {
}
/**
 * Retries the function that returns the promise until the promise successfully resolves up to n retries
 * @param fn function to retry
 * @param n how many times to retry
 * @param minWait min wait between retries in ms
 * @param maxWait max wait between retries in ms
 */ function retry(fn, { n , minWait , maxWait  }) {
    let completed = false;
    let rejectCancelled;
    const promise = new Promise(async (resolve, reject)=>{
        rejectCancelled = reject;
        while(true){
            let result;
            try {
                result = await fn();
                if (!completed) {
                    resolve(result);
                    completed = true;
                }
                break;
            } catch (error) {
                console.error(error);
                if (completed) {
                    break;
                }
                if (n <= 0 || !(error instanceof RetryableError)) {
                    reject(error);
                    completed = true;
                    break;
                }
                n--;
            }
            await waitRandom(minWait, maxWait);
        }
    });
    return {
        promise,
        cancel: ()=>{
            if (completed) return;
            completed = true;
            rejectCancelled(new CancelledError());
        }
    };
} /* eslint-enable */ 


/***/ }),

/***/ 1710:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (/* binding */ Updater)
/* harmony export */ });
/* unused harmony exports activeListeningKeys, outdatedListeningKeys */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var state_block_hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7063);
/* harmony import */ var hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4011);
/* harmony import */ var _hooks_useContract__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5882);
/* harmony import */ var _hooks_useDebounce__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5999);
/* harmony import */ var _retry__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9228);
/* harmony import */ var _actions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3884);
/* harmony import */ var _chunkArray__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6390);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([state_block_hooks__WEBPACK_IMPORTED_MODULE_2__]);
state_block_hooks__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];









// chunk calls so we do not exceed the gas limit
const CALL_CHUNK_SIZE = 500;
/**
 * Fetches a chunk of calls, enforcing a minimum block number constraint
 * @param multicallContract multicall contract to fetch against
 * @param chunk chunk of calls to make
 * @param minBlockNumber minimum block number of the result set
 */ async function fetchChunk(multicallContract, chunk, minBlockNumber) {
    console.debug('Fetching chunk', multicallContract, chunk, minBlockNumber);
    let resultsBlockNumber;
    let returnData;
    try {
        // prettier-ignore
        [resultsBlockNumber, returnData] = await multicallContract.aggregate(chunk.map((obj)=>[
                obj.address,
                obj.callData
            ]
        ), {
            blockTag: minBlockNumber
        });
    } catch (err) {
        const error = err;
        if (error.code === -32000 || error?.data?.message && error?.data?.message?.indexOf('header not found') !== -1 || error.message?.indexOf('header not found') !== -1) {
            throw new _retry__WEBPACK_IMPORTED_MODULE_6__/* .RetryableError */ .s1(`header not found for block number ${minBlockNumber}`);
        } else if (error.code === -32603 || error.message?.indexOf('execution ran out of gas') !== -1) {
            if (chunk.length > 1) {
                if (false) {}
                const half = Math.floor(chunk.length / 2);
                const [c0, c1] = await Promise.all([
                    fetchChunk(multicallContract, chunk.slice(0, half), minBlockNumber),
                    fetchChunk(multicallContract, chunk.slice(half, chunk.length), minBlockNumber), 
                ]);
                return {
                    results: c0.results.concat(c1.results),
                    blockNumber: c1.blockNumber
                };
            }
        }
        console.debug('Failed to fetch chunk inside retry', error);
        throw error;
    }
    if (resultsBlockNumber.toNumber() < minBlockNumber) {
        console.debug(`Fetched results for old block number: ${resultsBlockNumber.toString()} vs. ${minBlockNumber}`);
    }
    return {
        results: returnData,
        blockNumber: resultsBlockNumber.toNumber()
    };
}
/**
 * From the current all listeners state, return each call key mapped to the
 * minimum number of blocks per fetch. This is how often each key must be fetched.
 * @param allListeners the all listeners state
 * @param chainId the current chain id
 */ function activeListeningKeys(allListeners, chainId) {
    if (!allListeners || !chainId) return {};
    const listeners = allListeners[chainId];
    if (!listeners) return {};
    return Object.keys(listeners).reduce((memo, callKey)=>{
        const keyListeners = listeners[callKey];
        memo[callKey] = Object.keys(keyListeners).filter((key)=>{
            const blocksPerFetch = parseInt(key);
            if (blocksPerFetch <= 0) return false;
            return keyListeners[blocksPerFetch] > 0;
        }).reduce((previousMin, current)=>{
            return Math.min(previousMin, parseInt(current));
        }, Infinity);
        return memo;
    }, {});
}
/**
 * Return the keys that need to be refetched
 * @param callResults current call result state
 * @param listeningKeys each call key mapped to how old the data can be in blocks
 * @param chainId the current chain id
 * @param currentBlock the latest block number
 */ function outdatedListeningKeys(callResults, listeningKeys, chainId, currentBlock) {
    if (!chainId || !currentBlock) return [];
    const results = callResults[chainId];
    // no results at all, load everything
    if (!results) return Object.keys(listeningKeys);
    return Object.keys(listeningKeys).filter((callKey)=>{
        const blocksPerFetch = listeningKeys[callKey];
        const data = callResults[chainId][callKey];
        // no data, must fetch
        if (!data) return true;
        const minDataBlockNumber = currentBlock - (blocksPerFetch - 1);
        // already fetching it for a recent enough block, don't refetch it
        if (data.fetchingBlockNumber && data.fetchingBlockNumber >= minDataBlockNumber) return false;
        // if data is older than minDataBlockNumber, fetch it
        return !data.blockNumber || data.blockNumber < minDataBlockNumber;
    });
}
function Updater() {
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useDispatch)();
    const state = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((s)=>s.multicall
    );
    // wait for listeners to settle before triggering updates
    const debouncedListeners = (0,_hooks_useDebounce__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)(state.callListeners, 100);
    const currentBlock = (0,state_block_hooks__WEBPACK_IMPORTED_MODULE_2__/* .useCurrentBlock */ .je)();
    const { chainId  } = (0,hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)();
    const multicallContract = (0,_hooks_useContract__WEBPACK_IMPORTED_MODULE_4__/* .useMulticallContract */ .gq)();
    const cancellations = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
    const listeningKeys = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        return activeListeningKeys(debouncedListeners, chainId);
    }, [
        debouncedListeners,
        chainId
    ]);
    const unserializedOutdatedCallKeys = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        return outdatedListeningKeys(state.callResults, listeningKeys, chainId, currentBlock);
    }, [
        chainId,
        state.callResults,
        listeningKeys,
        currentBlock
    ]);
    const serializedOutdatedCallKeys = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>JSON.stringify(unserializedOutdatedCallKeys.sort())
    , [
        unserializedOutdatedCallKeys
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        if (!currentBlock || !chainId || !multicallContract) return;
        const outdatedCallKeys = JSON.parse(serializedOutdatedCallKeys);
        if (outdatedCallKeys.length === 0) return;
        const calls = outdatedCallKeys.map((key)=>(0,_actions__WEBPACK_IMPORTED_MODULE_7__/* .parseCallKey */ .gl)(key)
        );
        const chunkedCalls = (0,_chunkArray__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)(calls, CALL_CHUNK_SIZE);
        if (cancellations.current?.blockNumber !== currentBlock) {
            cancellations.current?.cancellations?.forEach((c)=>c()
            );
        }
        dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_7__/* .fetchingMulticallResults */ .nu)({
            calls,
            chainId,
            fetchingBlockNumber: currentBlock
        }));
        cancellations.current = {
            blockNumber: currentBlock,
            cancellations: chunkedCalls.map((chunk, index)=>{
                const { cancel , promise  } = (0,_retry__WEBPACK_IMPORTED_MODULE_6__/* .retry */ .XD)(()=>fetchChunk(multicallContract, chunk, currentBlock)
                , {
                    n: Infinity,
                    minWait: 2500,
                    maxWait: 3500
                });
                promise.then(({ results: returnData , blockNumber: fetchBlockNumber  })=>{
                    cancellations.current = {
                        cancellations: [],
                        blockNumber: currentBlock
                    };
                    // accumulates the length of all previous indices
                    const firstCallKeyIndex = chunkedCalls.slice(0, index).reduce((memo, curr)=>memo + curr.length
                    , 0);
                    const lastCallKeyIndex = firstCallKeyIndex + returnData.length;
                    dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_7__/* .updateMulticallResults */ .zT)({
                        chainId,
                        results: outdatedCallKeys.slice(firstCallKeyIndex, lastCallKeyIndex).reduce((memo, callKey, i)=>{
                            memo[callKey] = returnData[i] ?? null;
                            return memo;
                        }, {}),
                        blockNumber: fetchBlockNumber
                    }));
                }).catch((error)=>{
                    if (error instanceof _retry__WEBPACK_IMPORTED_MODULE_6__/* .CancelledError */ .p8) {
                        console.debug('Cancelled fetch for blockNumber', currentBlock);
                        return;
                    }
                    console.error('Failed to fetch multicall chunk', chunk, chainId, error);
                    dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_7__/* .errorFetchingMulticallResults */ .wC)({
                        calls: chunk,
                        chainId,
                        fetchingBlockNumber: currentBlock
                    }));
                });
                return cancel;
            })
        };
    }, [
        chainId,
        multicallContract,
        dispatch,
        serializedOutdatedCallKeys,
        currentBlock
    ]);
    return null;
};

});

/***/ }),

/***/ 6004:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ck": () => (/* binding */ REWARD_RATE),
/* harmony export */   "fq": () => (/* binding */ ROUND_BUFFER),
/* harmony export */   "v9": () => (/* binding */ PAST_ROUND_COUNT),
/* harmony export */   "ND": () => (/* binding */ FUTURE_ROUND_COUNT),
/* harmony export */   "yg": () => (/* binding */ ROUNDS_PER_PAGE),
/* harmony export */   "eQ": () => (/* binding */ LEADERBOARD_MIN_ROUNDS_PLAYED)
/* harmony export */ });
const REWARD_RATE = 0.97;
// Estimated number of seconds it takes to submit a transaction (3 blocks) in seconds
const ROUND_BUFFER = 9;
const PAST_ROUND_COUNT = 5;
const FUTURE_ROUND_COUNT = 2;
const ROUNDS_PER_PAGE = 200;
const LEADERBOARD_MIN_ROUNDS_PLAYED = 10;


/***/ }),

/***/ 8925:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "ub": () => (/* binding */ LEADERBOARD_RESULTS_PER_PAGE),
  "x4": () => (/* binding */ Result),
  "oO": () => (/* binding */ fetchUserRounds),
  "t$": () => (/* binding */ fetchUsersRoundsLength),
  "Fr": () => (/* binding */ getBetHistory),
  "jG": () => (/* binding */ getClaimStatuses),
  "fq": () => (/* binding */ getFilteredBets),
  "Tq": () => (/* binding */ getLedgerData),
  "n": () => (/* binding */ getPredictionData),
  "s9": () => (/* binding */ getPredictionUser),
  "D": () => (/* binding */ getPredictionUsers),
  "yz": () => (/* binding */ getRoundResult),
  "$8": () => (/* binding */ getRoundsData),
  "yn": () => (/* binding */ getTotalWon),
  "CM": () => (/* binding */ makeFutureRoundResponse),
  "a8": () => (/* binding */ makeLedgerData),
  "D5": () => (/* binding */ makeRoundData),
  "zN": () => (/* binding */ parseBigNumberObj),
  "WB": () => (/* binding */ serializePredictionsRoundsResponse),
  "ld": () => (/* binding */ transformBetResponse),
  "r3": () => (/* binding */ transformUserResponse)
});

// UNUSED EXPORTS: getBet, numberOrNull, serializePredictionsLedgerResponse, transformRoundResponse

// EXTERNAL MODULE: external "graphql-request"
var external_graphql_request_ = __webpack_require__(5805);
// EXTERNAL MODULE: ./src/config/constants/endpoints.ts
var endpoints = __webpack_require__(5906);
// EXTERNAL MODULE: external "@ethersproject/bignumber"
var bignumber_ = __webpack_require__(5757);
// EXTERNAL MODULE: ./src/state/types.ts
var types = __webpack_require__(5101);
// EXTERNAL MODULE: ./src/utils/multicall.ts
var multicall = __webpack_require__(1144);
// EXTERNAL MODULE: ./src/utils/contractHelpers.ts + 27 modules
var contractHelpers = __webpack_require__(4765);
// EXTERNAL MODULE: ./src/config/abi/predictions.json
var predictions = __webpack_require__(5883);
// EXTERNAL MODULE: ./src/utils/addressHelpers.ts + 1 modules
var addressHelpers = __webpack_require__(5878);
;// CONCATENATED MODULE: ./src/state/predictions/queries.ts
/**
 * Base fields are the all the top-level fields available in the api. Used in multiple queries
 */ const queries_getRoundBaseFields = ()=>`
  id
  epoch
  position
  failed
  startAt
  startBlock
  startHash
  lockAt
  lockBlock
  lockHash
  lockPrice
  lockRoundId
  closeAt
  closeBlock
  closeHash
  closePrice
  closeRoundId
  totalBets
  totalAmount
  bullBets
  bullAmount
  bearBets
  bearAmount
`
;
const queries_getBetBaseFields = ()=>`
 id
 hash  
 amount
 position
 claimed
 claimedAt
 claimedHash
 claimedBlock
 claimedBNB
 claimedNetBNB
 createdAt
 updatedAt
`
;
const queries_getUserBaseFields = ()=>`
  id
  createdAt
  updatedAt
  block
  totalBets
  totalBetsBull
  totalBetsBear
  totalBNB
  totalBNBBull
  totalBNBBear
  totalBetsClaimed
  totalBNBClaimed
  winRate
  averageBNB
  netBNB
`
;

// EXTERNAL MODULE: ./src/state/predictions/config.ts
var config = __webpack_require__(6004);
;// CONCATENATED MODULE: ./src/state/predictions/helpers.ts










var Result;
(function(Result) {
    Result["WIN"] = 'win';
    Result["LOSE"] = 'lose';
    Result["CANCELED"] = 'canceled';
    Result["HOUSE"] = 'house';
    Result["LIVE"] = 'live';
})(Result || (Result = {}));
const numberOrNull = (value)=>{
    if (value === null) {
        return null;
    }
    const valueNum = Number(value);
    return Number.isNaN(valueNum) ? null : valueNum;
};
const getRoundPosition = (positionResponse)=>{
    if (positionResponse === 'Bull') {
        return types/* BetPosition.BULL */.Tu.BULL;
    }
    if (positionResponse === 'Bear') {
        return types/* BetPosition.BEAR */.Tu.BEAR;
    }
    if (positionResponse === 'House') {
        return types/* BetPosition.HOUSE */.Tu.HOUSE;
    }
    return null;
};
const transformBetResponse = (betResponse)=>{
    const bet = {
        id: betResponse.id,
        hash: betResponse.hash,
        block: numberOrNull(betResponse.block),
        amount: betResponse.amount ? parseFloat(betResponse.amount) : 0,
        position: betResponse.position === 'Bull' ? types/* BetPosition.BULL */.Tu.BULL : types/* BetPosition.BEAR */.Tu.BEAR,
        claimed: betResponse.claimed,
        claimedAt: numberOrNull(betResponse.claimedAt),
        claimedBlock: numberOrNull(betResponse.claimedBlock),
        claimedHash: betResponse.claimedHash,
        claimedBNB: betResponse.claimedBNB ? parseFloat(betResponse.claimedBNB) : 0,
        claimedNetBNB: betResponse.claimedNetBNB ? parseFloat(betResponse.claimedNetBNB) : 0,
        createdAt: numberOrNull(betResponse.createdAt),
        updatedAt: numberOrNull(betResponse.updatedAt)
    };
    if (betResponse.user) {
        bet.user = transformUserResponse(betResponse.user);
    }
    if (betResponse.round) {
        bet.round = transformRoundResponse(betResponse.round);
    }
    return bet;
};
const transformUserResponse = (userResponse)=>{
    const { id , createdAt , updatedAt , block , totalBets , totalBetsBull , totalBetsBear , totalBNB , totalBNBBull , totalBNBBear , totalBetsClaimed , totalBNBClaimed , winRate , averageBNB , netBNB ,  } = userResponse;
    return {
        id,
        createdAt: numberOrNull(createdAt),
        updatedAt: numberOrNull(updatedAt),
        block: numberOrNull(block),
        totalBets: numberOrNull(totalBets),
        totalBetsBull: numberOrNull(totalBetsBull),
        totalBetsBear: numberOrNull(totalBetsBear),
        totalBNB: totalBNB ? parseFloat(totalBNB) : 0,
        totalBNBBull: totalBNBBull ? parseFloat(totalBNBBull) : 0,
        totalBNBBear: totalBNBBear ? parseFloat(totalBNBBear) : 0,
        totalBetsClaimed: numberOrNull(totalBetsClaimed),
        totalBNBClaimed: totalBNBClaimed ? parseFloat(totalBNBClaimed) : 0,
        winRate: winRate ? parseFloat(winRate) : 0,
        averageBNB: averageBNB ? parseFloat(averageBNB) : 0,
        netBNB: netBNB ? parseFloat(netBNB) : 0
    };
};
const transformRoundResponse = (roundResponse)=>{
    const { id , epoch , failed , position , startAt , startBlock , startHash , lockAt , lockBlock , lockHash , lockPrice , lockRoundId , closeAt , closeBlock , closeHash , closePrice , closeRoundId , totalBets , totalAmount , bullBets , bullAmount , bearBets , bearAmount , bets =[] ,  } = roundResponse;
    return {
        id,
        failed,
        startHash,
        lockHash,
        lockRoundId,
        closeRoundId,
        closeHash,
        position: getRoundPosition(position),
        epoch: numberOrNull(epoch),
        startAt: numberOrNull(startAt),
        startBlock: numberOrNull(startBlock),
        lockAt: numberOrNull(lockAt),
        lockBlock: numberOrNull(lockBlock),
        lockPrice: lockPrice ? parseFloat(lockPrice) : 0,
        closeAt: numberOrNull(closeAt),
        closeBlock: numberOrNull(closeBlock),
        closePrice: closePrice ? parseFloat(closePrice) : 0,
        totalBets: numberOrNull(totalBets),
        totalAmount: totalAmount ? parseFloat(totalAmount) : 0,
        bullBets: numberOrNull(bullBets),
        bullAmount: bullAmount ? parseFloat(bullAmount) : 0,
        bearBets: numberOrNull(bearBets),
        bearAmount: bearAmount ? parseFloat(bearAmount) : 0,
        bets: bets.map(transformBetResponse)
    };
};
const getRoundResult = (bet, currentEpoch)=>{
    const { round  } = bet;
    if (round.failed) {
        return Result.CANCELED;
    }
    if (round.epoch >= currentEpoch - 1) {
        return Result.LIVE;
    }
    if (bet.round.position === types/* BetPosition.HOUSE */.Tu.HOUSE) {
        return Result.HOUSE;
    }
    const roundResultPosition = round.closePrice > round.lockPrice ? types/* BetPosition.BULL */.Tu.BULL : types/* BetPosition.BEAR */.Tu.BEAR;
    return bet.position === roundResultPosition ? Result.WIN : Result.LOSE;
};
const getFilteredBets = (bets, filter)=>{
    switch(filter){
        case types/* HistoryFilter.COLLECTED */.dZ.COLLECTED:
            return bets.filter((bet)=>bet.claimed === true
            );
        case types/* HistoryFilter.UNCOLLECTED */.dZ.UNCOLLECTED:
            return bets.filter((bet)=>{
                return !bet.claimed && (bet.position === bet.round.position || bet.round.failed === true);
            });
        case types/* HistoryFilter.ALL */.dZ.ALL:
        default:
            return bets;
    }
};
const getTotalWon = async ()=>{
    const { market  } = await (0,external_graphql_request_.request)(endpoints/* GRAPH_API_PREDICTION */.v5, external_graphql_request_.gql`
      query getTotalWonData {
        market(id: 1) {
          totalBNB
          totalBNBTreasury
        }
      }
    `);
    const totalBNB = market.totalBNB ? parseFloat(market.totalBNB) : 0;
    const totalBNBTreasury = market.totalBNBTreasury ? parseFloat(market.totalBNBTreasury) : 0;
    return Math.max(totalBNB - totalBNBTreasury, 0);
};
const getBetHistory = async (where = {}, first = 1000, skip = 0)=>{
    const response = await (0,external_graphql_request_.request)(endpoints/* GRAPH_API_PREDICTION */.v5, external_graphql_request_.gql`
      query getBetHistory($first: Int!, $skip: Int!, $where: Bet_filter) {
        bets(first: $first, skip: $skip, where: $where, order: createdAt, orderDirection: desc) {
          ${queries_getBetBaseFields()}
          round {
            ${queries_getRoundBaseFields()}
          }
          user {
            ${queries_getUserBaseFields()}
          }
        }
      }
    `, {
        first,
        skip,
        where
    });
    return response.bets;
};
const getBet = async (betId)=>{
    const response = await request(GRAPH_API_PREDICTION, gql`
      query getBet($id: ID!) {
        bet(id: $id) {
          ${getBetBaseFields()}
          round {
            ${getRoundBaseFields()}
          }
          user {
            ${getUserBaseFields()}
          }
        }
      }
  `, {
        id: betId.toLowerCase()
    });
    return response.bet;
};
const getLedgerData = async (account, epochs)=>{
    const address = (0,addressHelpers/* getPredictionsAddress */.Df)();
    const ledgerCalls = epochs.map((epoch)=>({
            address,
            name: 'ledger',
            params: [
                epoch,
                account
            ]
        })
    );
    const response = await (0,multicall/* multicallv2 */.v)(predictions, ledgerCalls);
    return response;
};
const LEADERBOARD_RESULTS_PER_PAGE = 20;
const defaultPredictionUserOptions = {
    skip: 0,
    first: LEADERBOARD_RESULTS_PER_PAGE,
    orderBy: 'createdAt',
    orderDir: 'desc'
};
const getPredictionUsers = async (options = {})=>{
    const { first , skip , where , orderBy , orderDir  } = {
        ...defaultPredictionUserOptions,
        ...options
    };
    const response = await (0,external_graphql_request_.request)(endpoints/* GRAPH_API_PREDICTION */.v5, external_graphql_request_.gql`
      query getUsers($first: Int!, $skip: Int!, $where: User_filter, $orderBy: User_orderBy, $orderDir: OrderDirection) {
        users(first: $first, skip: $skip, where: $where, orderBy: $orderBy, orderDirection: $orderDir) {
          ${queries_getUserBaseFields()}
        }
      }
    `, {
        first,
        skip,
        where,
        orderBy,
        orderDir
    });
    return response.users;
};
const getPredictionUser = async (account)=>{
    const response = await (0,external_graphql_request_.request)(endpoints/* GRAPH_API_PREDICTION */.v5, external_graphql_request_.gql`
      query getUser($id: ID!) {
        user(id: $id) {
          ${queries_getUserBaseFields()}
        }
      }
  `, {
        id: account.toLowerCase()
    });
    return response.user;
};
const getClaimStatuses = async (account, epochs)=>{
    const address = (0,addressHelpers/* getPredictionsAddress */.Df)();
    const claimableCalls = epochs.map((epoch)=>({
            address,
            name: 'claimable',
            params: [
                epoch,
                account
            ]
        })
    );
    const claimableResponses = await (0,multicall/* multicallv2 */.v)(predictions, claimableCalls);
    return claimableResponses.reduce((accum, claimableResponse, index)=>{
        const epoch = epochs[index];
        const [claimable] = claimableResponse;
        return {
            ...accum,
            [epoch]: claimable
        };
    }, {});
};
const getPredictionData = async ()=>{
    const address = (0,addressHelpers/* getPredictionsAddress */.Df)();
    const staticCalls = [
        'currentEpoch',
        'intervalSeconds',
        'minBetAmount',
        'paused',
        'bufferSeconds'
    ].map((method)=>({
            address,
            name: method
        })
    );
    const [[currentEpoch], [intervalSeconds], [minBetAmount], [paused], [bufferSeconds]] = await (0,multicall/* multicallv2 */.v)(predictions, staticCalls);
    return {
        status: paused ? types/* PredictionStatus.PAUSED */.Gw.PAUSED : types/* PredictionStatus.LIVE */.Gw.LIVE,
        currentEpoch: currentEpoch.toNumber(),
        intervalSeconds: intervalSeconds.toNumber(),
        minBetAmount: minBetAmount.toString(),
        bufferSeconds: bufferSeconds.toNumber()
    };
};
const getRoundsData = async (epochs)=>{
    const address = (0,addressHelpers/* getPredictionsAddress */.Df)();
    const calls = epochs.map((epoch)=>({
            address,
            name: 'rounds',
            params: [
                epoch
            ]
        })
    );
    const response = await (0,multicall/* multicallv2 */.v)(predictions, calls);
    return response;
};
const makeFutureRoundResponse = (epoch, startTimestamp)=>{
    return {
        epoch,
        startTimestamp,
        lockTimestamp: null,
        closeTimestamp: null,
        lockPrice: null,
        closePrice: null,
        totalAmount: bignumber_.BigNumber.from(0).toJSON(),
        bullAmount: bignumber_.BigNumber.from(0).toJSON(),
        bearAmount: bignumber_.BigNumber.from(0).toJSON(),
        rewardBaseCalAmount: bignumber_.BigNumber.from(0).toJSON(),
        rewardAmount: bignumber_.BigNumber.from(0).toJSON(),
        oracleCalled: false,
        lockOracleId: null,
        closeOracleId: null
    };
};
const makeRoundData = (rounds)=>{
    return rounds.reduce((accum, round)=>{
        return {
            ...accum,
            [round.epoch.toString()]: round
        };
    }, {});
};
const serializePredictionsLedgerResponse = (ledgerResponse)=>({
        position: ledgerResponse.position === 0 ? types/* BetPosition.BULL */.Tu.BULL : types/* BetPosition.BEAR */.Tu.BEAR,
        amount: ledgerResponse.amount.toJSON(),
        claimed: ledgerResponse.claimed
    })
;
const makeLedgerData = (account, ledgers, epochs)=>{
    return ledgers.reduce((accum, ledgerResponse, index)=>{
        if (!ledgerResponse) {
            return accum;
        }
        // If the amount is zero that means the user did not bet
        if (ledgerResponse.amount.eq(0)) {
            return accum;
        }
        const epoch = epochs[index].toString();
        return {
            ...accum,
            [account]: {
                ...accum[account],
                [epoch]: serializePredictionsLedgerResponse(ledgerResponse)
            }
        };
    }, {});
};
/**
 * Serializes the return from the "rounds" call for redux
 */ const serializePredictionsRoundsResponse = (response)=>{
    const { epoch , startTimestamp , lockTimestamp , closeTimestamp , lockPrice , closePrice , totalAmount , bullAmount , bearAmount , rewardBaseCalAmount , rewardAmount , oracleCalled , lockOracleId , closeOracleId ,  } = response;
    return {
        oracleCalled,
        epoch: epoch.toNumber(),
        startTimestamp: startTimestamp.eq(0) ? null : startTimestamp.toNumber(),
        lockTimestamp: lockTimestamp.eq(0) ? null : lockTimestamp.toNumber(),
        closeTimestamp: closeTimestamp.eq(0) ? null : closeTimestamp.toNumber(),
        lockPrice: lockPrice.eq(0) ? null : lockPrice.toJSON(),
        closePrice: closePrice.eq(0) ? null : closePrice.toJSON(),
        totalAmount: totalAmount.toJSON(),
        bullAmount: bullAmount.toJSON(),
        bearAmount: bearAmount.toJSON(),
        rewardBaseCalAmount: rewardBaseCalAmount.toJSON(),
        rewardAmount: rewardAmount.toJSON(),
        lockOracleId: lockOracleId.toString(),
        closeOracleId: closeOracleId.toString()
    };
};
/**
 * Parse serialized values back into BigNumber
 * BigNumber values are stored with the "toJSON()" method, e.g  { type: "BigNumber", hex: string }
 */ const parseBigNumberObj = (data)=>{
    return Object.keys(data).reduce((accum, key)=>{
        const value = data[key];
        if (value && value?.type === 'BigNumber') {
            return {
                ...accum,
                [key]: bignumber_.BigNumber.from(value)
            };
        }
        return {
            ...accum,
            [key]: value
        };
    }, {});
};
const fetchUsersRoundsLength = async (account)=>{
    try {
        const contract = (0,contractHelpers/* getPredictionsContract */.qi)();
        const length = await contract.getUserRoundsLength(account);
        return length;
    } catch  {
        return bignumber_.BigNumber.from(0);
    }
};
/**
 * Fetches rounds a user has participated in
 */ const fetchUserRounds = async (account, cursor = 0, size = config/* ROUNDS_PER_PAGE */.yg)=>{
    const contract = (0,contractHelpers/* getPredictionsContract */.qi)();
    try {
        const [rounds, ledgers] = await contract.getUserRounds(account, cursor, size);
        return rounds.reduce((accum, round, index)=>{
            return {
                ...accum,
                [round.toString()]: serializePredictionsLedgerResponse(ledgers[index])
            };
        }, {});
    } catch  {
        // When the results run out the contract throws an error.
        return null;
    }
};


/***/ }),

/***/ 7774:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "uw": () => (/* binding */ initializePredictions),
/* harmony export */   "m0": () => (/* binding */ fetchRounds),
/* harmony export */   "MK": () => (/* binding */ fetchMarketData),
/* harmony export */   "Ub": () => (/* binding */ fetchLedgerData),
/* harmony export */   "sU": () => (/* binding */ fetchClaimableStatuses),
/* harmony export */   "uP": () => (/* binding */ fetchNodeHistory),
/* harmony export */   "dG": () => (/* binding */ filterLeaderboard),
/* harmony export */   "nI": () => (/* binding */ fetchAddressResult),
/* harmony export */   "Mk": () => (/* binding */ filterNextPageLeaderboard),
/* harmony export */   "nQ": () => (/* binding */ setChartPaneState),
/* harmony export */   "Yq": () => (/* binding */ setHistoryFilter),
/* harmony export */   "vR": () => (/* binding */ setHistoryPaneState),
/* harmony export */   "GG": () => (/* binding */ setLastOraclePrice),
/* harmony export */   "WB": () => (/* binding */ markAsCollected),
/* harmony export */   "G$": () => (/* binding */ setLeaderboardFilter),
/* harmony export */   "l3": () => (/* binding */ setSelectedAddress),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports fetchRound, fetchHistory, predictionsSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5757);
/* harmony import */ var _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ethersproject_units__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3138);
/* harmony import */ var _ethersproject_units__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_units__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var lodash_maxBy__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1341);
/* harmony import */ var lodash_maxBy__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(lodash_maxBy__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var lodash_merge__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1831);
/* harmony import */ var lodash_merge__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(lodash_merge__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var lodash_range__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4042);
/* harmony import */ var lodash_range__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(lodash_range__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var utils_bigNumber__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5128);
/* harmony import */ var state_types__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5101);
/* harmony import */ var utils_contractHelpers__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4765);
/* harmony import */ var config_constants_types__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7971);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6004);
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8925);












const initialState = {
    status: state_types__WEBPACK_IMPORTED_MODULE_7__/* .PredictionStatus.INITIAL */ .Gw.INITIAL,
    isLoading: false,
    isHistoryPaneOpen: false,
    isChartPaneOpen: false,
    isFetchingHistory: false,
    historyFilter: state_types__WEBPACK_IMPORTED_MODULE_7__/* .HistoryFilter.ALL */ .dZ.ALL,
    currentEpoch: 0,
    intervalSeconds: 300,
    minBetAmount: '10000000000000',
    bufferSeconds: 60,
    lastOraclePrice: utils_bigNumber__WEBPACK_IMPORTED_MODULE_6__/* .BIG_ZERO.toJSON */ .HW.toJSON(),
    rounds: {},
    history: [],
    totalHistory: 0,
    currentHistoryPage: 1,
    hasHistoryLoaded: false,
    ledgers: {},
    claimableStatuses: {},
    leaderboard: {
        selectedAddress: null,
        loadingState: config_constants_types__WEBPACK_IMPORTED_MODULE_9__/* .FetchStatus.Idle */ .iF.Idle,
        filters: {
            address: null,
            orderBy: 'netBNB',
            timePeriod: 'all'
        },
        skip: 0,
        hasMoreResults: true,
        addressResults: {},
        results: []
    }
};
const initializePredictions = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('predictions/initialize', async (account = null)=>{
    // Static values
    const marketData = await (0,_helpers__WEBPACK_IMPORTED_MODULE_10__/* .getPredictionData */ .n)();
    const epochs = marketData.currentEpoch > _config__WEBPACK_IMPORTED_MODULE_11__/* .PAST_ROUND_COUNT */ .v9 ? lodash_range__WEBPACK_IMPORTED_MODULE_5___default()(marketData.currentEpoch, marketData.currentEpoch - _config__WEBPACK_IMPORTED_MODULE_11__/* .PAST_ROUND_COUNT */ .v9) : [
        marketData.currentEpoch
    ];
    // Round data
    const roundsResponse = await (0,_helpers__WEBPACK_IMPORTED_MODULE_10__/* .getRoundsData */ .$8)(epochs);
    const initialRoundData = roundsResponse.reduce((accum, roundResponse)=>{
        const reduxNodeRound = (0,_helpers__WEBPACK_IMPORTED_MODULE_10__/* .serializePredictionsRoundsResponse */ .WB)(roundResponse);
        return {
            ...accum,
            [reduxNodeRound.epoch.toString()]: reduxNodeRound
        };
    }, {});
    const initializedData = {
        ...marketData,
        rounds: initialRoundData,
        ledgers: {},
        claimableStatuses: {}
    };
    if (!account) {
        return initializedData;
    }
    // Bet data
    const ledgerResponses = await (0,_helpers__WEBPACK_IMPORTED_MODULE_10__/* .getLedgerData */ .Tq)(account, epochs);
    // Claim statuses
    const claimableStatuses = await (0,_helpers__WEBPACK_IMPORTED_MODULE_10__/* .getClaimStatuses */ .jG)(account, epochs);
    return lodash_merge__WEBPACK_IMPORTED_MODULE_4___default()({}, initializedData, {
        ledgers: (0,_helpers__WEBPACK_IMPORTED_MODULE_10__/* .makeLedgerData */ .a8)(account, ledgerResponses, epochs),
        claimableStatuses
    });
});
const fetchRound = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('predictions/fetchRound', async (epoch)=>{
    const predictionContract = (0,utils_contractHelpers__WEBPACK_IMPORTED_MODULE_8__/* .getPredictionsContract */ .qi)();
    const response = await predictionContract.rounds(epoch);
    return (0,_helpers__WEBPACK_IMPORTED_MODULE_10__/* .serializePredictionsRoundsResponse */ .WB)(response);
});
const fetchRounds = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('predictions/fetchRounds', async (epochs)=>{
    const rounds = await (0,_helpers__WEBPACK_IMPORTED_MODULE_10__/* .getRoundsData */ .$8)(epochs);
    return rounds.reduce((accum, round)=>{
        if (!round) {
            return accum;
        }
        const reduxNodeRound = (0,_helpers__WEBPACK_IMPORTED_MODULE_10__/* .serializePredictionsRoundsResponse */ .WB)(round);
        return {
            ...accum,
            [reduxNodeRound.epoch.toString()]: reduxNodeRound
        };
    }, {});
});
const fetchMarketData = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('predictions/fetchMarketData', async ()=>{
    const marketData = await (0,_helpers__WEBPACK_IMPORTED_MODULE_10__/* .getPredictionData */ .n)();
    return marketData;
});
const fetchLedgerData = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('predictions/fetchLedgerData', async ({ account , epochs  })=>{
    const ledgers = await (0,_helpers__WEBPACK_IMPORTED_MODULE_10__/* .getLedgerData */ .Tq)(account, epochs);
    return (0,_helpers__WEBPACK_IMPORTED_MODULE_10__/* .makeLedgerData */ .a8)(account, ledgers, epochs);
});
const fetchClaimableStatuses = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('predictions/fetchClaimableStatuses', async ({ account , epochs  })=>{
    const ledgers = await (0,_helpers__WEBPACK_IMPORTED_MODULE_10__/* .getClaimStatuses */ .jG)(account, epochs);
    return ledgers;
});
const fetchHistory = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('predictions/fetchHistory', async ({ account , claimed  })=>{
    const response = await (0,_helpers__WEBPACK_IMPORTED_MODULE_10__/* .getBetHistory */ .Fr)({
        user: account.toLowerCase(),
        claimed
    });
    const bets = response.map(_helpers__WEBPACK_IMPORTED_MODULE_10__/* .transformBetResponse */ .ld);
    return {
        account,
        bets
    };
});
const fetchNodeHistory = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('predictions/fetchNodeHistory', async ({ account , page =1  })=>{
    const userRoundsLength = await (0,_helpers__WEBPACK_IMPORTED_MODULE_10__/* .fetchUsersRoundsLength */ .t$)(account);
    const emptyResult = {
        bets: [],
        claimableStatuses: {},
        totalHistory: userRoundsLength.toNumber()
    };
    const maxPages = userRoundsLength.lte(_config__WEBPACK_IMPORTED_MODULE_11__/* .ROUNDS_PER_PAGE */ .yg) ? 1 : Math.ceil(userRoundsLength.toNumber() / _config__WEBPACK_IMPORTED_MODULE_11__/* .ROUNDS_PER_PAGE */ .yg);
    if (userRoundsLength.eq(0)) {
        return emptyResult;
    }
    if (page > maxPages) {
        return emptyResult;
    }
    const cursor = userRoundsLength.sub(_config__WEBPACK_IMPORTED_MODULE_11__/* .ROUNDS_PER_PAGE */ .yg * page);
    // If the page request is the final one we only want to retrieve the amount of rounds up to the next cursor.
    const size = maxPages === page ? userRoundsLength.sub(_config__WEBPACK_IMPORTED_MODULE_11__/* .ROUNDS_PER_PAGE */ .yg * (page - 1)) // Previous page's cursor
    .toNumber() : _config__WEBPACK_IMPORTED_MODULE_11__/* .ROUNDS_PER_PAGE */ .yg;
    const userRounds = await (0,_helpers__WEBPACK_IMPORTED_MODULE_10__/* .fetchUserRounds */ .oO)(account, cursor.lt(0) ? 0 : cursor.toNumber(), size);
    if (!userRounds) {
        return emptyResult;
    }
    const epochs = Object.keys(userRounds).map((epochStr)=>Number(epochStr)
    );
    const roundData = await (0,_helpers__WEBPACK_IMPORTED_MODULE_10__/* .getRoundsData */ .$8)(epochs);
    const claimableStatuses = await (0,_helpers__WEBPACK_IMPORTED_MODULE_10__/* .getClaimStatuses */ .jG)(account, epochs);
    // Turn the data from the node into an Bet object that comes from the graph
    const bets = roundData.reduce((accum, round)=>{
        const reduxRound = (0,_helpers__WEBPACK_IMPORTED_MODULE_10__/* .serializePredictionsRoundsResponse */ .WB)(round);
        const ledger = userRounds[reduxRound.epoch];
        const ledgerAmount = _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_1__.BigNumber.from(ledger.amount);
        const closePrice = round.closePrice ? parseFloat((0,_ethersproject_units__WEBPACK_IMPORTED_MODULE_2__.formatUnits)(round.closePrice, 8)) : null;
        const lockPrice = round.lockPrice ? parseFloat((0,_ethersproject_units__WEBPACK_IMPORTED_MODULE_2__.formatUnits)(round.lockPrice, 8)) : null;
        const getRoundPosition = ()=>{
            if (!closePrice) {
                return null;
            }
            if (round.closePrice.eq(round.lockPrice)) {
                return state_types__WEBPACK_IMPORTED_MODULE_7__/* .BetPosition.HOUSE */ .Tu.HOUSE;
            }
            return round.closePrice.gt(round.lockPrice) ? state_types__WEBPACK_IMPORTED_MODULE_7__/* .BetPosition.BULL */ .Tu.BULL : state_types__WEBPACK_IMPORTED_MODULE_7__/* .BetPosition.BEAR */ .Tu.BEAR;
        };
        return [
            ...accum,
            {
                id: null,
                hash: null,
                amount: parseFloat((0,_ethersproject_units__WEBPACK_IMPORTED_MODULE_2__.formatUnits)(ledgerAmount)),
                position: ledger.position,
                claimed: ledger.claimed,
                claimedAt: null,
                claimedHash: null,
                claimedBNB: 0,
                claimedNetBNB: 0,
                createdAt: null,
                updatedAt: null,
                block: 0,
                round: {
                    id: null,
                    epoch: round.epoch.toNumber(),
                    failed: false,
                    startBlock: null,
                    startAt: round.startTimestamp ? round.startTimestamp.toNumber() : null,
                    startHash: null,
                    lockAt: round.lockTimestamp ? round.lockTimestamp.toNumber() : null,
                    lockBlock: null,
                    lockPrice,
                    lockHash: null,
                    lockRoundId: round.lockOracleId ? round.lockOracleId.toString() : null,
                    closeRoundId: round.closeOracleId ? round.closeOracleId.toString() : null,
                    closeHash: null,
                    closeAt: null,
                    closePrice,
                    closeBlock: null,
                    totalBets: 0,
                    totalAmount: parseFloat((0,_ethersproject_units__WEBPACK_IMPORTED_MODULE_2__.formatUnits)(round.totalAmount)),
                    bullBets: 0,
                    bullAmount: parseFloat((0,_ethersproject_units__WEBPACK_IMPORTED_MODULE_2__.formatUnits)(round.bullAmount)),
                    bearBets: 0,
                    bearAmount: parseFloat((0,_ethersproject_units__WEBPACK_IMPORTED_MODULE_2__.formatUnits)(round.bearAmount)),
                    position: getRoundPosition()
                }
            }, 
        ];
    }, []);
    return {
        bets,
        claimableStatuses,
        page,
        totalHistory: userRoundsLength.toNumber()
    };
});
// Leaderboard
const filterLeaderboard = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('predictions/filterLeaderboard', async ({ filters  })=>{
    const usersResponse = await (0,_helpers__WEBPACK_IMPORTED_MODULE_10__/* .getPredictionUsers */ .D)({
        skip: 0,
        orderBy: filters.orderBy,
        where: {
            totalBets_gte: _config__WEBPACK_IMPORTED_MODULE_11__/* .LEADERBOARD_MIN_ROUNDS_PLAYED */ .eQ,
            [`${filters.orderBy}_gt`]: 0
        }
    });
    return {
        results: usersResponse.map(_helpers__WEBPACK_IMPORTED_MODULE_10__/* .transformUserResponse */ .r3)
    };
});
const fetchAddressResult = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('predictions/fetchAddressResult', async (account, { rejectWithValue  })=>{
    const userResponse = await (0,_helpers__WEBPACK_IMPORTED_MODULE_10__/* .getPredictionUser */ .s9)(account);
    if (!userResponse) {
        return rejectWithValue(account);
    }
    return {
        account,
        data: (0,_helpers__WEBPACK_IMPORTED_MODULE_10__/* .transformUserResponse */ .r3)(userResponse)
    };
});
const filterNextPageLeaderboard = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('predictions/filterNextPageLeaderboard', async (skip, { getState  })=>{
    const state = getState();
    const usersResponse = await (0,_helpers__WEBPACK_IMPORTED_MODULE_10__/* .getPredictionUsers */ .D)({
        skip,
        orderBy: state.predictions.leaderboard.filters.orderBy,
        where: {
            totalBets_gte: _config__WEBPACK_IMPORTED_MODULE_11__/* .LEADERBOARD_MIN_ROUNDS_PLAYED */ .eQ,
            [`${state.predictions.leaderboard.filters.orderBy}_gt`]: 0
        }
    });
    return {
        results: usersResponse.map(_helpers__WEBPACK_IMPORTED_MODULE_10__/* .transformUserResponse */ .r3),
        skip
    };
});
const predictionsSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: 'predictions',
    initialState,
    reducers: {
        setLeaderboardFilter: (state, action)=>{
            state.leaderboard.filters = {
                ...state.leaderboard.filters,
                ...action.payload
            };
            // Anytime we filters change we need to reset back to page 1
            state.leaderboard.skip = 0;
            state.leaderboard.hasMoreResults = true;
        },
        setHistoryPaneState: (state, action)=>{
            state.isHistoryPaneOpen = action.payload;
            state.historyFilter = state_types__WEBPACK_IMPORTED_MODULE_7__/* .HistoryFilter.ALL */ .dZ.ALL;
        },
        setChartPaneState: (state, action)=>{
            state.isChartPaneOpen = action.payload;
        },
        setHistoryFilter: (state, action)=>{
            state.historyFilter = action.payload;
        },
        setLastOraclePrice: (state, action)=>{
            state.lastOraclePrice = action.payload;
        },
        markAsCollected: (state, action)=>{
            state.claimableStatuses = {
                ...state.claimableStatuses,
                ...action.payload
            };
        },
        setSelectedAddress: (state, action)=>{
            state.leaderboard.selectedAddress = action.payload;
        }
    },
    extraReducers: (builder)=>{
        // Leaderboard filter
        builder.addCase(filterLeaderboard.pending, (state)=>{
            // Only mark as loading if we come from Fetched. This allows initialization.
            if (state.leaderboard.loadingState === config_constants_types__WEBPACK_IMPORTED_MODULE_9__/* .FetchStatus.Fetched */ .iF.Fetched) {
                state.leaderboard.loadingState = config_constants_types__WEBPACK_IMPORTED_MODULE_9__/* .FetchStatus.Fetched */ .iF.Fetched;
            }
        });
        builder.addCase(filterLeaderboard.fulfilled, (state, action)=>{
            const { results  } = action.payload;
            state.leaderboard.loadingState = config_constants_types__WEBPACK_IMPORTED_MODULE_9__/* .FetchStatus.Fetched */ .iF.Fetched;
            state.leaderboard.results = results;
            if (results.length < _helpers__WEBPACK_IMPORTED_MODULE_10__/* .LEADERBOARD_RESULTS_PER_PAGE */ .ub) {
                state.leaderboard.hasMoreResults = false;
            }
            // Populate address results to reduce calls
            state.leaderboard.addressResults = {
                ...state.leaderboard.addressResults,
                ...results.reduce((accum, result)=>{
                    return {
                        ...accum,
                        [result.id]: result
                    };
                }, {})
            };
        });
        // Leaderboard account result
        builder.addCase(fetchAddressResult.pending, (state)=>{
            state.leaderboard.loadingState = config_constants_types__WEBPACK_IMPORTED_MODULE_9__/* .FetchStatus.Fetching */ .iF.Fetching;
        });
        builder.addCase(fetchAddressResult.fulfilled, (state, action)=>{
            const { account , data  } = action.payload;
            state.leaderboard.loadingState = config_constants_types__WEBPACK_IMPORTED_MODULE_9__/* .FetchStatus.Fetched */ .iF.Fetched;
            state.leaderboard.addressResults[account] = data;
        });
        builder.addCase(fetchAddressResult.rejected, (state, action)=>{
            state.leaderboard.loadingState = config_constants_types__WEBPACK_IMPORTED_MODULE_9__/* .FetchStatus.Fetched */ .iF.Fetched // TODO: should handle error
            ;
            state.leaderboard.addressResults[action.payload] = null;
        });
        // Leaderboard next page
        builder.addCase(filterNextPageLeaderboard.pending, (state)=>{
            state.leaderboard.loadingState = config_constants_types__WEBPACK_IMPORTED_MODULE_9__/* .FetchStatus.Fetching */ .iF.Fetching;
        });
        builder.addCase(filterNextPageLeaderboard.fulfilled, (state, action)=>{
            const { results , skip  } = action.payload;
            state.leaderboard.loadingState = config_constants_types__WEBPACK_IMPORTED_MODULE_9__/* .FetchStatus.Fetched */ .iF.Fetched;
            state.leaderboard.results = [
                ...state.leaderboard.results,
                ...results
            ];
            state.leaderboard.skip = skip;
            if (results.length < _helpers__WEBPACK_IMPORTED_MODULE_10__/* .LEADERBOARD_RESULTS_PER_PAGE */ .ub) {
                state.leaderboard.hasMoreResults = false;
            }
        });
        // Claimable statuses
        builder.addCase(fetchClaimableStatuses.fulfilled, (state, action)=>{
            state.claimableStatuses = lodash_merge__WEBPACK_IMPORTED_MODULE_4___default()({}, state.claimableStatuses, action.payload);
        });
        // Ledger (bet) records
        builder.addCase(fetchLedgerData.fulfilled, (state, action)=>{
            state.ledgers = lodash_merge__WEBPACK_IMPORTED_MODULE_4___default()({}, state.ledgers, action.payload);
        });
        // Get static market data
        builder.addCase(fetchMarketData.fulfilled, (state, action)=>{
            const { status , currentEpoch , intervalSeconds , minBetAmount  } = action.payload;
            // If the round has change add a new future round
            if (state.currentEpoch !== currentEpoch) {
                const newestRound = lodash_maxBy__WEBPACK_IMPORTED_MODULE_3___default()(Object.values(state.rounds), 'epoch');
                const futureRound = (0,_helpers__WEBPACK_IMPORTED_MODULE_10__/* .makeFutureRoundResponse */ .CM)(newestRound.epoch + 1, newestRound.startTimestamp + intervalSeconds + _config__WEBPACK_IMPORTED_MODULE_11__/* .ROUND_BUFFER */ .fq);
                state.rounds[futureRound.epoch] = futureRound;
            }
            state.status = status;
            state.currentEpoch = currentEpoch;
            state.intervalSeconds = intervalSeconds;
            state.minBetAmount = minBetAmount;
        });
        // Initialize predictions
        builder.addCase(initializePredictions.fulfilled, (state, action)=>{
            const { status , currentEpoch , intervalSeconds , bufferSeconds , rounds , claimableStatuses , ledgers  } = action.payload;
            const futureRounds = [];
            const currentRound = rounds[currentEpoch];
            for(let i = 1; i <= _config__WEBPACK_IMPORTED_MODULE_11__/* .FUTURE_ROUND_COUNT */ .ND; i++){
                futureRounds.push((0,_helpers__WEBPACK_IMPORTED_MODULE_10__/* .makeFutureRoundResponse */ .CM)(currentEpoch + i, currentRound.startTimestamp + intervalSeconds * i));
            }
            return {
                ...state,
                status,
                currentEpoch,
                intervalSeconds,
                bufferSeconds,
                claimableStatuses,
                ledgers,
                rounds: lodash_merge__WEBPACK_IMPORTED_MODULE_4___default()({}, rounds, (0,_helpers__WEBPACK_IMPORTED_MODULE_10__/* .makeRoundData */ .D5)(futureRounds))
            };
        });
        // Get single round
        builder.addCase(fetchRound.fulfilled, (state, action)=>{
            state.rounds = lodash_merge__WEBPACK_IMPORTED_MODULE_4___default()({}, state.rounds, {
                [action.payload.epoch.toString()]: action.payload
            });
        });
        // Get multiple rounds
        builder.addCase(fetchRounds.fulfilled, (state, action)=>{
            state.rounds = lodash_merge__WEBPACK_IMPORTED_MODULE_4___default()({}, state.rounds, action.payload);
        });
        // Show History
        builder.addCase(fetchHistory.pending, (state)=>{
            state.isFetchingHistory = true;
        });
        builder.addCase(fetchHistory.rejected, (state)=>{
            state.isFetchingHistory = false;
        });
        builder.addCase(fetchHistory.fulfilled, (state, action)=>{
            const { account , bets  } = action.payload;
            state.isFetchingHistory = false;
            state.history[account] = lodash_merge__WEBPACK_IMPORTED_MODULE_4___default()([], state.history[account] ?? [], bets);
        });
        // History from the node
        builder.addCase(fetchNodeHistory.pending, (state)=>{
            state.isFetchingHistory = true;
        });
        builder.addCase(fetchNodeHistory.rejected, (state)=>{
            state.isFetchingHistory = false;
        });
        builder.addCase(fetchNodeHistory.fulfilled, (state, action)=>{
            const { bets , claimableStatuses , page , totalHistory  } = action.payload;
            state.isFetchingHistory = false;
            state.history = page === 1 ? bets : [
                ...state.history,
                ...bets
            ];
            state.claimableStatuses = {
                ...state.claimableStatuses,
                ...claimableStatuses
            };
            state.hasHistoryLoaded = state.history.length === totalHistory || bets.length === 0;
            state.totalHistory = totalHistory;
            state.currentHistoryPage = page;
        });
    }
});
// Actions
const { setChartPaneState , setHistoryFilter , setHistoryPaneState , setLastOraclePrice , markAsCollected , setLeaderboardFilter , setSelectedAddress ,  } = predictionsSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (predictionsSlice.reducer);


/***/ }),

/***/ 5712:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ms": () => (/* binding */ getUsername),
/* harmony export */   "rC": () => (/* binding */ getProfileAvatar),
/* harmony export */   "Ai": () => (/* binding */ getProfile)
/* harmony export */ });
/* harmony import */ var config_abi_pancakeProfile_json__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2335);
/* harmony import */ var utils_multicall__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1144);
/* harmony import */ var utils_addressHelpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5878);



const transformProfileResponse = (profileResponse)=>{
    const { 0: userId , 1: numberPoints , 2: teamId , 3: collectionAddress , 4: tokenId , 5: isActive  } = profileResponse;
    return {
        userId: userId.toNumber(),
        points: numberPoints.toNumber(),
        teamId: teamId.toNumber(),
        tokenId: tokenId.toNumber(),
        collectionAddress,
        isActive
    };
};
const profileApi = "https://profile.pancakeswap.com";
const getUsername = async (address)=>{
    try {
        const response = await fetch(`${profileApi}/api/users/${address.toLowerCase()}`);
        if (!response.ok) {
            return '';
        }
        const { username =''  } = await response.json();
        return username;
    } catch (error) {
        return '';
    }
};
/**
 * Intended to be used for getting a profile avatar
 */ const getProfileAvatar = async (address)=>{
    try {
        const profileCalls = [
            'hasRegistered',
            'getUserProfile'
        ].map((method)=>{
            return {
                address: (0,utils_addressHelpers__WEBPACK_IMPORTED_MODULE_2__/* .getPancakeProfileAddress */ .Re)(),
                name: method,
                params: [
                    address
                ]
            };
        });
        const profileCallsResult = await (0,utils_multicall__WEBPACK_IMPORTED_MODULE_1__/* .multicallv2 */ .v)(config_abi_pancakeProfile_json__WEBPACK_IMPORTED_MODULE_0__, profileCalls, {
            requireSuccess: false
        });
        const [[hasRegistered], profileResponse] = profileCallsResult;
        if (!hasRegistered) {
            return null;
        }
        const { tokenId , collectionAddress , isActive  } = transformProfileResponse(profileResponse);
        return {
            hasRegistered
        };
    } catch  {
        return {
            nft: null,
            hasRegistered: false
        };
    }
};
const getProfile = async (address)=>{
    try {
        const profileCalls = [
            'hasRegistered',
            'getUserProfile'
        ].map((method)=>{
            return {
                address: (0,utils_addressHelpers__WEBPACK_IMPORTED_MODULE_2__/* .getPancakeProfileAddress */ .Re)(),
                name: method,
                params: [
                    address
                ]
            };
        });
        const profileCallsResult = await (0,utils_multicall__WEBPACK_IMPORTED_MODULE_1__/* .multicallv2 */ .v)(config_abi_pancakeProfile_json__WEBPACK_IMPORTED_MODULE_0__, profileCalls, {
            requireSuccess: false
        });
        const [[hasRegistered], profileResponse] = profileCallsResult;
        if (!hasRegistered) {
            return {
                hasRegistered,
                profile: null
            };
        }
        const { userId , points , teamId , tokenId , collectionAddress , isActive  } = transformProfileResponse(profileResponse);
        const username = await getUsername(address);
        // If the profile is not active the tokenId returns 0, which is still a valid token id
        // so only fetch the nft data if active
        const profile = {
            userId,
            points,
            teamId,
            tokenId,
            username,
            collectionAddress,
            isActive
        };
        return {
            hasRegistered,
            profile
        };
    } catch (e) {
        console.error(e);
        return null;
    }
};


/***/ }),

/***/ 9424:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Q5": () => (/* binding */ useFetchProfile),
/* harmony export */   "Un": () => (/* binding */ useProfile),
/* harmony export */   "WO": () => (/* binding */ useGetProfileAvatar)
/* harmony export */ });
/* unused harmony exports useProfileForAddress, useAchievementsForAddress */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8328);
/* harmony import */ var state__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4861);
/* harmony import */ var state_achievements_helpers__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8543);
/* harmony import */ var config_constants_types__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7971);
/* harmony import */ var swr_immutable__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9847);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5952);
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5712);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swr_immutable__WEBPACK_IMPORTED_MODULE_7__]);
swr_immutable__WEBPACK_IMPORTED_MODULE_7__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];










const useFetchProfile = ()=>{
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_1__.useWeb3React)();
    const dispatch = (0,state__WEBPACK_IMPORTED_MODULE_4__/* .useAppDispatch */ .TL)();
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        if (account) {
            dispatch((0,___WEBPACK_IMPORTED_MODULE_8__/* .fetchProfile */ .In)(account));
        }
    }, [
        account,
        dispatch
    ]);
};
const useProfileForAddress = (address)=>{
    const { data , status , mutate  } = useSWRImmutable(address ? [
        address,
        'profile'
    ] : null, ()=>getProfile(address)
    );
    return {
        profile: data,
        isFetching: status === FetchStatus.Fetching,
        refresh: mutate
    };
};
const useAchievementsForAddress = (address)=>{
    const { data , status , mutate  } = useSWRImmutable(address ? [
        address,
        'achievements'
    ] : null, ()=>getAchievements(address)
    );
    return {
        achievements: data || [],
        isFetching: status === FetchStatus.Fetching,
        refresh: mutate
    };
};
const useProfile = ()=>{
    const { isInitialized , isLoading , data , hasRegistered  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useSelector)((state)=>state.profile
    );
    return {
        profile: data,
        hasProfile: isInitialized && hasRegistered,
        isInitialized,
        isLoading
    };
};
const useGetProfileAvatar = (account)=>{
    const profileAvatar = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useSelector)((state)=>state.profile.profileAvatars[account]
    );
    const { username , hasRegistered , usernameFetchStatus , avatarFetchStatus  } = profileAvatar || {};
    const dispatch = (0,state__WEBPACK_IMPORTED_MODULE_4__/* .useAppDispatch */ .TL)();
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        const address = (0,utils__WEBPACK_IMPORTED_MODULE_3__/* .isAddress */ .UJ)(account);
        if (avatarFetchStatus !== config_constants_types__WEBPACK_IMPORTED_MODULE_6__/* .FetchStatus.Fetched */ .iF.Fetched && address) {
            dispatch((0,___WEBPACK_IMPORTED_MODULE_8__/* .fetchProfileAvatar */ .ky)(account));
        }
        if (!username && avatarFetchStatus === config_constants_types__WEBPACK_IMPORTED_MODULE_6__/* .FetchStatus.Fetched */ .iF.Fetched && usernameFetchStatus !== config_constants_types__WEBPACK_IMPORTED_MODULE_6__/* .FetchStatus.Fetched */ .iF.Fetched && address) {
            dispatch((0,___WEBPACK_IMPORTED_MODULE_8__/* .fetchProfileUsername */ .c7)({
                account,
                hasRegistered
            }));
        }
    }, [
        account,
        username,
        hasRegistered,
        avatarFetchStatus,
        usernameFetchStatus,
        dispatch
    ]);
    return {
        username,
        usernameFetchStatus,
        avatarFetchStatus
    };
};

});

/***/ }),

/***/ 5952:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "In": () => (/* binding */ fetchProfile),
/* harmony export */   "ky": () => (/* binding */ fetchProfileAvatar),
/* harmony export */   "c7": () => (/* binding */ fetchProfileUsername),
/* harmony export */   "Gb": () => (/* binding */ profileClear),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports initialState, profileSlice, addPoints */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var config_constants_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7971);
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5712);



const initialState = {
    isInitialized: false,
    isLoading: false,
    hasRegistered: false,
    data: null,
    profileAvatars: {}
};
const fetchProfile = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('profile/fetchProfile', async (account)=>{
    const { hasRegistered , profile  } = await (0,_helpers__WEBPACK_IMPORTED_MODULE_2__/* .getProfile */ .Ai)(account);
    return {
        hasRegistered,
        profile
    };
});
const fetchProfileAvatar = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('profile/fetchProfileAvatar', async (account)=>{
    const { hasRegistered  } = await (0,_helpers__WEBPACK_IMPORTED_MODULE_2__/* .getProfileAvatar */ .rC)(account);
    return {
        account,
        hasRegistered
    };
});
const fetchProfileUsername = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('profile/fetchProfileUsername', async ({ account , hasRegistered  })=>{
    if (!hasRegistered) {
        return {
            account,
            username: ''
        };
    }
    const username = await (0,_helpers__WEBPACK_IMPORTED_MODULE_2__/* .getUsername */ .Ms)(account);
    return {
        account,
        username
    };
});
const profileSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: 'profile',
    initialState,
    reducers: {
        profileClear: ()=>({
                ...initialState,
                isLoading: false
            })
        ,
        addPoints: (state, action)=>{
            state.data.points += action.payload;
        }
    },
    extraReducers: (builder)=>{
        builder.addCase(fetchProfile.pending, (state)=>{
            state.isLoading = true;
        });
        builder.addCase(fetchProfile.fulfilled, (state, action)=>{
            const { hasRegistered , profile  } = action.payload;
            state.isInitialized = true;
            state.isLoading = false;
            state.hasRegistered = hasRegistered;
            state.data = profile;
        });
        builder.addCase(fetchProfile.rejected, (state)=>{
            state.isLoading = false;
            state.isInitialized = true;
        });
        builder.addCase(fetchProfileUsername.pending, (state, action)=>{
            const { account  } = action.meta.arg;
            if (state.profileAvatars[account]) {
                state.profileAvatars[account] = {
                    ...state.profileAvatars[account],
                    usernameFetchStatus: config_constants_types__WEBPACK_IMPORTED_MODULE_1__/* .FetchStatus.Fetching */ .iF.Fetching
                };
            } else {
                state.profileAvatars[account] = {
                    hasRegistered: false,
                    username: null,
                    // I think in theory this else should never be reached since we only check for username after we checked for profile/avatar
                    // just in case I set isFetchingAvatar will be Fetched.Fetching at this point to avoid refetching
                    usernameFetchStatus: config_constants_types__WEBPACK_IMPORTED_MODULE_1__/* .FetchStatus.Fetching */ .iF.Fetching,
                    avatarFetchStatus: config_constants_types__WEBPACK_IMPORTED_MODULE_1__/* .FetchStatus.Fetched */ .iF.Fetched
                };
            }
        });
        builder.addCase(fetchProfileUsername.fulfilled, (state, action)=>{
            const { account , username  } = action.payload;
            if (state.profileAvatars[account]) {
                state.profileAvatars[account] = {
                    ...state.profileAvatars[account],
                    username,
                    usernameFetchStatus: config_constants_types__WEBPACK_IMPORTED_MODULE_1__/* .FetchStatus.Fetched */ .iF.Fetched
                };
            } else {
                state.profileAvatars[account] = {
                    username,
                    hasRegistered: true,
                    usernameFetchStatus: config_constants_types__WEBPACK_IMPORTED_MODULE_1__/* .FetchStatus.Fetched */ .iF.Fetched,
                    // I think in theory this else should never be reached since we only check for username after we checked for profile/avatar
                    // just in case I set isFetchingAvatar will be FetchStatus.Fetched at this point to avoid refetching
                    avatarFetchStatus: config_constants_types__WEBPACK_IMPORTED_MODULE_1__/* .FetchStatus.Fetched */ .iF.Fetched
                };
            }
        });
        builder.addCase(fetchProfileUsername.rejected, (state, action)=>{
            const { account  } = action.meta.arg;
            if (state.profileAvatars[account]) {
                state.profileAvatars[account] = {
                    ...state.profileAvatars[account],
                    username: '',
                    usernameFetchStatus: config_constants_types__WEBPACK_IMPORTED_MODULE_1__/* .FetchStatus.Fetched */ .iF.Fetched
                };
            } else {
                state.profileAvatars[account] = {
                    hasRegistered: false,
                    username: '',
                    usernameFetchStatus: config_constants_types__WEBPACK_IMPORTED_MODULE_1__/* .FetchStatus.Fetched */ .iF.Fetched,
                    avatarFetchStatus: config_constants_types__WEBPACK_IMPORTED_MODULE_1__/* .FetchStatus.Fetched */ .iF.Fetched
                };
            }
        });
        builder.addCase(fetchProfileAvatar.pending, (state, action)=>{
            const account = action.meta.arg;
            if (state.profileAvatars[account]) {
                state.profileAvatars[account] = {
                    ...state.profileAvatars[account],
                    hasRegistered: false,
                    avatarFetchStatus: config_constants_types__WEBPACK_IMPORTED_MODULE_1__/* .FetchStatus.Fetching */ .iF.Fetching
                };
            } else {
                state.profileAvatars[account] = {
                    username: null,
                    hasRegistered: false,
                    usernameFetchStatus: config_constants_types__WEBPACK_IMPORTED_MODULE_1__/* .FetchStatus.Idle */ .iF.Idle,
                    avatarFetchStatus: config_constants_types__WEBPACK_IMPORTED_MODULE_1__/* .FetchStatus.Fetching */ .iF.Fetching
                };
            }
        });
        builder.addCase(fetchProfileAvatar.fulfilled, (state, action)=>{
            const { account , hasRegistered  } = action.payload;
            if (state.profileAvatars[account]) {
                state.profileAvatars[account] = {
                    ...state.profileAvatars[account],
                    hasRegistered,
                    avatarFetchStatus: config_constants_types__WEBPACK_IMPORTED_MODULE_1__/* .FetchStatus.Fetched */ .iF.Fetched
                };
            } else {
                state.profileAvatars[account] = {
                    username: null,
                    hasRegistered,
                    usernameFetchStatus: config_constants_types__WEBPACK_IMPORTED_MODULE_1__/* .FetchStatus.Idle */ .iF.Idle,
                    avatarFetchStatus: config_constants_types__WEBPACK_IMPORTED_MODULE_1__/* .FetchStatus.Fetched */ .iF.Fetched
                };
            }
        });
        builder.addCase(fetchProfileAvatar.rejected, (state, action)=>{
            const account = action.meta.arg;
            if (state.profileAvatars[account]) {
                state.profileAvatars[account] = {
                    ...state.profileAvatars[account],
                    hasRegistered: false,
                    avatarFetchStatus: config_constants_types__WEBPACK_IMPORTED_MODULE_1__/* .FetchStatus.Fetched */ .iF.Fetched
                };
            } else {
                state.profileAvatars[account] = {
                    username: null,
                    hasRegistered: false,
                    usernameFetchStatus: config_constants_types__WEBPACK_IMPORTED_MODULE_1__/* .FetchStatus.Idle */ .iF.Idle,
                    avatarFetchStatus: config_constants_types__WEBPACK_IMPORTED_MODULE_1__/* .FetchStatus.Fetched */ .iF.Fetched
                };
            }
        });
    }
});
// Actions
const { profileClear , addPoints  } = profileSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (profileSlice.reducer);


/***/ }),

/***/ 1564:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "dT": () => (/* binding */ addTransaction),
/* harmony export */   "fY": () => (/* binding */ clearAllTransactions),
/* harmony export */   "Aw": () => (/* binding */ finalizeTransaction),
/* harmony export */   "LN": () => (/* binding */ checkedTransaction)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const addTransaction = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('transactions/addTransaction');
const clearAllTransactions = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('transactions/clearAllTransactions');
const finalizeTransaction = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('transactions/finalizeTransaction');
const checkedTransaction = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('transactions/checkedTransaction');


/***/ }),

/***/ 6573:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Updater)
/* harmony export */ });
/* unused harmony export shouldCheck */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9150);
/* harmony import */ var hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4011);
/* harmony import */ var state_block_hooks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7063);
/* harmony import */ var components_Toast__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3937);
/* harmony import */ var hooks_useToast__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(789);
/* harmony import */ var _actions__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1564);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([state_block_hooks__WEBPACK_IMPORTED_MODULE_5__]);
state_block_hooks__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];









function shouldCheck(currentBlock, tx) {
    if (tx.receipt) return false;
    if (!tx.lastCheckedBlockNumber) return true;
    const blocksSinceCheck = currentBlock - tx.lastCheckedBlockNumber;
    if (blocksSinceCheck < 1) return false;
    const minutesPending = (new Date().getTime() - tx.addedTime) / 1000 / 60;
    if (minutesPending > 60) {
        // every 10 blocks if pending for longer than an hour
        return blocksSinceCheck > 9;
    }
    if (minutesPending > 5) {
        // every 3 blocks if pending more than 5 minutes
        return blocksSinceCheck > 2;
    }
    // otherwise every block
    return true;
}
function Updater() {
    const { library , chainId  } = (0,hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)();
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_3__/* .useTranslation */ .$G)();
    const currentBlock = (0,state_block_hooks__WEBPACK_IMPORTED_MODULE_5__/* .useCurrentBlock */ .je)();
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useDispatch)();
    const state = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useSelector)((s)=>s.transactions
    );
    const transactions = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>chainId ? state[chainId] ?? {} : {}
    , [
        chainId,
        state
    ]);
    const { toastError , toastSuccess  } = (0,hooks_useToast__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (!chainId || !library || !currentBlock) return;
        Object.keys(transactions).filter((hash)=>shouldCheck(currentBlock, transactions[hash])
        ).forEach((hash)=>{
            library.getTransactionReceipt(hash).then((receipt)=>{
                if (receipt) {
                    dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_8__/* .finalizeTransaction */ .Aw)({
                        chainId,
                        hash,
                        receipt: {
                            blockHash: receipt.blockHash,
                            blockNumber: receipt.blockNumber,
                            contractAddress: receipt.contractAddress,
                            from: receipt.from,
                            status: receipt.status,
                            to: receipt.to,
                            transactionHash: receipt.transactionHash,
                            transactionIndex: receipt.transactionIndex
                        }
                    }));
                    const toast = receipt.status === 1 ? toastSuccess : toastError;
                    toast(t('Transaction receipt'), /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_6__/* .ToastDescriptionWithTx */ .YO, {
                        txHash: receipt.transactionHash
                    }));
                } else {
                    dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_8__/* .checkedTransaction */ .LN)({
                        chainId,
                        hash,
                        blockNumber: currentBlock
                    }));
                }
            }).catch((error)=>{
                console.error(`failed to check transaction hash: ${hash}`, error);
            });
        });
    }, [
        chainId,
        library,
        transactions,
        currentBlock,
        dispatch,
        toastSuccess,
        toastError,
        t
    ]);
    return null;
};

});

/***/ }),

/***/ 5101:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "om": () => (/* binding */ VaultKey),
/* harmony export */   "Tu": () => (/* binding */ BetPosition),
/* harmony export */   "Gw": () => (/* binding */ PredictionStatus),
/* harmony export */   "dZ": () => (/* binding */ HistoryFilter)
/* harmony export */ });
/* unused harmony exports SnapshotCommand, ProposalType, ProposalState */
var VaultKey;
(function(VaultKey) {
    VaultKey["CakeVault"] = 'cakeVault';
    VaultKey["IfoPool"] = 'ifoPool';
})(VaultKey || (VaultKey = {}));
var BetPosition;
(function(BetPosition) {
    BetPosition["BULL"] = 'Bull';
    BetPosition["BEAR"] = 'Bear';
    BetPosition["HOUSE"] = 'House';
})(BetPosition || (BetPosition = {}));
var PredictionStatus;
(function(PredictionStatus) {
    PredictionStatus["INITIAL"] = 'initial';
    PredictionStatus["LIVE"] = 'live';
    PredictionStatus["PAUSED"] = 'paused';
    PredictionStatus["ERROR"] = 'error';
})(PredictionStatus || (PredictionStatus = {}));
var HistoryFilter;
(function(HistoryFilter) {
    HistoryFilter["ALL"] = 'all';
    HistoryFilter["COLLECTED"] = 'collected';
    HistoryFilter["UNCOLLECTED"] = 'uncollected';
})(HistoryFilter || (HistoryFilter = {}));
var SnapshotCommand;
(function(SnapshotCommand) {
    SnapshotCommand["PROPOSAL"] = 'proposal';
    SnapshotCommand["VOTE"] = 'vote';
})(SnapshotCommand || (SnapshotCommand = {}));
var ProposalType;
(function(ProposalType) {
    ProposalType["ALL"] = 'all';
    ProposalType["CORE"] = 'core';
    ProposalType["COMMUNITY"] = 'community';
})(ProposalType || (ProposalType = {}));
var ProposalState;
(function(ProposalState) {
    ProposalState["ACTIVE"] = 'active';
    ProposalState["PENDING"] = 'pending';
    ProposalState["CLOSED"] = 'closed';
})(ProposalState || (ProposalState = {}));


/***/ }),

/***/ 6245:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GR": () => (/* binding */ FarmStakedOnly),
/* harmony export */   "wO": () => (/* binding */ ViewMode),
/* harmony export */   "UU": () => (/* binding */ ChartViewMode),
/* harmony export */   "zv": () => (/* binding */ updateUserExpertMode),
/* harmony export */   "fO": () => (/* binding */ updateUserSingleHopOnly),
/* harmony export */   "rQ": () => (/* binding */ updateUserSlippageTolerance),
/* harmony export */   "gw": () => (/* binding */ updateUserDeadline),
/* harmony export */   "eg": () => (/* binding */ addSerializedToken),
/* harmony export */   "zQ": () => (/* binding */ removeSerializedToken),
/* harmony export */   "f9": () => (/* binding */ addSerializedPair),
/* harmony export */   "cd": () => (/* binding */ removeSerializedPair),
/* harmony export */   "B8": () => (/* binding */ muteAudio),
/* harmony export */   "u7": () => (/* binding */ unmuteAudio),
/* harmony export */   "X8": () => (/* binding */ toggleTheme),
/* harmony export */   "Gs": () => (/* binding */ updateUserFarmStakedOnly),
/* harmony export */   "mm": () => (/* binding */ updateUserPoolStakedOnly),
/* harmony export */   "d4": () => (/* binding */ updateUserPoolsViewMode),
/* harmony export */   "gk": () => (/* binding */ updateUserFarmsViewMode),
/* harmony export */   "RC": () => (/* binding */ updateUserPredictionAcceptedRisk),
/* harmony export */   "c4": () => (/* binding */ updateUserPredictionChartDisclaimerShow),
/* harmony export */   "_C": () => (/* binding */ updateUserExpertModeAcknowledgementShow),
/* harmony export */   "zk": () => (/* binding */ updateUserUsernameVisibility),
/* harmony export */   "dy": () => (/* binding */ updateGasPrice),
/* harmony export */   "zS": () => (/* binding */ addWatchlistToken),
/* harmony export */   "Dn": () => (/* binding */ addWatchlistPool),
/* harmony export */   "l5": () => (/* binding */ hidePhishingWarningBanner),
/* harmony export */   "hN": () => (/* binding */ setIsExchangeChartDisplayed),
/* harmony export */   "p9": () => (/* binding */ setChartViewMode),
/* harmony export */   "Hr": () => (/* binding */ setSubgraphHealthIndicatorDisplayed)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

var FarmStakedOnly;
(function(FarmStakedOnly) {
    FarmStakedOnly["ON_FINISHED"] = 'onFinished';
    FarmStakedOnly["TRUE"] = 'true';
    FarmStakedOnly["FALSE"] = 'false';
})(FarmStakedOnly || (FarmStakedOnly = {}));
var ViewMode;
(function(ViewMode) {
    ViewMode["TABLE"] = "TABLE";
    ViewMode["CARD"] = "CARD";
})(ViewMode || (ViewMode = {}));
var ChartViewMode;
(function(ChartViewMode) {
    ChartViewMode["BASIC"] = "BASIC";
    ChartViewMode["TRADING_VIEW"] = "TRADING_VIEW";
})(ChartViewMode || (ChartViewMode = {}));
const updateUserExpertMode = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('user/updateUserExpertMode');
const updateUserSingleHopOnly = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('user/updateUserSingleHopOnly');
const updateUserSlippageTolerance = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('user/updateUserSlippageTolerance');
const updateUserDeadline = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('user/updateUserDeadline');
const addSerializedToken = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('user/addSerializedToken');
const removeSerializedToken = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('user/removeSerializedToken');
const addSerializedPair = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('user/addSerializedPair');
const removeSerializedPair = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('user/removeSerializedPair');
const muteAudio = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('user/muteAudio');
const unmuteAudio = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('user/unmuteAudio');
const toggleTheme = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('user/toggleTheme');
const updateUserFarmStakedOnly = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('user/updateUserFarmStakedOnly');
const updateUserPoolStakedOnly = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('user/updateUserPoolStakedOnly');
const updateUserPoolsViewMode = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('user/updateUserPoolsViewMode');
const updateUserFarmsViewMode = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('user/updateUserFarmsViewMode');
const updateUserPredictionAcceptedRisk = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('user/updateUserPredictionAcceptedRisk');
const updateUserPredictionChartDisclaimerShow = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('user/updateUserPredictionChartDisclaimerShow');
const updateUserExpertModeAcknowledgementShow = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('user/updateUserExpertModeAcknowledgementShow');
const updateUserUsernameVisibility = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('user/updateUserUsernameVisibility');
const updateGasPrice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('user/updateGasPrice');
const addWatchlistToken = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('user/addWatchlistToken');
const addWatchlistPool = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('user/addWatchlistPool');
const hidePhishingWarningBanner = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('user/hidePhishingWarningBanner');
const setIsExchangeChartDisplayed = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('user/toggleIsExchangeChartDisplayed');
const setChartViewMode = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('user/setChartViewMode');
const setSubgraphHealthIndicatorDisplayed = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('user/setSubgraphHealthIndicatorDisplayed');


/***/ }),

/***/ 787:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Mq": () => (/* binding */ serializeToken),
/* harmony export */   "iG": () => (/* binding */ deserializeToken),
/* harmony export */   "DB": () => (/* binding */ GAS_PRICE),
/* harmony export */   "j4": () => (/* binding */ GAS_PRICE_GWEI)
/* harmony export */ });
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2877);
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ethersproject_units__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3138);
/* harmony import */ var _ethersproject_units__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_units__WEBPACK_IMPORTED_MODULE_1__);


function serializeToken(token) {
    return {
        chainId: token.chainId,
        address: token.address,
        decimals: token.decimals,
        symbol: token.symbol,
        name: token.name,
        projectLink: token.projectLink
    };
}
function deserializeToken(serializedToken) {
    return new _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(serializedToken.chainId, serializedToken.address, serializedToken.decimals, serializedToken.symbol, serializedToken.name, serializedToken.projectLink);
}
var GAS_PRICE;
(function(GAS_PRICE) {
    GAS_PRICE["default"] = '5';
    GAS_PRICE["fast"] = '6';
    GAS_PRICE["instant"] = '7';
    GAS_PRICE["testnet"] = '10';
})(GAS_PRICE || (GAS_PRICE = {}));
const GAS_PRICE_GWEI = {
    default: (0,_ethersproject_units__WEBPACK_IMPORTED_MODULE_1__.parseUnits)(GAS_PRICE.default, 'gwei').toString(),
    fast: (0,_ethersproject_units__WEBPACK_IMPORTED_MODULE_1__.parseUnits)(GAS_PRICE.fast, 'gwei').toString(),
    instant: (0,_ethersproject_units__WEBPACK_IMPORTED_MODULE_1__.parseUnits)(GAS_PRICE.instant, 'gwei').toString(),
    testnet: (0,_ethersproject_units__WEBPACK_IMPORTED_MODULE_1__.parseUnits)(GAS_PRICE.testnet, 'gwei').toString()
};


/***/ }),

/***/ 8605:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TO": () => (/* binding */ useAudioModeManager),
/* harmony export */   "FT": () => (/* binding */ usePhishingBannerManager),
/* harmony export */   "YF": () => (/* binding */ useSubgraphHealthIndicatorManager),
/* harmony export */   "DG": () => (/* binding */ useExpertModeManager),
/* harmony export */   "HY": () => (/* binding */ useThemeManager),
/* harmony export */   "RO": () => (/* binding */ useUserSingleHopOnly),
/* harmony export */   "$2": () => (/* binding */ useUserSlippageTolerance),
/* harmony export */   "oI": () => (/* binding */ useUserPredictionAcceptedRisk),
/* harmony export */   "TL": () => (/* binding */ useUserPredictionChartDisclaimerShow),
/* harmony export */   "wX": () => (/* binding */ useUserExpertModeAcknowledgementShow),
/* harmony export */   "A6": () => (/* binding */ useUserTransactionTTL),
/* harmony export */   "Fh": () => (/* binding */ useGasPrice),
/* harmony export */   "nF": () => (/* binding */ useGasPriceManager),
/* harmony export */   "z6": () => (/* binding */ useWatchlistTokens),
/* harmony export */   "Hx": () => (/* binding */ useWatchlistPools)
/* harmony export */ });
/* unused harmony exports useExchangeChartManager, useExchangeChartViewManager, useIsExpertMode, useUserFarmStakedOnly, useUserPoolStakedOnly, useUserPoolsViewMode, useUserFarmsViewMode, useUserUsernameVisibility, useAddUserToken, useRemoveUserAddedToken, usePairAdder, toV2LiquidityToken, useTrackedTokenPairs */
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2877);
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4146);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(date_fns__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var lodash_flatMap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8190);
/* harmony import */ var lodash_flatMap__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lodash_flatMap__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var config_constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1311);
/* harmony import */ var hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4011);
/* harmony import */ var hooks_Tokens__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6435);
/* harmony import */ var _actions__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6245);
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(787);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks_Tokens__WEBPACK_IMPORTED_MODULE_7__]);
hooks_Tokens__WEBPACK_IMPORTED_MODULE_7__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];










function useAudioModeManager() {
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useDispatch)();
    const audioPlay = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useSelector)((state)=>state.user.audioPlay
    );
    const toggleSetAudioMode = (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)(()=>{
        if (audioPlay) {
            dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_8__/* .muteAudio */ .B8)());
        } else {
            dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_8__/* .unmuteAudio */ .u7)());
        }
    }, [
        audioPlay,
        dispatch
    ]);
    return [
        audioPlay,
        toggleSetAudioMode
    ];
}
function usePhishingBannerManager() {
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useDispatch)();
    const hideTimestampPhishingWarningBanner = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useSelector)((state)=>state.user.hideTimestampPhishingWarningBanner
    );
    const now = Date.now();
    const showPhishingWarningBanner = hideTimestampPhishingWarningBanner ? (0,date_fns__WEBPACK_IMPORTED_MODULE_1__.differenceInDays)(now, hideTimestampPhishingWarningBanner) >= 1 : true;
    const hideBanner = (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)(()=>{
        dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_8__/* .hidePhishingWarningBanner */ .l5)());
    }, [
        dispatch
    ]);
    return [
        showPhishingWarningBanner,
        hideBanner
    ];
}
// Get user preference for exchange price chart
// For mobile layout chart is hidden by default
function useExchangeChartManager(isMobile) {
    const dispatch = useDispatch();
    const isChartDisplayed = useSelector((state)=>state.user.isExchangeChartDisplayed
    );
    const setUserChartPreference = useCallback((isDisplayed)=>{
        dispatch(setIsExchangeChartDisplayed(isDisplayed));
    }, [
        dispatch
    ]);
    return [
        isMobile ? false : isChartDisplayed,
        setUserChartPreference
    ];
}
function useExchangeChartViewManager() {
    const dispatch = useDispatch();
    const chartViewMode = useSelector((state)=>state.user.userChartViewMode
    );
    const setUserChartViewPreference = useCallback((view)=>{
        dispatch(setChartViewMode(view));
    }, [
        dispatch
    ]);
    return [
        chartViewMode,
        setUserChartViewPreference
    ];
}
function useSubgraphHealthIndicatorManager() {
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useDispatch)();
    const isSubgraphHealthIndicatorDisplayed = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useSelector)((state)=>state.user.isSubgraphHealthIndicatorDisplayed
    );
    const setSubgraphHealthIndicatorDisplayedPreference = (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)((newIsDisplayed)=>{
        dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_8__/* .setSubgraphHealthIndicatorDisplayed */ .Hr)(newIsDisplayed));
    }, [
        dispatch
    ]);
    return [
        isSubgraphHealthIndicatorDisplayed,
        setSubgraphHealthIndicatorDisplayedPreference
    ];
}
function useIsExpertMode() {
    return (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useSelector)((state)=>state.user.userExpertMode
    );
}
function useExpertModeManager() {
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useDispatch)();
    const expertMode = useIsExpertMode();
    const toggleSetExpertMode = (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)(()=>{
        dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_8__/* .updateUserExpertMode */ .zv)({
            userExpertMode: !expertMode
        }));
    }, [
        expertMode,
        dispatch
    ]);
    return [
        expertMode,
        toggleSetExpertMode
    ];
}
function useThemeManager() {
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useDispatch)();
    const isDark = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useSelector)((state)=>state.user.isDark
    );
    const toggleTheme = (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)(()=>{
        dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_8__/* .toggleTheme */ .X8)());
    }, [
        dispatch
    ]);
    return [
        isDark,
        toggleTheme
    ];
}
function useUserSingleHopOnly() {
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useDispatch)();
    const singleHopOnly = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useSelector)((state)=>state.user.userSingleHopOnly
    );
    const setSingleHopOnly = (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)((newSingleHopOnly)=>{
        dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_8__/* .updateUserSingleHopOnly */ .fO)({
            userSingleHopOnly: newSingleHopOnly
        }));
    }, [
        dispatch
    ]);
    return [
        singleHopOnly,
        setSingleHopOnly
    ];
}
function useUserSlippageTolerance() {
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useDispatch)();
    const userSlippageTolerance = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useSelector)((state)=>{
        return state.user.userSlippageTolerance;
    });
    const setUserSlippageTolerance = (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)((slippage)=>{
        dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_8__/* .updateUserSlippageTolerance */ .rQ)({
            userSlippageTolerance: slippage
        }));
    }, [
        dispatch
    ]);
    return [
        userSlippageTolerance,
        setUserSlippageTolerance
    ];
}
function useUserFarmStakedOnly(isActive) {
    const dispatch = useDispatch();
    const userFarmStakedOnly = useSelector((state)=>{
        return state.user.userFarmStakedOnly;
    });
    const setUserFarmStakedOnly = useCallback((stakedOnly)=>{
        const farmStakedOnly = stakedOnly ? FarmStakedOnly.TRUE : FarmStakedOnly.FALSE;
        dispatch(updateUserFarmStakedOnly({
            userFarmStakedOnly: farmStakedOnly
        }));
    }, [
        dispatch
    ]);
    return [
        userFarmStakedOnly === FarmStakedOnly.ON_FINISHED ? !isActive : userFarmStakedOnly === FarmStakedOnly.TRUE,
        setUserFarmStakedOnly, 
    ];
}
function useUserPoolStakedOnly() {
    const dispatch = useDispatch();
    const userPoolStakedOnly = useSelector((state)=>{
        return state.user.userPoolStakedOnly;
    });
    const setUserPoolStakedOnly = useCallback((stakedOnly)=>{
        dispatch(updateUserPoolStakedOnly({
            userPoolStakedOnly: stakedOnly
        }));
    }, [
        dispatch
    ]);
    return [
        userPoolStakedOnly,
        setUserPoolStakedOnly
    ];
}
function useUserPoolsViewMode() {
    const dispatch = useDispatch();
    const userPoolsViewMode = useSelector((state)=>{
        return state.user.userPoolsViewMode;
    });
    const setUserPoolsViewMode = useCallback((viewMode)=>{
        dispatch(updateUserPoolsViewMode({
            userPoolsViewMode: viewMode
        }));
    }, [
        dispatch
    ]);
    return [
        userPoolsViewMode,
        setUserPoolsViewMode
    ];
}
function useUserFarmsViewMode() {
    const dispatch = useDispatch();
    const userFarmsViewMode = useSelector((state)=>{
        return state.user.userFarmsViewMode;
    });
    const setUserFarmsViewMode = useCallback((viewMode)=>{
        dispatch(updateUserFarmsViewMode({
            userFarmsViewMode: viewMode
        }));
    }, [
        dispatch
    ]);
    return [
        userFarmsViewMode,
        setUserFarmsViewMode
    ];
}
function useUserPredictionAcceptedRisk() {
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useDispatch)();
    const userPredictionAcceptedRisk = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useSelector)((state)=>{
        return state.user.userPredictionAcceptedRisk;
    });
    const setUserPredictionAcceptedRisk = (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)((acceptedRisk)=>{
        dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_8__/* .updateUserPredictionAcceptedRisk */ .RC)({
            userAcceptedRisk: acceptedRisk
        }));
    }, [
        dispatch
    ]);
    return [
        userPredictionAcceptedRisk,
        setUserPredictionAcceptedRisk
    ];
}
function useUserPredictionChartDisclaimerShow() {
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useDispatch)();
    const userPredictionChartDisclaimerShow = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useSelector)((state)=>{
        return state.user.userPredictionChartDisclaimerShow;
    });
    const setPredictionUserChartDisclaimerShow = (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)((showDisclaimer)=>{
        dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_8__/* .updateUserPredictionChartDisclaimerShow */ .c4)({
            userShowDisclaimer: showDisclaimer
        }));
    }, [
        dispatch
    ]);
    return [
        userPredictionChartDisclaimerShow,
        setPredictionUserChartDisclaimerShow
    ];
}
function useUserExpertModeAcknowledgementShow() {
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useDispatch)();
    const userExpertModeAcknowledgementShow = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useSelector)((state)=>{
        return state.user.userExpertModeAcknowledgementShow;
    });
    const setUserExpertModeAcknowledgementShow = (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)((showAcknowledgement)=>{
        dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_8__/* .updateUserExpertModeAcknowledgementShow */ ._C)({
            userExpertModeAcknowledgementShow: showAcknowledgement
        }));
    }, [
        dispatch
    ]);
    return [
        userExpertModeAcknowledgementShow,
        setUserExpertModeAcknowledgementShow
    ];
}
function useUserUsernameVisibility() {
    const dispatch = useDispatch();
    const userUsernameVisibility = useSelector((state)=>{
        return state.user.userUsernameVisibility;
    });
    const setUserUsernameVisibility = useCallback((usernameVisibility)=>{
        dispatch(updateUserUsernameVisibility({
            userUsernameVisibility: usernameVisibility
        }));
    }, [
        dispatch
    ]);
    return [
        userUsernameVisibility,
        setUserUsernameVisibility
    ];
}
function useUserTransactionTTL() {
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useDispatch)();
    const userDeadline = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useSelector)((state)=>{
        return state.user.userDeadline;
    });
    const setUserDeadline = (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)((deadline)=>{
        dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_8__/* .updateUserDeadline */ .gw)({
            userDeadline: deadline
        }));
    }, [
        dispatch
    ]);
    return [
        userDeadline,
        setUserDeadline
    ];
}
function useAddUserToken() {
    const dispatch = useDispatch();
    return useCallback((token)=>{
        dispatch(addSerializedToken({
            serializedToken: serializeToken(token)
        }));
    }, [
        dispatch
    ]);
}
function useRemoveUserAddedToken() {
    const dispatch = useDispatch();
    return useCallback((chainId, address)=>{
        dispatch(removeSerializedToken({
            chainId,
            address
        }));
    }, [
        dispatch
    ]);
}
function useGasPrice() {
    const chainId = "1666700000";
    const userGas = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useSelector)((state)=>state.user.gasPrice
    );
    return chainId === _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET.toString() ? userGas : _helpers__WEBPACK_IMPORTED_MODULE_9__/* .GAS_PRICE_GWEI.testnet */ .j4.testnet;
}
function useGasPriceManager() {
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useDispatch)();
    const userGasPrice = useGasPrice();
    const setGasPrice = (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)((gasPrice)=>{
        dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_8__/* .updateGasPrice */ .dy)({
            gasPrice
        }));
    }, [
        dispatch
    ]);
    return [
        userGasPrice,
        setGasPrice
    ];
}
function serializePair(pair) {
    return {
        token0: serializeToken(pair.token0),
        token1: serializeToken(pair.token1)
    };
}
function usePairAdder() {
    const dispatch = useDispatch();
    return useCallback((pair)=>{
        dispatch(addSerializedPair({
            serializedPair: serializePair(pair)
        }));
    }, [
        dispatch
    ]);
}
/**
 * Given two tokens return the liquidity token that represents its liquidity shares
 * @param tokenA one of the two tokens
 * @param tokenB the other token
 */ function toV2LiquidityToken([tokenA, tokenB]) {
    return new Token(tokenA.chainId, Pair.getAddress(tokenA, tokenB), 18, 'Cake-LP', 'Pancake LPs');
}
/**
 * Returns all the pairs of tokens that are tracked by the user for the current chain ID.
 */ function useTrackedTokenPairs() {
    const { chainId  } = useActiveWeb3React();
    const tokens = useAllTokens(true);
    // pinned pairs
    const pinnedPairs = useMemo(()=>chainId ? PINNED_PAIRS[chainId] ?? [] : []
    , [
        chainId
    ]);
    // pairs for every token against every base
    const generatedPairs = useMemo(()=>chainId ? flatMap(Object.keys(tokens), (tokenAddress)=>{
            const token = tokens[tokenAddress];
            // for each token on the current chain,
            return(// loop though all bases on the current chain
            (BASES_TO_TRACK_LIQUIDITY_FOR[chainId] ?? [])// to construct pairs of the given token with each base
            .map((base)=>{
                if (base.address === token.address) {
                    return null;
                }
                return [
                    base,
                    token
                ];
            }).filter((p)=>p !== null
            ));
        }) : []
    , [
        tokens,
        chainId
    ]);
    // pairs saved by users
    const savedSerializedPairs = useSelector(({ user: { pairs  }  })=>pairs
    );
    const userPairs = useMemo(()=>{
        if (!chainId || !savedSerializedPairs) return [];
        const forChain = savedSerializedPairs[chainId];
        if (!forChain) return [];
        return Object.keys(forChain).map((pairId)=>{
            return [
                deserializeToken(forChain[pairId].token0),
                deserializeToken(forChain[pairId].token1)
            ];
        });
    }, [
        savedSerializedPairs,
        chainId
    ]);
    const combinedList = useMemo(()=>userPairs.concat(generatedPairs).concat(pinnedPairs)
    , [
        generatedPairs,
        pinnedPairs,
        userPairs
    ]);
    return useMemo(()=>{
        // dedupes pairs of tokens in the combined list
        const keyed = combinedList.reduce((memo, [tokenA, tokenB])=>{
            const sorted = tokenA.sortsBefore(tokenB);
            const key = sorted ? `${tokenA.address}:${tokenB.address}` : `${tokenB.address}:${tokenA.address}`;
            if (memo[key]) return memo;
            memo[key] = sorted ? [
                tokenA,
                tokenB
            ] : [
                tokenB,
                tokenA
            ];
            return memo;
        }, {});
        return Object.keys(keyed).map((key)=>keyed[key]
        );
    }, [
        combinedList
    ]);
}
const useWatchlistTokens = ()=>{
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useDispatch)();
    const savedTokens = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useSelector)((state)=>state.user.watchlistTokens
    ) ?? [];
    const updatedSavedTokens = (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)((address)=>{
        dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_8__/* .addWatchlistToken */ .zS)({
            address
        }));
    }, [
        dispatch
    ]);
    return [
        savedTokens,
        updatedSavedTokens
    ];
};
const useWatchlistPools = ()=>{
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useDispatch)();
    const savedPools = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useSelector)((state)=>state.user.watchlistPools
    ) ?? [];
    const updateSavedPools = (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)((address)=>{
        dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_8__/* .addWatchlistPool */ .Dn)({
            address
        }));
    }, [
        dispatch
    ]);
    return [
        savedPools,
        updateSavedPools
    ];
};

});

/***/ }),

/***/ 4797:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useUserAddedTokens)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4011);
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(787);




function useUserAddedTokens() {
    const { chainId  } = (0,hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)();
    const serializedTokensMap = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)(({ user: { tokens  }  })=>tokens
    );
    return (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        if (!chainId) return [];
        return Object.values(serializedTokensMap?.[chainId] ?? {}).map(_helpers__WEBPACK_IMPORTED_MODULE_3__/* .deserializeToken */ .iG);
    }, [
        serializedTokensMap,
        chainId
    ]);
};


/***/ }),

/***/ 1055:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const GlobalStyle = styled_components__WEBPACK_IMPORTED_MODULE_0__.createGlobalStyle`
  * {
    font-family: 'Kanit', sans-serif;
  }
  body {
    background-color: ${({ theme  })=>theme.colors.background
};

    img {
      height: auto;
      max-width: 100%;
    }
  }
`;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (GlobalStyle);


/***/ }),

/***/ 5878:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Jc": () => (/* binding */ getAnniversaryAchievement),
  "pf": () => (/* binding */ getChainlinkOracleAddress),
  "I8": () => (/* binding */ getMulticallAddress),
  "Re": () => (/* binding */ getPancakeProfileAddress),
  "Df": () => (/* binding */ getPredictionsAddress)
});

// UNUSED EXPORTS: getAddress, getBunnyFactoryAddress, getBunnySpecialAddress, getBunnySpecialCakeVaultAddress, getBunnySpecialLotteryAddress, getBunnySpecialPredictionAddress, getBunnySpecialXmasAddress, getCakeVaultAddress, getClaimRefundAddress, getFarmAuctionAddress, getIfoPoolAddress, getLotteryV2Address, getMasterChefAddress, getPancakeRabbitsAddress, getPancakeSquadAddress, getPointCenterIfoAddress, getTradingCompetitionAddress, getTradingCompetitionAddressV2, getVaultPoolAddress

// EXTERNAL MODULE: external "@mdemouchy/sdk"
var sdk_ = __webpack_require__(2877);
;// CONCATENATED MODULE: ./src/config/constants/contracts.ts
/* harmony default export */ const contracts = ({
    masterChef: {
        1666700000: '0x1d32c2945C8FDCBc7156c553B7cEa4325a17f4f9',
        1666600000: '0x73feaa1eE314F8c655E354234017bE2193C9E24E'
    },
    sousChef: {
        1666700000: '0xd3af5fe61dbaf8f73149bfcfa9fb653ff096029a',
        1666600000: '0x6ab8463a4185b80905e05a9ff80a2d6b714b9e95'
    },
    lotteryV2: {
        1666700000: '0x5790c3534F30437641541a0FA04C992799602998',
        1666600000: '0x5aF6D33DE2ccEC94efb1bDF8f92Bd58085432d2c'
    },
    multiCall: {
        1666600000: '0x42e28c4DD13eb25D656ad3a5BC5EA221557259bF',
        1666700000: '0x42e28c4DD13eb25D656ad3a5BC5EA221557259bF'
    },
    pancakeProfile: {
        1666600000: '0xDf4dBf6536201370F95e06A0F8a7a70fE40E388a',
        1666700000: '0x4B683C7E13B6d5D7fd1FeA9530F451954c1A7c8A'
    },
    pancakeRabbits: {
        1666600000: '0xDf7952B35f24aCF7fC0487D01c8d5690a60DBa07',
        1666700000: '0x60935F36e4631F73f0f407e68642144e07aC7f5E'
    },
    bunnyFactory: {
        1666600000: '0xfa249Caa1D16f75fa159F7DFBAc0cC5EaB48CeFf',
        1666700000: '0x707CBF373175fdB601D34eeBF2Cf665d08f01148'
    },
    claimRefund: {
        1666600000: '0xE7e53A7e9E3Cf6b840f167eF69519175c497e149',
        1666700000: ''
    },
    pointCenterIfo: {
        1666600000: '0x3C6919b132462C1FEc572c6300E83191f4F0012a',
        1666700000: '0xd2Ac1B1728Bb1C11ae02AB6e75B76Ae41A2997e3'
    },
    bunnySpecial: {
        1666600000: '0xFee8A195570a18461146F401d6033f5ab3380849',
        1666700000: '0x7b7b1583De1DeB32Ce6605F6deEbF24A0671c17C'
    },
    tradingCompetition: {
        1666600000: '0xd718baa0B1F4f70dcC8458154042120FFE0DEFFA',
        1666700000: '0xC787F45B833721ED3aC46E99b703B3E1E01abb97'
    },
    tradingCompetitionV2: {
        1666600000: '0xA8FECf847e28aa1Df39E995a45b7FCfb91b676d4',
        1666700000: ''
    },
    easterNft: {
        1666600000: '0x23c41D28A239dDCAABd1bb1deF8d057189510066',
        1666700000: '0x24ec6962dbe874F6B67B5C50857565667fA0854F'
    },
    cakeVault: {
        1666600000: '0xa80240Eb5d7E05d3F250cF000eEc0891d00b51CC',
        1666700000: ''
    },
    ifoPool: {
        1666600000: '0x1B2A2f6ed4A1401E8C73B4c2B6172455ce2f78E8',
        1666700000: ''
    },
    predictions: {
        1666600000: '0x3e28109673164120cbb7a811710565a57cfde5e4',
        1666700000: '0x3e28109673164120cbb7a811710565a57cfde5e4'
    },
    chainlinkOracle: {
        1666600000: '0xcEe686F89bc0dABAd95AEAAC980aE1d97A075FAD',
        1666700000: '0xcEe686F89bc0dABAd95AEAAC980aE1d97A075FAD'
    },
    bunnySpecialCakeVault: {
        1666600000: '0x5B4a770Abe7Eafb2601CA4dF9d73EA99363E60a4',
        1666700000: ''
    },
    bunnySpecialPrediction: {
        1666600000: '0x342c99e9aC24157657095eC69CB04b73257e7A9C',
        1666700000: ''
    },
    bunnySpecialLottery: {
        1666600000: '0x24ED31d31C5868e5a96aA77fdcB890f3511fa0b2',
        1666700000: '0x382cB497110F398F0f152cae82821476AE51c9cF'
    },
    bunnySpecialXmas: {
        1666600000: '0x59EdDF3c21509dA3b0aCCd7c5ccc596d930f4783',
        1666700000: ''
    },
    farmAuction: {
        1666600000: '0xb92Ab7c1edcb273AbA24b0656cEb3681654805D2',
        1666700000: '0x3F9602593b4f7C67ab045DB51BbDEa94E40fA9Fe'
    },
    AnniversaryAchievement: {
        1666600000: '0x787980da5491118C3cB33B21aB50c8c379D2C552',
        1666700000: '0x981aE96378e770DE44F89cD9175E708f9EDB70a9'
    },
    pancakeSquad: {
        1666600000: '0x0a8901b0E25DEb55A87524f0cC164E9644020EBA',
        1666700000: '0xfC0c3F11fDA72Cb9A56F28Ec8D44C0ae4B3ABF86'
    }
});

;// CONCATENATED MODULE: ./src/utils/addressHelpers.ts


const getAddress = (address)=>{
    const chainId = "1666700000";
    return address[chainId] ? address[chainId] : address[sdk_.ChainId.MAINNET];
};
const getMasterChefAddress = ()=>{
    return getAddress(addresses.masterChef);
};
const getMulticallAddress = ()=>{
    return getAddress(contracts.multiCall);
};
const getLotteryV2Address = ()=>{
    return getAddress(addresses.lotteryV2);
};
const getPancakeProfileAddress = ()=>{
    return getAddress(contracts.pancakeProfile);
};
const getPancakeRabbitsAddress = ()=>{
    return getAddress(addresses.pancakeRabbits);
};
const getBunnyFactoryAddress = ()=>{
    return getAddress(addresses.bunnyFactory);
};
const getClaimRefundAddress = ()=>{
    return getAddress(addresses.claimRefund);
};
const getPointCenterIfoAddress = ()=>{
    return getAddress(addresses.pointCenterIfo);
};
const getBunnySpecialAddress = ()=>{
    return getAddress(addresses.bunnySpecial);
};
const getTradingCompetitionAddress = ()=>{
    return getAddress(addresses.tradingCompetition);
};
const getTradingCompetitionAddressV2 = ()=>{
    return getAddress(addresses.tradingCompetitionV2);
};
const getVaultPoolAddress = (vaultKey)=>{
    if (!vaultKey) {
        return null;
    }
    return getAddress(addresses[vaultKey]);
};
const getCakeVaultAddress = ()=>{
    return getAddress(addresses.cakeVault);
};
const getIfoPoolAddress = ()=>{
    return getAddress(addresses.ifoPool);
};
const getPredictionsAddress = ()=>{
    return getAddress(contracts.predictions);
};
const getChainlinkOracleAddress = ()=>{
    return getAddress(contracts.chainlinkOracle);
};
const getBunnySpecialCakeVaultAddress = ()=>{
    return getAddress(addresses.bunnySpecialCakeVault);
};
const getBunnySpecialPredictionAddress = ()=>{
    return getAddress(addresses.bunnySpecialPrediction);
};
const getBunnySpecialLotteryAddress = ()=>{
    return getAddress(addresses.bunnySpecialLottery);
};
const getBunnySpecialXmasAddress = ()=>{
    return getAddress(addresses.bunnySpecialXmas);
};
const getFarmAuctionAddress = ()=>{
    return getAddress(addresses.farmAuction);
};
const getAnniversaryAchievement = ()=>{
    return getAddress(contracts.AnniversaryAchievement);
};
const getPancakeSquadAddress = ()=>{
    return getAddress(addresses.pancakeSquad);
};


/***/ }),

/***/ 5128:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HW": () => (/* binding */ BIG_ZERO),
/* harmony export */   "xp": () => (/* binding */ BIG_TEN)
/* harmony export */ });
/* unused harmony exports BIG_ONE, BIG_NINE, ethersToSerializedBigNumber, ethersToBigNumber */
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4215);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(bignumber_js__WEBPACK_IMPORTED_MODULE_0__);

const BIG_ZERO = new (bignumber_js__WEBPACK_IMPORTED_MODULE_0___default())(0);
const BIG_ONE = new (bignumber_js__WEBPACK_IMPORTED_MODULE_0___default())(1);
const BIG_NINE = new (bignumber_js__WEBPACK_IMPORTED_MODULE_0___default())(9);
const BIG_TEN = new (bignumber_js__WEBPACK_IMPORTED_MODULE_0___default())(10);
const ethersToSerializedBigNumber = (ethersBn)=>ethersToBigNumber(ethersBn).toJSON()
;
const ethersToBigNumber = (ethersBn)=>new BigNumber(ethersBn.toString())
;


/***/ }),

/***/ 8382:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "J": () => (/* binding */ clearUserStates)
/* harmony export */ });
/* harmony import */ var _sentry_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5427);
/* harmony import */ var _sentry_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_sentry_react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _state_profile__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5952);
/* harmony import */ var _web3React__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2338);
/* harmony import */ var _state_transactions_actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1564);





const clearUserStates = (dispatch, chainId)=>{
    dispatch((0,_state_profile__WEBPACK_IMPORTED_MODULE_2__/* .profileClear */ .Gb)());
    _sentry_react__WEBPACK_IMPORTED_MODULE_0__.configureScope((scope)=>scope.setUser(null)
    );
    // This localStorage key is set by @web3-react/walletconnect-connector
    if (window.localStorage.getItem('walletconnect')) {
        _web3React__WEBPACK_IMPORTED_MODULE_3__/* .connectorsByName.walletconnect.close */ .BA.walletconnect.close();
        _web3React__WEBPACK_IMPORTED_MODULE_3__/* .connectorsByName.walletconnect.walletConnectProvider */ .BA.walletconnect.walletConnectProvider = null;
    }
    window.localStorage.removeItem(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.connectorLocalStorageKey);
    if (chainId) {
        dispatch((0,_state_transactions_actions__WEBPACK_IMPORTED_MODULE_4__/* .clearAllTransactions */ .fY)({
            chainId
        }));
    }
};


/***/ }),

/***/ 4765:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "f$": () => (/* binding */ getAnniversaryAchievementContract),
  "Qr": () => (/* binding */ getChainlinkOracleContract),
  "tV": () => (/* binding */ getMulticallContract),
  "qi": () => (/* binding */ getPredictionsContract)
});

// UNUSED EXPORTS: getBep20Contract, getBunnyFactoryContract, getBunnySpecialCakeVaultContract, getBunnySpecialContract, getBunnySpecialLotteryContract, getBunnySpecialPredictionContract, getBunnySpecialXmasContract, getCakeContract, getCakeVaultContract, getClaimRefundContract, getErc721CollectionContract, getErc721Contract, getFarmAuctionContract, getIfoPoolContract, getIfoV1Contract, getIfoV2Contract, getLotteryV2Contract, getLpContract, getMasterchefContract, getPancakeRabbitContract, getPancakeSquadContract, getPointCenterIfoContract, getProfileContract, getSouschefContract, getSouschefV2Contract, getTradingCompetitionContract, getTradingCompetitionContractV2

// EXTERNAL MODULE: external "@ethersproject/contracts"
var contracts_ = __webpack_require__(2792);
// EXTERNAL MODULE: ./src/utils/providers.ts
var providers = __webpack_require__(5922);
// EXTERNAL MODULE: ./src/config/constants/index.ts + 1 modules
var constants = __webpack_require__(1311);
// EXTERNAL MODULE: ./src/config/constants/types.ts
var types = __webpack_require__(7971);
// EXTERNAL MODULE: ./src/config/constants/tokens.ts
var constants_tokens = __webpack_require__(9748);
// EXTERNAL MODULE: ./src/utils/addressHelpers.ts + 1 modules
var addressHelpers = __webpack_require__(5878);
// EXTERNAL MODULE: ./src/config/abi/pancakeProfile.json
var pancakeProfile = __webpack_require__(2335);
;// CONCATENATED MODULE: ./src/config/abi/pancakeRabbits.json
const pancakeRabbits_namespaceObject = [];
;// CONCATENATED MODULE: ./src/config/abi/bunnyFactory.json
const bunnyFactory_namespaceObject = [];
;// CONCATENATED MODULE: ./src/config/abi/bunnySpecial.json
const bunnySpecial_namespaceObject = [];
// EXTERNAL MODULE: ./src/config/abi/erc20.json
var erc20 = __webpack_require__(3324);
;// CONCATENATED MODULE: ./src/config/abi/erc721.json
const erc721_namespaceObject = [];
;// CONCATENATED MODULE: ./src/config/abi/lpToken.json
const lpToken_namespaceObject = [];
;// CONCATENATED MODULE: ./src/config/abi/cake.json
const cake_namespaceObject = [];
;// CONCATENATED MODULE: ./src/config/abi/ifoV1.json
const ifoV1_namespaceObject = [];
;// CONCATENATED MODULE: ./src/config/abi/ifoV2.json
const ifoV2_namespaceObject = [];
// EXTERNAL MODULE: ./src/config/abi/pointCenterIfo.json
var abi_pointCenterIfo = __webpack_require__(8750);
;// CONCATENATED MODULE: ./src/config/abi/lotteryV2.json
const lotteryV2_namespaceObject = [];
;// CONCATENATED MODULE: ./src/config/abi/masterchef.json
const masterchef_namespaceObject = [];
;// CONCATENATED MODULE: ./src/config/abi/sousChef.json
const sousChef_namespaceObject = [];
;// CONCATENATED MODULE: ./src/config/abi/sousChefV2.json
const sousChefV2_namespaceObject = [];
;// CONCATENATED MODULE: ./src/config/abi/sousChefBnb.json
const sousChefBnb_namespaceObject = [];
;// CONCATENATED MODULE: ./src/config/abi/claimRefund.json
const claimRefund_namespaceObject = [];
;// CONCATENATED MODULE: ./src/config/abi/tradingCompetition.json
const tradingCompetition_namespaceObject = [];
;// CONCATENATED MODULE: ./src/config/abi/tradingCompetitionV2.json
const tradingCompetitionV2_namespaceObject = [];
;// CONCATENATED MODULE: ./src/config/abi/cakeVault.json
const cakeVault_namespaceObject = [];
;// CONCATENATED MODULE: ./src/config/abi/ifoPool.json
const ifoPool_namespaceObject = [];
// EXTERNAL MODULE: ./src/config/abi/predictions.json
var predictions = __webpack_require__(5883);
;// CONCATENATED MODULE: ./src/config/abi/chainlinkOracle.json
const chainlinkOracle_namespaceObject = JSON.parse('[{"inputs":[{"internalType":"address","name":"_aggregator","type":"address"},{"internalType":"address","name":"_accessController","type":"address"}],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"int256","name":"current","type":"int256"},{"indexed":true,"internalType":"uint256","name":"roundId","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"updatedAt","type":"uint256"}],"name":"AnswerUpdated","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"roundId","type":"uint256"},{"indexed":true,"internalType":"address","name":"startedBy","type":"address"},{"indexed":false,"internalType":"uint256","name":"startedAt","type":"uint256"}],"name":"NewRound","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"from","type":"address"},{"indexed":true,"internalType":"address","name":"to","type":"address"}],"name":"OwnershipTransferRequested","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"from","type":"address"},{"indexed":true,"internalType":"address","name":"to","type":"address"}],"name":"OwnershipTransferred","type":"event"},{"inputs":[],"name":"acceptOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"accessController","outputs":[{"internalType":"contract AccessControllerInterface","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"aggregator","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_aggregator","type":"address"}],"name":"confirmAggregator","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"decimals","outputs":[{"internalType":"uint8","name":"","type":"uint8"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"description","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_roundId","type":"uint256"}],"name":"getAnswer","outputs":[{"internalType":"int256","name":"","type":"int256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint80","name":"_roundId","type":"uint80"}],"name":"getRoundData","outputs":[{"internalType":"uint80","name":"roundId","type":"uint80"},{"internalType":"int256","name":"answer","type":"int256"},{"internalType":"uint256","name":"startedAt","type":"uint256"},{"internalType":"uint256","name":"updatedAt","type":"uint256"},{"internalType":"uint80","name":"answeredInRound","type":"uint80"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_roundId","type":"uint256"}],"name":"getTimestamp","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"latestAnswer","outputs":[{"internalType":"int256","name":"","type":"int256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"latestRound","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"latestRoundData","outputs":[{"internalType":"uint80","name":"roundId","type":"uint80"},{"internalType":"int256","name":"answer","type":"int256"},{"internalType":"uint256","name":"startedAt","type":"uint256"},{"internalType":"uint256","name":"updatedAt","type":"uint256"},{"internalType":"uint80","name":"answeredInRound","type":"uint80"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"latestTimestamp","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint16","name":"","type":"uint16"}],"name":"phaseAggregators","outputs":[{"internalType":"contract AggregatorV2V3Interface","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"phaseId","outputs":[{"internalType":"uint16","name":"","type":"uint16"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_aggregator","type":"address"}],"name":"proposeAggregator","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"proposedAggregator","outputs":[{"internalType":"contract AggregatorV2V3Interface","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint80","name":"_roundId","type":"uint80"}],"name":"proposedGetRoundData","outputs":[{"internalType":"uint80","name":"roundId","type":"uint80"},{"internalType":"int256","name":"answer","type":"int256"},{"internalType":"uint256","name":"startedAt","type":"uint256"},{"internalType":"uint256","name":"updatedAt","type":"uint256"},{"internalType":"uint80","name":"answeredInRound","type":"uint80"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"proposedLatestRoundData","outputs":[{"internalType":"uint80","name":"roundId","type":"uint80"},{"internalType":"int256","name":"answer","type":"int256"},{"internalType":"uint256","name":"startedAt","type":"uint256"},{"internalType":"uint256","name":"updatedAt","type":"uint256"},{"internalType":"uint80","name":"answeredInRound","type":"uint80"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_accessController","type":"address"}],"name":"setController","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_to","type":"address"}],"name":"transferOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"version","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"}]');
// EXTERNAL MODULE: ./src/config/abi/Multicall.json
var Multicall = __webpack_require__(3373);
;// CONCATENATED MODULE: ./src/config/abi/bunnySpecialCakeVault.json
const bunnySpecialCakeVault_namespaceObject = [];
;// CONCATENATED MODULE: ./src/config/abi/bunnySpecialPrediction.json
const bunnySpecialPrediction_namespaceObject = [];
;// CONCATENATED MODULE: ./src/config/abi/bunnySpecialLottery.json
const bunnySpecialLottery_namespaceObject = [];
;// CONCATENATED MODULE: ./src/config/abi/bunnySpecialXmas.json
const bunnySpecialXmas_namespaceObject = [];
;// CONCATENATED MODULE: ./src/config/abi/farmAuction.json
const farmAuction_namespaceObject = [];
;// CONCATENATED MODULE: ./src/config/abi/anniversaryAchievement.json
const anniversaryAchievement_namespaceObject = JSON.parse('[{"inputs":[{"internalType":"address","name":"_pancakeProfile","type":"address"},{"internalType":"uint256","name":"_numberPoints","type":"uint256"},{"internalType":"uint256","name":"_thresholdPoints","type":"uint256"},{"internalType":"uint256","name":"_campaignId","type":"uint256"},{"internalType":"uint256","name":"_endBlock","type":"uint256"}],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"uint256","name":"campaignId","type":"uint256"}],"name":"NewCampaignId","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"uint256","name":"endBlock","type":"uint256"}],"name":"NewEndBlock","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"uint256","name":"numberPoints","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"thresholdPoints","type":"uint256"}],"name":"NewNumberPointsAndThreshold","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"previousOwner","type":"address"},{"indexed":true,"internalType":"address","name":"newOwner","type":"address"}],"name":"OwnershipTransferred","type":"event"},{"inputs":[],"name":"campaignId","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_user","type":"address"}],"name":"canClaim","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_campaignId","type":"uint256"}],"name":"changeCampaignId","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_endBlock","type":"uint256"}],"name":"changeEndBlock","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_numberPoints","type":"uint256"},{"internalType":"uint256","name":"_thresholdPoints","type":"uint256"}],"name":"changeNumberPointsAndThreshold","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"claimAnniversaryPoints","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"endBlock","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"hasClaimed","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"numberPoints","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"pancakeProfile","outputs":[{"internalType":"contract PancakeProfile","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"renounceOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"thresholdPoints","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"newOwner","type":"address"}],"name":"transferOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"}]');
;// CONCATENATED MODULE: ./src/config/abi/pancakeSquad.json
const pancakeSquad_namespaceObject = [];
;// CONCATENATED MODULE: ./src/config/abi/erc721collection.json
const erc721collection_namespaceObject = [];
;// CONCATENATED MODULE: ./src/utils/contractHelpers.ts





// Addresses

// ABI
































const getContract = (abi, address, signer)=>{
    const signerOrProvider = signer ?? providers/* simpleRpcProvider */.J;
    return new contracts_.Contract(address, abi, signerOrProvider);
};
const getBep20Contract = (address, signer)=>{
    return getContract(bep20Abi, address, signer);
};
const getErc721Contract = (address, signer)=>{
    return getContract(erc721Abi, address, signer);
};
const getLpContract = (address, signer)=>{
    return getContract(lpTokenAbi, address, signer);
};
const getIfoV1Contract = (address, signer)=>{
    return getContract(ifoV1Abi, address, signer);
};
const getIfoV2Contract = (address, signer)=>{
    return getContract(ifoV2Abi, address, signer);
};
const getSouschefContract = (id, signer)=>{
    const config = poolsConfig.find((pool)=>pool.sousId === id
    );
    const abi = config.poolCategory === PoolCategory.BINANCE ? sousChefBnb : sousChef;
    return getContract(abi, getAddress(config.contractAddress), signer);
};
const getSouschefV2Contract = (id, signer)=>{
    const config = poolsConfig.find((pool)=>pool.sousId === id
    );
    return getContract(sousChefV2, getAddress(config.contractAddress), signer);
};
const getPointCenterIfoContract = (signer)=>{
    return getContract(pointCenterIfo, getPointCenterIfoAddress(), signer);
};
const getCakeContract = (signer)=>{
    return getContract(cakeAbi, tokens.cake.address, signer);
};
const getProfileContract = (signer)=>{
    return getContract(profileABI, getPancakeProfileAddress(), signer);
};
const getPancakeRabbitContract = (signer)=>{
    return getContract(pancakeRabbitsAbi, getPancakeRabbitsAddress(), signer);
};
const getBunnyFactoryContract = (signer)=>{
    return getContract(bunnyFactoryAbi, getBunnyFactoryAddress(), signer);
};
const getBunnySpecialContract = (signer)=>{
    return getContract(bunnySpecialAbi, getBunnySpecialAddress(), signer);
};
const getLotteryV2Contract = (signer)=>{
    return getContract(lotteryV2Abi, getLotteryV2Address(), signer);
};
const getMasterchefContract = (signer)=>{
    return getContract(masterChef, getMasterChefAddress(), signer);
};
const getClaimRefundContract = (signer)=>{
    return getContract(claimRefundAbi, getClaimRefundAddress(), signer);
};
const getTradingCompetitionContract = (signer)=>{
    return getContract(tradingCompetitionAbi, getTradingCompetitionAddress(), signer);
};
const getTradingCompetitionContractV2 = (signer)=>{
    return getContract(tradingCompetitionV2Abi, getTradingCompetitionAddressV2(), signer);
};
const getCakeVaultContract = (signer)=>{
    return getContract(cakeVaultAbi, getCakeVaultAddress(), signer);
};
const getIfoPoolContract = (signer)=>{
    return getContract(ifoPoolAbi, getIfoPoolAddress(), signer);
};
const getPredictionsContract = (signer)=>{
    return getContract(predictions, (0,addressHelpers/* getPredictionsAddress */.Df)(), signer);
};
const getChainlinkOracleContract = (signer)=>{
    return getContract(chainlinkOracle_namespaceObject, (0,addressHelpers/* getChainlinkOracleAddress */.pf)(), signer);
};
const getMulticallContract = (signer)=>{
    return getContract(Multicall, (0,addressHelpers/* getMulticallAddress */.I8)(), signer);
};
const getBunnySpecialCakeVaultContract = (signer)=>{
    return getContract(bunnySpecialCakeVaultAbi, getBunnySpecialCakeVaultAddress(), signer);
};
const getBunnySpecialPredictionContract = (signer)=>{
    return getContract(bunnySpecialPredictionAbi, getBunnySpecialPredictionAddress(), signer);
};
const getBunnySpecialLotteryContract = (signer)=>{
    return getContract(bunnySpecialLotteryAbi, getBunnySpecialLotteryAddress(), signer);
};
const getBunnySpecialXmasContract = (signer)=>{
    return getContract(bunnySpecialXmasAbi, getBunnySpecialXmasAddress(), signer);
};
const getFarmAuctionContract = (signer)=>{
    return getContract(farmAuctionAbi, getFarmAuctionAddress(), signer);
};
const getAnniversaryAchievementContract = (signer)=>{
    return getContract(anniversaryAchievement_namespaceObject, (0,addressHelpers/* getAnniversaryAchievement */.Jc)(), signer);
};
const getPancakeSquadContract = (signer)=>{
    return getContract(pancakeSquadAbi, getPancakeSquadAddress(), signer);
};
const getErc721CollectionContract = (signer, address)=>{
    return getContract(erc721CollectionAbi, address, signer);
};


/***/ }),

/***/ 5044:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "U4": () => (/* binding */ getBalanceAmount),
/* harmony export */   "NJ": () => (/* binding */ getFullDisplayBalance),
/* harmony export */   "uf": () => (/* binding */ formatNumber),
/* harmony export */   "dp": () => (/* binding */ formatBigNumber),
/* harmony export */   "U1": () => (/* binding */ formatBigNumberToFixed),
/* harmony export */   "w$": () => (/* binding */ formatFixedNumber),
/* harmony export */   "uI": () => (/* binding */ formatLocalisedCompactNumber)
/* harmony export */ });
/* unused harmony exports getDecimalAmount, getBalanceNumber */
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4215);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(bignumber_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5757);
/* harmony import */ var _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ethersproject_units__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3138);
/* harmony import */ var _ethersproject_units__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_units__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var contexts_Localization_helpers__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5290);
/* harmony import */ var _bigNumber__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5128);





/**
 * Take a formatted amount, e.g. 15 BNB and convert it to full decimal value, e.g. 15000000000000000
 */ const getDecimalAmount = (amount, decimals = 18)=>{
    return new BigNumber(amount).times(BIG_TEN.pow(decimals));
};
const getBalanceAmount = (amount, decimals = 18)=>{
    return new (bignumber_js__WEBPACK_IMPORTED_MODULE_0___default())(amount).dividedBy(_bigNumber__WEBPACK_IMPORTED_MODULE_4__/* .BIG_TEN.pow */ .xp.pow(decimals));
};
/**
 * This function is not really necessary but is used throughout the site.
 */ const getBalanceNumber = (balance, decimals = 18)=>{
    return getBalanceAmount(balance, decimals).toNumber();
};
const getFullDisplayBalance = (balance, decimals = 18, displayDecimals)=>{
    return getBalanceAmount(balance, decimals).toFixed(displayDecimals);
};
const formatNumber = (number, minPrecision = 2, maxPrecision = 2)=>{
    const options = {
        minimumFractionDigits: minPrecision,
        maximumFractionDigits: maxPrecision
    };
    return number.toLocaleString(undefined, options);
};
/**
 * Method to format the display of wei given an EthersBigNumber object
 * Note: does NOT round
 */ const formatBigNumber = (number, displayDecimals = 18, decimals = 18)=>{
    const remainder = number.mod(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_1__.BigNumber.from(10).pow(decimals - displayDecimals));
    return (0,_ethersproject_units__WEBPACK_IMPORTED_MODULE_2__.formatUnits)(number.sub(remainder), decimals);
};
/**
 * Method to format the display of wei given an EthersBigNumber object with toFixed
 * Note: rounds
 */ const formatBigNumberToFixed = (number, displayDecimals = 18, decimals = 18)=>{
    const formattedString = (0,_ethersproject_units__WEBPACK_IMPORTED_MODULE_2__.formatUnits)(number, decimals);
    return (+formattedString).toFixed(displayDecimals);
};
/**
 * Formats a FixedNumber like BigNumber
 * i.e. Formats 9763410526137450427.1196 into 9.763 (3 display decimals)
 */ const formatFixedNumber = (number, displayDecimals = 18, decimals = 18)=>{
    // Remove decimal
    const [leftSide] = number.toString().split('.');
    return formatBigNumber(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_1__.BigNumber.from(leftSide), displayDecimals, decimals);
};
const formatLocalisedCompactNumber = (number)=>{
    const codeFromStorage = (0,contexts_Localization_helpers__WEBPACK_IMPORTED_MODULE_3__/* .getLanguageCodeFromLS */ .jq)();
    return new Intl.NumberFormat(codeFromStorage, {
        notation: 'compact',
        compactDisplay: 'long',
        maximumSignificantDigits: 2
    }).format(number);
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (formatLocalisedCompactNumber)));


/***/ }),

/***/ 7308:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "t": () => (/* binding */ nodes),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var lodash_sample__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7657);
/* harmony import */ var lodash_sample__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash_sample__WEBPACK_IMPORTED_MODULE_0__);

if (false) {}
// Array of available nodes to connect to
const nodes = [
    "https://api.s0.b.hmny.io",
    "https://api.s0.b.hmny.io",
    "https://api.s0.b.hmny.io"
];
const getNodeUrl = ()=>{
    // Use custom node if available (both for development and production)
    // However on the testnet it wouldn't work, so if on testnet - comment out the NEXT_PUBLIC_NODE_PRODUCTION from env file
    if (process.env.NEXT_PUBLIC_NODE_PRODUCTION) {
        return process.env.NEXT_PUBLIC_NODE_PRODUCTION;
    }
    return lodash_sample__WEBPACK_IMPORTED_MODULE_0___default()(nodes);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (getNodeUrl);


/***/ }),

/***/ 8328:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "hr": () => (/* binding */ escapeRegExp),
  "s6": () => (/* binding */ getBscScanLink),
  "uN": () => (/* binding */ getContract),
  "TY": () => (/* binding */ getProviderOrSigner),
  "UJ": () => (/* binding */ isAddress)
});

// UNUSED EXPORTS: basisPointsToPercent, calculateGasMargin, calculateSlippageAmount, getBscScanLinkForNft, getRouterContract, getSigner, isTokenOnList

// EXTERNAL MODULE: external "@ethersproject/contracts"
var contracts_ = __webpack_require__(2792);
// EXTERNAL MODULE: external "@ethersproject/address"
var address_ = __webpack_require__(1541);
// EXTERNAL MODULE: external "@ethersproject/constants"
var constants_ = __webpack_require__(6644);
// EXTERNAL MODULE: external "@ethersproject/bignumber"
var bignumber_ = __webpack_require__(5757);
;// CONCATENATED MODULE: ./src/config/abi/IPancakeRouter02.json
const IPancakeRouter02_namespaceObject = [];
// EXTERNAL MODULE: external "@mdemouchy/sdk"
var sdk_ = __webpack_require__(2877);
// EXTERNAL MODULE: ./src/config/constants/index.ts + 1 modules
var constants = __webpack_require__(1311);
// EXTERNAL MODULE: ./src/config/index.ts
var config = __webpack_require__(3206);
// EXTERNAL MODULE: ./src/utils/providers.ts
var providers = __webpack_require__(5922);
;// CONCATENATED MODULE: ./src/utils/index.ts









// returns the checksummed address if the address is valid, otherwise returns false
function isAddress(value) {
    try {
        return (0,address_.getAddress)(value);
    } catch  {
        return false;
    }
}
function getBscScanLink(data, type, chainId = sdk_.ChainId.MAINNET) {
    switch(type){
        case 'transaction':
            {
                return `${config/* BASE_BSC_SCAN_URLS */.st[chainId]}/tx/${data}`;
            }
        case 'token':
            {
                return `${config/* BASE_BSC_SCAN_URLS */.st[chainId]}/token/${data}`;
            }
        case 'block':
            {
                return `${config/* BASE_BSC_SCAN_URLS */.st[chainId]}/block/${data}`;
            }
        case 'countdown':
            {
                return `${config/* BASE_BSC_SCAN_URLS */.st[chainId]}/block/countdown/${data}`;
            }
        default:
            {
                return `${config/* BASE_BSC_SCAN_URLS */.st[chainId]}/address/${data}`;
            }
    }
}
function getBscScanLinkForNft(collectionAddress, tokenId, chainId = ChainId.MAINNET) {
    return `${BASE_BSC_SCAN_URLS[chainId]}/token/${collectionAddress}?a=${tokenId}`;
}
// add 10%
function calculateGasMargin(value) {
    return value.mul(BigNumber.from(10000).add(BigNumber.from(1000))).div(BigNumber.from(10000));
}
// converts a basis points value to a sdk percent
function basisPointsToPercent(num) {
    return new Percent(JSBI.BigInt(num), JSBI.BigInt(10000));
}
function calculateSlippageAmount(value, slippage) {
    if (slippage < 0 || slippage > 10000) {
        throw Error(`Unexpected slippage value: ${slippage}`);
    }
    return [
        JSBI.divide(JSBI.multiply(value.raw, JSBI.BigInt(10000 - slippage)), JSBI.BigInt(10000)),
        JSBI.divide(JSBI.multiply(value.raw, JSBI.BigInt(10000 + slippage)), JSBI.BigInt(10000)), 
    ];
}
// account is not optional
function getSigner(library, account) {
    return library.getSigner(account).connectUnchecked();
}
// account is optional
function getProviderOrSigner(library, account) {
    return account ? getSigner(library, account) : library;
}
// account is optional
function getContract(address, ABI, signer) {
    if (!isAddress(address) || address === constants_.AddressZero) {
        throw Error(`Invalid 'address' parameter '${address}'.`);
    }
    return new contracts_.Contract(address, ABI, signer ?? providers/* simpleRpcProvider */.J);
}
// account is optional
function getRouterContract(_, library, account) {
    return getContract(ROUTER_ADDRESS, IPancakeRouter02ABI, getProviderOrSigner(library, account));
}
function escapeRegExp(string) {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') // $& means the whole matched string
    ;
}
function isTokenOnList(defaultTokens, currency) {
    if (currency === ETHER) return true;
    return Boolean(currency instanceof Token && defaultTokens[currency.chainId]?.[currency.address]);
}


/***/ }),

/***/ 1144:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "v": () => (/* binding */ multicallv2)
/* harmony export */ });
/* harmony import */ var _ethersproject_abi__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6187);
/* harmony import */ var _ethersproject_abi__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_abi__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var utils_contractHelpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4765);


const multicall = async (abi, calls)=>{
    const multi = getMulticallContract();
    const itf = new Interface(abi);
    const calldata = calls.map((call)=>({
            target: call.address.toLowerCase(),
            callData: itf.encodeFunctionData(call.name, call.params)
        })
    );
    const { returnData  } = await multi.aggregate(calldata);
    const res = returnData.map((call, i)=>itf.decodeFunctionResult(calls[i].name, call)
    );
    return res;
};
/**
 * Multicall V2 uses the new "tryAggregate" function. It is different in 2 ways
 *
 * 1. If "requireSuccess" is false multicall will not bail out if one of the calls fails
 * 2. The return includes a boolean whether the call was successful e.g. [wasSuccessful, callResult]
 */ const multicallv2 = async (abi, calls, options = {
    requireSuccess: true
})=>{
    const { requireSuccess  } = options;
    const multi = (0,utils_contractHelpers__WEBPACK_IMPORTED_MODULE_1__/* .getMulticallContract */ .tV)();
    const itf = new _ethersproject_abi__WEBPACK_IMPORTED_MODULE_0__.Interface(abi);
    const calldata = calls.map((call)=>({
            target: call.address.toLowerCase(),
            callData: itf.encodeFunctionData(call.name, call.params)
        })
    );
    const returnData = await multi.tryAggregate(requireSuccess, calldata);
    const res = returnData.map((call, i)=>{
        const [result, data] = call;
        return result ? itf.decodeFunctionResult(calls[i].name, data) : null;
    });
    return res;
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (multicall)));


/***/ }),

/***/ 7879:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "as": () => (/* binding */ multiplyPriceByAmount)
/* harmony export */ });
/* unused harmony exports computeTradePriceBreakdown, warningSeverity, formatExecutionPrice */
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2877);
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _config_constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1311);


const BASE_FEE = new _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.Percent(_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(25), _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(10000));
const ONE_HUNDRED_PERCENT = new _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.Percent(_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(10000), _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(10000));
const INPUT_FRACTION_AFTER_FEE = ONE_HUNDRED_PERCENT.subtract(BASE_FEE);
// computes price breakdown for the trade
function computeTradePriceBreakdown(trade) {
    // for each hop in our trade, take away the x*y=k price impact from 0.3% fees
    // e.g. for 3 tokens/2 hops: 1 - ((1 - .03) * (1-.03))
    const realizedLPFee = !trade ? undefined : ONE_HUNDRED_PERCENT.subtract(trade.route.pairs.reduce((currentFee)=>currentFee.multiply(INPUT_FRACTION_AFTER_FEE)
    , ONE_HUNDRED_PERCENT));
    // remove lp fees from price impact
    const priceImpactWithoutFeeFraction = trade && realizedLPFee ? trade.priceImpact.subtract(realizedLPFee) : undefined;
    // the x*y=k impact
    const priceImpactWithoutFeePercent = priceImpactWithoutFeeFraction ? new Percent(priceImpactWithoutFeeFraction?.numerator, priceImpactWithoutFeeFraction?.denominator) : undefined;
    // the amount of the input that accrues to LPs
    const realizedLPFeeAmount = realizedLPFee && trade && (trade.inputAmount instanceof TokenAmount ? new TokenAmount(trade.inputAmount.token, realizedLPFee.multiply(trade.inputAmount.raw).quotient) : CurrencyAmount.ether(realizedLPFee.multiply(trade.inputAmount.raw).quotient));
    return {
        priceImpactWithoutFee: priceImpactWithoutFeePercent,
        realizedLPFee: realizedLPFeeAmount
    };
}
function warningSeverity(priceImpact) {
    if (!priceImpact?.lessThan(BLOCKED_PRICE_IMPACT_NON_EXPERT)) return 4;
    if (!priceImpact?.lessThan(ALLOWED_PRICE_IMPACT_HIGH)) return 3;
    if (!priceImpact?.lessThan(ALLOWED_PRICE_IMPACT_MEDIUM)) return 2;
    if (!priceImpact?.lessThan(ALLOWED_PRICE_IMPACT_LOW)) return 1;
    return 0;
}
function formatExecutionPrice(trade, inverted) {
    if (!trade) {
        return '';
    }
    return inverted ? `${trade.executionPrice.invert().toSignificant(6)} ${trade.inputAmount.currency.symbol} / ${trade.outputAmount.currency.symbol}` : `${trade.executionPrice.toSignificant(6)} ${trade.outputAmount.currency.symbol} / ${trade.inputAmount.currency.symbol}`;
}
/**
 * Helper to multiply a Price object by an arbitrary amount
 */ const multiplyPriceByAmount = (price, amount, significantDigits = 18)=>{
    if (!price) {
        return 0;
    }
    return parseFloat(price.toSignificant(significantDigits)) * amount;
};


/***/ }),

/***/ 5922:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "J": () => (/* binding */ simpleRpcProvider)
/* harmony export */ });
/* harmony import */ var _ethersproject_providers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(399);
/* harmony import */ var _ethersproject_providers__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_providers__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var utils_getRpcUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7308);


const RPC_URL = (0,utils_getRpcUrl__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)();
const simpleRpcProvider = new _ethersproject_providers__WEBPACK_IMPORTED_MODULE_0__.StaticJsonRpcProvider(RPC_URL);
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = (null);


/***/ }),

/***/ 3467:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/**
 * Truncate a transaction or address hash
 */ const truncateHash = (address, startLength = 4, endLength = 4)=>{
    return `${address.substring(0, startLength)}...${address.substring(address.length - endLength)}`;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (truncateHash);


/***/ }),

/***/ 2338:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BA": () => (/* binding */ connectorsByName),
/* harmony export */   "av": () => (/* binding */ getLibrary)
/* harmony export */ });
/* unused harmony export signMessage */
/* harmony import */ var _web3_react_injected_connector__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6590);
/* harmony import */ var _web3_react_injected_connector__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_web3_react_injected_connector__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _web3_react_walletconnect_connector__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9795);
/* harmony import */ var _web3_react_walletconnect_connector__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_web3_react_walletconnect_connector__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _binance_chain_bsc_connector__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8454);
/* harmony import */ var _binance_chain_bsc_connector__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_binance_chain_bsc_connector__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _ethersproject_bytes__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9935);
/* harmony import */ var _ethersproject_bytes__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_bytes__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _ethersproject_strings__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9213);
/* harmony import */ var _ethersproject_strings__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_strings__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _ethersproject_providers__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(399);
/* harmony import */ var _ethersproject_providers__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_providers__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _getRpcUrl__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7308);








const POLLING_INTERVAL = 12000;
const rpcUrl = (0,_getRpcUrl__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
const chainId = parseInt("1666700000", 10);
const injected = new _web3_react_injected_connector__WEBPACK_IMPORTED_MODULE_0__.InjectedConnector({
    supportedChainIds: [
        chainId
    ]
});
const walletconnect = new _web3_react_walletconnect_connector__WEBPACK_IMPORTED_MODULE_1__.WalletConnectConnector({
    rpc: {
        [chainId]: rpcUrl
    },
    qrcode: true,
    pollingInterval: POLLING_INTERVAL
});
const bscConnector = new _binance_chain_bsc_connector__WEBPACK_IMPORTED_MODULE_2__.BscConnector({
    supportedChainIds: [
        chainId
    ]
});
const connectorsByName = {
    [_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.ConnectorNames.Injected]: injected,
    [_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.ConnectorNames.WalletConnect]: walletconnect,
    [_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.ConnectorNames.BSC]: bscConnector
};
const getLibrary = (provider)=>{
    const library = new _ethersproject_providers__WEBPACK_IMPORTED_MODULE_6__.Web3Provider(provider);
    library.pollingInterval = POLLING_INTERVAL;
    return library;
};
/**
 * BSC Wallet requires a different sign method
 * @see https://docs.binance.org/smart-chain/wallet/wallet_api.html#binancechainbnbsignaddress-string-message-string-promisepublickey-string-signature-string
 */ const signMessage = async (connector, provider, account, message)=>{
    if (window.BinanceChain && connector instanceof BscConnector) {
        const { signature  } = await window.BinanceChain.bnbSign(account, message);
        return signature;
    }
    /**
   * Wallet Connect does not sign the message correctly unless you use their method
   * @see https://github.com/WalletConnect/walletconnect-monorepo/issues/462
   */ if (provider.provider?.wc) {
        const wcMessage = hexlify(toUtf8Bytes(message));
        const signature = await provider.provider?.wc.signPersonalMessage([
            wcMessage,
            account
        ]);
        return signature;
    }
    return provider.getSigner(account).signMessage(message);
};


/***/ }),

/***/ 3854:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "pu": () => (/* binding */ wrappedCurrency)
/* harmony export */ });
/* unused harmony exports wrappedCurrencyAmount, unwrappedToken */
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2877);
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__);

function wrappedCurrency(currency, chainId) {
    return chainId && currency === _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.ETHER ? _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.WETH[chainId] : currency instanceof _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.Token ? currency : undefined;
}
function wrappedCurrencyAmount(currencyAmount, chainId) {
    const token = currencyAmount && chainId ? wrappedCurrency(currencyAmount.currency, chainId) : undefined;
    return token && currencyAmount ? new TokenAmount(token, currencyAmount.raw) : undefined;
}
function unwrappedToken(token) {
    if (token.equals(WETH[token.chainId])) return ETHER;
    return token;
}


/***/ }),

/***/ 2006:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var components_Layout_Page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9770);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9150);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1664);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([components_Layout_Page__WEBPACK_IMPORTED_MODULE_4__]);
components_Layout_Page__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];







const StyledNotFound = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-61c1aea1-0"
})`
  align-items: center;
  display: flex;
  flex-direction: column;
  height: calc(100vh - 64px);
  justify-content: center;
`;
const NotFound = ()=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_5__/* .useTranslation */ .$G)();
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Layout_Page__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(StyledNotFound, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.LogoIcon, {
                    width: "64px",
                    mb: "8px"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Heading, {
                    scale: "xxl",
                    children: "404"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                    mb: "16px",
                    children: t('Oops, page not found.')
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_6__["default"], {
                    href: "/",
                    passHref: true,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Button, {
                        as: "a",
                        scale: "sm",
                        children: t('Back Home')
                    })
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NotFound);

});

/***/ }),

/***/ 7020:
/***/ ((module) => {

module.exports = JSON.parse('{"polyfillFiles":["static/chunks/polyfills-5cd94c89d3acac5f.js"],"devFiles":[],"ampDevFiles":[],"lowPriorityFiles":["static/p-7hfptfU_wDmo0-zX3ZS/_buildManifest.js","static/p-7hfptfU_wDmo0-zX3ZS/_ssgManifest.js","static/p-7hfptfU_wDmo0-zX3ZS/_middlewareManifest.js"],"pages":{"/":["static/chunks/webpack-fbb47d5975907de5.js","static/chunks/framework-fda7fa95de900d79.js","static/chunks/main-54a3d1c18ccbd6c7.js","static/chunks/857-1f1b27be1f8a1970.js","static/chunks/pages/index-6a067c8b2226d32c.js"],"/404":["static/chunks/webpack-fbb47d5975907de5.js","static/chunks/framework-fda7fa95de900d79.js","static/chunks/main-54a3d1c18ccbd6c7.js","static/chunks/pages/404-0eb66c1423adab97.js"],"/_app":["static/chunks/webpack-fbb47d5975907de5.js","static/chunks/framework-fda7fa95de900d79.js","static/chunks/main-54a3d1c18ccbd6c7.js","static/chunks/pages/_app-54587978378d7f50.js"],"/_error":["static/chunks/webpack-fbb47d5975907de5.js","static/chunks/framework-fda7fa95de900d79.js","static/chunks/main-54a3d1c18ccbd6c7.js","static/chunks/pages/_error-b8904986404808d2.js"],"/info":["static/chunks/webpack-fbb47d5975907de5.js","static/chunks/framework-fda7fa95de900d79.js","static/chunks/main-54a3d1c18ccbd6c7.js","static/chunks/724-bb876b4dca0e7fa3.js","static/chunks/201-61103e76e9dd8f25.js","static/chunks/24-961738101b8c89ad.js","static/chunks/838-610e470c03df5f5d.js","static/chunks/pages/info-534743de35bb4166.js"],"/info/pools":["static/chunks/webpack-fbb47d5975907de5.js","static/chunks/framework-fda7fa95de900d79.js","static/chunks/main-54a3d1c18ccbd6c7.js","static/chunks/724-bb876b4dca0e7fa3.js","static/chunks/24-961738101b8c89ad.js","static/chunks/pages/info/pools-9c3094b94028b904.js"],"/info/pools/[address]":["static/chunks/webpack-fbb47d5975907de5.js","static/chunks/framework-fda7fa95de900d79.js","static/chunks/main-54a3d1c18ccbd6c7.js","static/chunks/724-bb876b4dca0e7fa3.js","static/chunks/201-61103e76e9dd8f25.js","static/chunks/24-961738101b8c89ad.js","static/chunks/838-610e470c03df5f5d.js","static/chunks/pages/info/pools/[address]-445fde70f30fd6c8.js"],"/info/tokens":["static/chunks/webpack-fbb47d5975907de5.js","static/chunks/framework-fda7fa95de900d79.js","static/chunks/main-54a3d1c18ccbd6c7.js","static/chunks/724-bb876b4dca0e7fa3.js","static/chunks/24-961738101b8c89ad.js","static/chunks/pages/info/tokens-9494cd1d38dc26bf.js"],"/info/tokens/[address]":["static/chunks/webpack-fbb47d5975907de5.js","static/chunks/framework-fda7fa95de900d79.js","static/chunks/main-54a3d1c18ccbd6c7.js","static/chunks/724-bb876b4dca0e7fa3.js","static/chunks/201-61103e76e9dd8f25.js","static/chunks/24-961738101b8c89ad.js","static/chunks/838-610e470c03df5f5d.js","static/chunks/pages/info/tokens/[address]-824471b59242d11c.js"],"/prediction":["static/chunks/webpack-fbb47d5975907de5.js","static/chunks/framework-fda7fa95de900d79.js","static/chunks/main-54a3d1c18ccbd6c7.js","static/chunks/857-1f1b27be1f8a1970.js","static/chunks/706-122277c69a08663d.js","static/css/370626aab6077489.css","static/chunks/pages/prediction-af0096787848aff3.js"],"/prediction/leaderboard":["static/chunks/webpack-fbb47d5975907de5.js","static/chunks/framework-fda7fa95de900d79.js","static/chunks/main-54a3d1c18ccbd6c7.js","static/chunks/pages/prediction/leaderboard-c64bb38ba2990b79.js"]},"ampFirstPages":[]}');

/***/ }),

/***/ 3978:
/***/ ((module) => {

module.exports = JSON.parse('{"../../node_modules/@web3-react/walletconnect-connector/dist/walletconnect-connector.esm.js -> @walletconnect/web3-provider":{"id":64488,"files":["static/chunks/539.c6f670e2639e7105.js","static/chunks/488.17b05774d1eb7e32.js","static/chunks/281.8595ea58891a3fae.js"]},"../components/GlobalCheckClaimStatus/index.tsx -> ./AnniversaryAchievementModal":{"id":28765,"files":["static/chunks/765.7cb7579700e98d14.js"]},"../hooks/useFetchListCallback.ts -> ../utils/getTokenList":{"id":34432,"files":["static/chunks/539.c6f670e2639e7105.js","static/chunks/53.78c4050552539d33.js","static/chunks/432.f2ca6ece5b47415e.js"]},"../views/Info/components/InfoCharts/ChartCard/index.tsx -> views/Info/components/InfoCharts/CandleChart":{"id":85491,"files":["static/chunks/149.dfa7c2f0dd9fc776.js","static/chunks/491.54faaec6b437de64.js"]}}');

/***/ }),

/***/ 9450:
/***/ ((module) => {

module.exports = JSON.parse('{"Dg":[{"source":"/info/token/:address","destination":"/info/tokens/:address","regex":"^/info/token(?:/([^/]+?))(?:/)?$"},{"source":"/info/pool/:address","destination":"/info/pools/:address","regex":"^/info/pool(?:/([^/]+?))(?:/)?$"},{"source":"/info/pair/:address","destination":"/info/pools/:address","regex":"^/info/pair(?:/([^/]+?))(?:/)?$"}]}');

/***/ }),

/***/ 3725:
/***/ ((module) => {

module.exports = JSON.parse('[{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"owner","type":"address"},{"indexed":true,"internalType":"address","name":"spender","type":"address"},{"indexed":false,"internalType":"uint256","name":"value","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"sender","type":"address"},{"indexed":false,"internalType":"uint256","name":"amount0","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount1","type":"uint256"},{"indexed":true,"internalType":"address","name":"to","type":"address"}],"name":"Burn","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"sender","type":"address"},{"indexed":false,"internalType":"uint256","name":"amount0","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount1","type":"uint256"}],"name":"Mint","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"sender","type":"address"},{"indexed":false,"internalType":"uint256","name":"amount0In","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount1In","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount0Out","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount1Out","type":"uint256"},{"indexed":true,"internalType":"address","name":"to","type":"address"}],"name":"Swap","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"uint112","name":"reserve0","type":"uint112"},{"indexed":false,"internalType":"uint112","name":"reserve1","type":"uint112"}],"name":"Sync","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"from","type":"address"},{"indexed":true,"internalType":"address","name":"to","type":"address"},{"indexed":false,"internalType":"uint256","name":"value","type":"uint256"}],"name":"Transfer","type":"event"},{"inputs":[],"name":"DOMAIN_SEPARATOR","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"MINIMUM_LIQUIDITY","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"pure","type":"function"},{"inputs":[],"name":"PERMIT_TYPEHASH","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"stateMutability":"pure","type":"function"},{"inputs":[{"internalType":"address","name":"owner","type":"address"},{"internalType":"address","name":"spender","type":"address"}],"name":"allowance","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"spender","type":"address"},{"internalType":"uint256","name":"value","type":"uint256"}],"name":"approve","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"owner","type":"address"}],"name":"balanceOf","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"to","type":"address"}],"name":"burn","outputs":[{"internalType":"uint256","name":"amount0","type":"uint256"},{"internalType":"uint256","name":"amount1","type":"uint256"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"decimals","outputs":[{"internalType":"uint8","name":"","type":"uint8"}],"stateMutability":"pure","type":"function"},{"inputs":[],"name":"factory","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getReserves","outputs":[{"internalType":"uint112","name":"reserve0","type":"uint112"},{"internalType":"uint112","name":"reserve1","type":"uint112"},{"internalType":"uint32","name":"blockTimestampLast","type":"uint32"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"},{"internalType":"address","name":"","type":"address"}],"name":"initialize","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"kLast","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"to","type":"address"}],"name":"mint","outputs":[{"internalType":"uint256","name":"liquidity","type":"uint256"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"name","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"pure","type":"function"},{"inputs":[{"internalType":"address","name":"owner","type":"address"}],"name":"nonces","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"owner","type":"address"},{"internalType":"address","name":"spender","type":"address"},{"internalType":"uint256","name":"value","type":"uint256"},{"internalType":"uint256","name":"deadline","type":"uint256"},{"internalType":"uint8","name":"v","type":"uint8"},{"internalType":"bytes32","name":"r","type":"bytes32"},{"internalType":"bytes32","name":"s","type":"bytes32"}],"name":"permit","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"price0CumulativeLast","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"price1CumulativeLast","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"to","type":"address"}],"name":"skim","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"amount0Out","type":"uint256"},{"internalType":"uint256","name":"amount1Out","type":"uint256"},{"internalType":"address","name":"to","type":"address"},{"internalType":"bytes","name":"data","type":"bytes"}],"name":"swap","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"symbol","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"pure","type":"function"},{"inputs":[],"name":"sync","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"token0","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"token1","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"totalSupply","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"value","type":"uint256"}],"name":"transfer","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"value","type":"uint256"}],"name":"transferFrom","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"}]');

/***/ }),

/***/ 3373:
/***/ ((module) => {

module.exports = JSON.parse('[{"inputs":[{"components":[{"internalType":"address","name":"target","type":"address"},{"internalType":"bytes","name":"callData","type":"bytes"}],"internalType":"struct Multicall2.Call[]","name":"calls","type":"tuple[]"}],"name":"aggregate","outputs":[{"internalType":"uint256","name":"blockNumber","type":"uint256"},{"internalType":"bytes[]","name":"returnData","type":"bytes[]"}],"stateMutability":"view","type":"function"},{"inputs":[{"components":[{"internalType":"address","name":"target","type":"address"},{"internalType":"bytes","name":"callData","type":"bytes"}],"internalType":"struct Multicall2.Call[]","name":"calls","type":"tuple[]"}],"name":"blockAndAggregate","outputs":[{"internalType":"uint256","name":"blockNumber","type":"uint256"},{"internalType":"bytes32","name":"blockHash","type":"bytes32"},{"components":[{"internalType":"bool","name":"success","type":"bool"},{"internalType":"bytes","name":"returnData","type":"bytes"}],"internalType":"struct Multicall2.Result[]","name":"returnData","type":"tuple[]"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"blockNumber","type":"uint256"}],"name":"getBlockHash","outputs":[{"internalType":"bytes32","name":"blockHash","type":"bytes32"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getBlockNumber","outputs":[{"internalType":"uint256","name":"blockNumber","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getCurrentBlockCoinbase","outputs":[{"internalType":"address","name":"coinbase","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getCurrentBlockDifficulty","outputs":[{"internalType":"uint256","name":"difficulty","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getCurrentBlockGasLimit","outputs":[{"internalType":"uint256","name":"gaslimit","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getCurrentBlockTimestamp","outputs":[{"internalType":"uint256","name":"timestamp","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"addr","type":"address"}],"name":"getEthBalance","outputs":[{"internalType":"uint256","name":"balance","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getLastBlockHash","outputs":[{"internalType":"bytes32","name":"blockHash","type":"bytes32"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"bool","name":"requireSuccess","type":"bool"},{"components":[{"internalType":"address","name":"target","type":"address"},{"internalType":"bytes","name":"callData","type":"bytes"}],"internalType":"struct Multicall2.Call[]","name":"calls","type":"tuple[]"}],"name":"tryAggregate","outputs":[{"components":[{"internalType":"bool","name":"success","type":"bool"},{"internalType":"bytes","name":"returnData","type":"bytes"}],"internalType":"struct Multicall2.Result[]","name":"returnData","type":"tuple[]"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"bool","name":"requireSuccess","type":"bool"},{"components":[{"internalType":"address","name":"target","type":"address"},{"internalType":"bytes","name":"callData","type":"bytes"}],"internalType":"struct Multicall2.Call[]","name":"calls","type":"tuple[]"}],"name":"tryBlockAndAggregate","outputs":[{"internalType":"uint256","name":"blockNumber","type":"uint256"},{"internalType":"bytes32","name":"blockHash","type":"bytes32"},{"components":[{"internalType":"bool","name":"success","type":"bool"},{"internalType":"bytes","name":"returnData","type":"bytes"}],"internalType":"struct Multicall2.Result[]","name":"returnData","type":"tuple[]"}],"stateMutability":"nonpayable","type":"function"}]');

/***/ }),

/***/ 3324:
/***/ ((module) => {

module.exports = JSON.parse('[{"constant":true,"inputs":[],"name":"name","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_spender","type":"address"},{"name":"_value","type":"uint256"}],"name":"approve","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"totalSupply","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_from","type":"address"},{"name":"_to","type":"address"},{"name":"_value","type":"uint256"}],"name":"transferFrom","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"decimals","outputs":[{"name":"","type":"uint8"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"_owner","type":"address"}],"name":"balanceOf","outputs":[{"name":"balance","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"symbol","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_to","type":"address"},{"name":"_value","type":"uint256"}],"name":"transfer","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"name":"_owner","type":"address"},{"name":"_spender","type":"address"}],"name":"allowance","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"payable":true,"stateMutability":"payable","type":"fallback"},{"anonymous":false,"inputs":[{"indexed":true,"name":"owner","type":"address"},{"indexed":true,"name":"spender","type":"address"},{"indexed":false,"name":"value","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"from","type":"address"},{"indexed":true,"name":"to","type":"address"},{"indexed":false,"name":"value","type":"uint256"}],"name":"Transfer","type":"event"}]');

/***/ }),

/***/ 2335:
/***/ ((module) => {

module.exports = JSON.parse('[{"inputs":[{"internalType":"contract IBEP20","name":"_cakeToken","type":"address"},{"internalType":"uint256","name":"_numberCakeToReactivate","type":"uint256"},{"internalType":"uint256","name":"_numberCakeToRegister","type":"uint256"},{"internalType":"uint256","name":"_numberCakeToUpdate","type":"uint256"}],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"role","type":"bytes32"},{"indexed":true,"internalType":"bytes32","name":"previousAdminRole","type":"bytes32"},{"indexed":true,"internalType":"bytes32","name":"newAdminRole","type":"bytes32"}],"name":"RoleAdminChanged","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"role","type":"bytes32"},{"indexed":true,"internalType":"address","name":"account","type":"address"},{"indexed":true,"internalType":"address","name":"sender","type":"address"}],"name":"RoleGranted","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"role","type":"bytes32"},{"indexed":true,"internalType":"address","name":"account","type":"address"},{"indexed":true,"internalType":"address","name":"sender","type":"address"}],"name":"RoleRevoked","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"uint256","name":"teamId","type":"uint256"},{"indexed":false,"internalType":"string","name":"teamName","type":"string"}],"name":"TeamAdd","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"teamId","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"numberPoints","type":"uint256"},{"indexed":true,"internalType":"uint256","name":"campaignId","type":"uint256"}],"name":"TeamPointIncrease","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"userAddress","type":"address"},{"indexed":false,"internalType":"uint256","name":"oldTeamId","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"newTeamId","type":"uint256"}],"name":"UserChangeTeam","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"userAddress","type":"address"},{"indexed":false,"internalType":"uint256","name":"teamId","type":"uint256"},{"indexed":false,"internalType":"address","name":"nftAddress","type":"address"},{"indexed":false,"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"UserNew","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"userAddress","type":"address"},{"indexed":false,"internalType":"uint256","name":"teamId","type":"uint256"}],"name":"UserPause","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"userAddress","type":"address"},{"indexed":false,"internalType":"uint256","name":"numberPoints","type":"uint256"},{"indexed":true,"internalType":"uint256","name":"campaignId","type":"uint256"}],"name":"UserPointIncrease","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"address[]","name":"userAddresses","type":"address[]"},{"indexed":false,"internalType":"uint256","name":"numberPoints","type":"uint256"},{"indexed":true,"internalType":"uint256","name":"campaignId","type":"uint256"}],"name":"UserPointIncreaseMultiple","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"userAddress","type":"address"},{"indexed":false,"internalType":"uint256","name":"teamId","type":"uint256"},{"indexed":false,"internalType":"address","name":"nftAddress","type":"address"},{"indexed":false,"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"UserReactivate","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"userAddress","type":"address"},{"indexed":false,"internalType":"address","name":"nftAddress","type":"address"},{"indexed":false,"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"UserUpdate","type":"event"},{"inputs":[],"name":"DEFAULT_ADMIN_ROLE","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"NFT_ROLE","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"POINT_ROLE","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"SPECIAL_ROLE","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_nftAddress","type":"address"}],"name":"addNftAddress","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"string","name":"_teamName","type":"string"},{"internalType":"string","name":"_teamDescription","type":"string"}],"name":"addTeam","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"cakeToken","outputs":[{"internalType":"contract IBEP20","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_userAddress","type":"address"},{"internalType":"uint256","name":"_newTeamId","type":"uint256"}],"name":"changeTeam","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_amount","type":"uint256"}],"name":"claimFee","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_teamId","type":"uint256"},{"internalType":"address","name":"_nftAddress","type":"address"},{"internalType":"uint256","name":"_tokenId","type":"uint256"}],"name":"createProfile","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bytes32","name":"role","type":"bytes32"}],"name":"getRoleAdmin","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"bytes32","name":"role","type":"bytes32"},{"internalType":"uint256","name":"index","type":"uint256"}],"name":"getRoleMember","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"bytes32","name":"role","type":"bytes32"}],"name":"getRoleMemberCount","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_teamId","type":"uint256"}],"name":"getTeamProfile","outputs":[{"internalType":"string","name":"","type":"string"},{"internalType":"string","name":"","type":"string"},{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_userAddress","type":"address"}],"name":"getUserProfile","outputs":[{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"address","name":"","type":"address"},{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"bytes32","name":"role","type":"bytes32"},{"internalType":"address","name":"account","type":"address"}],"name":"grantRole","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"hasRegistered","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"bytes32","name":"role","type":"bytes32"},{"internalType":"address","name":"account","type":"address"}],"name":"hasRole","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_teamId","type":"uint256"},{"internalType":"uint256","name":"_numberPoints","type":"uint256"},{"internalType":"uint256","name":"_campaignId","type":"uint256"}],"name":"increaseTeamPoints","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_userAddress","type":"address"},{"internalType":"uint256","name":"_numberPoints","type":"uint256"},{"internalType":"uint256","name":"_campaignId","type":"uint256"}],"name":"increaseUserPoints","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address[]","name":"_userAddresses","type":"address[]"},{"internalType":"uint256","name":"_numberPoints","type":"uint256"},{"internalType":"uint256","name":"_campaignId","type":"uint256"}],"name":"increaseUserPointsMultiple","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_teamId","type":"uint256"}],"name":"makeTeamJoinable","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_teamId","type":"uint256"}],"name":"makeTeamNotJoinable","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"numberActiveProfiles","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"numberCakeToReactivate","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"numberCakeToRegister","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"numberCakeToUpdate","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"numberTeams","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"},{"internalType":"address","name":"","type":"address"},{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"bytes","name":"","type":"bytes"}],"name":"onERC721Received","outputs":[{"internalType":"bytes4","name":"","type":"bytes4"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"pauseProfile","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_nftAddress","type":"address"},{"internalType":"uint256","name":"_tokenId","type":"uint256"}],"name":"reactivateProfile","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_teamId","type":"uint256"},{"internalType":"uint256","name":"_numberPoints","type":"uint256"}],"name":"removeTeamPoints","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_userAddress","type":"address"},{"internalType":"uint256","name":"_numberPoints","type":"uint256"}],"name":"removeUserPoints","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address[]","name":"_userAddresses","type":"address[]"},{"internalType":"uint256","name":"_numberPoints","type":"uint256"}],"name":"removeUserPointsMultiple","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_teamId","type":"uint256"},{"internalType":"string","name":"_teamName","type":"string"},{"internalType":"string","name":"_teamDescription","type":"string"}],"name":"renameTeam","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bytes32","name":"role","type":"bytes32"},{"internalType":"address","name":"account","type":"address"}],"name":"renounceRole","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bytes32","name":"role","type":"bytes32"},{"internalType":"address","name":"account","type":"address"}],"name":"revokeRole","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_newNumberCakeToReactivate","type":"uint256"},{"internalType":"uint256","name":"_newNumberCakeToRegister","type":"uint256"},{"internalType":"uint256","name":"_newNumberCakeToUpdate","type":"uint256"}],"name":"updateNumberCake","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_nftAddress","type":"address"},{"internalType":"uint256","name":"_tokenId","type":"uint256"}],"name":"updateProfile","outputs":[],"stateMutability":"nonpayable","type":"function"}]');

/***/ }),

/***/ 8750:
/***/ ((module) => {

module.exports = [];

/***/ }),

/***/ 5883:
/***/ ((module) => {

module.exports = JSON.parse('[{"inputs":[{"internalType":"address","name":"_oracleAddress","type":"address"},{"internalType":"address","name":"_adminAddress","type":"address"},{"internalType":"address","name":"_operatorAddress","type":"address"},{"internalType":"uint256","name":"_intervalSeconds","type":"uint256"},{"internalType":"uint256","name":"_bufferSeconds","type":"uint256"},{"internalType":"uint256","name":"_minBetAmount","type":"uint256"},{"internalType":"uint256","name":"_oracleUpdateAllowance","type":"uint256"},{"internalType":"uint256","name":"_treasuryFee","type":"uint256"}],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"sender","type":"address"},{"indexed":true,"internalType":"uint256","name":"epoch","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"BetBear","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"sender","type":"address"},{"indexed":true,"internalType":"uint256","name":"epoch","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"BetBull","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"sender","type":"address"},{"indexed":true,"internalType":"uint256","name":"epoch","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"Claim","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"epoch","type":"uint256"},{"indexed":true,"internalType":"uint256","name":"roundId","type":"uint256"},{"indexed":false,"internalType":"int256","name":"price","type":"int256"}],"name":"EndRound","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"epoch","type":"uint256"},{"indexed":true,"internalType":"uint256","name":"roundId","type":"uint256"},{"indexed":false,"internalType":"int256","name":"price","type":"int256"}],"name":"LockRound","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"address","name":"admin","type":"address"}],"name":"NewAdminAddress","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"uint256","name":"bufferSeconds","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"intervalSeconds","type":"uint256"}],"name":"NewBufferAndIntervalSeconds","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"epoch","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"minBetAmount","type":"uint256"}],"name":"NewMinBetAmount","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"address","name":"operator","type":"address"}],"name":"NewOperatorAddress","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"address","name":"oracle","type":"address"}],"name":"NewOracle","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"uint256","name":"oracleUpdateAllowance","type":"uint256"}],"name":"NewOracleUpdateAllowance","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"epoch","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"treasuryFee","type":"uint256"}],"name":"NewTreasuryFee","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"previousOwner","type":"address"},{"indexed":true,"internalType":"address","name":"newOwner","type":"address"}],"name":"OwnershipTransferred","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"epoch","type":"uint256"}],"name":"Pause","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"address","name":"account","type":"address"}],"name":"Paused","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"epoch","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"rewardBaseCalAmount","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"rewardAmount","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"treasuryAmount","type":"uint256"}],"name":"RewardsCalculated","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"epoch","type":"uint256"}],"name":"StartRound","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"token","type":"address"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"TokenRecovery","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"TreasuryClaim","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"epoch","type":"uint256"}],"name":"Unpause","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"address","name":"account","type":"address"}],"name":"Unpaused","type":"event"},{"inputs":[],"name":"MAX_TREASURY_FEE","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"adminAddress","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"epoch","type":"uint256"}],"name":"betBear","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"uint256","name":"epoch","type":"uint256"}],"name":"betBull","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[],"name":"bufferSeconds","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256[]","name":"epochs","type":"uint256[]"}],"name":"claim","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"claimTreasury","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"epoch","type":"uint256"},{"internalType":"address","name":"user","type":"address"}],"name":"claimable","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"currentEpoch","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"executeRound","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"genesisLockOnce","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"genesisLockRound","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"genesisStartOnce","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"genesisStartRound","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"user","type":"address"},{"internalType":"uint256","name":"cursor","type":"uint256"},{"internalType":"uint256","name":"size","type":"uint256"}],"name":"getUserRounds","outputs":[{"internalType":"uint256[]","name":"","type":"uint256[]"},{"components":[{"internalType":"enum PancakePredictionV2.Position","name":"position","type":"uint8"},{"internalType":"uint256","name":"amount","type":"uint256"},{"internalType":"bool","name":"claimed","type":"bool"}],"internalType":"struct PancakePredictionV2.BetInfo[]","name":"","type":"tuple[]"},{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"user","type":"address"}],"name":"getUserRoundsLength","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"intervalSeconds","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"address","name":"","type":"address"}],"name":"ledger","outputs":[{"internalType":"enum PancakePredictionV2.Position","name":"position","type":"uint8"},{"internalType":"uint256","name":"amount","type":"uint256"},{"internalType":"bool","name":"claimed","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"minBetAmount","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"operatorAddress","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"oracle","outputs":[{"internalType":"contract AggregatorV3Interface","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"oracleLatestRoundId","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"oracleUpdateAllowance","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"pause","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"paused","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_token","type":"address"},{"internalType":"uint256","name":"_amount","type":"uint256"}],"name":"recoverToken","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"epoch","type":"uint256"},{"internalType":"address","name":"user","type":"address"}],"name":"refundable","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"renounceOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"rounds","outputs":[{"internalType":"uint256","name":"epoch","type":"uint256"},{"internalType":"uint256","name":"startTimestamp","type":"uint256"},{"internalType":"uint256","name":"lockTimestamp","type":"uint256"},{"internalType":"uint256","name":"closeTimestamp","type":"uint256"},{"internalType":"int256","name":"lockPrice","type":"int256"},{"internalType":"int256","name":"closePrice","type":"int256"},{"internalType":"uint256","name":"lockOracleId","type":"uint256"},{"internalType":"uint256","name":"closeOracleId","type":"uint256"},{"internalType":"uint256","name":"totalAmount","type":"uint256"},{"internalType":"uint256","name":"bullAmount","type":"uint256"},{"internalType":"uint256","name":"bearAmount","type":"uint256"},{"internalType":"uint256","name":"rewardBaseCalAmount","type":"uint256"},{"internalType":"uint256","name":"rewardAmount","type":"uint256"},{"internalType":"bool","name":"oracleCalled","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_adminAddress","type":"address"}],"name":"setAdmin","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_bufferSeconds","type":"uint256"},{"internalType":"uint256","name":"_intervalSeconds","type":"uint256"}],"name":"setBufferAndIntervalSeconds","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_minBetAmount","type":"uint256"}],"name":"setMinBetAmount","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_operatorAddress","type":"address"}],"name":"setOperator","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_oracle","type":"address"}],"name":"setOracle","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_oracleUpdateAllowance","type":"uint256"}],"name":"setOracleUpdateAllowance","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_treasuryFee","type":"uint256"}],"name":"setTreasuryFee","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"newOwner","type":"address"}],"name":"transferOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"treasuryAmount","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"treasuryFee","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"unpause","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"},{"internalType":"uint256","name":"","type":"uint256"}],"name":"userRounds","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"}]');

/***/ })

};
;
//# sourceMappingURL=151.js.map