"use strict";
exports.id = 432;
exports.ids = [432];
exports.modules = {

/***/ 4432:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ getTokenList)
});

// EXTERNAL MODULE: ./node_modules/@uniswap/token-lists/src/tokenlist.schema.json
var tokenlist_schema = __webpack_require__(475);
// EXTERNAL MODULE: external "ajv"
var external_ajv_ = __webpack_require__(5888);
var external_ajv_default = /*#__PURE__*/__webpack_require__.n(external_ajv_);
// EXTERNAL MODULE: external "cids"
var external_cids_ = __webpack_require__(8729);
var external_cids_default = /*#__PURE__*/__webpack_require__.n(external_cids_);
// EXTERNAL MODULE: external "multicodec"
var external_multicodec_ = __webpack_require__(6677);
// EXTERNAL MODULE: external "multihashes"
var external_multihashes_ = __webpack_require__(3735);
;// CONCATENATED MODULE: ./src/utils/contenthashToUri.ts



function hexToUint8Array(hex) {
    // eslint-disable-next-line no-param-reassign
    hex = hex.startsWith('0x') ? hex.substr(2) : hex;
    if (hex.length % 2 !== 0) throw new Error('hex must have length that is multiple of 2');
    const arr = new Uint8Array(hex.length / 2);
    for(let i = 0; i < arr.length; i++){
        arr[i] = parseInt(hex.substr(i * 2, 2), 16);
    }
    return arr;
}
const UTF_8_DECODER = new TextDecoder();
/**
 * Returns the URI representation of the content hash for supported codecs
 * @param contenthash to decode
 */ function contenthashToUri(contenthash) {
    const buff = hexToUint8Array(contenthash);
    const codec = (0,external_multicodec_.getCodec)(buff) // the typing is wrong for @types/multicodec
    ;
    switch(codec){
        case 'ipfs-ns':
            {
                const data = (0,external_multicodec_.rmPrefix)(buff);
                const cid = new (external_cids_default())(data);
                return `ipfs://${(0,external_multihashes_.toB58String)(cid.multihash)}`;
            }
        case 'ipns-ns':
            {
                const data = (0,external_multicodec_.rmPrefix)(buff);
                const cid = new (external_cids_default())(data);
                const multihash = (0,external_multihashes_.decode)(cid.multihash);
                if (multihash.name === 'identity') {
                    return `ipns://${UTF_8_DECODER.decode(multihash.digest).trim()}`;
                }
                return `ipns://${(0,external_multihashes_.toB58String)(cid.multihash)}`;
            }
        default:
            throw new Error(`Unrecognized codec: ${codec}`);
    }
};

;// CONCATENATED MODULE: ./src/utils/ENS/parseENSAddress.ts
const ENS_NAME_REGEX = /^(([a-zA-Z0-9]+(-[a-zA-Z0-9]+)*\.)+)eth(\/.*)?$/;
function parseENSAddress(ensAddress) {
    const match = ensAddress.match(ENS_NAME_REGEX);
    if (!match) return undefined;
    return {
        ensName: `${match[1].toLowerCase()}eth`,
        ensPath: match[4]
    };
}
/* harmony default export */ const ENS_parseENSAddress = ((/* unused pure expression or super */ null && (parseENSAddress)));

;// CONCATENATED MODULE: ./src/utils/uriToHttp.ts
/* eslint-disable no-case-declarations */ /**
 * Given a URI that may be ipfs, ipns, http, or https protocol, return the fetch-able http(s) URLs for the same content
 * @param uri to convert to fetch-able http url
 */ function uriToHttp(uri) {
    const protocol = uri.split(':')[0].toLowerCase();
    switch(protocol){
        case 'https':
            return [
                uri
            ];
        case 'http':
            return [
                `https${uri.substr(4)}`,
                uri
            ];
        case 'ipfs':
            const hash = uri.match(/^ipfs:(\/\/)?(.*)$/i)?.[2];
            return [
                `https://cloudflare-ipfs.com/ipfs/${hash}/`,
                `https://ipfs.io/ipfs/${hash}/`
            ];
        case 'ipns':
            const name = uri.match(/^ipns:(\/\/)?(.*)$/i)?.[2];
            return [
                `https://cloudflare-ipfs.com/ipns/${name}/`,
                `https://ipfs.io/ipns/${name}/`
            ];
        default:
            return [];
    }
};

;// CONCATENATED MODULE: ./src/utils/getTokenList.ts





const tokenListValidator = new (external_ajv_default())({
    allErrors: true
}).compile(tokenlist_schema);
/**
 * Contains the logic for resolving a list URL to a validated token list
 * @param listUrl list url
 * @param resolveENSContentHash resolves an ens name to a contenthash
 */ async function getTokenList(listUrl, resolveENSContentHash) {
    const parsedENS = parseENSAddress(listUrl);
    let urls;
    if (parsedENS) {
        let contentHashUri;
        try {
            contentHashUri = await resolveENSContentHash(parsedENS.ensName);
        } catch (error) {
            console.error(`Failed to resolve ENS name: ${parsedENS.ensName}`, error);
            throw new Error(`Failed to resolve ENS name: ${parsedENS.ensName}`);
        }
        let translatedUri;
        try {
            translatedUri = contenthashToUri(contentHashUri);
        } catch (error1) {
            console.error('Failed to translate contenthash to URI', contentHashUri);
            throw new Error(`Failed to translate contenthash to URI: ${contentHashUri}`);
        }
        urls = uriToHttp(`${translatedUri}${parsedENS.ensPath ?? ''}`);
    } else {
        urls = uriToHttp(listUrl);
    }
    for(let i = 0; i < urls.length; i++){
        const url = urls[i];
        const isLast = i === urls.length - 1;
        let response;
        try {
            response = await fetch(url);
        } catch (error2) {
            console.error('Failed to fetch list', listUrl, error2);
            if (isLast) throw new Error(`Failed to download list ${listUrl}`);
            continue;
        }
        if (!response.ok) {
            if (isLast) throw new Error(`Failed to download list ${listUrl}`);
            continue;
        }
        const json = await response.json();
        if (!tokenListValidator(json)) {
            const validationErrors = tokenListValidator.errors?.reduce((memo, error)=>{
                const add = `${error.dataPath} ${error.message ?? ''}`;
                return memo.length > 0 ? `${memo}; ${add}` : `${add}`;
            }, '') ?? 'unknown error';
            throw new Error(`Token list failed validation: ${validationErrors}`);
        }
        return json;
    }
    throw new Error('Unrecognized list URL protocol.');
};


/***/ })

};
;
//# sourceMappingURL=432.js.map