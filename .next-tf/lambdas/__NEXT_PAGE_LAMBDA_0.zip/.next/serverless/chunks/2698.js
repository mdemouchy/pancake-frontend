"use strict";
exports.id = 2698;
exports.ids = [2698];
exports.modules = {

/***/ 89969:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Oy": () => (/* reexport safe */ _pools__WEBPACK_IMPORTED_MODULE_1__.Oy),
/* harmony export */   "yi": () => (/* reexport safe */ _pools__WEBPACK_IMPORTED_MODULE_1__.yi),
/* harmony export */   "J4": () => (/* reexport safe */ _pools__WEBPACK_IMPORTED_MODULE_1__.J4),
/* harmony export */   "cR": () => (/* reexport safe */ _pools__WEBPACK_IMPORTED_MODULE_1__.cR)
/* harmony export */ });
/* harmony import */ var _farms__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(66319);
/* harmony import */ var _pools__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(13591);
/* harmony import */ var _teams__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65926);
/* harmony import */ var _block__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(93139);






/***/ }),

/***/ 24098:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(99150);
/* harmony import */ var components_Balance__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(20922);





const RecentCakeProfitBalance = ({ cakeToDisplay , dollarValueToDisplay , dateStringToDisplay ,  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_3__/* .useTranslation */ .$G)();
    const { targetRef , tooltip , tooltipVisible  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.useTooltip)(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                fontSize: "16px",
                value: cakeToDisplay,
                decimals: 3,
                bold: true,
                unit: " CAKE"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                fontSize: "16px",
                value: dollarValueToDisplay,
                decimals: 2,
                bold: true,
                prefix: "~$"
            }),
            t('Earned since your last action'),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                children: dateStringToDisplay
            })
        ]
    }), {
        placement: 'bottom-end'
    });
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            tooltipVisible && tooltip,
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.TooltipText, {
                ref: targetRef,
                small: true,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                    fontSize: "14px",
                    value: cakeToDisplay
                })
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RecentCakeProfitBalance);


/***/ }),

/***/ 14992:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(18054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99150);
/* harmony import */ var state_farms_hooks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8733);
/* harmony import */ var state_pools_hooks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1624);
/* harmony import */ var views_Pools_helpers__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(53136);
/* harmony import */ var _RecentCakeProfitBalance__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(24098);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([state_farms_hooks__WEBPACK_IMPORTED_MODULE_5__, state_pools_hooks__WEBPACK_IMPORTED_MODULE_6__]);
([state_farms_hooks__WEBPACK_IMPORTED_MODULE_5__, state_pools_hooks__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);









const RecentCakeProfitCountdownRow = ({ vaultKey  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_3__.useWeb3React)();
    const { pricePerFullShare , userData: { cakeAtLastUserAction , userShares , lastUserActionTime  } ,  } = (0,state_pools_hooks__WEBPACK_IMPORTED_MODULE_6__/* .useVaultPoolByKey */ .eB)(vaultKey);
    const cakePriceBusd = (0,state_farms_hooks__WEBPACK_IMPORTED_MODULE_5__/* .usePriceCakeBusd */ .Iu)();
    const { hasAutoEarnings , autoCakeToDisplay , autoUsdToDisplay  } = (0,views_Pools_helpers__WEBPACK_IMPORTED_MODULE_7__/* .getCakeVaultEarnings */ .UN)(account, cakeAtLastUserAction, userShares, pricePerFullShare, cakePriceBusd.toNumber());
    const lastActionInMs = lastUserActionTime && parseInt(lastUserActionTime) * 1000;
    const dateTimeLastAction = new Date(lastActionInMs);
    const dateStringToDisplay = dateTimeLastAction.toLocaleString();
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
        alignItems: "center",
        justifyContent: "space-between",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                fontSize: "14px",
                children: `${t('Recent CAKE profit')}:`
            }),
            hasAutoEarnings && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_RecentCakeProfitBalance__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                cakeToDisplay: autoCakeToDisplay,
                dollarValueToDisplay: autoUsdToDisplay,
                dateStringToDisplay: dateStringToDisplay
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RecentCakeProfitCountdownRow);

});

/***/ }),

/***/ 92199:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var utils_formatBalance__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(65044);
/* harmony import */ var state_types__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(45101);
/* harmony import */ var state_farms_hooks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8733);
/* harmony import */ var state_pools_hooks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1624);
/* harmony import */ var components_Balance__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(20922);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(99150);
/* harmony import */ var _PoolCard_Modals_NotEnoughTokensModal__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(67576);
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(53136);
/* harmony import */ var _VaultStakeModal__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1799);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_VaultStakeModal__WEBPACK_IMPORTED_MODULE_11__, _PoolCard_Modals_NotEnoughTokensModal__WEBPACK_IMPORTED_MODULE_9__, state_farms_hooks__WEBPACK_IMPORTED_MODULE_5__, state_pools_hooks__WEBPACK_IMPORTED_MODULE_6__]);
([_VaultStakeModal__WEBPACK_IMPORTED_MODULE_11__, _PoolCard_Modals_NotEnoughTokensModal__WEBPACK_IMPORTED_MODULE_9__, state_farms_hooks__WEBPACK_IMPORTED_MODULE_5__, state_pools_hooks__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);












const HasSharesActions = ({ pool , stakingTokenBalance , performanceFee  })=>{
    const { totalShares , userData: { userShares , isLoading  } , pricePerFullShare ,  } = (0,state_pools_hooks__WEBPACK_IMPORTED_MODULE_6__/* .useVaultPoolByKey */ .eB)(pool.vaultKey);
    const { stakingToken  } = pool;
    const { cakeAsBigNumber , cakeAsNumberBalance  } = (0,_helpers__WEBPACK_IMPORTED_MODULE_10__/* .convertSharesToCake */ .ur)(userShares, pricePerFullShare);
    const cakePriceBusd = (0,state_farms_hooks__WEBPACK_IMPORTED_MODULE_5__/* .usePriceCakeBusd */ .Iu)();
    const stakedDollarValue = cakePriceBusd.gt(0) ? (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_3__/* .getBalanceNumber */ .mW)(cakeAsBigNumber.multipliedBy(cakePriceBusd), stakingToken.decimals) : 0;
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_8__/* .useTranslation */ .$G)();
    const [onPresentTokenRequired] = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.useModal)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PoolCard_Modals_NotEnoughTokensModal__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
        tokenSymbol: stakingToken.symbol
    }));
    const [onPresentStake] = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.useModal)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_VaultStakeModal__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
        stakingMax: stakingTokenBalance,
        performanceFee: performanceFee,
        pool: pool
    }));
    const [onPresentUnstake] = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.useModal)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_VaultStakeModal__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
        stakingMax: cakeAsBigNumber,
        pool: pool,
        isRemovingStake: true
    }));
    const totalSharesPercentage = userShares && userShares.gt(0) && totalShares && userShares.dividedBy(totalShares).multipliedBy(100).decimalPlaces(5);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
        justifyContent: "space-between",
        alignItems: "center",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                flexDirection: "column",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        fontSize: "20px",
                        bold: true,
                        value: cakeAsNumberBalance,
                        decimals: 5
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        as: _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex,
                        fontSize: "12px",
                        color: "textSubtle",
                        flexWrap: "wrap",
                        children: [
                            cakePriceBusd.gt(0) ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                value: stakedDollarValue,
                                fontSize: "12px",
                                color: "textSubtle",
                                decimals: 2,
                                prefix: "~",
                                unit: " USD"
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Skeleton, {
                                mt: "1px",
                                height: 16,
                                width: 64
                            }),
                            !isLoading && totalSharesPercentage && pool.vaultKey === state_types__WEBPACK_IMPORTED_MODULE_4__/* .VaultKey.IfoPool */ .om.IfoPool && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                as: "span",
                                ml: "2px",
                                children: [
                                    "| ",
                                    t('%num% of total', {
                                        num: `${totalSharesPercentage.toString()}%`
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.IconButton, {
                        variant: "secondary",
                        onClick: onPresentUnstake,
                        mr: "6px",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.MinusIcon, {
                            color: "primary",
                            width: "24px"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.IconButton, {
                        variant: "secondary",
                        onClick: stakingTokenBalance.gt(0) ? onPresentStake : onPresentTokenRequired,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.AddIcon, {
                            color: "primary",
                            width: "24px",
                            height: "24px"
                        })
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HasSharesActions);

});

/***/ }),

/***/ 558:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(99150);
/* harmony import */ var _hooks_useApprove__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(86534);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_useApprove__WEBPACK_IMPORTED_MODULE_4__]);
_hooks_useApprove__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];





const VaultApprovalAction = ({ vaultKey , isLoading =false , setLastUpdated  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_3__/* .useTranslation */ .$G)();
    const { handleApprove , requestedApproval  } = (0,_hooks_useApprove__WEBPACK_IMPORTED_MODULE_4__/* .useVaultApprove */ .Le)(vaultKey, setLastUpdated);
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: isLoading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Skeleton, {
            width: "100%",
            height: "52px"
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
            isLoading: requestedApproval,
            endIcon: requestedApproval ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.AutoRenewIcon, {
                spin: true,
                color: "currentColor"
            }) : null,
            disabled: requestedApproval,
            onClick: handleApprove,
            width: "100%",
            children: t('Enable')
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (VaultApprovalAction);

});

/***/ }),

/***/ 60757:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(99150);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _PoolCard_Modals_NotEnoughTokensModal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(67576);
/* harmony import */ var _VaultStakeModal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1799);
/* harmony import */ var _HasSharesActions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(92199);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_HasSharesActions__WEBPACK_IMPORTED_MODULE_6__, _VaultStakeModal__WEBPACK_IMPORTED_MODULE_5__, _PoolCard_Modals_NotEnoughTokensModal__WEBPACK_IMPORTED_MODULE_4__]);
([_HasSharesActions__WEBPACK_IMPORTED_MODULE_6__, _VaultStakeModal__WEBPACK_IMPORTED_MODULE_5__, _PoolCard_Modals_NotEnoughTokensModal__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);







const VaultStakeActions = ({ pool , stakingTokenBalance , accountHasSharesStaked , performanceFee , isLoading =false ,  })=>{
    const { stakingToken  } = pool;
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_2__/* .useTranslation */ .$G)();
    const [onPresentTokenRequired] = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.useModal)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PoolCard_Modals_NotEnoughTokensModal__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
        tokenSymbol: stakingToken.symbol
    }));
    const [onPresentStake] = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.useModal)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_VaultStakeModal__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
        stakingMax: stakingTokenBalance,
        pool: pool,
        performanceFee: performanceFee
    }));
    const renderStakeAction = ()=>{
        return accountHasSharesStaked ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_HasSharesActions__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
            pool: pool,
            stakingTokenBalance: stakingTokenBalance,
            performanceFee: performanceFee
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Button, {
            onClick: stakingTokenBalance.gt(0) ? onPresentStake : onPresentTokenRequired,
            children: t('Stake')
        });
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Flex, {
        flexDirection: "column",
        children: isLoading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Skeleton, {
            width: "100%",
            height: "52px"
        }) : renderStakeAction()
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (VaultStakeActions);

});

/***/ }),

/***/ 1716:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "z": () => (/* binding */ IfoVaultCardAvgBalance),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(34215);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(bignumber_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_Balance__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(20922);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(99150);
/* harmony import */ var state_types__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(45101);
/* harmony import */ var utils_bigNumber__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(35128);
/* harmony import */ var state_pools_hooks__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1624);
/* harmony import */ var components_QuestionHelper__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(45061);
/* harmony import */ var components_Layout_Flex__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(40508);
/* harmony import */ var hooks_useBUSDPrice__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(90834);
/* harmony import */ var utils_formatBalance__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(65044);
/* harmony import */ var _VaultApprovalAction__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(558);
/* harmony import */ var _VaultStakeActions__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(60757);
/* harmony import */ var _hooks_useApprove__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(86534);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_VaultApprovalAction__WEBPACK_IMPORTED_MODULE_14__, _VaultStakeActions__WEBPACK_IMPORTED_MODULE_15__, _hooks_useApprove__WEBPACK_IMPORTED_MODULE_16__, hooks_useBUSDPrice__WEBPACK_IMPORTED_MODULE_12__, state_pools_hooks__WEBPACK_IMPORTED_MODULE_9__]);
([_VaultApprovalAction__WEBPACK_IMPORTED_MODULE_14__, _VaultStakeActions__WEBPACK_IMPORTED_MODULE_15__, _hooks_useApprove__WEBPACK_IMPORTED_MODULE_16__, hooks_useBUSDPrice__WEBPACK_IMPORTED_MODULE_12__, state_pools_hooks__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);

















const InlineText = styled_components__WEBPACK_IMPORTED_MODULE_4___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Text).withConfig({
    componentId: "sc-544d7aaa-0"
})`
  display: inline;
`;
const IfoVaultCardAvgBalance = ()=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_6__/* .useTranslation */ .$G)();
    const credit = (0,state_pools_hooks__WEBPACK_IMPORTED_MODULE_9__/* .useIfoPoolCredit */ .Eo)();
    const cakeAsNumberBalance = (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_13__/* .getBalanceNumber */ .mW)(credit);
    const creditsDollarValue = (0,hooks_useBUSDPrice__WEBPACK_IMPORTED_MODULE_12__/* .useBUSDCakeAmount */ .Tx)(cakeAsNumberBalance);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(components_Layout_Flex__WEBPACK_IMPORTED_MODULE_11__/* .FlexGap */ .O, {
                gap: "4px",
                alignItems: "center",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(InlineText, {
                        color: "secondary",
                        textTransform: "uppercase",
                        bold: true,
                        fontSize: "12px",
                        children: t('IFO Credit')
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_QuestionHelper__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                        size: "24px",
                        placement: "auto",
                        display: "inline",
                        text: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Text, {
                                    children: t('Your entry limit in the next IFO sale is determined by your IFO credit. This is calculated by the average CAKE balance of the principal amount in the IFO pool during the last credit calculation period.')
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Text, {
                                    children: t('Please note: even the pool is auto compounding. Amount of profits will not be included during IFO credit calculations.')
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Flex, {
                flexDirection: "column",
                pb: "16px",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        fontSize: "20px",
                        bold: true,
                        value: cakeAsNumberBalance,
                        decimals: 5
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Text, {
                        fontSize: "12px",
                        color: "textSubtle",
                        display: "flex",
                        children: creditsDollarValue !== undefined ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                            value: creditsDollarValue,
                            fontSize: "12px",
                            color: "textSubtle",
                            decimals: 2,
                            prefix: "~",
                            unit: " USD"
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Skeleton, {
                            mt: "1px",
                            height: 16,
                            width: 64
                        })
                    })
                ]
            })
        ]
    }));
};
const CakeVaultCardActions = ({ pool , accountHasSharesStaked , isLoading , performanceFee  })=>{
    const { stakingToken , userData  } = pool;
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_6__/* .useTranslation */ .$G)();
    const stakingTokenBalance = userData?.stakingTokenBalance ? new (bignumber_js__WEBPACK_IMPORTED_MODULE_1___default())(userData.stakingTokenBalance) : utils_bigNumber__WEBPACK_IMPORTED_MODULE_8__/* .BIG_ZERO */ .HW;
    const { isVaultApproved , setLastUpdated  } = (0,_hooks_useApprove__WEBPACK_IMPORTED_MODULE_16__/* .useCheckVaultApprovalStatus */ .dI)(pool.vaultKey);
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Flex, {
        flexDirection: "column",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Flex, {
            flexDirection: "column",
            children: [
                isVaultApproved && pool.vaultKey === state_types__WEBPACK_IMPORTED_MODULE_7__/* .VaultKey.IfoPool */ .om.IfoPool && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(IfoVaultCardAvgBalance, {}),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Box, {
                    display: "inline",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(InlineText, {
                            color: accountHasSharesStaked ? 'secondary' : 'textSubtle',
                            textTransform: "uppercase",
                            bold: true,
                            fontSize: "12px",
                            children: [
                                accountHasSharesStaked ? stakingToken.symbol : t('Stake'),
                                ' '
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(InlineText, {
                            color: accountHasSharesStaked ? 'textSubtle' : 'secondary',
                            textTransform: "uppercase",
                            bold: true,
                            fontSize: "12px",
                            children: accountHasSharesStaked ? t('Staked (compounding)') : `${stakingToken.symbol}`
                        })
                    ]
                }),
                isVaultApproved ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_VaultStakeActions__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                    isLoading: isLoading,
                    pool: pool,
                    stakingTokenBalance: stakingTokenBalance,
                    accountHasSharesStaked: accountHasSharesStaked,
                    performanceFee: performanceFee
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_VaultApprovalAction__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                    vaultKey: pool.vaultKey,
                    isLoading: isLoading,
                    setLastUpdated: setLastUpdated
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CakeVaultCardActions);

});

/***/ }),

/***/ 70061:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "K": () => (/* binding */ CreditCalcBlock),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99150);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(18054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var components_ConnectWalletButton__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(30621);
/* harmony import */ var state_pools_hooks__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1624);
/* harmony import */ var state_types__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(45101);
/* harmony import */ var views_Pools_helpers__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(53136);
/* harmony import */ var components_Layout_Flex__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(40508);
/* harmony import */ var config_constants_pools__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(71080);
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(38328);
/* harmony import */ var _PoolCard_AprRow__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(3779);
/* harmony import */ var _PoolCard_StyledCard__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(12020);
/* harmony import */ var _PoolCard_CardFooter__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(73322);
/* harmony import */ var _PoolCard_PoolCardHeader__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(68624);
/* harmony import */ var _VaultCardActions__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(1716);
/* harmony import */ var _UnstakingFeeCountdownRow__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(59116);
/* harmony import */ var _RecentCakeProfitRow__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(14992);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_PoolCard_CardFooter__WEBPACK_IMPORTED_MODULE_15__, _VaultCardActions__WEBPACK_IMPORTED_MODULE_17__, _UnstakingFeeCountdownRow__WEBPACK_IMPORTED_MODULE_18__, _RecentCakeProfitRow__WEBPACK_IMPORTED_MODULE_19__, state_pools_hooks__WEBPACK_IMPORTED_MODULE_7__]);
([_PoolCard_CardFooter__WEBPACK_IMPORTED_MODULE_15__, _VaultCardActions__WEBPACK_IMPORTED_MODULE_17__, _UnstakingFeeCountdownRow__WEBPACK_IMPORTED_MODULE_18__, _RecentCakeProfitRow__WEBPACK_IMPORTED_MODULE_19__, state_pools_hooks__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);




















const StyledCardBody = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.CardBody).withConfig({
    componentId: "sc-dad1eec0-0"
})`
  min-height: ${({ isLoading  })=>isLoading ? '0' : '254px'
};
`;
const CreditCalcBlock = ()=>{
    const { creditStartBlock , creditEndBlock , hasEndBlockOver  } = (0,state_pools_hooks__WEBPACK_IMPORTED_MODULE_7__/* .useIfoPoolCreditBlock */ .Ab)();
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    const { tooltip , tooltipVisible , targetRef  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.useTooltip)(hasEndBlockOver ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                children: t('The latest credit calculation period has ended. After the coming IFO, credits will be reset and the calculation will resume.')
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.LinkExternal, {
                href: "https://twitter.com/pancakeswap",
                children: t('Follow us on Twitter to catch the latest news about the coming IFO.')
            })
        ]
    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                children: t('The start block of the current calculation period. Your average IFO CAKE Pool staking balance is calculated throughout this period.')
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.LinkExternal, {
                href: "https://medium.com/pancakeswap/initial-farm-offering-ifo-3-0-ifo-staking-pool-622d8bd356f1",
                children: t('Check out our Medium article for more details.')
            })
        ]
    }), {
        placement: 'auto'
    });
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
        mt: "8px",
        justifyContent: "space-between",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                fontSize: "14px",
                children: hasEndBlockOver ? t('Credit calculation ended:') : t('Credit calculation starts:')
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                mr: "6px",
                alignItems: "center",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Link, {
                        external: true,
                        href: (0,utils__WEBPACK_IMPORTED_MODULE_12__/* .getBscScanLink */ .s6)(hasEndBlockOver ? creditEndBlock : creditStartBlock, 'block'),
                        mr: "4px",
                        color: hasEndBlockOver ? 'warning' : 'primary',
                        fontSize: "14px",
                        children: hasEndBlockOver ? creditEndBlock : creditStartBlock
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        ref: targetRef,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.HelpIcon, {
                            color: "textSubtle"
                        })
                    })
                ]
            }),
            tooltipVisible && tooltip
        ]
    }));
};
const CakeVaultCard = ({ pool , showStakedOnly , defaultFooterExpanded , ...props })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_5__.useWeb3React)();
    const { userData: { userShares , isLoading: isVaultUserDataLoading  } , fees: { performanceFeeAsDecimal  } , pricePerFullShare ,  } = (0,state_pools_hooks__WEBPACK_IMPORTED_MODULE_7__/* .useVaultPoolByKey */ .eB)(pool.vaultKey);
    const { cakeAsBigNumber  } = (0,views_Pools_helpers__WEBPACK_IMPORTED_MODULE_9__/* .convertSharesToCake */ .ur)(userShares, pricePerFullShare);
    const accountHasSharesStaked = userShares && userShares.gt(0);
    const isLoading = !pool.userData || isVaultUserDataLoading;
    if (showStakedOnly && !accountHasSharesStaked) {
        return null;
    }
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_PoolCard_StyledCard__WEBPACK_IMPORTED_MODULE_14__/* .StyledCard */ .r, {
        isActive: true,
        ...props,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_PoolCard_PoolCardHeader__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                isStaking: accountHasSharesStaked,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PoolCard_PoolCardHeader__WEBPACK_IMPORTED_MODULE_16__/* .PoolCardHeaderTitle */ .e, {
                        title: t(config_constants_pools__WEBPACK_IMPORTED_MODULE_11__/* .vaultPoolConfig */ .Y[pool.vaultKey].name),
                        subTitle: t(config_constants_pools__WEBPACK_IMPORTED_MODULE_11__/* .vaultPoolConfig */ .Y[pool.vaultKey].description)
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.TokenPairImage, {
                        ...config_constants_pools__WEBPACK_IMPORTED_MODULE_11__/* .vaultPoolConfig */ .Y[pool.vaultKey].tokenImage,
                        width: 64,
                        height: 64
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(StyledCardBody, {
                isLoading: isLoading,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PoolCard_AprRow__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                        pool: pool,
                        stakedBalance: cakeAsBigNumber,
                        performanceFee: performanceFeeAsDecimal
                    }),
                    pool.vaultKey === state_types__WEBPACK_IMPORTED_MODULE_8__/* .VaultKey.IfoPool */ .om.IfoPool && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CreditCalcBlock, {}),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(components_Layout_Flex__WEBPACK_IMPORTED_MODULE_10__/* .FlexGap */ .O, {
                        mt: "16px",
                        gap: "24px",
                        flexDirection: accountHasSharesStaked ? 'column-reverse' : 'column',
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Box, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Box, {
                                        mt: "24px",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_RecentCakeProfitRow__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z, {
                                            vaultKey: pool.vaultKey
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Box, {
                                        mt: "8px",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UnstakingFeeCountdownRow__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {
                                            vaultKey: pool.vaultKey
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                                flexDirection: "column",
                                children: account ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_VaultCardActions__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                                    pool: pool,
                                    accountHasSharesStaked: accountHasSharesStaked,
                                    isLoading: isLoading,
                                    performanceFee: performanceFeeAsDecimal
                                }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                            mb: "10px",
                                            textTransform: "uppercase",
                                            fontSize: "12px",
                                            color: "textSubtle",
                                            bold: true,
                                            children: t('Start earning')
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_ConnectWalletButton__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
                                    ]
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PoolCard_CardFooter__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                defaultExpanded: defaultFooterExpanded,
                pool: pool,
                account: account
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CakeVaultCard);

});

/***/ }),

/***/ 3779:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99150);
/* harmony import */ var components_Balance__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(20922);
/* harmony import */ var components_RoiCalculatorModal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(46414);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(34215);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(bignumber_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var utils_bigNumber__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(35128);
/* harmony import */ var config_constants_pools__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(71080);










const ApyLabelContainer = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex).withConfig({
    componentId: "sc-bdb1049d-0"
})`
  cursor: pointer;

  &:hover {
    opacity: 0.5;
  }
`;
const AprRow = ({ pool , stakedBalance , performanceFee =0  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    const { stakingToken , earningToken , isFinished , apr , rawApr , earningTokenPrice , stakingTokenPrice , userData , vaultKey ,  } = pool;
    const stakingTokenBalance = userData?.stakingTokenBalance ? new (bignumber_js__WEBPACK_IMPORTED_MODULE_7___default())(userData.stakingTokenBalance) : utils_bigNumber__WEBPACK_IMPORTED_MODULE_8__/* .BIG_ZERO */ .HW;
    const tooltipContent = vaultKey ? t('APY includes compounding, APR doesn’t. This pool’s CAKE is compounded automatically, so we show APY.') : t('This pool’s rewards aren’t compounded automatically, so we show APR');
    const { targetRef , tooltip , tooltipVisible  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.useTooltip)(tooltipContent, {
        placement: 'bottom-start'
    });
    const apyModalLink = stakingToken.address ? `/swap?outputCurrency=${stakingToken.address}` : '/swap';
    const [onPresentApyModal] = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.useModal)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_RoiCalculatorModal__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
        earningTokenPrice: earningTokenPrice,
        stakingTokenPrice: stakingTokenPrice,
        apr: vaultKey ? rawApr : apr,
        linkLabel: t('Get %symbol%', {
            symbol: stakingToken.symbol
        }),
        linkHref: apyModalLink,
        stakingTokenBalance: stakedBalance.plus(stakingTokenBalance),
        stakingTokenSymbol: stakingToken.symbol,
        earningTokenSymbol: earningToken.symbol,
        autoCompoundFrequency: config_constants_pools__WEBPACK_IMPORTED_MODULE_9__/* .vaultPoolConfig */ .Y[vaultKey]?.autoCompoundFrequency ?? 0,
        performanceFee: performanceFee
    }));
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
        alignItems: "center",
        justifyContent: "space-between",
        children: [
            tooltipVisible && tooltip,
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.TooltipText, {
                ref: targetRef,
                children: vaultKey ? `${t('APY')}:` : `${t('APR')}:`
            }),
            apr || isFinished ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ApyLabelContainer, {
                alignItems: "center",
                onClick: onPresentApyModal,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        fontSize: "16px",
                        isDisabled: isFinished,
                        value: isFinished ? 0 : apr,
                        decimals: 2,
                        unit: "%",
                        onClick: onPresentApyModal
                    }),
                    !isFinished && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.IconButton, {
                        variant: "text",
                        scale: "sm",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.CalculateIcon, {
                            color: "textSubtle",
                            width: "18px"
                        })
                    })
                ]
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Skeleton, {
                width: "82px",
                height: "32px"
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AprRow);


/***/ }),

/***/ 88524:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(34215);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(bignumber_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var utils_formatBalance__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(65044);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(99150);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var config__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(33206);
/* harmony import */ var state_block_hooks__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(37063);
/* harmony import */ var state_pools_hooks__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1624);
/* harmony import */ var utils_addressHelpers__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(55878);
/* harmony import */ var utils_wallet__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(49058);
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(38328);
/* harmony import */ var components_Balance__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(20922);
/* harmony import */ var views_Pools_helpers__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(53136);
/* harmony import */ var utils_bigNumber__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(35128);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([state_pools_hooks__WEBPACK_IMPORTED_MODULE_9__, state_block_hooks__WEBPACK_IMPORTED_MODULE_8__]);
([state_pools_hooks__WEBPACK_IMPORTED_MODULE_9__, state_block_hooks__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);
















const ExpandedWrapper = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Flex).withConfig({
    componentId: "sc-7c7f36c-0"
})`
  svg {
    height: 14px;
    width: 14px;
  }
`;
const ExpandedFooter = ({ pool , account  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_5__/* .useTranslation */ .$G)();
    const currentBlock = (0,state_block_hooks__WEBPACK_IMPORTED_MODULE_8__/* .useCurrentBlock */ .je)();
    const { stakingToken , earningToken , totalStaked , startBlock , endBlock , stakingLimit , contractAddress , sousId , vaultKey ,  } = pool;
    const { totalCakeInVault , fees: { performanceFee  } ,  } = (0,state_pools_hooks__WEBPACK_IMPORTED_MODULE_9__/* .useVaultPoolByKey */ .eB)(vaultKey);
    const vaultPools = (0,state_pools_hooks__WEBPACK_IMPORTED_MODULE_9__/* .useVaultPools */ .KV)();
    const cakeInVaults = Object.values(vaultPools).reduce((total, vault)=>{
        return total.plus(vault.totalCakeInVault);
    }, utils_bigNumber__WEBPACK_IMPORTED_MODULE_15__/* .BIG_ZERO */ .HW);
    const tokenAddress = earningToken.address || '';
    const poolContractAddress = (0,utils_addressHelpers__WEBPACK_IMPORTED_MODULE_10__/* .getAddress */ .Kn)(contractAddress);
    const cakeVaultContractAddress = (0,utils_addressHelpers__WEBPACK_IMPORTED_MODULE_10__/* .getVaultPoolAddress */ .ZX)(vaultKey);
    const isMetaMaskInScope = !!window.ethereum?.isMetaMask;
    const isManualCakePool = sousId === 0;
    const { shouldShowBlockCountdown , blocksUntilStart , blocksRemaining , hasPoolStarted , blocksToDisplay  } = (0,views_Pools_helpers__WEBPACK_IMPORTED_MODULE_14__/* .getPoolBlockInfo */ .zy)(pool, currentBlock);
    const { targetRef , tooltip , tooltipVisible  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.useTooltip)(t('Subtracted automatically from each yield harvest and burned.'), {
        placement: 'bottom-start'
    });
    const getTotalStakedBalance = ()=>{
        if (vaultKey) {
            return (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_4__/* .getBalanceNumber */ .mW)(totalCakeInVault, stakingToken.decimals);
        }
        if (isManualCakePool) {
            const manualCakeTotalMinusAutoVault = new (bignumber_js__WEBPACK_IMPORTED_MODULE_2___default())(totalStaked).minus(cakeInVaults);
            return (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_4__/* .getBalanceNumber */ .mW)(manualCakeTotalMinusAutoVault, stakingToken.decimals);
        }
        return (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_4__/* .getBalanceNumber */ .mW)(totalStaked, stakingToken.decimals);
    };
    const { targetRef: totalStakedTargetRef , tooltip: totalStakedTooltip , tooltipVisible: totalStakedTooltipVisible ,  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.useTooltip)(t('Total amount of %symbol% staked in this pool', {
        symbol: stakingToken.symbol
    }), {
        placement: 'bottom'
    });
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ExpandedWrapper, {
        flexDirection: "column",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Flex, {
                mb: "2px",
                justifyContent: "space-between",
                alignItems: "center",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Text, {
                        small: true,
                        children: [
                            t('Total staked'),
                            ":"
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Flex, {
                        alignItems: "flex-start",
                        children: [
                            totalStaked && totalStaked.gte(0) ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                        small: true,
                                        value: getTotalStakedBalance(),
                                        decimals: 0,
                                        unit: ` ${stakingToken.symbol}`
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        ref: totalStakedTargetRef,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.HelpIcon, {
                                            color: "textSubtle",
                                            width: "20px",
                                            ml: "6px",
                                            mt: "4px"
                                        })
                                    })
                                ]
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Skeleton, {
                                width: "90px",
                                height: "21px"
                            }),
                            totalStakedTooltipVisible && totalStakedTooltip
                        ]
                    })
                ]
            }),
            stakingLimit && stakingLimit.gt(0) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Flex, {
                mb: "2px",
                justifyContent: "space-between",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Text, {
                        small: true,
                        children: [
                            t('Max. stake per user'),
                            ":"
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Text, {
                        small: true,
                        children: `${(0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_4__/* .getFullDisplayBalance */ .NJ)(stakingLimit, stakingToken.decimals, 0)} ${stakingToken.symbol}`
                    })
                ]
            }),
            shouldShowBlockCountdown && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Flex, {
                mb: "2px",
                justifyContent: "space-between",
                alignItems: "center",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Text, {
                        small: true,
                        children: [
                            hasPoolStarted ? t('Ends in') : t('Starts in'),
                            ":"
                        ]
                    }),
                    blocksRemaining || blocksUntilStart ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Flex, {
                        alignItems: "center",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Link, {
                            external: true,
                            href: (0,utils__WEBPACK_IMPORTED_MODULE_12__/* .getBscScanLink */ .s6)(hasPoolStarted ? endBlock : startBlock, 'countdown'),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                    small: true,
                                    value: blocksToDisplay,
                                    decimals: 0,
                                    color: "primary"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Text, {
                                    small: true,
                                    ml: "4px",
                                    color: "primary",
                                    textTransform: "lowercase",
                                    children: t('Blocks')
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.TimerIcon, {
                                    ml: "4px",
                                    color: "primary"
                                })
                            ]
                        })
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Skeleton, {
                        width: "54px",
                        height: "21px"
                    })
                ]
            }),
            vaultKey && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Flex, {
                mb: "2px",
                justifyContent: "space-between",
                alignItems: "center",
                children: [
                    tooltipVisible && tooltip,
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.TooltipText, {
                        ref: targetRef,
                        small: true,
                        children: t('Performance Fee')
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Flex, {
                        alignItems: "center",
                        children: performanceFee ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Text, {
                            ml: "4px",
                            small: true,
                            children: [
                                performanceFee / 100,
                                "%"
                            ]
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Skeleton, {
                            width: "90px",
                            height: "21px"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Flex, {
                mb: "2px",
                justifyContent: "flex-end",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.LinkExternal, {
                    href: `/info/token/${earningToken.address}`,
                    bold: false,
                    small: true,
                    children: t('See Token Info')
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Flex, {
                mb: "2px",
                justifyContent: "flex-end",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.LinkExternal, {
                    href: earningToken.projectLink,
                    bold: false,
                    small: true,
                    children: t('View Project Site')
                })
            }),
            poolContractAddress && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Flex, {
                mb: "2px",
                justifyContent: "flex-end",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.LinkExternal, {
                    href: `${config__WEBPACK_IMPORTED_MODULE_7__/* .BASE_BSC_SCAN_URL */ .OS}/address/${vaultKey ? cakeVaultContractAddress : poolContractAddress}`,
                    bold: false,
                    small: true,
                    children: t('View Contract')
                })
            }),
            account && isMetaMaskInScope && tokenAddress && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Flex, {
                justifyContent: "flex-end",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Button, {
                    variant: "text",
                    p: "0",
                    height: "auto",
                    onClick: ()=>(0,utils_wallet__WEBPACK_IMPORTED_MODULE_11__/* .registerToken */ .$)(tokenAddress, earningToken.symbol, earningToken.decimals)
                    ,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Text, {
                            color: "primary",
                            fontSize: "14px",
                            children: t('Add to Metamask')
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.MetamaskIcon, {
                            ml: "4px"
                        })
                    ]
                })
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(ExpandedFooter));

});

/***/ }),

/***/ 73322:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(99150);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var components_Tags__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(69160);
/* harmony import */ var _ExpandedFooter__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(88524);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_ExpandedFooter__WEBPACK_IMPORTED_MODULE_6__]);
_ExpandedFooter__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];







const ExpandableButtonWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Flex).withConfig({
    componentId: "sc-59f2d8a4-0"
})`
  align-items: center;
  justify-content: space-between;
  button {
    padding: 0;
  }
`;
const Footer = ({ pool , account , defaultExpanded  })=>{
    const { vaultKey  } = pool;
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_3__/* .useTranslation */ .$G)();
    const { 0: isExpanded , 1: setIsExpanded  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(defaultExpanded || false);
    const manualTooltipText = t('You must harvest and compound your earnings from this pool manually.');
    const autoTooltipText = t('Any funds you stake in this pool will be automagically harvested and restaked (compounded) for you.');
    const { targetRef , tooltip , tooltipVisible  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.useTooltip)(vaultKey ? autoTooltipText : manualTooltipText, {
        placement: 'bottom'
    });
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.CardFooter, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ExpandableButtonWrapper, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Flex, {
                        alignItems: "center",
                        children: [
                            vaultKey ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Tags__WEBPACK_IMPORTED_MODULE_5__/* .CompoundingPoolTag */ .yd, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Tags__WEBPACK_IMPORTED_MODULE_5__/* .ManualPoolTag */ .EM, {}),
                            tooltipVisible && tooltip,
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Flex, {
                                ref: targetRef,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.HelpIcon, {
                                    ml: "4px",
                                    width: "20px",
                                    height: "20px",
                                    color: "textSubtle"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.ExpandableLabel, {
                        expanded: isExpanded,
                        onClick: ()=>setIsExpanded(!isExpanded)
                        ,
                        children: isExpanded ? t('Hide') : t('Details')
                    })
                ]
            }),
            isExpanded && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ExpandedFooter__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                pool: pool,
                account: account
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footer);

});

/***/ }),

/***/ 67576:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(99150);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var hooks_useTheme__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(23917);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks_useTheme__WEBPACK_IMPORTED_MODULE_5__]);
hooks_useTheme__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];






const StyledLink = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Link).withConfig({
    componentId: "sc-9fbd5cee-0"
})`
  width: 100%;
`;
const NotEnoughTokensModal = ({ tokenSymbol , onDismiss  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_2__/* .useTranslation */ .$G)();
    const { theme  } = (0,hooks_useTheme__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)();
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Modal, {
        title: t('%symbol% required', {
            symbol: tokenSymbol
        }),
        onDismiss: onDismiss,
        headerBackground: theme.colors.gradients.cardHeader,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                color: "failure",
                bold: true,
                children: t('Insufficient %symbol% balance', {
                    symbol: tokenSymbol
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                mt: "24px",
                children: t('You’ll need %symbol% to stake in this pool!', {
                    symbol: tokenSymbol
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                children: t('Buy some %symbol%, or make sure your %symbol% isn’t in another pool or LP.', {
                    symbol: tokenSymbol
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Button, {
                mt: "24px",
                as: "a",
                external: true,
                href: "/swap",
                children: [
                    t('Buy'),
                    " ",
                    tokenSymbol
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledLink, {
                href: "https://yieldwatch.net",
                external: true,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Button, {
                    variant: "secondary",
                    mt: "8px",
                    width: "100%",
                    children: [
                        t('Locate Assets'),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.OpenNewIcon, {
                            color: "primary",
                            ml: "4px"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Button, {
                variant: "text",
                onClick: onDismiss,
                children: t('Close Window')
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NotEnoughTokensModal);

});

/***/ }),

/***/ 68928:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);




const StyledButton = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Button).withConfig({
    componentId: "sc-8e59765f-0"
})`
  flex-grow: 1;
`;
const PercentageButton = ({ children , onClick  })=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledButton, {
        scale: "xs",
        mx: "2px",
        p: "4px 16px",
        variant: "tertiary",
        onClick: onClick,
        children: children
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PercentageButton);


/***/ }),

/***/ 54231:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99150);
/* harmony import */ var hooks_useTheme__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(23917);
/* harmony import */ var hooks_useToast__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(789);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(34215);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(bignumber_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var components_RoiCalculatorModal__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(46414);
/* harmony import */ var components_Toast__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(63937);
/* harmony import */ var utils_formatBalance__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(65044);
/* harmony import */ var utils_compoundApyHelpers__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(16395);
/* harmony import */ var utils_sentry__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(17226);
/* harmony import */ var _PercentageButton__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(68928);
/* harmony import */ var _hooks_useStakePool__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(2930);
/* harmony import */ var _hooks_useUnstakePool__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(77806);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks_useTheme__WEBPACK_IMPORTED_MODULE_5__]);
hooks_useTheme__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];
















const StyledLink = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Link).withConfig({
    componentId: "sc-e68eef3d-0"
})`
  width: 100%;
`;
const AnnualRoiContainer = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex).withConfig({
    componentId: "sc-e68eef3d-1"
})`
  cursor: pointer;
`;
const AnnualRoiDisplay = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text).withConfig({
    componentId: "sc-e68eef3d-2"
})`
  width: 72px;
  max-width: 72px;
  overflow: hidden;
  text-align: right;
  text-overflow: ellipsis;
`;
const StakeModal = ({ isBnbPool , pool , stakingTokenBalance , stakingTokenPrice , isRemovingStake =false , onDismiss ,  })=>{
    const { sousId , stakingToken , earningTokenPrice , apr , userData , stakingLimit , earningToken  } = pool;
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    const { theme  } = (0,hooks_useTheme__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)();
    const { onStake  } = (0,_hooks_useStakePool__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z)(sousId, isBnbPool);
    const { onUnstake  } = (0,_hooks_useUnstakePool__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z)(sousId, pool.enableEmergencyWithdraw);
    const { toastSuccess , toastError  } = (0,hooks_useToast__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)();
    const { 0: pendingTx , 1: setPendingTx  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: stakeAmount , 1: setStakeAmount  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const { 0: hasReachedStakeLimit , 1: setHasReachedStakedLimit  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: percent , 1: setPercent  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const { 0: showRoiCalculator , 1: setShowRoiCalculator  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const getCalculatedStakingLimit = ()=>{
        if (isRemovingStake) {
            return userData.stakedBalance;
        }
        return stakingLimit.gt(0) && stakingTokenBalance.gt(stakingLimit) ? stakingLimit : stakingTokenBalance;
    };
    const fullDecimalStakeAmount = (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_10__/* .getDecimalAmount */ .Qe)(new (bignumber_js__WEBPACK_IMPORTED_MODULE_7___default())(stakeAmount), stakingToken.decimals);
    const userNotEnoughToken = isRemovingStake ? userData.stakedBalance.lt(fullDecimalStakeAmount) : userData.stakingTokenBalance.lt(fullDecimalStakeAmount);
    const usdValueStaked = new (bignumber_js__WEBPACK_IMPORTED_MODULE_7___default())(stakeAmount).times(stakingTokenPrice);
    const formattedUsdValueStaked = !usdValueStaked.isNaN() && (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_10__/* .formatNumber */ .uf)(usdValueStaked.toNumber());
    const interestBreakdown = (0,utils_compoundApyHelpers__WEBPACK_IMPORTED_MODULE_15__/* .getInterestBreakdown */ .A1)({
        principalInUSD: !usdValueStaked.isNaN() ? usdValueStaked.toNumber() : 0,
        apr,
        earningTokenPrice
    });
    const annualRoi = interestBreakdown[3] * pool.earningTokenPrice;
    const formattedAnnualRoi = (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_10__/* .formatNumber */ .uf)(annualRoi, annualRoi > 10000 ? 0 : 2, annualRoi > 10000 ? 0 : 2);
    const getTokenLink = stakingToken.address ? `/swap?outputCurrency=${stakingToken.address}` : '/swap';
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (stakingLimit.gt(0) && !isRemovingStake) {
            setHasReachedStakedLimit(fullDecimalStakeAmount.plus(userData.stakedBalance).gt(stakingLimit));
        }
    }, [
        stakeAmount,
        stakingLimit,
        userData,
        stakingToken,
        isRemovingStake,
        setHasReachedStakedLimit,
        fullDecimalStakeAmount, 
    ]);
    const handleStakeInputChange = (input)=>{
        if (input) {
            const convertedInput = (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_10__/* .getDecimalAmount */ .Qe)(new (bignumber_js__WEBPACK_IMPORTED_MODULE_7___default())(input), stakingToken.decimals);
            const percentage = Math.floor(convertedInput.dividedBy(getCalculatedStakingLimit()).multipliedBy(100).toNumber());
            setPercent(Math.min(percentage, 100));
        } else {
            setPercent(0);
        }
        setStakeAmount(input);
    };
    const handleChangePercent = (sliderPercent)=>{
        if (sliderPercent > 0) {
            const percentageOfStakingMax = getCalculatedStakingLimit().dividedBy(100).multipliedBy(sliderPercent);
            const amountToStake = (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_10__/* .getFullDisplayBalance */ .NJ)(percentageOfStakingMax, stakingToken.decimals, stakingToken.decimals);
            setStakeAmount(amountToStake);
        } else {
            setStakeAmount('');
        }
        setPercent(sliderPercent);
    };
    const handleConfirmClick = async ()=>{
        setPendingTx(true);
        try {
            if (isRemovingStake) {
                // unstaking
                await onUnstake(stakeAmount, stakingToken.decimals, (tx)=>{
                    toastSuccess(`${t('Transaction Submitted')}!`, /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_9__/* .ToastDescriptionWithTx */ .YO, {
                        txHash: tx.hash
                    }));
                }, (receipt)=>{
                    toastSuccess(`${t('Unstaked')}!`, /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_9__/* .ToastDescriptionWithTx */ .YO, {
                        txHash: receipt.transactionHash,
                        children: t('Your %symbol% earnings have also been harvested to your wallet!', {
                            symbol: earningToken.symbol
                        })
                    }));
                }, (receipt)=>{
                    toastError(t('Error'), /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_9__/* .ToastDescriptionWithTx */ .YO, {
                        txHash: receipt.transactionHash,
                        children: t('Please try again. Confirm the transaction and make sure you are paying enough gas!')
                    }));
                });
            } else {
                // staking
                await onStake(stakeAmount, stakingToken.decimals, (tx)=>{
                    toastSuccess(`${t('Transaction Submitted')}!`, /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_9__/* .ToastDescriptionWithTx */ .YO, {
                        txHash: tx.hash
                    }));
                }, (receipt)=>{
                    toastSuccess(`${t('Staked')}!`, /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_9__/* .ToastDescriptionWithTx */ .YO, {
                        txHash: receipt.transactionHash,
                        children: t('Your %symbol% funds have been staked in the pool!', {
                            symbol: stakingToken.symbol
                        })
                    }));
                }, (receipt)=>{
                    toastError(t('Error'), /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_9__/* .ToastDescriptionWithTx */ .YO, {
                        txHash: receipt.transactionHash,
                        children: t('Please try again. Confirm the transaction and make sure you are paying enough gas!')
                    }));
                });
            }
            setPendingTx(false);
            onDismiss();
        } catch (e) {
            (0,utils_sentry__WEBPACK_IMPORTED_MODULE_11__/* .logError */ .H)(e);
            toastError(t('Error'), t('Please try again. Confirm the transaction and make sure you are paying enough gas!'));
            setPendingTx(false);
        }
    };
    if (showRoiCalculator) {
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_RoiCalculatorModal__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
            earningTokenPrice: earningTokenPrice,
            stakingTokenPrice: stakingTokenPrice,
            apr: apr,
            linkLabel: t('Get %symbol%', {
                symbol: stakingToken.symbol
            }),
            linkHref: getTokenLink,
            stakingTokenBalance: userData.stakedBalance.plus(stakingTokenBalance),
            stakingTokenSymbol: stakingToken.symbol,
            earningTokenSymbol: earningToken.symbol,
            onBack: ()=>setShowRoiCalculator(false)
            ,
            initialValue: stakeAmount
        }));
    }
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Modal, {
        minWidth: "346px",
        title: isRemovingStake ? t('Unstake') : t('Stake in Pool'),
        onDismiss: onDismiss,
        headerBackground: theme.colors.gradients.cardHeader,
        children: [
            stakingLimit.gt(0) && !isRemovingStake && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                color: "secondary",
                bold: true,
                mb: "24px",
                style: {
                    textAlign: 'center'
                },
                fontSize: "16px",
                children: t('Max stake for this pool: %amount% %token%', {
                    amount: (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_10__/* .getFullDisplayBalance */ .NJ)(stakingLimit, stakingToken.decimals, 0),
                    token: stakingToken.symbol
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                alignItems: "center",
                justifyContent: "space-between",
                mb: "8px",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                        bold: true,
                        children: [
                            isRemovingStake ? t('Unstake') : t('Stake'),
                            ":"
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                        alignItems: "center",
                        minWidth: "70px",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Image, {
                                src: `/images/tokens/${stakingToken.address}.png`,
                                width: 24,
                                height: 24,
                                alt: stakingToken.symbol
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                ml: "4px",
                                bold: true,
                                children: stakingToken.symbol
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.BalanceInput, {
                value: stakeAmount,
                onUserInput: handleStakeInputChange,
                currencyValue: stakingTokenPrice !== 0 && `~${formattedUsdValueStaked || 0} USD`,
                isWarning: hasReachedStakeLimit || userNotEnoughToken,
                decimals: stakingToken.decimals
            }),
            hasReachedStakeLimit && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                color: "failure",
                fontSize: "12px",
                style: {
                    textAlign: 'right'
                },
                mt: "4px",
                children: t('Maximum total stake: %amount% %token%', {
                    amount: (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_10__/* .getFullDisplayBalance */ .NJ)(new (bignumber_js__WEBPACK_IMPORTED_MODULE_7___default())(stakingLimit), stakingToken.decimals, 0),
                    token: stakingToken.symbol
                })
            }),
            userNotEnoughToken && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                color: "failure",
                fontSize: "12px",
                style: {
                    textAlign: 'right'
                },
                mt: "4px",
                children: t('Insufficient %symbol% balance', {
                    symbol: stakingToken.symbol
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                ml: "auto",
                color: "textSubtle",
                fontSize: "12px",
                mb: "8px",
                children: t('Balance: %balance%', {
                    balance: (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_10__/* .getFullDisplayBalance */ .NJ)(getCalculatedStakingLimit(), stakingToken.decimals)
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Slider, {
                min: 0,
                max: 100,
                value: percent,
                onValueChanged: handleChangePercent,
                name: "stake",
                valueLabel: `${percent}%`,
                step: 1
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                alignItems: "center",
                justifyContent: "space-between",
                mt: "8px",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PercentageButton__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                        onClick: ()=>handleChangePercent(25)
                        ,
                        children: "25%"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PercentageButton__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                        onClick: ()=>handleChangePercent(50)
                        ,
                        children: "50%"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PercentageButton__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                        onClick: ()=>handleChangePercent(75)
                        ,
                        children: "75%"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PercentageButton__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                        onClick: ()=>handleChangePercent(100)
                        ,
                        children: t('Max')
                    })
                ]
            }),
            !isRemovingStake && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                mt: "24px",
                alignItems: "center",
                justifyContent: "space-between",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                        mr: "8px",
                        color: "textSubtle",
                        children: [
                            t('Annual ROI at current rates'),
                            ":"
                        ]
                    }),
                    Number.isFinite(annualRoi) ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(AnnualRoiContainer, {
                        alignItems: "center",
                        onClick: ()=>{
                            setShowRoiCalculator(true);
                        },
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(AnnualRoiDisplay, {
                                children: [
                                    "$",
                                    formattedAnnualRoi
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.IconButton, {
                                variant: "text",
                                scale: "sm",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.CalculateIcon, {
                                    color: "textSubtle",
                                    width: "18px"
                                })
                            })
                        ]
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Skeleton, {
                        width: 60
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Button, {
                isLoading: pendingTx,
                endIcon: pendingTx ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.AutoRenewIcon, {
                    spin: true,
                    color: "currentColor"
                }) : null,
                onClick: handleConfirmClick,
                disabled: !stakeAmount || parseFloat(stakeAmount) === 0 || hasReachedStakeLimit || userNotEnoughToken,
                mt: "24px",
                children: pendingTx ? t('Confirming') : t('Confirm')
            }),
            !isRemovingStake && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledLink, {
                external: true,
                href: getTokenLink,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Button, {
                    width: "100%",
                    mt: "8px",
                    variant: "secondary",
                    children: t('Get %symbol%', {
                        symbol: stakingToken.symbol
                    })
                })
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (StakeModal);

});

/***/ }),

/***/ 68624:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "e": () => (/* binding */ PoolCardHeaderTitle),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);




const Wrapper = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.CardHeader).withConfig({
    componentId: "sc-1f488775-0"
})`
  background: ${({ isFinished , background , theme  })=>isFinished ? theme.colors.backgroundDisabled : theme.colors.gradients[background]
};
  border-radius: ${({ theme  })=>`${theme.radii.card} ${theme.radii.card} 0 0`
};
`;
const PoolCardHeader = ({ isFinished =false , isStaking =false , children  })=>{
    const background = isStaking ? 'bubblegum' : 'cardHeader';
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Wrapper, {
        isFinished: isFinished,
        background: background,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Flex, {
            alignItems: "center",
            justifyContent: "space-between",
            children: children
        })
    }));
};
const PoolCardHeaderTitle = ({ isFinished , title , subTitle ,  })=>{
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Flex, {
        flexDirection: "column",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Heading, {
                color: isFinished ? 'textDisabled' : 'body',
                scale: "lg",
                children: title
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Text, {
                fontSize: "14px",
                color: isFinished ? 'textDisabled' : 'textSubtle',
                children: subTitle
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PoolCardHeader);


/***/ }),

/***/ 12020:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "r": () => (/* binding */ StyledCard)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__);


const StyledCard = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Card).withConfig({
    componentId: "sc-d6e2e347-0"
})`
  max-width: 352px;
  margin: 0 8px 24px;
  width: 100%;
  min-width: 300px;
  display: flex;
  flex-direction: column;
  align-self: baseline;
  position: relative;
  color: ${({ isFinished , theme  })=>theme.colors[isFinished ? 'textDisabled' : 'secondary']
};

  ${({ theme  })=>theme.mediaQueries.sm
} {
    margin: 0 12px 46px;
  }
`;
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (StyledCard)));


/***/ }),

/***/ 86437:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(34215);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(bignumber_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var components_ConnectWalletButton__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(30621);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(18054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var state_pools_hooks__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1624);
/* harmony import */ var components_Balance__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(20922);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(99150);
/* harmony import */ var utils_formatBalance__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(65044);
/* harmony import */ var config_constants_types__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(97971);
/* harmony import */ var utils_bigNumber__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(35128);
/* harmony import */ var hooks_useContract__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(46063);
/* harmony import */ var views_Pools_helpers__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(53136);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(4985);
/* harmony import */ var _PoolCard_Modals_NotEnoughTokensModal__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(67576);
/* harmony import */ var _PoolCard_Modals_StakeModal__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(54231);
/* harmony import */ var _CakeVaultCard_VaultStakeModal__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(1799);
/* harmony import */ var _hooks_useApprove__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(86534);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_CakeVaultCard_VaultStakeModal__WEBPACK_IMPORTED_MODULE_18__, _PoolCard_Modals_StakeModal__WEBPACK_IMPORTED_MODULE_17__, _PoolCard_Modals_NotEnoughTokensModal__WEBPACK_IMPORTED_MODULE_16__, state_pools_hooks__WEBPACK_IMPORTED_MODULE_7__, _hooks_useApprove__WEBPACK_IMPORTED_MODULE_19__]);
([_CakeVaultCard_VaultStakeModal__WEBPACK_IMPORTED_MODULE_18__, _PoolCard_Modals_StakeModal__WEBPACK_IMPORTED_MODULE_17__, _PoolCard_Modals_NotEnoughTokensModal__WEBPACK_IMPORTED_MODULE_16__, state_pools_hooks__WEBPACK_IMPORTED_MODULE_7__, _hooks_useApprove__WEBPACK_IMPORTED_MODULE_19__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);




















const IconButtonWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-c735da80-0"
})`
  display: flex;
`;
const Staked = ({ pool , userDataLoaded  })=>{
    const { sousId , stakingToken , earningToken , stakingLimit , isFinished , poolCategory , userData , stakingTokenPrice , vaultKey ,  } = pool;
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_9__/* .useTranslation */ .$G)();
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_6__.useWeb3React)();
    const stakingTokenContract = (0,hooks_useContract__WEBPACK_IMPORTED_MODULE_13__/* .useERC20 */ .X_)(stakingToken.address || '');
    const { handleApprove: handlePoolApprove , requestedApproval: requestedPoolApproval  } = (0,_hooks_useApprove__WEBPACK_IMPORTED_MODULE_19__/* .useApprovePool */ .iB)(stakingTokenContract, sousId, earningToken.symbol);
    const { isVaultApproved , setLastUpdated  } = (0,_hooks_useApprove__WEBPACK_IMPORTED_MODULE_19__/* .useCheckVaultApprovalStatus */ .dI)(pool.vaultKey);
    const { handleApprove: handleVaultApprove , requestedApproval: requestedVaultApproval  } = (0,_hooks_useApprove__WEBPACK_IMPORTED_MODULE_19__/* .useVaultApprove */ .Le)(pool.vaultKey, setLastUpdated);
    const handleApprove = vaultKey ? handleVaultApprove : handlePoolApprove;
    const requestedApproval = vaultKey ? requestedVaultApproval : requestedPoolApproval;
    const isBnbPool = poolCategory === config_constants_types__WEBPACK_IMPORTED_MODULE_11__/* .PoolCategory.BINANCE */ .jh.BINANCE;
    const allowance = userData?.allowance ? new (bignumber_js__WEBPACK_IMPORTED_MODULE_3___default())(userData.allowance) : utils_bigNumber__WEBPACK_IMPORTED_MODULE_12__/* .BIG_ZERO */ .HW;
    const stakedBalance = userData?.stakedBalance ? new (bignumber_js__WEBPACK_IMPORTED_MODULE_3___default())(userData.stakedBalance) : utils_bigNumber__WEBPACK_IMPORTED_MODULE_12__/* .BIG_ZERO */ .HW;
    const isNotVaultAndHasStake = !vaultKey && stakedBalance.gt(0);
    const stakingTokenBalance = userData?.stakingTokenBalance ? new (bignumber_js__WEBPACK_IMPORTED_MODULE_3___default())(userData.stakingTokenBalance) : utils_bigNumber__WEBPACK_IMPORTED_MODULE_12__/* .BIG_ZERO */ .HW;
    const stakedTokenBalance = (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_10__/* .getBalanceNumber */ .mW)(stakedBalance, stakingToken.decimals);
    const stakedTokenDollarBalance = (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_10__/* .getBalanceNumber */ .mW)(stakedBalance.multipliedBy(stakingTokenPrice), stakingToken.decimals);
    const { userData: { userShares  } , pricePerFullShare ,  } = (0,state_pools_hooks__WEBPACK_IMPORTED_MODULE_7__/* .useVaultPoolByKey */ .eB)(pool.vaultKey);
    const { cakeAsBigNumber , cakeAsNumberBalance  } = (0,views_Pools_helpers__WEBPACK_IMPORTED_MODULE_14__/* .convertSharesToCake */ .ur)(userShares, pricePerFullShare);
    const hasSharesStaked = userShares && userShares.gt(0);
    const isVaultWithShares = vaultKey && hasSharesStaked;
    const stakedAutoDollarValue = (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_10__/* .getBalanceNumber */ .mW)(cakeAsBigNumber.multipliedBy(stakingTokenPrice), stakingToken.decimals);
    const needsApproval = vaultKey ? !isVaultApproved : !allowance.gt(0) && !isBnbPool;
    const [onPresentTokenRequired] = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.useModal)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PoolCard_Modals_NotEnoughTokensModal__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
        tokenSymbol: stakingToken.symbol
    }));
    const [onPresentStake] = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.useModal)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PoolCard_Modals_StakeModal__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
        isBnbPool: isBnbPool,
        pool: pool,
        stakingTokenBalance: stakingTokenBalance,
        stakingTokenPrice: stakingTokenPrice
    }));
    const [onPresentVaultStake] = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.useModal)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CakeVaultCard_VaultStakeModal__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {
        stakingMax: stakingTokenBalance,
        pool: pool
    }));
    const [onPresentUnstake] = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.useModal)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PoolCard_Modals_StakeModal__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
        stakingTokenBalance: stakingTokenBalance,
        isBnbPool: isBnbPool,
        pool: pool,
        stakingTokenPrice: stakingTokenPrice,
        isRemovingStake: true
    }));
    const [onPresentVaultUnstake] = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.useModal)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CakeVaultCard_VaultStakeModal__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {
        stakingMax: cakeAsBigNumber,
        pool: pool,
        isRemovingStake: true
    }));
    const onStake = ()=>{
        if (vaultKey) {
            onPresentVaultStake();
        } else {
            onPresentStake();
        }
    };
    const onUnstake = ()=>{
        if (vaultKey) {
            onPresentVaultUnstake();
        } else {
            onPresentUnstake();
        }
    };
    const { targetRef , tooltip , tooltipVisible  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.useTooltip)(t("You've already staked the maximum amount you can stake in this pool!"), {
        placement: 'bottom'
    });
    const reachStakingLimit = stakingLimit.gt(0) && userData.stakedBalance.gte(stakingLimit);
    if (!account) {
        return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styles__WEBPACK_IMPORTED_MODULE_15__/* .ActionContainer */ .sX, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styles__WEBPACK_IMPORTED_MODULE_15__/* .ActionTitles */ .Ad, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                        fontSize: "12px",
                        bold: true,
                        color: "textSubtle",
                        as: "span",
                        textTransform: "uppercase",
                        children: t('Start staking')
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styles__WEBPACK_IMPORTED_MODULE_15__/* .ActionContent */ .O6, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_ConnectWalletButton__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        width: "100%"
                    })
                })
            ]
        }));
    }
    if (!userDataLoaded) {
        return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styles__WEBPACK_IMPORTED_MODULE_15__/* .ActionContainer */ .sX, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styles__WEBPACK_IMPORTED_MODULE_15__/* .ActionTitles */ .Ad, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                        fontSize: "12px",
                        bold: true,
                        color: "textSubtle",
                        as: "span",
                        textTransform: "uppercase",
                        children: t('Start staking')
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styles__WEBPACK_IMPORTED_MODULE_15__/* .ActionContent */ .O6, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Skeleton, {
                        width: 180,
                        height: "32px",
                        marginTop: 14
                    })
                })
            ]
        }));
    }
    if (needsApproval) {
        return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styles__WEBPACK_IMPORTED_MODULE_15__/* .ActionContainer */ .sX, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styles__WEBPACK_IMPORTED_MODULE_15__/* .ActionTitles */ .Ad, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                        fontSize: "12px",
                        bold: true,
                        color: "textSubtle",
                        as: "span",
                        textTransform: "uppercase",
                        children: t('Enable pool')
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styles__WEBPACK_IMPORTED_MODULE_15__/* .ActionContent */ .O6, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Button, {
                        width: "100%",
                        disabled: requestedApproval,
                        onClick: handleApprove,
                        variant: "secondary",
                        children: t('Enable')
                    })
                })
            ]
        }));
    }
    // Wallet connected, user data loaded and approved
    if (isNotVaultAndHasStake || isVaultWithShares) {
        return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styles__WEBPACK_IMPORTED_MODULE_15__/* .ActionContainer */ .sX, {
            isAutoVault: !!vaultKey,
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styles__WEBPACK_IMPORTED_MODULE_15__/* .ActionTitles */ .Ad, {
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                            fontSize: "12px",
                            bold: true,
                            color: "secondary",
                            as: "span",
                            textTransform: "uppercase",
                            children: [
                                stakingToken.symbol,
                                ' '
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                            fontSize: "12px",
                            bold: true,
                            color: "textSubtle",
                            as: "span",
                            textTransform: "uppercase",
                            children: vaultKey ? t('Staked (compounding)') : t('Staked')
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styles__WEBPACK_IMPORTED_MODULE_15__/* .ActionContent */ .O6, {
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Flex, {
                            flex: "1",
                            pt: "16px",
                            flexDirection: "column",
                            alignSelf: "flex-start",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                    lineHeight: "1",
                                    bold: true,
                                    fontSize: "20px",
                                    decimals: 5,
                                    value: vaultKey ? cakeAsNumberBalance : stakedTokenBalance
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                    fontSize: "12px",
                                    display: "inline",
                                    color: "textSubtle",
                                    decimals: 2,
                                    value: vaultKey ? stakedAutoDollarValue : stakedTokenDollarBalance,
                                    unit: " USD",
                                    prefix: "~"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(IconButtonWrapper, {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.IconButton, {
                                    variant: "secondary",
                                    onClick: onUnstake,
                                    mr: "6px",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.MinusIcon, {
                                        color: "primary",
                                        width: "14px"
                                    })
                                }),
                                reachStakingLimit ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    ref: targetRef,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.IconButton, {
                                        variant: "secondary",
                                        disabled: true,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.AddIcon, {
                                            color: "textDisabled",
                                            width: "24px",
                                            height: "24px"
                                        })
                                    })
                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.IconButton, {
                                    variant: "secondary",
                                    onClick: stakingTokenBalance.gt(0) ? onStake : onPresentTokenRequired,
                                    disabled: isFinished,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.AddIcon, {
                                        color: "primary",
                                        width: "14px"
                                    })
                                })
                            ]
                        }),
                        tooltipVisible && tooltip
                    ]
                })
            ]
        }));
    }
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styles__WEBPACK_IMPORTED_MODULE_15__/* .ActionContainer */ .sX, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styles__WEBPACK_IMPORTED_MODULE_15__/* .ActionTitles */ .Ad, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                        fontSize: "12px",
                        bold: true,
                        color: "secondary",
                        as: "span",
                        textTransform: "uppercase",
                        children: [
                            t('Stake'),
                            ' '
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                        fontSize: "12px",
                        bold: true,
                        color: "textSubtle",
                        as: "span",
                        textTransform: "uppercase",
                        children: stakingToken.symbol
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styles__WEBPACK_IMPORTED_MODULE_15__/* .ActionContent */ .O6, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Button, {
                    width: "100%",
                    onClick: stakingTokenBalance.gt(0) ? onStake : onPresentTokenRequired,
                    variant: "secondary",
                    disabled: isFinished,
                    children: t('Stake')
                })
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Staked);

});

/***/ }),

/***/ 4985:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "sX": () => (/* binding */ ActionContainer),
/* harmony export */   "Ad": () => (/* binding */ ActionTitles),
/* harmony export */   "O6": () => (/* binding */ ActionContent)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const ActionContainer = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
    componentId: "sc-47420aea-0"
})`
  padding: 16px;
  border: 2px solid ${({ theme  })=>theme.colors.input
};
  border-radius: 16px;
  flex-grow: 1;
  flex-basis: 0;
  margin-bottom: 16px;

  ${({ theme  })=>theme.mediaQueries.sm
} {
    margin-left: 12px;
    margin-right: 12px;
    margin-bottom: 0;
    height: ${({ isAutoVault  })=>isAutoVault ? '130px' : 'auto'
};
  }
}

  ${({ theme  })=>theme.mediaQueries.xl
} {
    margin-left: 32px;
    margin-right: 0;
  }
`;
const ActionTitles = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
    componentId: "sc-47420aea-1"
})`
  font-weight: 600;
  font-size: 12px;
`;
const ActionContent = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
    componentId: "sc-47420aea-2"
})`
  display: flex;
  justify-content: space-between;
  align-items: center;
`;


/***/ }),

/***/ 86534:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "iB": () => (/* binding */ useApprovePool),
/* harmony export */   "Le": () => (/* binding */ useVaultApprove),
/* harmony export */   "dI": () => (/* binding */ useCheckVaultApprovalStatus)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(18054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ethersproject_constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(26644);
/* harmony import */ var _ethersproject_constants__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_constants__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var state__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(82727);
/* harmony import */ var state_actions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(89969);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(99150);
/* harmony import */ var hooks_useContract__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(46063);
/* harmony import */ var hooks_useToast__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(789);
/* harmony import */ var hooks_useCallWithGasPrice__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(71228);
/* harmony import */ var components_Toast__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(63937);
/* harmony import */ var utils_sentry__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(17226);
/* harmony import */ var hooks_useSWRContract__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(38472);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks_useSWRContract__WEBPACK_IMPORTED_MODULE_12__, hooks_useCallWithGasPrice__WEBPACK_IMPORTED_MODULE_9__]);
([hooks_useSWRContract__WEBPACK_IMPORTED_MODULE_12__, hooks_useCallWithGasPrice__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);













const useApprovePool = (lpContract, sousId, earningTokenSymbol)=>{
    const { 0: requestedApproval , 1: setRequestedApproval  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { toastSuccess , toastError  } = (0,hooks_useToast__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
    const { callWithGasPrice  } = (0,hooks_useCallWithGasPrice__WEBPACK_IMPORTED_MODULE_9__/* .useCallWithGasPrice */ .d)();
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_6__/* .useTranslation */ .$G)();
    const dispatch = (0,state__WEBPACK_IMPORTED_MODULE_4__/* .useAppDispatch */ .TL)();
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_2__.useWeb3React)();
    const sousChefContract = (0,hooks_useContract__WEBPACK_IMPORTED_MODULE_7__/* .useSousChef */ .AP)(sousId);
    const handleApprove = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(async ()=>{
        try {
            setRequestedApproval(true);
            const tx = await callWithGasPrice(lpContract, 'approve', [
                sousChefContract.address,
                _ethersproject_constants__WEBPACK_IMPORTED_MODULE_3__.MaxUint256
            ]);
            toastSuccess(`${t('Transaction Submitted')}!`, /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_10__/* .ToastDescriptionWithTx */ .YO, {
                txHash: tx.hash
            }));
            const receipt = await tx.wait();
            dispatch((0,state_actions__WEBPACK_IMPORTED_MODULE_5__/* .updateUserAllowance */ .Oy)(sousId, account));
            if (receipt.status) {
                toastSuccess(t('Contract Enabled'), /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_10__/* .ToastDescriptionWithTx */ .YO, {
                    txHash: receipt.transactionHash,
                    children: t('You can now stake in the %symbol% pool!', {
                        symbol: earningTokenSymbol
                    })
                }));
                setRequestedApproval(false);
            } else {
                // user rejected tx or didn't go thru
                toastError(t('Error'), t('Please try again. Confirm the transaction and make sure you are paying enough gas!'));
                setRequestedApproval(false);
            }
        } catch (e) {
            (0,utils_sentry__WEBPACK_IMPORTED_MODULE_11__/* .logError */ .H)(e);
            toastError(t('Error'), t('Please try again. Confirm the transaction and make sure you are paying enough gas!'));
        }
    }, [
        account,
        dispatch,
        lpContract,
        sousChefContract,
        sousId,
        earningTokenSymbol,
        t,
        toastError,
        toastSuccess,
        callWithGasPrice, 
    ]);
    return {
        handleApprove,
        requestedApproval
    };
};
// Approve CAKE auto pool
const useVaultApprove = (vaultKey, setLastUpdated)=>{
    const { 0: requestedApproval , 1: setRequestedApproval  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_6__/* .useTranslation */ .$G)();
    const { toastSuccess , toastError  } = (0,hooks_useToast__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
    const vaultPoolContract = (0,hooks_useContract__WEBPACK_IMPORTED_MODULE_7__/* .useVaultPoolContract */ .Ak)(vaultKey);
    const { callWithGasPrice  } = (0,hooks_useCallWithGasPrice__WEBPACK_IMPORTED_MODULE_9__/* .useCallWithGasPrice */ .d)();
    const cakeContract = (0,hooks_useContract__WEBPACK_IMPORTED_MODULE_7__/* .useCake */ .kL)();
    const handleApprove = async ()=>{
        const tx = await callWithGasPrice(cakeContract, 'approve', [
            vaultPoolContract.address,
            _ethersproject_constants__WEBPACK_IMPORTED_MODULE_3__.MaxUint256
        ]);
        toastSuccess(`${t('Transaction Submitted')}!`, /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_10__/* .ToastDescriptionWithTx */ .YO, {
            txHash: tx.hash
        }));
        setRequestedApproval(true);
        const receipt = await tx.wait();
        if (receipt.status) {
            toastSuccess(t('Contract Enabled'), /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_10__/* .ToastDescriptionWithTx */ .YO, {
                txHash: receipt.transactionHash,
                children: t('You can now stake in the %symbol% vault!', {
                    symbol: 'CAKE'
                })
            }));
            setLastUpdated();
            setRequestedApproval(false);
        } else {
            toastError(t('Error'), t('Please try again. Confirm the transaction and make sure you are paying enough gas!'));
            setRequestedApproval(false);
        }
    };
    return {
        handleApprove,
        requestedApproval
    };
};
const useCheckVaultApprovalStatus = (vaultKey)=>{
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_2__.useWeb3React)();
    const cakeContract = (0,hooks_useContract__WEBPACK_IMPORTED_MODULE_7__/* .useCake */ .kL)();
    const vaultPoolContract = (0,hooks_useContract__WEBPACK_IMPORTED_MODULE_7__/* .useVaultPoolContract */ .Ak)(vaultKey);
    const key = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>account ? {
            contract: cakeContract,
            methodName: 'allowance',
            params: [
                account,
                vaultPoolContract.address
            ]
        } : null
    , [
        account,
        cakeContract,
        vaultPoolContract.address
    ]);
    const { data , mutate  } = (0,hooks_useSWRContract__WEBPACK_IMPORTED_MODULE_12__/* .useSWRContract */ .Av)(key);
    return {
        isVaultApproved: data ? data.gt(0) : false,
        setLastUpdated: mutate
    };
};

});

/***/ }),

/***/ 2930:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var state__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(82727);
/* harmony import */ var state_actions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(89969);
/* harmony import */ var utils_calls__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(50059);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(34215);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(bignumber_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var config__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(33206);
/* harmony import */ var utils_bigNumber__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(35128);
/* harmony import */ var hooks_useContract__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(46063);
/* harmony import */ var utils_getGasPrice__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(76582);










const options = {
    gasLimit: config__WEBPACK_IMPORTED_MODULE_6__/* .DEFAULT_GAS_LIMIT */ .QL
};
const sousStake = async (sousChefContract, amount, decimals = 18)=>{
    const gasPrice = (0,utils_getGasPrice__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)();
    return sousChefContract.deposit(new (bignumber_js__WEBPACK_IMPORTED_MODULE_5___default())(amount).times(utils_bigNumber__WEBPACK_IMPORTED_MODULE_7__/* .BIG_TEN.pow */ .xp.pow(decimals)).toString(), {
        ...options,
        gasPrice
    });
};
const sousStakeBnb = async (sousChefContract, amount)=>{
    const gasPrice = (0,utils_getGasPrice__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)();
    return sousChefContract.deposit(new (bignumber_js__WEBPACK_IMPORTED_MODULE_5___default())(amount).times(config__WEBPACK_IMPORTED_MODULE_6__/* .DEFAULT_TOKEN_DECIMAL */ .o3).toString(), {
        ...options,
        gasPrice
    });
};
const useStakePool = (sousId, isUsingBnb = false)=>{
    const dispatch = (0,state__WEBPACK_IMPORTED_MODULE_2__/* .useAppDispatch */ .TL)();
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_1__.useWeb3React)();
    const masterChefContract = (0,hooks_useContract__WEBPACK_IMPORTED_MODULE_8__/* .useMasterchef */ .y8)();
    const sousChefContract = (0,hooks_useContract__WEBPACK_IMPORTED_MODULE_8__/* .useSousChef */ .AP)(sousId);
    const handleStake = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async (amount, decimals, onTransactionSubmitted, onSuccess, onError)=>{
        let tx;
        if (sousId === 0) {
            tx = await (0,utils_calls__WEBPACK_IMPORTED_MODULE_4__/* .stakeFarm */ .AQ)(masterChefContract, 0, amount);
        } else if (isUsingBnb) {
            tx = await sousStakeBnb(sousChefContract, amount);
        } else {
            tx = await sousStake(sousChefContract, amount, decimals);
        }
        onTransactionSubmitted(tx);
        const receipt = await tx.wait();
        if (receipt.status) {
            onSuccess(receipt);
            dispatch((0,state_actions__WEBPACK_IMPORTED_MODULE_3__/* .updateUserStakedBalance */ .cR)(sousId, account));
            dispatch((0,state_actions__WEBPACK_IMPORTED_MODULE_3__/* .updateUserBalance */ .yi)(sousId, account));
        } else {
            onError(receipt);
        }
    }, [
        account,
        dispatch,
        isUsingBnb,
        masterChefContract,
        sousChefContract,
        sousId
    ]);
    return {
        onStake: handleStake
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useStakePool);


/***/ }),

/***/ 77806:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ethersproject_units__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(93138);
/* harmony import */ var _ethersproject_units__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_units__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var state__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(82727);
/* harmony import */ var state_actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(89969);
/* harmony import */ var utils_calls__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(50059);
/* harmony import */ var hooks_useContract__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(46063);
/* harmony import */ var utils_getGasPrice__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(76582);








const sousUnstake = (sousChefContract, amount, decimals)=>{
    const gasPrice = (0,utils_getGasPrice__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
    const units = (0,_ethersproject_units__WEBPACK_IMPORTED_MODULE_2__.parseUnits)(amount, decimals);
    return sousChefContract.withdraw(units.toString(), {
        gasPrice
    });
};
const sousEmergencyUnstake = (sousChefContract)=>{
    const gasPrice = (0,utils_getGasPrice__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
    return sousChefContract.emergencyWithdraw({
        gasPrice
    });
};
const useUnstakePool = (sousId, enableEmergencyWithdraw = false)=>{
    const dispatch = (0,state__WEBPACK_IMPORTED_MODULE_3__/* .useAppDispatch */ .TL)();
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_1__.useWeb3React)();
    const masterChefContract = (0,hooks_useContract__WEBPACK_IMPORTED_MODULE_6__/* .useMasterchef */ .y8)();
    const sousChefContract = (0,hooks_useContract__WEBPACK_IMPORTED_MODULE_6__/* .useSousChef */ .AP)(sousId);
    const handleUnstake = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async (amount, decimals, onTransactionSubmitted, onSuccess, onError)=>{
        let tx;
        if (sousId === 0) {
            tx = await (0,utils_calls__WEBPACK_IMPORTED_MODULE_5__/* .unstakeFarm */ .dU)(masterChefContract, 0, amount);
        } else if (enableEmergencyWithdraw) {
            tx = await sousEmergencyUnstake(sousChefContract);
        } else {
            tx = await sousUnstake(sousChefContract, amount, decimals);
        }
        onTransactionSubmitted(tx);
        const receipt = await tx.wait();
        if (receipt.status) {
            onSuccess(receipt);
            dispatch((0,state_actions__WEBPACK_IMPORTED_MODULE_4__/* .updateUserStakedBalance */ .cR)(sousId, account));
            dispatch((0,state_actions__WEBPACK_IMPORTED_MODULE_4__/* .updateUserBalance */ .yi)(sousId, account));
            dispatch((0,state_actions__WEBPACK_IMPORTED_MODULE_4__/* .updateUserPendingReward */ .J4)(sousId, account));
        } else {
            onError(receipt);
        }
    }, [
        account,
        dispatch,
        enableEmergencyWithdraw,
        masterChefContract,
        sousChefContract,
        sousId
    ]);
    return {
        onUnstake: handleUnstake
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useUnstakePool);


/***/ })

};
;
//# sourceMappingURL=2698.js.map