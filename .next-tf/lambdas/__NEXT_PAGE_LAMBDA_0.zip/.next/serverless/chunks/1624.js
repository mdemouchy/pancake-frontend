"use strict";
exports.id = 1624;
exports.ids = [1624];
exports.modules = {

/***/ 1624:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DM": () => (/* binding */ useFetchPublicPoolsData),
/* harmony export */   "ad": () => (/* binding */ useFetchUserPools),
/* harmony export */   "Oh": () => (/* binding */ usePools),
/* harmony export */   "wx": () => (/* binding */ useFetchCakeVault),
/* harmony export */   "HV": () => (/* binding */ useFetchIfoPool),
/* harmony export */   "Xo": () => (/* binding */ useCakeVault),
/* harmony export */   "KV": () => (/* binding */ useVaultPools),
/* harmony export */   "eB": () => (/* binding */ useVaultPoolByKey),
/* harmony export */   "IK": () => (/* binding */ useIfoPoolVault),
/* harmony export */   "Ab": () => (/* binding */ useIfoPoolCreditBlock),
/* harmony export */   "Eo": () => (/* binding */ useIfoPoolCredit),
/* harmony export */   "ix": () => (/* binding */ useIfoWithApr)
/* harmony export */ });
/* unused harmony export usePool */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(34215);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(bignumber_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(18054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var state__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(82727);
/* harmony import */ var utils_bigNumber__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(35128);
/* harmony import */ var views_Pools_helpers__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(53136);
/* harmony import */ var hooks_useRefreshEffect__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(27892);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(13591);
/* harmony import */ var _types__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(45101);
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(89713);
/* harmony import */ var _farms__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(66319);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks_useRefreshEffect__WEBPACK_IMPORTED_MODULE_7__]);
hooks_useRefreshEffect__WEBPACK_IMPORTED_MODULE_7__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];












const useFetchPublicPoolsData = ()=>{
    const dispatch = (0,state__WEBPACK_IMPORTED_MODULE_4__/* .useAppDispatch */ .TL)();
    (0,hooks_useRefreshEffect__WEBPACK_IMPORTED_MODULE_7__/* .useSlowRefreshEffect */ .X)(()=>{
        const fetchPoolsDataWithFarms = async ()=>{
            const activeFarms = _farms__WEBPACK_IMPORTED_MODULE_11__/* .nonArchivedFarms.filter */ .ck.filter((farm)=>farm.pid !== 0
            );
            await dispatch((0,_farms__WEBPACK_IMPORTED_MODULE_11__/* .fetchFarmsPublicDataAsync */ .eG)(activeFarms.map((farm)=>farm.pid
            )));
            (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.batch)(()=>{
                dispatch((0,___WEBPACK_IMPORTED_MODULE_8__/* .fetchPoolsPublicDataAsync */ .ht)());
                dispatch((0,___WEBPACK_IMPORTED_MODULE_8__/* .fetchPoolsStakingLimitsAsync */ .E$)());
            });
        };
        fetchPoolsDataWithFarms();
    }, [
        dispatch
    ]);
};
const useFetchUserPools = (account)=>{
    const dispatch = (0,state__WEBPACK_IMPORTED_MODULE_4__/* .useAppDispatch */ .TL)();
    (0,hooks_useRefreshEffect__WEBPACK_IMPORTED_MODULE_7__/* .useFastRefreshEffect */ .a)(()=>{
        if (account) {
            dispatch((0,___WEBPACK_IMPORTED_MODULE_8__/* .fetchPoolsUserDataAsync */ .XK)(account));
        }
    }, [
        account,
        dispatch
    ]);
};
const usePools = ()=>{
    const { pools , userDataLoaded  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useSelector)((state)=>({
            pools: state.pools.data,
            userDataLoaded: state.pools.userDataLoaded
        })
    );
    return {
        pools: pools.map(_helpers__WEBPACK_IMPORTED_MODULE_10__/* .transformPool */ .xK),
        userDataLoaded
    };
};
const usePool = (sousId)=>{
    const { pool , userDataLoaded  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useSelector)((state)=>({
            pool: state.pools.data.find((p)=>p.sousId === sousId
            ),
            userDataLoaded: state.pools.userDataLoaded
        })
    );
    return {
        pool: (0,_helpers__WEBPACK_IMPORTED_MODULE_10__/* .transformPool */ .xK)(pool),
        userDataLoaded
    };
};
const useFetchCakeVault = ()=>{
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_2__.useWeb3React)();
    const dispatch = (0,state__WEBPACK_IMPORTED_MODULE_4__/* .useAppDispatch */ .TL)();
    (0,hooks_useRefreshEffect__WEBPACK_IMPORTED_MODULE_7__/* .useFastRefreshEffect */ .a)(()=>{
        dispatch((0,___WEBPACK_IMPORTED_MODULE_8__/* .fetchCakeVaultPublicData */ .P4)());
    }, [
        dispatch
    ]);
    (0,hooks_useRefreshEffect__WEBPACK_IMPORTED_MODULE_7__/* .useFastRefreshEffect */ .a)(()=>{
        dispatch((0,___WEBPACK_IMPORTED_MODULE_8__/* .fetchCakeVaultUserData */ .x$)({
            account
        }));
    }, [
        dispatch,
        account
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        dispatch((0,___WEBPACK_IMPORTED_MODULE_8__/* .fetchCakeVaultFees */ .HX)());
    }, [
        dispatch
    ]);
};
const useFetchIfoPool = (fetchCakePool = true)=>{
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_2__.useWeb3React)();
    const dispatch = (0,state__WEBPACK_IMPORTED_MODULE_4__/* .useAppDispatch */ .TL)();
    (0,hooks_useRefreshEffect__WEBPACK_IMPORTED_MODULE_7__/* .useFastRefreshEffect */ .a)(()=>{
        (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.batch)(()=>{
            if (fetchCakePool) {
                dispatch((0,___WEBPACK_IMPORTED_MODULE_8__/* .fetchCakePoolPublicDataAsync */ .PE)());
            }
            dispatch((0,___WEBPACK_IMPORTED_MODULE_8__/* .fetchIfoPoolPublicData */ .ON)());
        });
    }, [
        dispatch,
        fetchCakePool
    ]);
    (0,hooks_useRefreshEffect__WEBPACK_IMPORTED_MODULE_7__/* .useFastRefreshEffect */ .a)(()=>{
        if (account) {
            (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.batch)(()=>{
                dispatch((0,___WEBPACK_IMPORTED_MODULE_8__/* .fetchIfoPoolUserAndCredit */ .W3)({
                    account
                }));
                if (fetchCakePool) {
                    dispatch((0,___WEBPACK_IMPORTED_MODULE_8__/* .fetchCakePoolUserDataAsync */ .wI)(account));
                }
            });
        }
    }, [
        dispatch,
        account,
        fetchCakePool
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        dispatch((0,___WEBPACK_IMPORTED_MODULE_8__/* .fetchIfoPoolFees */ .TU)());
    }, [
        dispatch
    ]);
};
const useCakeVault = ()=>{
    return useVaultPoolByKey(_types__WEBPACK_IMPORTED_MODULE_9__/* .VaultKey.CakeVault */ .om.CakeVault);
};
const useVaultPools = ()=>{
    return {
        [_types__WEBPACK_IMPORTED_MODULE_9__/* .VaultKey.CakeVault */ .om.CakeVault]: useVaultPoolByKey(_types__WEBPACK_IMPORTED_MODULE_9__/* .VaultKey.CakeVault */ .om.CakeVault),
        [_types__WEBPACK_IMPORTED_MODULE_9__/* .VaultKey.IfoPool */ .om.IfoPool]: useVaultPoolByKey(_types__WEBPACK_IMPORTED_MODULE_9__/* .VaultKey.IfoPool */ .om.IfoPool)
    };
};
const useVaultPoolByKey = (key)=>{
    const { totalShares: totalSharesAsString , pricePerFullShare: pricePerFullShareAsString , totalCakeInVault: totalCakeInVaultAsString , estimatedCakeBountyReward: estimatedCakeBountyRewardAsString , totalPendingCakeHarvest: totalPendingCakeHarvestAsString , fees: { performanceFee , callFee , withdrawalFee , withdrawalFeePeriod  } , userData: { isLoading , userShares: userSharesAsString , cakeAtLastUserAction: cakeAtLastUserActionAsString , lastDepositedTime , lastUserActionTime ,  } ,  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useSelector)((state)=>key ? state.pools[key] : ___WEBPACK_IMPORTED_MODULE_8__/* .initialPoolVaultState */ .XW
    );
    const estimatedCakeBountyReward = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        return new (bignumber_js__WEBPACK_IMPORTED_MODULE_1___default())(estimatedCakeBountyRewardAsString);
    }, [
        estimatedCakeBountyRewardAsString
    ]);
    const totalPendingCakeHarvest = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        return new (bignumber_js__WEBPACK_IMPORTED_MODULE_1___default())(totalPendingCakeHarvestAsString);
    }, [
        totalPendingCakeHarvestAsString
    ]);
    const totalShares = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        return new (bignumber_js__WEBPACK_IMPORTED_MODULE_1___default())(totalSharesAsString);
    }, [
        totalSharesAsString
    ]);
    const pricePerFullShare = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        return new (bignumber_js__WEBPACK_IMPORTED_MODULE_1___default())(pricePerFullShareAsString);
    }, [
        pricePerFullShareAsString
    ]);
    const totalCakeInVault = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        return new (bignumber_js__WEBPACK_IMPORTED_MODULE_1___default())(totalCakeInVaultAsString);
    }, [
        totalCakeInVaultAsString
    ]);
    const userShares = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        return new (bignumber_js__WEBPACK_IMPORTED_MODULE_1___default())(userSharesAsString);
    }, [
        userSharesAsString
    ]);
    const cakeAtLastUserAction = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        return new (bignumber_js__WEBPACK_IMPORTED_MODULE_1___default())(cakeAtLastUserActionAsString);
    }, [
        cakeAtLastUserActionAsString
    ]);
    const performanceFeeAsDecimal = performanceFee && performanceFee / 100;
    return {
        totalShares,
        pricePerFullShare,
        totalCakeInVault,
        estimatedCakeBountyReward,
        totalPendingCakeHarvest,
        fees: {
            performanceFeeAsDecimal,
            performanceFee,
            callFee,
            withdrawalFee,
            withdrawalFeePeriod
        },
        userData: {
            isLoading,
            userShares,
            cakeAtLastUserAction,
            lastDepositedTime,
            lastUserActionTime
        }
    };
};
const useIfoPoolVault = ()=>{
    return useVaultPoolByKey(_types__WEBPACK_IMPORTED_MODULE_9__/* .VaultKey.IfoPool */ .om.IfoPool);
};
const useIfoPoolCreditBlock = ()=>{
    return (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useSelector)((state)=>({
            creditStartBlock: state.pools.ifoPool.creditStartBlock,
            creditEndBlock: state.pools.ifoPool.creditEndBlock,
            hasEndBlockOver: state.block.currentBlock >= state.pools.ifoPool.creditEndBlock
        })
    );
};
const useIfoPoolCredit = ()=>{
    const creditAsString = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useSelector)((state)=>state.pools.ifoPool.userData?.credit ?? utils_bigNumber__WEBPACK_IMPORTED_MODULE_5__/* .BIG_ZERO */ .HW
    );
    const credit = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        return new (bignumber_js__WEBPACK_IMPORTED_MODULE_1___default())(creditAsString);
    }, [
        creditAsString
    ]);
    return credit;
};
const useIfoWithApr = ()=>{
    const { fees: { performanceFeeAsDecimal  } ,  } = useIfoPoolVault();
    const { pool: poolZero  } = usePool(0);
    const ifoPoolWithApr = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        const ifoPool = {
            ...poolZero
        };
        ifoPool.vaultKey = _types__WEBPACK_IMPORTED_MODULE_9__/* .VaultKey.IfoPool */ .om.IfoPool;
        ifoPool.apr = (0,views_Pools_helpers__WEBPACK_IMPORTED_MODULE_6__/* .getAprData */ .rD)(ifoPool, performanceFeeAsDecimal).apr;
        ifoPool.rawApr = poolZero.apr;
        return ifoPool;
    }, [
        performanceFeeAsDecimal,
        poolZero
    ]);
    return {
        pool: ifoPoolWithApr
    };
};

});

/***/ })

};
;
//# sourceMappingURL=1624.js.map