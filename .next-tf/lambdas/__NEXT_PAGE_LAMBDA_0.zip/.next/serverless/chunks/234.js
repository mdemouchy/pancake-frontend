"use strict";
exports.id = 234;
exports.ids = [234];
exports.modules = {

/***/ 96700:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* reexport */ ExpandableSectionButton_ExpandableSectionButton)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(57518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: external "@pancakeswap/uikit"
var uikit_ = __webpack_require__(2829);
// EXTERNAL MODULE: ./src/contexts/Localization/index.tsx + 3 modules
var Localization = __webpack_require__(99150);
;// CONCATENATED MODULE: ./src/components/ExpandableSectionButton/ExpandableSectionButton.tsx





const Wrapper = external_styled_components_default().div.withConfig({
    componentId: "sc-b6677f58-0"
})`
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;

  svg {
    fill: ${({ theme  })=>theme.colors.primary
};
  }
`;
const ExpandableSectionButton = ({ onClick , expanded =false  })=>{
    const { t  } = (0,Localization/* useTranslation */.$G)();
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(Wrapper, {
        "aria-label": t('Hide or show expandable content'),
        role: "button",
        onClick: ()=>onClick()
        ,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Text, {
                color: "primary",
                bold: true,
                children: expanded ? t('Hide') : t('Details')
            }),
            expanded ? /*#__PURE__*/ jsx_runtime_.jsx(uikit_.ChevronUpIcon, {}) : /*#__PURE__*/ jsx_runtime_.jsx(uikit_.ChevronDownIcon, {})
        ]
    }));
};
/* harmony default export */ const ExpandableSectionButton_ExpandableSectionButton = (ExpandableSectionButton);

;// CONCATENATED MODULE: ./src/components/ExpandableSectionButton/index.ts



/***/ }),

/***/ 3725:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "n": () => (/* reexport */ Modal_ModalActions),
  "S": () => (/* reexport */ Modal_ModalInput)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(57518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
;// CONCATENATED MODULE: ./src/components/Modal/Spacer.tsx



const Spacer = ({ size ='md'  })=>{
    const { spacing  } = (0,external_react_.useContext)(external_styled_components_.ThemeContext);
    let s;
    switch(size){
        case 'lg':
            s = spacing[6];
            break;
        case 'sm':
            s = spacing[2];
            break;
        case 'md':
        default:
            s = spacing[4];
    }
    return(/*#__PURE__*/ jsx_runtime_.jsx(StyledSpacer, {
        size: s
    }));
};
const StyledSpacer = external_styled_components_default().div.withConfig({
    componentId: "sc-12204eb7-0"
})`
  height: ${(props)=>props.size
}px;
  width: ${(props)=>props.size
}px;
`;
/* harmony default export */ const Modal_Spacer = (Spacer);

;// CONCATENATED MODULE: ./src/components/Modal/ModalActions.tsx




const ModalActions = ({ children  })=>{
    const l = external_react_default().Children.toArray(children).length;
    return(/*#__PURE__*/ jsx_runtime_.jsx(StyledModalActions, {
        children: external_react_default().Children.map(children, (child, i)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(StyledModalAction, {
                        children: child
                    }),
                    i < l - 1 && /*#__PURE__*/ jsx_runtime_.jsx(Modal_Spacer, {})
                ]
            })
        )
    }));
};
const StyledModalActions = external_styled_components_default().div.withConfig({
    componentId: "sc-26dcdd92-0"
})`
  align-items: center;
  background-color: ${(props)=>props.theme.colors.primaryDark
}00;
  display: flex;
  margin: 0;
  padding: ${(props)=>props.theme.spacing[4]
}px 0;
`;
const StyledModalAction = external_styled_components_default().div.withConfig({
    componentId: "sc-26dcdd92-1"
})`
  flex: 1;
`;
/* harmony default export */ const Modal_ModalActions = (ModalActions);

// EXTERNAL MODULE: external "@pancakeswap/uikit"
var uikit_ = __webpack_require__(2829);
// EXTERNAL MODULE: ./src/contexts/Localization/index.tsx + 3 modules
var Localization = __webpack_require__(99150);
// EXTERNAL MODULE: external "@ethersproject/units"
var units_ = __webpack_require__(93138);
// EXTERNAL MODULE: ./src/utils/formatBalance.ts
var formatBalance = __webpack_require__(65044);
;// CONCATENATED MODULE: ./src/components/Modal/ModalInput.tsx







const getBoxShadow = ({ isWarning =false , theme  })=>{
    if (isWarning) {
        return theme.shadows.warning;
    }
    return theme.shadows.inset;
};
const StyledTokenInput = external_styled_components_default().div.withConfig({
    componentId: "sc-52d8db52-0"
})`
  display: flex;
  flex-direction: column;
  background-color: ${({ theme  })=>theme.colors.input
};
  border-radius: 16px;
  box-shadow: ${getBoxShadow};
  color: ${({ theme  })=>theme.colors.text
};
  padding: 8px 16px 8px 0;
  width: 100%;
`;
const StyledInput = external_styled_components_default()(uikit_.Input).withConfig({
    componentId: "sc-52d8db52-1"
})`
  box-shadow: none;
  width: 60px;
  margin: 0 8px;
  padding: 0 8px;
  border: none;

  ${({ theme  })=>theme.mediaQueries.xs
} {
    width: 80px;
  }

  ${({ theme  })=>theme.mediaQueries.sm
} {
    width: auto;
  }
`;
const StyledErrorMessage = external_styled_components_default()(uikit_.Text).withConfig({
    componentId: "sc-52d8db52-2"
})`
  position: absolute;
  bottom: -22px;
  a {
    display: inline;
  }
`;
const ModalInput = ({ max , symbol , onChange , onSelectMax , value , addLiquidityUrl , inputTitle , decimals =18 ,  })=>{
    const { t  } = (0,Localization/* useTranslation */.$G)();
    const isBalanceZero = max === '0' || !max;
    const displayBalance = (balance)=>{
        if (isBalanceZero) {
            return '0';
        }
        const balanceUnits = (0,units_.parseUnits)(balance, decimals);
        return (0,formatBalance/* formatBigNumber */.dp)(balanceUnits, decimals, decimals);
    };
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        style: {
            position: 'relative'
        },
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(StyledTokenInput, {
                isWarning: isBalanceZero,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(uikit_.Flex, {
                        justifyContent: "space-between",
                        pl: "16px",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Text, {
                                fontSize: "14px",
                                children: inputTitle
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Text, {
                                fontSize: "14px",
                                children: t('Balance: %balance%', {
                                    balance: displayBalance(max)
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(uikit_.Flex, {
                        alignItems: "flex-end",
                        justifyContent: "space-around",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(StyledInput, {
                                pattern: `^[0-9]*[.,]?[0-9]{0,${decimals}}$`,
                                inputMode: "decimal",
                                step: "any",
                                min: "0",
                                onChange: onChange,
                                placeholder: "0",
                                value: value
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Button, {
                                scale: "sm",
                                onClick: onSelectMax,
                                mr: "8px",
                                children: t('Max')
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Text, {
                                fontSize: "16px",
                                children: symbol
                            })
                        ]
                    })
                ]
            }),
            isBalanceZero && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(StyledErrorMessage, {
                fontSize: "14px",
                color: "failure",
                children: [
                    t('No tokens to stake'),
                    ":",
                    ' ',
                    /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Link, {
                        fontSize: "14px",
                        bold: false,
                        href: addLiquidityUrl,
                        external: true,
                        color: "failure",
                        children: t('Get %symbol%', {
                            symbol
                        })
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const Modal_ModalInput = (ModalInput);

;// CONCATENATED MODULE: ./src/components/Modal/index.ts




/***/ }),

/***/ 51912:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var config_constants_tokens__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(29748);
// Constructing the two forward-slash-separated parts of the 'Add Liquidity' URL
// Each part of the url represents a different side of the LP pair.

const getLiquidityUrlPathParts = ({ quoteTokenAddress , tokenAddress  })=>{
    const wBnbAddress = config_constants_tokens__WEBPACK_IMPORTED_MODULE_0__/* ["default"].wbnb.address */ .ZP.wbnb.address;
    const firstPart = !quoteTokenAddress || quoteTokenAddress === wBnbAddress ? 'BNB' : quoteTokenAddress;
    const secondPart = !tokenAddress || tokenAddress === wBnbAddress ? 'BNB' : tokenAddress;
    return `${firstPart}/${secondPart}`;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (getLiquidityUrlPathParts);


/***/ }),

/***/ 48969:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "V2": () => (/* binding */ getDisplayApr),
/* harmony export */   "GX": () => (/* binding */ FarmsContext),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(34215);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(bignumber_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(18054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(42877);
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var components_NextLink__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(53629);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var components_Layout_Flex__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(40508);
/* harmony import */ var components_Layout_Page__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9770);
/* harmony import */ var state_farms_hooks__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8733);
/* harmony import */ var hooks_useIntersectionObserver__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(76538);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(99150);
/* harmony import */ var utils_formatBalance__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(65044);
/* harmony import */ var utils_apr__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(28668);
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(49949);
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(lodash_orderBy__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var utils_farmHelpers__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(74842);
/* harmony import */ var utils_latinise__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(11438);
/* harmony import */ var state_user_hooks__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(68605);
/* harmony import */ var state_user_actions__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(46245);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var components_PageHeader__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(44482);
/* harmony import */ var components_SearchInput__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(14450);
/* harmony import */ var components_Select_Select__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(37370);
/* harmony import */ var components_Loading__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(8080);
/* harmony import */ var _components_FarmTable_FarmTable__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(94121);
/* harmony import */ var _components_FarmTabButtons__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(90286);
/* harmony import */ var _components_ToggleView_ToggleView__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(59901);
/* harmony import */ var _components_types__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(81655);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([components_Layout_Page__WEBPACK_IMPORTED_MODULE_9__, _components_FarmTable_FarmTable__WEBPACK_IMPORTED_MODULE_24__, state_user_hooks__WEBPACK_IMPORTED_MODULE_17__, state_farms_hooks__WEBPACK_IMPORTED_MODULE_10__]);
([components_Layout_Page__WEBPACK_IMPORTED_MODULE_9__, _components_FarmTable_FarmTable__WEBPACK_IMPORTED_MODULE_24__, state_user_hooks__WEBPACK_IMPORTED_MODULE_17__, state_farms_hooks__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);





























const ControlContainer = styled_components__WEBPACK_IMPORTED_MODULE_7___default().div.withConfig({
    componentId: "sc-489a7376-0"
})`
  display: flex;
  width: 100%;
  align-items: center;
  position: relative;

  justify-content: space-between;
  flex-direction: column;
  margin-bottom: 32px;

  ${({ theme  })=>theme.mediaQueries.sm
} {
    flex-direction: row;
    flex-wrap: wrap;
    padding: 16px 32px;
    margin-bottom: 0;
  }
`;
const ToggleWrapper = styled_components__WEBPACK_IMPORTED_MODULE_7___default().div.withConfig({
    componentId: "sc-489a7376-1"
})`
  display: flex;
  align-items: center;
  margin-left: 10px;

  ${_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text} {
    margin-left: 8px;
  }
`;
const LabelWrapper = styled_components__WEBPACK_IMPORTED_MODULE_7___default().div.withConfig({
    componentId: "sc-489a7376-2"
})`
  > ${_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text} {
    font-size: 12px;
  }
`;
const FilterContainer = styled_components__WEBPACK_IMPORTED_MODULE_7___default().div.withConfig({
    componentId: "sc-489a7376-3"
})`
  display: flex;
  align-items: center;
  width: 100%;
  padding: 8px 0px;

  ${({ theme  })=>theme.mediaQueries.sm
} {
    width: auto;
    padding: 0;
  }
`;
const ViewControls = styled_components__WEBPACK_IMPORTED_MODULE_7___default().div.withConfig({
    componentId: "sc-489a7376-4"
})`
  flex-wrap: wrap;
  justify-content: space-between;
  display: flex;
  align-items: center;
  width: 100%;

  > div {
    padding: 8px 0px;
  }

  ${({ theme  })=>theme.mediaQueries.sm
} {
    justify-content: flex-start;
    width: auto;

    > div {
      padding: 0;
    }
  }
`;
const StyledImage = styled_components__WEBPACK_IMPORTED_MODULE_7___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Image).withConfig({
    componentId: "sc-489a7376-5"
})`
  margin-left: auto;
  margin-right: auto;
  margin-top: 58px;
`;
const NUMBER_OF_FARMS_VISIBLE = 12;
const getDisplayApr = (cakeRewardsApr, lpRewardsApr)=>{
    if (cakeRewardsApr && lpRewardsApr) {
        return (cakeRewardsApr + lpRewardsApr).toLocaleString('en-US', {
            maximumFractionDigits: 2
        });
    }
    if (cakeRewardsApr) {
        return cakeRewardsApr.toLocaleString('en-US', {
            maximumFractionDigits: 2
        });
    }
    return null;
};
const Farms = ({ children  })=>{
    const { pathname  } = (0,next_router__WEBPACK_IMPORTED_MODULE_19__.useRouter)();
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_12__/* .useTranslation */ .$G)();
    const { data: farmsLP , userDataLoaded  } = (0,state_farms_hooks__WEBPACK_IMPORTED_MODULE_10__/* .useFarms */ .E2)();
    const cakePrice = (0,state_farms_hooks__WEBPACK_IMPORTED_MODULE_10__/* .usePriceCakeBusd */ .Iu)();
    const { 0: query , 1: setQuery  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const [viewMode, setViewMode] = (0,state_user_hooks__WEBPACK_IMPORTED_MODULE_17__/* .useUserFarmsViewMode */ .y9)();
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_3__.useWeb3React)();
    const { 0: sortOption , 1: setSortOption  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('hot');
    const { observerRef , isIntersecting  } = (0,hooks_useIntersectionObserver__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z)();
    const chosenFarmsLength = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(0);
    const isArchived = pathname.includes('archived');
    const isInactive = pathname.includes('history');
    const isActive = !isInactive && !isArchived;
    (0,state_farms_hooks__WEBPACK_IMPORTED_MODULE_10__/* .usePollFarmsWithUserData */ .Cs)(isArchived);
    // Users with no wallet connected should see 0 as Earned amount
    // Connected users should see loading indicator until first userData has loaded
    const userDataReady = !account || !!account && userDataLoaded;
    const [stakedOnly, setStakedOnly] = (0,state_user_hooks__WEBPACK_IMPORTED_MODULE_17__/* .useUserFarmStakedOnly */ .XD)(isActive);
    const activeFarms = farmsLP.filter((farm)=>farm.pid !== 0 && farm.multiplier !== '0X' && !(0,utils_farmHelpers__WEBPACK_IMPORTED_MODULE_28__/* ["default"] */ .Z)(farm.pid)
    );
    const inactiveFarms = farmsLP.filter((farm)=>farm.pid !== 0 && farm.multiplier === '0X' && !(0,utils_farmHelpers__WEBPACK_IMPORTED_MODULE_28__/* ["default"] */ .Z)(farm.pid)
    );
    const archivedFarms = farmsLP.filter((farm)=>(0,utils_farmHelpers__WEBPACK_IMPORTED_MODULE_28__/* ["default"] */ .Z)(farm.pid)
    );
    const stakedOnlyFarms = activeFarms.filter((farm)=>farm.userData && new (bignumber_js__WEBPACK_IMPORTED_MODULE_2___default())(farm.userData.stakedBalance).isGreaterThan(0)
    );
    const stakedInactiveFarms = inactiveFarms.filter((farm)=>farm.userData && new (bignumber_js__WEBPACK_IMPORTED_MODULE_2___default())(farm.userData.stakedBalance).isGreaterThan(0)
    );
    const stakedArchivedFarms = archivedFarms.filter((farm)=>farm.userData && new (bignumber_js__WEBPACK_IMPORTED_MODULE_2___default())(farm.userData.stakedBalance).isGreaterThan(0)
    );
    const farmsList = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((farmsToDisplay)=>{
        let farmsToDisplayWithAPR = farmsToDisplay.map((farm)=>{
            if (!farm.lpTotalInQuoteToken || !farm.quoteTokenPriceBusd) {
                return farm;
            }
            const totalLiquidity = new (bignumber_js__WEBPACK_IMPORTED_MODULE_2___default())(farm.lpTotalInQuoteToken).times(farm.quoteTokenPriceBusd);
            const { cakeRewardsApr , lpRewardsApr  } = isActive ? (0,utils_apr__WEBPACK_IMPORTED_MODULE_14__/* .getFarmApr */ .yW)(new (bignumber_js__WEBPACK_IMPORTED_MODULE_2___default())(farm.poolWeight), cakePrice, totalLiquidity, farm.lpAddresses[_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_5__.ChainId.MAINNET]) : {
                cakeRewardsApr: 0,
                lpRewardsApr: 0
            };
            return {
                ...farm,
                apr: cakeRewardsApr,
                lpRewardsApr,
                liquidity: totalLiquidity
            };
        });
        if (query) {
            const lowercaseQuery = (0,utils_latinise__WEBPACK_IMPORTED_MODULE_16__/* .latinise */ .b)(query.toLowerCase());
            farmsToDisplayWithAPR = farmsToDisplayWithAPR.filter((farm)=>{
                return (0,utils_latinise__WEBPACK_IMPORTED_MODULE_16__/* .latinise */ .b)(farm.lpSymbol.toLowerCase()).includes(lowercaseQuery);
            });
        }
        return farmsToDisplayWithAPR;
    }, [
        cakePrice,
        query,
        isActive
    ]);
    const handleChangeQuery = (event)=>{
        setQuery(event.target.value);
    };
    const { 0: numberOfFarmsVisible , 1: setNumberOfFarmsVisible  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(NUMBER_OF_FARMS_VISIBLE);
    const chosenFarmsMemoized = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        let chosenFarms = [];
        const sortFarms = (farms)=>{
            switch(sortOption){
                case 'apr':
                    return lodash_orderBy__WEBPACK_IMPORTED_MODULE_15___default()(farms, (farm)=>farm.apr + farm.lpRewardsApr
                    , 'desc');
                case 'multiplier':
                    return lodash_orderBy__WEBPACK_IMPORTED_MODULE_15___default()(farms, (farm)=>farm.multiplier ? Number(farm.multiplier.slice(0, -1)) : 0
                    , 'desc');
                case 'earned':
                    return lodash_orderBy__WEBPACK_IMPORTED_MODULE_15___default()(farms, (farm)=>farm.userData ? Number(farm.userData.earnings) : 0
                    , 'desc');
                case 'liquidity':
                    return lodash_orderBy__WEBPACK_IMPORTED_MODULE_15___default()(farms, (farm)=>Number(farm.liquidity)
                    , 'desc');
                default:
                    return farms;
            }
        };
        if (isActive) {
            chosenFarms = stakedOnly ? farmsList(stakedOnlyFarms) : farmsList(activeFarms);
        }
        if (isInactive) {
            chosenFarms = stakedOnly ? farmsList(stakedInactiveFarms) : farmsList(inactiveFarms);
        }
        if (isArchived) {
            chosenFarms = stakedOnly ? farmsList(stakedArchivedFarms) : farmsList(archivedFarms);
        }
        return sortFarms(chosenFarms).slice(0, numberOfFarmsVisible);
    }, [
        sortOption,
        activeFarms,
        farmsList,
        inactiveFarms,
        archivedFarms,
        isActive,
        isInactive,
        isArchived,
        stakedArchivedFarms,
        stakedInactiveFarms,
        stakedOnly,
        stakedOnlyFarms,
        numberOfFarmsVisible, 
    ]);
    chosenFarmsLength.current = chosenFarmsMemoized.length;
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (isIntersecting) {
            setNumberOfFarmsVisible((farmsCurrentlyVisible)=>{
                if (farmsCurrentlyVisible <= chosenFarmsLength.current) {
                    return farmsCurrentlyVisible + NUMBER_OF_FARMS_VISIBLE;
                }
                return farmsCurrentlyVisible;
            });
        }
    }, [
        isIntersecting
    ]);
    const rowData = chosenFarmsMemoized.map((farm)=>{
        const { token , quoteToken  } = farm;
        const tokenAddress = token.address;
        const quoteTokenAddress = quoteToken.address;
        const lpLabel = farm.lpSymbol && farm.lpSymbol.split(' ')[0].toUpperCase().replace('PANCAKE', '');
        const row = {
            apr: {
                value: getDisplayApr(farm.apr, farm.lpRewardsApr),
                pid: farm.pid,
                multiplier: farm.multiplier,
                lpLabel,
                lpSymbol: farm.lpSymbol,
                tokenAddress,
                quoteTokenAddress,
                cakePrice,
                originalValue: farm.apr
            },
            farm: {
                label: lpLabel,
                pid: farm.pid,
                token: farm.token,
                quoteToken: farm.quoteToken
            },
            earned: {
                earnings: (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_13__/* .getBalanceNumber */ .mW)(new (bignumber_js__WEBPACK_IMPORTED_MODULE_2___default())(farm.userData.earnings)),
                pid: farm.pid
            },
            liquidity: {
                liquidity: farm.liquidity
            },
            multiplier: {
                multiplier: farm.multiplier
            },
            details: farm
        };
        return row;
    });
    const renderContent = ()=>{
        if (viewMode === state_user_actions__WEBPACK_IMPORTED_MODULE_18__/* .ViewMode.TABLE */ .wO.TABLE && rowData.length) {
            const columnSchema = _components_types__WEBPACK_IMPORTED_MODULE_27__/* .DesktopColumnSchema */ .X;
            const columns = columnSchema.map((column)=>({
                    id: column.id,
                    name: column.name,
                    label: column.label,
                    sort: (a, b)=>{
                        switch(column.name){
                            case 'farm':
                                return b.id - a.id;
                            case 'apr':
                                if (a.original.apr.value && b.original.apr.value) {
                                    return Number(a.original.apr.value) - Number(b.original.apr.value);
                                }
                                return 0;
                            case 'earned':
                                return a.original.earned.earnings - b.original.earned.earnings;
                            default:
                                return 1;
                        }
                    },
                    sortable: column.sortable
                })
            );
            return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FarmTable_FarmTable__WEBPACK_IMPORTED_MODULE_24__/* ["default"] */ .Z, {
                data: rowData,
                columns: columns,
                userDataReady: userDataReady
            }));
        }
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Layout_Flex__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
            children: children
        }));
    };
    const handleSortOptionChange = (option)=>{
        setSortOption(option.value);
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(FarmsContext.Provider, {
        value: {
            chosenFarmsMemoized
        },
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(components_PageHeader__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Heading, {
                        as: "h1",
                        scale: "xxl",
                        color: "secondary",
                        mb: "24px",
                        children: t('Farms')
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Heading, {
                        scale: "lg",
                        color: "text",
                        children: t('Stake LP tokens to earn.')
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_NextLink__WEBPACK_IMPORTED_MODULE_6__/* .NextLinkFromReactRouter */ .a, {
                        to: "/farms/auction",
                        id: "lottery-pot-banner",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Button, {
                            p: "0",
                            variant: "text",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                                    color: "primary",
                                    bold: true,
                                    fontSize: "16px",
                                    mr: "4px",
                                    children: t('Community Auctions')
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.ArrowForwardIcon, {
                                    color: "primary"
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(components_Layout_Page__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ControlContainer, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ViewControls, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ToggleView_ToggleView__WEBPACK_IMPORTED_MODULE_26__/* ["default"] */ .Z, {
                                        viewMode: viewMode,
                                        onToggle: (mode)=>setViewMode(mode)
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ToggleWrapper, {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Toggle, {
                                                id: "staked-only-farms",
                                                checked: stakedOnly,
                                                onChange: ()=>setStakedOnly(!stakedOnly)
                                                ,
                                                scale: "sm"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                                                children: [
                                                    " ",
                                                    t('Staked only')
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FarmTabButtons__WEBPACK_IMPORTED_MODULE_25__/* ["default"] */ .Z, {
                                        hasStakeInFinishedFarms: stakedInactiveFarms.length > 0
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(FilterContainer, {
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(LabelWrapper, {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                                                textTransform: "uppercase",
                                                children: t('Sort by')
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Select_Select__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .Z, {
                                                options: [
                                                    {
                                                        label: t('Hot'),
                                                        value: 'hot'
                                                    },
                                                    {
                                                        label: t('APR'),
                                                        value: 'apr'
                                                    },
                                                    {
                                                        label: t('Multiplier'),
                                                        value: 'multiplier'
                                                    },
                                                    {
                                                        label: t('Earned'),
                                                        value: 'earned'
                                                    },
                                                    {
                                                        label: t('Liquidity'),
                                                        value: 'liquidity'
                                                    }, 
                                                ],
                                                onOptionChange: handleSortOptionChange
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(LabelWrapper, {
                                        style: {
                                            marginLeft: 16
                                        },
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                                                textTransform: "uppercase",
                                                children: t('Search')
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_SearchInput__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .Z, {
                                                onChange: handleChangeQuery,
                                                placeholder: "Search Farms"
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    renderContent(),
                    account && !userDataLoaded && stakedOnly && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Flex, {
                        justifyContent: "center",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Loading__WEBPACK_IMPORTED_MODULE_23__/* ["default"] */ .Z, {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        ref: observerRef
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledImage, {
                        src: "/images/decorations/3dpan.png",
                        alt: "Pancake illustration",
                        width: 120,
                        height: 103
                    })
                ]
            })
        ]
    }));
};
const FarmsContext = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createContext({
    chosenFarmsMemoized: []
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Farms);

});

/***/ }),

/***/ 37272:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(34215);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(bignumber_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var components_Modal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3725);
/* harmony import */ var components_RoiCalculatorModal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(46414);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(99150);
/* harmony import */ var utils_formatBalance__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(65044);
/* harmony import */ var hooks_useToast__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(789);
/* harmony import */ var utils_compoundApyHelpers__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(16395);
/* harmony import */ var utils_sentry__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(17226);












const AnnualRoiContainer = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Flex).withConfig({
    componentId: "sc-bd129f45-0"
})`
  cursor: pointer;
`;
const AnnualRoiDisplay = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text).withConfig({
    componentId: "sc-bd129f45-1"
})`
  width: 72px;
  max-width: 72px;
  overflow: hidden;
  text-align: right;
  text-overflow: ellipsis;
`;
const DepositModal = ({ max , stakedBalance , onConfirm , onDismiss , tokenName ='' , multiplier , displayApr , lpPrice , lpLabel , apr , addLiquidityUrl , cakePrice ,  })=>{
    const { 0: val , 1: setVal  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)('');
    const { toastError  } = (0,hooks_useToast__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)();
    const { 0: pendingTx , 1: setPendingTx  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const { 0: showRoiCalculator , 1: setShowRoiCalculator  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_7__/* .useTranslation */ .$G)();
    const fullBalance = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        return (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_8__/* .getFullDisplayBalance */ .NJ)(max);
    }, [
        max
    ]);
    const lpTokensToStake = new (bignumber_js__WEBPACK_IMPORTED_MODULE_1___default())(val);
    const fullBalanceNumber = new (bignumber_js__WEBPACK_IMPORTED_MODULE_1___default())(fullBalance);
    const usdToStake = lpTokensToStake.times(lpPrice);
    const interestBreakdown = (0,utils_compoundApyHelpers__WEBPACK_IMPORTED_MODULE_11__/* .getInterestBreakdown */ .A1)({
        principalInUSD: !lpTokensToStake.isNaN() ? usdToStake.toNumber() : 0,
        apr,
        earningTokenPrice: cakePrice.toNumber()
    });
    const annualRoi = cakePrice.times(interestBreakdown[3]);
    const annualRoiAsNumber = annualRoi.toNumber();
    const formattedAnnualRoi = (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_8__/* .formatNumber */ .uf)(annualRoiAsNumber, annualRoi.gt(10000) ? 0 : 2, annualRoi.gt(10000) ? 0 : 2);
    const handleChange = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)((e)=>{
        if (e.currentTarget.validity.valid) {
            setVal(e.currentTarget.value.replace(/,/g, '.'));
        }
    }, [
        setVal
    ]);
    const handleSelectMax = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)(()=>{
        setVal(fullBalance);
    }, [
        fullBalance,
        setVal
    ]);
    if (showRoiCalculator) {
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_RoiCalculatorModal__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
            linkLabel: t('Get %symbol%', {
                symbol: lpLabel
            }),
            stakingTokenBalance: stakedBalance.plus(max),
            stakingTokenSymbol: tokenName,
            stakingTokenPrice: lpPrice.toNumber(),
            earningTokenPrice: cakePrice.toNumber(),
            apr: apr,
            multiplier: multiplier,
            displayApr: displayApr,
            linkHref: addLiquidityUrl,
            isFarm: true,
            initialValue: val,
            onBack: ()=>setShowRoiCalculator(false)
        }));
    }
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Modal, {
        title: t('Stake LP tokens'),
        onDismiss: onDismiss,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Modal__WEBPACK_IMPORTED_MODULE_5__/* .ModalInput */ .S, {
                value: val,
                onSelectMax: handleSelectMax,
                onChange: handleChange,
                max: fullBalance,
                symbol: tokenName,
                addLiquidityUrl: addLiquidityUrl,
                inputTitle: t('Stake')
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Flex, {
                mt: "24px",
                alignItems: "center",
                justifyContent: "space-between",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                        mr: "8px",
                        color: "textSubtle",
                        children: [
                            t('Annual ROI at current rates'),
                            ":"
                        ]
                    }),
                    Number.isFinite(annualRoiAsNumber) ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(AnnualRoiContainer, {
                        alignItems: "center",
                        onClick: ()=>{
                            setShowRoiCalculator(true);
                        },
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(AnnualRoiDisplay, {
                                children: [
                                    "$",
                                    formattedAnnualRoi
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.IconButton, {
                                variant: "text",
                                scale: "sm",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.CalculateIcon, {
                                    color: "textSubtle",
                                    width: "18px"
                                })
                            })
                        ]
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Skeleton, {
                        width: 60
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(components_Modal__WEBPACK_IMPORTED_MODULE_5__/* .ModalActions */ .n, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Button, {
                        variant: "secondary",
                        onClick: onDismiss,
                        width: "100%",
                        disabled: pendingTx,
                        children: t('Cancel')
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Button, {
                        width: "100%",
                        disabled: pendingTx || !lpTokensToStake.isFinite() || lpTokensToStake.eq(0) || lpTokensToStake.gt(fullBalanceNumber),
                        onClick: async ()=>{
                            setPendingTx(true);
                            try {
                                await onConfirm(val);
                                onDismiss();
                            } catch (e) {
                                (0,utils_sentry__WEBPACK_IMPORTED_MODULE_10__/* .logError */ .H)(e);
                                toastError(t('Error'), t('Please try again. Confirm the transaction and make sure you are paying enough gas!'));
                            } finally{
                                setPendingTx(false);
                            }
                        },
                        children: pendingTx ? t('Confirming') : t('Confirm')
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.LinkExternal, {
                href: addLiquidityUrl,
                style: {
                    alignSelf: 'center'
                },
                children: t('Get %symbol%', {
                    symbol: tokenName
                })
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DepositModal);


/***/ }),

/***/ 75313:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var components_RoiCalculatorModal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(46414);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(99150);
/* harmony import */ var state_farms_hooks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8733);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([state_farms_hooks__WEBPACK_IMPORTED_MODULE_6__]);
state_farms_hooks__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];







const ApyLabelContainer = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex).withConfig({
    componentId: "sc-a8b04e94-0"
})`
  cursor: pointer;

  &:hover {
    opacity: 0.5;
  }
`;
const ApyButton = ({ variant , pid , lpLabel , lpSymbol , cakePrice , apr , multiplier , displayApr , addLiquidityUrl ,  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_5__/* .useTranslation */ .$G)();
    const lpPrice = (0,state_farms_hooks__WEBPACK_IMPORTED_MODULE_6__/* .useLpTokenPrice */ .w5)(lpSymbol);
    const { tokenBalance , stakedBalance  } = (0,state_farms_hooks__WEBPACK_IMPORTED_MODULE_6__/* .useFarmUser */ .Dx)(pid);
    const [onPresentApyModal] = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.useModal)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_RoiCalculatorModal__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
        linkLabel: t('Get %symbol%', {
            symbol: lpLabel
        }),
        stakingTokenBalance: stakedBalance.plus(tokenBalance),
        stakingTokenSymbol: lpSymbol,
        stakingTokenPrice: lpPrice.toNumber(),
        earningTokenPrice: cakePrice.toNumber(),
        apr: apr,
        multiplier: multiplier,
        displayApr: displayApr,
        linkHref: addLiquidityUrl,
        isFarm: true
    }));
    const handleClickButton = (event)=>{
        event.stopPropagation();
        onPresentApyModal();
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ApyLabelContainer, {
        alignItems: "center",
        onClick: handleClickButton,
        children: [
            displayApr,
            "%",
            variant === 'text-and-button' && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.IconButton, {
                variant: "text",
                scale: "sm",
                ml: "4px",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.CalculateIcon, {
                    width: "18px"
                })
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ApyButton);

});

/***/ }),

/***/ 14757:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_ConnectWalletButton__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(30621);
/* harmony import */ var components_Toast__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(63937);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99150);
/* harmony import */ var hooks_useContract__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(46063);
/* harmony import */ var hooks_useToast__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(789);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var state__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(82727);
/* harmony import */ var state_farms__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(66319);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var utils_addressHelpers__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(55878);
/* harmony import */ var utils_sentry__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(17226);
/* harmony import */ var _hooks_useApproveFarm__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(76807);
/* harmony import */ var _HarvestAction__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(90922);
/* harmony import */ var _StakeAction__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(6090);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_HarvestAction__WEBPACK_IMPORTED_MODULE_14__, _StakeAction__WEBPACK_IMPORTED_MODULE_15__, _hooks_useApproveFarm__WEBPACK_IMPORTED_MODULE_13__]);
([_HarvestAction__WEBPACK_IMPORTED_MODULE_14__, _StakeAction__WEBPACK_IMPORTED_MODULE_15__, _hooks_useApproveFarm__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);
















const Action = styled_components__WEBPACK_IMPORTED_MODULE_10___default().div.withConfig({
    componentId: "sc-75a92127-0"
})`
  padding-top: 16px;
`;
const CardActions = ({ farm , account , addLiquidityUrl , cakePrice , lpLabel  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    const { toastSuccess , toastError  } = (0,hooks_useToast__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)();
    const { 0: requestedApproval , 1: setRequestedApproval  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)(false);
    const { pid , lpAddresses  } = farm;
    const { allowance , tokenBalance , stakedBalance , earnings  } = farm.userData || {};
    const lpAddress = (0,utils_addressHelpers__WEBPACK_IMPORTED_MODULE_11__/* .getAddress */ .Kn)(lpAddresses);
    const isApproved = account && allowance && allowance.isGreaterThan(0);
    const dispatch = (0,state__WEBPACK_IMPORTED_MODULE_8__/* .useAppDispatch */ .TL)();
    const lpContract = (0,hooks_useContract__WEBPACK_IMPORTED_MODULE_5__/* .useERC20 */ .X_)(lpAddress);
    const { onApprove  } = (0,_hooks_useApproveFarm__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z)(lpContract);
    const handleApprove = (0,react__WEBPACK_IMPORTED_MODULE_7__.useCallback)(async ()=>{
        try {
            setRequestedApproval(true);
            await onApprove((tx)=>{
                toastSuccess(`${t('Transaction Submitted')}!`, /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_3__/* .ToastDescriptionWithTx */ .YO, {
                    txHash: tx.hash
                }));
            }, (receipt)=>{
                toastSuccess(t('Contract Enabled'), /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_3__/* .ToastDescriptionWithTx */ .YO, {
                    txHash: receipt.transactionHash
                }));
            }, (receipt)=>{
                toastError(t('Error'), /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_3__/* .ToastDescriptionWithTx */ .YO, {
                    txHash: receipt.transactionHash,
                    children: t('Please try again. Confirm the transaction and make sure you are paying enough gas!')
                }));
            });
            dispatch((0,state_farms__WEBPACK_IMPORTED_MODULE_9__/* .fetchFarmUserDataAsync */ .IV)({
                account,
                pids: [
                    pid
                ]
            }));
        } catch (e) {
            (0,utils_sentry__WEBPACK_IMPORTED_MODULE_12__/* .logError */ .H)(e);
            toastError(t('Error'), t('Please try again. Confirm the transaction and make sure you are paying enough gas!'));
        } finally{
            setRequestedApproval(false);
        }
    }, [
        onApprove,
        dispatch,
        account,
        pid,
        t,
        toastError,
        toastSuccess
    ]);
    const renderApprovalOrStakeButton = ()=>{
        return isApproved ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_StakeAction__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
            stakedBalance: stakedBalance,
            tokenBalance: tokenBalance,
            tokenName: farm.lpSymbol,
            pid: pid,
            apr: farm.apr,
            lpLabel: lpLabel,
            cakePrice: cakePrice,
            addLiquidityUrl: addLiquidityUrl
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Button, {
            mt: "8px",
            width: "100%",
            disabled: requestedApproval,
            onClick: handleApprove,
            children: t('Enable Contract')
        });
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Action, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Text, {
                        bold: true,
                        textTransform: "uppercase",
                        color: "secondary",
                        fontSize: "12px",
                        pr: "4px",
                        children: "CAKE"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Text, {
                        bold: true,
                        textTransform: "uppercase",
                        color: "textSubtle",
                        fontSize: "12px",
                        children: t('Earned')
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_HarvestAction__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                earnings: earnings,
                pid: pid
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Text, {
                        bold: true,
                        textTransform: "uppercase",
                        color: "secondary",
                        fontSize: "12px",
                        pr: "4px",
                        children: farm.lpSymbol
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Text, {
                        bold: true,
                        textTransform: "uppercase",
                        color: "textSubtle",
                        fontSize: "12px",
                        children: t('Staked')
                    })
                ]
            }),
            !account ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_ConnectWalletButton__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                mt: "8px",
                width: "100%"
            }) : renderApprovalOrStakeButton()
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CardActions);

});

/***/ }),

/***/ 19244:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var components_Tags__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(69160);
/* harmony import */ var components_TokenImage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(95239);






const Wrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex).withConfig({
    componentId: "sc-16f6b5a1-0"
})`
  svg {
    margin-right: 4px;
  }
`;
const MultiplierTag = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Tag).withConfig({
    componentId: "sc-16f6b5a1-1"
})`
  margin-left: 4px;
`;
const CardHeading = ({ lpLabel , multiplier , isCommunityFarm , token , quoteToken  })=>{
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Wrapper, {
        justifyContent: "space-between",
        alignItems: "center",
        mb: "12px",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_TokenImage__WEBPACK_IMPORTED_MODULE_5__/* .TokenPairImage */ .q, {
                variant: "inverted",
                primaryToken: token,
                secondaryToken: quoteToken,
                width: 64,
                height: 64
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                flexDirection: "column",
                alignItems: "flex-end",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Heading, {
                        mb: "4px",
                        children: lpLabel.split(' ')[0]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                        justifyContent: "center",
                        children: [
                            isCommunityFarm ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Tags__WEBPACK_IMPORTED_MODULE_4__/* .CommunityTag */ .vl, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Tags__WEBPACK_IMPORTED_MODULE_4__/* .CoreTag */ .eE, {}),
                            multiplier ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(MultiplierTag, {
                                variant: "secondary",
                                children: multiplier
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Skeleton, {
                                ml: "4px",
                                width: 42,
                                height: 28
                            })
                        ]
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CardHeading);


/***/ }),

/***/ 96745:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(99150);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__);





const Wrapper = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
    componentId: "sc-78577dcf-0"
})`
  margin-top: 24px;
`;
const StyledLinkExternal = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.LinkExternal).withConfig({
    componentId: "sc-78577dcf-1"
})`
  font-weight: 400;
`;
const DetailsSection = ({ bscScanAddress , infoAddress , removed , totalValueFormatted , lpLabel , addLiquidityUrl ,  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_2__/* .useTranslation */ .$G)();
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Wrapper, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Flex, {
                justifyContent: "space-between",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                        children: [
                            t('Total Liquidity'),
                            ":"
                        ]
                    }),
                    totalValueFormatted ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                        children: totalValueFormatted
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Skeleton, {
                        width: 75,
                        height: 25
                    })
                ]
            }),
            !removed && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledLinkExternal, {
                href: addLiquidityUrl,
                children: t('Get %symbol%', {
                    symbol: lpLabel
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledLinkExternal, {
                href: bscScanAddress,
                children: t('View Contract')
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledLinkExternal, {
                href: infoAddress,
                children: t('See Pair Info')
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DetailsSection);


/***/ }),

/***/ 3352:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(38328);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(99150);
/* harmony import */ var components_ExpandableSectionButton__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(96700);
/* harmony import */ var config__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(33206);
/* harmony import */ var utils_addressHelpers__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(55878);
/* harmony import */ var utils_getLiquidityUrlPathParts__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(51912);
/* harmony import */ var _DetailsSection__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(96745);
/* harmony import */ var _CardHeading__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(19244);
/* harmony import */ var _CardActionsContainer__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(14757);
/* harmony import */ var _ApyButton__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(75313);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_CardActionsContainer__WEBPACK_IMPORTED_MODULE_12__, _ApyButton__WEBPACK_IMPORTED_MODULE_13__]);
([_CardActionsContainer__WEBPACK_IMPORTED_MODULE_12__, _ApyButton__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);














const StyledCard = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Card).withConfig({
    componentId: "sc-b4a313a-0"
})`
  align-self: baseline;
`;
const FarmCardInnerContainer = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex).withConfig({
    componentId: "sc-b4a313a-1"
})`
  flex-direction: column;
  justify-content: space-around;
  padding: 24px;
`;
const ExpandingWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-b4a313a-2"
})`
  padding: 24px;
  border-top: 2px solid ${({ theme  })=>theme.colors.cardBorder
};
  overflow: hidden;
`;
const FarmCard = ({ farm , displayApr , removed , cakePrice , account  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_5__/* .useTranslation */ .$G)();
    const { 0: showExpandableSection , 1: setShowExpandableSection  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const totalValueFormatted = farm.liquidity && farm.liquidity.gt(0) ? `$${farm.liquidity.toNumber().toLocaleString(undefined, {
        maximumFractionDigits: 0
    })}` : '';
    const lpLabel = farm.lpSymbol && farm.lpSymbol.toUpperCase().replace('PANCAKE', '');
    const earnLabel = farm.dual ? farm.dual.earnLabel : t('CAKE + Fees');
    const liquidityUrlPathParts = (0,utils_getLiquidityUrlPathParts__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)({
        quoteTokenAddress: farm.quoteToken.address,
        tokenAddress: farm.token.address
    });
    const addLiquidityUrl = `${config__WEBPACK_IMPORTED_MODULE_7__/* .BASE_ADD_LIQUIDITY_URL */ .wI}/${liquidityUrlPathParts}`;
    const lpAddress = (0,utils_addressHelpers__WEBPACK_IMPORTED_MODULE_8__/* .getAddress */ .Kn)(farm.lpAddresses);
    const isPromotedFarm = farm.token.symbol === 'CAKE';
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(StyledCard, {
        isActive: isPromotedFarm,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(FarmCardInnerContainer, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CardHeading__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                        lpLabel: lpLabel,
                        multiplier: farm.multiplier,
                        isCommunityFarm: farm.isCommunity,
                        token: farm.token,
                        quoteToken: farm.quoteToken
                    }),
                    !removed && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                        justifyContent: "space-between",
                        alignItems: "center",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                children: [
                                    t('APR'),
                                    ":"
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                bold: true,
                                style: {
                                    display: 'flex',
                                    alignItems: 'center'
                                },
                                children: farm.apr ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ApyButton__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                    variant: "text-and-button",
                                    pid: farm.pid,
                                    lpSymbol: farm.lpSymbol,
                                    multiplier: farm.multiplier,
                                    lpLabel: lpLabel,
                                    addLiquidityUrl: addLiquidityUrl,
                                    cakePrice: cakePrice,
                                    apr: farm.apr,
                                    displayApr: displayApr
                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Skeleton, {
                                    height: 24,
                                    width: 80
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                        justifyContent: "space-between",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                children: [
                                    t('Earn'),
                                    ":"
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                bold: true,
                                children: earnLabel
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CardActionsContainer__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                        farm: farm,
                        lpLabel: lpLabel,
                        account: account,
                        cakePrice: cakePrice,
                        addLiquidityUrl: addLiquidityUrl
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ExpandingWrapper, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_ExpandableSectionButton__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                        onClick: ()=>setShowExpandableSection(!showExpandableSection)
                        ,
                        expanded: showExpandableSection
                    }),
                    showExpandableSection && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_DetailsSection__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                        removed: removed,
                        bscScanAddress: (0,utils__WEBPACK_IMPORTED_MODULE_4__/* .getBscScanLink */ .s6)(lpAddress, 'address'),
                        infoAddress: `/info/pool/${lpAddress}`,
                        totalValueFormatted: totalValueFormatted,
                        lpLabel: lpLabel,
                        addLiquidityUrl: addLiquidityUrl
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FarmCard);

});

/***/ }),

/***/ 90922:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(18054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(34215);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(bignumber_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var components_Balance__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(20922);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(99150);
/* harmony import */ var components_Toast__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(63937);
/* harmony import */ var hooks_useToast__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(789);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var state__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(82727);
/* harmony import */ var state_farms__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(66319);
/* harmony import */ var state_farms_hooks__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8733);
/* harmony import */ var utils_bigNumber__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(35128);
/* harmony import */ var utils_formatBalance__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(65044);
/* harmony import */ var utils_sentry__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(17226);
/* harmony import */ var _hooks_useHarvestFarm__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(86507);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([state_farms_hooks__WEBPACK_IMPORTED_MODULE_11__]);
state_farms_hooks__WEBPACK_IMPORTED_MODULE_11__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];
















const HarvestAction = ({ earnings , pid  })=>{
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_2__.useWeb3React)();
    const { toastSuccess , toastError  } = (0,hooks_useToast__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_5__/* .useTranslation */ .$G)();
    const { 0: pendingTx , 1: setPendingTx  } = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)(false);
    const { onReward  } = (0,_hooks_useHarvestFarm__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z)(pid);
    const cakePrice = (0,state_farms_hooks__WEBPACK_IMPORTED_MODULE_11__/* .usePriceCakeBusd */ .Iu)();
    const dispatch = (0,state__WEBPACK_IMPORTED_MODULE_9__/* .useAppDispatch */ .TL)();
    const rawEarningsBalance = account ? (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_13__/* .getBalanceAmount */ .U4)(earnings) : utils_bigNumber__WEBPACK_IMPORTED_MODULE_12__/* .BIG_ZERO */ .HW;
    const displayBalance = rawEarningsBalance.toFixed(3, (bignumber_js__WEBPACK_IMPORTED_MODULE_3___default().ROUND_DOWN));
    const earningsBusd = rawEarningsBalance ? rawEarningsBalance.multipliedBy(cakePrice).toNumber() : 0;
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Flex, {
        mb: "8px",
        justifyContent: "space-between",
        alignItems: "center",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                flexDirection: "column",
                alignItems: "flex-start",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Heading, {
                        color: rawEarningsBalance.eq(0) ? 'textDisabled' : 'text',
                        children: displayBalance
                    }),
                    earningsBusd > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                        fontSize: "12px",
                        color: "textSubtle",
                        decimals: 2,
                        value: earningsBusd,
                        unit: " USD",
                        prefix: "~"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Button, {
                disabled: rawEarningsBalance.eq(0) || pendingTx,
                onClick: async ()=>{
                    setPendingTx(true);
                    try {
                        await onReward((tx)=>{
                            toastSuccess(`${t('Transaction Submitted')}!`, /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_6__/* .ToastDescriptionWithTx */ .YO, {
                                txHash: tx.hash
                            }));
                        }, (receipt)=>{
                            toastSuccess(`${t('Harvested')}!`, /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_6__/* .ToastDescriptionWithTx */ .YO, {
                                txHash: receipt.transactionHash,
                                children: t('Your %symbol% earnings have been sent to your wallet!', {
                                    symbol: 'CAKE'
                                })
                            }));
                        }, (receipt)=>{
                            toastError(t('Error'), /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_6__/* .ToastDescriptionWithTx */ .YO, {
                                txHash: receipt.transactionHash,
                                children: t('Please try again. Confirm the transaction and make sure you are paying enough gas!')
                            }));
                        });
                    } catch (e) {
                        toastError(t('Error'), t('Please try again. Confirm the transaction and make sure you are paying enough gas!'));
                        (0,utils_sentry__WEBPACK_IMPORTED_MODULE_14__/* .logError */ .H)(e);
                    } finally{
                        setPendingTx(false);
                    }
                    dispatch((0,state_farms__WEBPACK_IMPORTED_MODULE_10__/* .fetchFarmUserDataAsync */ .IV)({
                        account,
                        pids: [
                            pid
                        ]
                    }));
                },
                children: pendingTx ? t('Harvesting') : t('Harvest')
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HarvestAction);

});

/***/ }),

/***/ 6090:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(18054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(34215);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(bignumber_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var hooks_useToast__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(789);
/* harmony import */ var components_Balance__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(20922);
/* harmony import */ var components_Toast__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(63937);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(99150);
/* harmony import */ var state__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(82727);
/* harmony import */ var state_farms__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(66319);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var state_farms_hooks__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8733);
/* harmony import */ var utils_formatBalance__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(65044);
/* harmony import */ var _DepositModal__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(37272);
/* harmony import */ var _WithdrawModal__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(71154);
/* harmony import */ var _hooks_useUnstakeFarms__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(97321);
/* harmony import */ var _hooks_useStakeFarms__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(60508);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([state_farms_hooks__WEBPACK_IMPORTED_MODULE_13__]);
state_farms_hooks__WEBPACK_IMPORTED_MODULE_13__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];



















const IconButtonWrapper = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
    componentId: "sc-60a688e2-0"
})`
  display: flex;
  svg {
    width: 20px;
  }
`;
const StakeAction = ({ stakedBalance , tokenBalance , tokenName , pid , multiplier , apr , displayApr , addLiquidityUrl , cakePrice , lpLabel ,  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_9__/* .useTranslation */ .$G)();
    const { onStake  } = (0,_hooks_useStakeFarms__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z)(pid);
    const { onUnstake  } = (0,_hooks_useUnstakeFarms__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z)(pid);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_12__.useRouter)();
    const dispatch = (0,state__WEBPACK_IMPORTED_MODULE_10__/* .useAppDispatch */ .TL)();
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_2__.useWeb3React)();
    const lpPrice = (0,state_farms_hooks__WEBPACK_IMPORTED_MODULE_13__/* .useLpTokenPrice */ .w5)(tokenName);
    const { toastSuccess , toastError  } = (0,hooks_useToast__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)();
    const handleStake = async (amount)=>{
        await onStake(amount, (tx)=>{
            toastSuccess(`${t('Transaction Submitted')}!`, /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_8__/* .ToastDescriptionWithTx */ .YO, {
                txHash: tx.hash
            }));
        }, (receipt)=>{
            toastSuccess(`${t('Staked')}!`, /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_8__/* .ToastDescriptionWithTx */ .YO, {
                txHash: receipt.transactionHash,
                children: t('Your funds have been staked in the farm')
            }));
        }, (receipt)=>{
            toastError(t('Error'), /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_8__/* .ToastDescriptionWithTx */ .YO, {
                txHash: receipt.transactionHash,
                children: t('Please try again. Confirm the transaction and make sure you are paying enough gas!')
            }));
        });
        dispatch((0,state_farms__WEBPACK_IMPORTED_MODULE_11__/* .fetchFarmUserDataAsync */ .IV)({
            account,
            pids: [
                pid
            ]
        }));
    };
    const handleUnstake = async (amount)=>{
        await onUnstake(amount, (tx)=>{
            toastSuccess(`${t('Transaction Submitted')}!`, /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_8__/* .ToastDescriptionWithTx */ .YO, {
                txHash: tx.hash
            }));
        }, (receipt)=>{
            toastSuccess(`${t('Unstaked')}!`, /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_8__/* .ToastDescriptionWithTx */ .YO, {
                txHash: receipt.transactionHash,
                children: t('Your earnings have also been harvested to your wallet')
            }));
        }, (receipt)=>{
            toastError(t('Error'), /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_8__/* .ToastDescriptionWithTx */ .YO, {
                txHash: receipt.transactionHash,
                children: t('Please try again. Confirm the transaction and make sure you are paying enough gas!')
            }));
        });
        dispatch((0,state_farms__WEBPACK_IMPORTED_MODULE_11__/* .fetchFarmUserDataAsync */ .IV)({
            account,
            pids: [
                pid
            ]
        }));
    };
    const displayBalance = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        const stakedBalanceBigNumber = (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_14__/* .getBalanceAmount */ .U4)(stakedBalance);
        if (stakedBalanceBigNumber.gt(0) && stakedBalanceBigNumber.lt(0.0000001)) {
            return '<0.0000001';
        }
        if (stakedBalanceBigNumber.gt(0)) {
            return stakedBalanceBigNumber.toFixed(8, (bignumber_js__WEBPACK_IMPORTED_MODULE_4___default().ROUND_DOWN));
        }
        return stakedBalanceBigNumber.toFixed(3, (bignumber_js__WEBPACK_IMPORTED_MODULE_4___default().ROUND_DOWN));
    }, [
        stakedBalance
    ]);
    const [onPresentDeposit] = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.useModal)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_DepositModal__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
        max: tokenBalance,
        stakedBalance: stakedBalance,
        onConfirm: handleStake,
        tokenName: tokenName,
        multiplier: multiplier,
        lpPrice: lpPrice,
        lpLabel: lpLabel,
        apr: apr,
        displayApr: displayApr,
        addLiquidityUrl: addLiquidityUrl,
        cakePrice: cakePrice
    }));
    const [onPresentWithdraw] = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.useModal)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_WithdrawModal__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
        max: stakedBalance,
        onConfirm: handleUnstake,
        tokenName: tokenName
    }));
    const renderStakingButtons = ()=>{
        return stakedBalance.eq(0) ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Button, {
            onClick: onPresentDeposit,
            disabled: [
                'history',
                'archived'
            ].some((item)=>router.pathname.includes(item)
            ),
            children: t('Stake LP')
        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(IconButtonWrapper, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.IconButton, {
                    variant: "tertiary",
                    onClick: onPresentWithdraw,
                    mr: "6px",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.MinusIcon, {
                        color: "primary",
                        width: "14px"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.IconButton, {
                    variant: "tertiary",
                    onClick: onPresentDeposit,
                    disabled: [
                        'history',
                        'archived'
                    ].some((item)=>router.pathname.includes(item)
                    ),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.AddIcon, {
                        color: "primary",
                        width: "14px"
                    })
                })
            ]
        });
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Flex, {
        justifyContent: "space-between",
        alignItems: "center",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Flex, {
                flexDirection: "column",
                alignItems: "flex-start",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Heading, {
                        color: stakedBalance.eq(0) ? 'textDisabled' : 'text',
                        children: displayBalance()
                    }),
                    stakedBalance.gt(0) && lpPrice.gt(0) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        fontSize: "12px",
                        color: "textSubtle",
                        decimals: 2,
                        value: (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_14__/* .getBalanceNumber */ .mW)(lpPrice.times(stakedBalance)),
                        unit: " USD",
                        prefix: "~"
                    })
                ]
            }),
            renderStakingButtons()
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (StakeAction);

});

/***/ }),

/***/ 90286:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99150);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var components_NextLink__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(53629);







const FarmTabButtons = ({ hasStakeInFinishedFarms  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)();
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    let activeIndex;
    switch(router.pathname){
        case '/farms':
            activeIndex = 0;
            break;
        case '/farms/history':
            activeIndex = 1;
            break;
        case '/farms/archived':
            activeIndex = 2;
            break;
        default:
            activeIndex = 0;
            break;
    }
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Wrapper, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.ButtonMenu, {
            activeIndex: activeIndex,
            scale: "sm",
            variant: "subtle",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.ButtonMenuItem, {
                    as: components_NextLink__WEBPACK_IMPORTED_MODULE_6__/* .NextLinkFromReactRouter */ .a,
                    to: "/farms",
                    children: t('Live')
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.NotificationDot, {
                    show: hasStakeInFinishedFarms,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.ButtonMenuItem, {
                        as: components_NextLink__WEBPACK_IMPORTED_MODULE_6__/* .NextLinkFromReactRouter */ .a,
                        to: "/farms/history",
                        id: "finished-farms-button",
                        children: t('Finished')
                    })
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FarmTabButtons);
const Wrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-4161135f-0"
})`
  display: flex;
  justify-content: center;
  align-items: center;

  a {
    padding-left: 12px;
    padding-right: 12px;
  }

  ${({ theme  })=>theme.mediaQueries.sm
} {
    margin-left: 16px;
  }
`;


/***/ }),

/***/ 89048:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(99150);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var utils_getLiquidityUrlPathParts__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(51912);
/* harmony import */ var utils_addressHelpers__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(55878);
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(38328);
/* harmony import */ var components_Tags__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(69160);
/* harmony import */ var _HarvestAction__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(42286);
/* harmony import */ var _StakedAction__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(21488);
/* harmony import */ var _Apr__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(46843);
/* harmony import */ var _Multiplier__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(19701);
/* harmony import */ var _Liquidity__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(7146);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_StakedAction__WEBPACK_IMPORTED_MODULE_10__, _HarvestAction__WEBPACK_IMPORTED_MODULE_9__, _Apr__WEBPACK_IMPORTED_MODULE_11__]);
([_StakedAction__WEBPACK_IMPORTED_MODULE_10__, _HarvestAction__WEBPACK_IMPORTED_MODULE_9__, _Apr__WEBPACK_IMPORTED_MODULE_11__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);














const expandAnimation = styled_components__WEBPACK_IMPORTED_MODULE_2__.keyframes`
  from {
    max-height: 0px;
  }
  to {
    max-height: 500px;
  }
`;
const collapseAnimation = styled_components__WEBPACK_IMPORTED_MODULE_2__.keyframes`
  from {
    max-height: 500px;
  }
  to {
    max-height: 0px;
  }
`;
const Container = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-835ee594-0"
})`
  animation: ${({ expanded  })=>expanded ? styled_components__WEBPACK_IMPORTED_MODULE_2__.css`
          ${expandAnimation} 300ms linear forwards
        ` : styled_components__WEBPACK_IMPORTED_MODULE_2__.css`
          ${collapseAnimation} 300ms linear forwards
        `
};
  overflow: hidden;
  background: ${({ theme  })=>theme.colors.background
};
  display: flex;
  width: 100%;
  flex-direction: column-reverse;
  padding: 24px;

  ${({ theme  })=>theme.mediaQueries.lg
} {
    flex-direction: row;
    padding: 16px 32px;
  }
`;
const StyledLinkExternal = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.LinkExternal).withConfig({
    componentId: "sc-835ee594-1"
})`
  font-weight: 400;
`;
const StakeContainer = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-835ee594-2"
})`
  color: ${({ theme  })=>theme.colors.text
};
  align-items: center;
  display: flex;
  justify-content: space-between;

  ${({ theme  })=>theme.mediaQueries.sm
} {
    justify-content: flex-start;
  }
`;
const TagsContainer = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-835ee594-3"
})`
  display: flex;
  align-items: center;
  margin-top: 25px;

  ${({ theme  })=>theme.mediaQueries.sm
} {
    margin-top: 16px;
  }

  > div {
    height: 24px;
    padding: 0 6px;
    font-size: 14px;
    margin-right: 4px;

    svg {
      width: 14px;
    }
  }
`;
const ActionContainer = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-835ee594-4"
})`
  display: flex;
  flex-direction: column;

  ${({ theme  })=>theme.mediaQueries.sm
} {
    flex-direction: row;
    align-items: center;
    flex-grow: 1;
    flex-basis: 0;
  }
`;
const InfoContainer = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-835ee594-5"
})`
  min-width: 200px;
`;
const ValueContainer = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-835ee594-6"
})`
  display: block;

  ${({ theme  })=>theme.mediaQueries.lg
} {
    display: none;
  }
`;
const ValueWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-835ee594-7"
})`
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin: 4px 0px;
`;
const ActionPanel = ({ details , apr , multiplier , liquidity , userDataReady , expanded ,  })=>{
    const farm = details;
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_3__/* .useTranslation */ .$G)();
    const isActive = farm.multiplier !== '0X';
    const { quoteToken , token , dual  } = farm;
    const lpLabel = farm.lpSymbol && farm.lpSymbol.toUpperCase().replace('PANCAKE', '');
    const liquidityUrlPathParts = (0,utils_getLiquidityUrlPathParts__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)({
        quoteTokenAddress: quoteToken.address,
        tokenAddress: token.address
    });
    const lpAddress = (0,utils_addressHelpers__WEBPACK_IMPORTED_MODULE_6__/* .getAddress */ .Kn)(farm.lpAddresses);
    const bsc = (0,utils__WEBPACK_IMPORTED_MODULE_7__/* .getBscScanLink */ .s6)(lpAddress, 'address');
    const info = `/info/pool/${lpAddress}`;
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Container, {
        expanded: expanded,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(InfoContainer, {
                children: [
                    isActive && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StakeContainer, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledLinkExternal, {
                            href: `/add/${liquidityUrlPathParts}`,
                            children: t('Get %symbol%', {
                                symbol: lpLabel
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledLinkExternal, {
                        href: bsc,
                        children: t('View Contract')
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledLinkExternal, {
                        href: info,
                        children: t('See Pair Info')
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(TagsContainer, {
                        children: [
                            farm.isCommunity ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Tags__WEBPACK_IMPORTED_MODULE_8__/* .CommunityTag */ .vl, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Tags__WEBPACK_IMPORTED_MODULE_8__/* .CoreTag */ .eE, {}),
                            dual ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Tags__WEBPACK_IMPORTED_MODULE_8__/* .DualTag */ .YE, {}) : null
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ValueContainer, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ValueWrapper, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                                children: t('APR')
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Apr__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                ...apr
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ValueWrapper, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                                children: t('Multiplier')
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Multiplier__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                ...multiplier
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ValueWrapper, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                                children: t('Liquidity')
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Liquidity__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                ...liquidity
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ActionContainer, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_HarvestAction__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                        ...farm,
                        userDataReady: userDataReady
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_StakedAction__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                        ...farm,
                        userDataReady: userDataReady,
                        lpLabel: lpLabel,
                        displayApr: apr.value
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ActionPanel);

});

/***/ }),

/***/ 42286:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(18054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(34215);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(bignumber_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var components_Balance__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(20922);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(99150);
/* harmony import */ var components_Toast__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(63937);
/* harmony import */ var hooks_useToast__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(789);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var state__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(82727);
/* harmony import */ var state_farms__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(66319);
/* harmony import */ var state_farms_hooks__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8733);
/* harmony import */ var utils_bigNumber__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(35128);
/* harmony import */ var utils_formatBalance__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(65044);
/* harmony import */ var utils_sentry__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(17226);
/* harmony import */ var _hooks_useHarvestFarm__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(86507);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(97371);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([state_farms_hooks__WEBPACK_IMPORTED_MODULE_11__]);
state_farms_hooks__WEBPACK_IMPORTED_MODULE_11__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];

















const HarvestAction = ({ pid , userData , userDataReady  })=>{
    const { toastSuccess , toastError  } = (0,hooks_useToast__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
    const earningsBigNumber = new (bignumber_js__WEBPACK_IMPORTED_MODULE_3___default())(userData.earnings);
    const cakePrice = (0,state_farms_hooks__WEBPACK_IMPORTED_MODULE_11__/* .usePriceCakeBusd */ .Iu)();
    let earnings = utils_bigNumber__WEBPACK_IMPORTED_MODULE_12__/* .BIG_ZERO */ .HW;
    let earningsBusd = 0;
    let displayBalance = userDataReady ? earnings.toLocaleString() : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Skeleton, {
        width: 60
    });
    // If user didn't connect wallet default balance will be 0
    if (!earningsBigNumber.isZero()) {
        earnings = (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_13__/* .getBalanceAmount */ .U4)(earningsBigNumber);
        earningsBusd = earnings.multipliedBy(cakePrice).toNumber();
        displayBalance = earnings.toFixed(3, (bignumber_js__WEBPACK_IMPORTED_MODULE_3___default().ROUND_DOWN));
    }
    const { 0: pendingTx , 1: setPendingTx  } = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)(false);
    const { onReward  } = (0,_hooks_useHarvestFarm__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z)(pid);
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_5__/* .useTranslation */ .$G)();
    const dispatch = (0,state__WEBPACK_IMPORTED_MODULE_9__/* .useAppDispatch */ .TL)();
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_2__.useWeb3React)();
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styles__WEBPACK_IMPORTED_MODULE_16__/* .ActionContainer */ .sX, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styles__WEBPACK_IMPORTED_MODULE_16__/* .ActionTitles */ .Ad, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Text, {
                        bold: true,
                        textTransform: "uppercase",
                        color: "secondary",
                        fontSize: "12px",
                        pr: "4px",
                        children: "CAKE"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Text, {
                        bold: true,
                        textTransform: "uppercase",
                        color: "textSubtle",
                        fontSize: "12px",
                        children: t('Earned')
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styles__WEBPACK_IMPORTED_MODULE_16__/* .ActionContent */ .O6, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Heading, {
                                children: displayBalance
                            }),
                            earningsBusd > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                fontSize: "12px",
                                color: "textSubtle",
                                decimals: 2,
                                value: earningsBusd,
                                unit: " USD",
                                prefix: "~"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Button, {
                        disabled: earnings.eq(0) || pendingTx || !userDataReady,
                        onClick: async ()=>{
                            setPendingTx(true);
                            try {
                                await onReward((tx)=>{
                                    toastSuccess(`${t('Transaction Submitted')}!`, /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_6__/* .ToastDescriptionWithTx */ .YO, {
                                        txHash: tx.hash
                                    }));
                                }, (receipt)=>{
                                    toastSuccess(`${t('Harvested')}!`, /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_6__/* .ToastDescriptionWithTx */ .YO, {
                                        txHash: receipt.transactionHash,
                                        children: t('Your %symbol% earnings have been sent to your wallet!', {
                                            symbol: 'CAKE'
                                        })
                                    }));
                                }, (receipt)=>{
                                    toastError(t('Error'), /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_6__/* .ToastDescriptionWithTx */ .YO, {
                                        txHash: receipt.transactionHash,
                                        children: t('Please try again. Confirm the transaction and make sure you are paying enough gas!')
                                    }));
                                });
                            } catch (e) {
                                toastError(t('Error'), t('Please try again. Confirm the transaction and make sure you are paying enough gas!'));
                                (0,utils_sentry__WEBPACK_IMPORTED_MODULE_14__/* .logError */ .H)(e);
                            } finally{
                                setPendingTx(false);
                            }
                            dispatch((0,state_farms__WEBPACK_IMPORTED_MODULE_10__/* .fetchFarmUserDataAsync */ .IV)({
                                account,
                                pids: [
                                    pid
                                ]
                            }));
                        },
                        ml: "4px",
                        children: pendingTx ? t('Harvesting') : t('Harvest')
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HarvestAction);

});

/***/ }),

/***/ 21488:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(18054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(34215);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(bignumber_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var components_Balance__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(20922);
/* harmony import */ var components_ConnectWalletButton__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(30621);
/* harmony import */ var components_Toast__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(63937);
/* harmony import */ var config__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(33206);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(99150);
/* harmony import */ var hooks_useContract__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(46063);
/* harmony import */ var hooks_useToast__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(789);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var state__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(82727);
/* harmony import */ var state_farms__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(66319);
/* harmony import */ var state_farms_hooks__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(8733);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var utils_addressHelpers__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(55878);
/* harmony import */ var utils_formatBalance__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(65044);
/* harmony import */ var utils_getLiquidityUrlPathParts__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(51912);
/* harmony import */ var utils_sentry__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(17226);
/* harmony import */ var _hooks_useApproveFarm__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(76807);
/* harmony import */ var _hooks_useStakeFarms__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(60508);
/* harmony import */ var _hooks_useUnstakeFarms__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(97321);
/* harmony import */ var _DepositModal__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(37272);
/* harmony import */ var _WithdrawModal__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(71154);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(97371);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_useApproveFarm__WEBPACK_IMPORTED_MODULE_21__, state_farms_hooks__WEBPACK_IMPORTED_MODULE_15__]);
([_hooks_useApproveFarm__WEBPACK_IMPORTED_MODULE_21__, state_farms_hooks__WEBPACK_IMPORTED_MODULE_15__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);



























const IconButtonWrapper = styled_components__WEBPACK_IMPORTED_MODULE_16___default().div.withConfig({
    componentId: "sc-ca89c0fb-0"
})`
  display: flex;
`;
const Staked = ({ pid , apr , multiplier , lpSymbol , lpLabel , lpAddresses , quoteToken , token , userDataReady , displayApr ,  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_8__/* .useTranslation */ .$G)();
    const { toastSuccess , toastError  } = (0,hooks_useToast__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)();
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_2__.useWeb3React)();
    const { 0: requestedApproval , 1: setRequestedApproval  } = (0,react__WEBPACK_IMPORTED_MODULE_12__.useState)(false);
    const { allowance , tokenBalance , stakedBalance  } = (0,state_farms_hooks__WEBPACK_IMPORTED_MODULE_15__/* .useFarmUser */ .Dx)(pid);
    const { onStake  } = (0,_hooks_useStakeFarms__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .Z)(pid);
    const { onUnstake  } = (0,_hooks_useUnstakeFarms__WEBPACK_IMPORTED_MODULE_23__/* ["default"] */ .Z)(pid);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_11__.useRouter)();
    const lpPrice = (0,state_farms_hooks__WEBPACK_IMPORTED_MODULE_15__/* .useLpTokenPrice */ .w5)(lpSymbol);
    const cakePrice = (0,state_farms_hooks__WEBPACK_IMPORTED_MODULE_15__/* .usePriceCakeBusd */ .Iu)();
    const isApproved = account && allowance && allowance.isGreaterThan(0);
    const lpAddress = (0,utils_addressHelpers__WEBPACK_IMPORTED_MODULE_17__/* .getAddress */ .Kn)(lpAddresses);
    const liquidityUrlPathParts = (0,utils_getLiquidityUrlPathParts__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z)({
        quoteTokenAddress: quoteToken.address,
        tokenAddress: token.address
    });
    const addLiquidityUrl = `${config__WEBPACK_IMPORTED_MODULE_7__/* .BASE_ADD_LIQUIDITY_URL */ .wI}/${liquidityUrlPathParts}`;
    const handleStake = async (amount)=>{
        await onStake(amount, (tx)=>{
            toastSuccess(`${t('Transaction Submitted')}!`, /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_6__/* .ToastDescriptionWithTx */ .YO, {
                txHash: tx.hash
            }));
        }, (receipt)=>{
            toastSuccess(`${t('Staked')}!`, /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_6__/* .ToastDescriptionWithTx */ .YO, {
                txHash: receipt.transactionHash,
                children: t('Your funds have been staked in the farm')
            }));
        }, (receipt)=>{
            toastError(t('Error'), /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_6__/* .ToastDescriptionWithTx */ .YO, {
                txHash: receipt.transactionHash,
                children: t('Please try again. Confirm the transaction and make sure you are paying enough gas!')
            }));
        });
        dispatch((0,state_farms__WEBPACK_IMPORTED_MODULE_14__/* .fetchFarmUserDataAsync */ .IV)({
            account,
            pids: [
                pid
            ]
        }));
    };
    const handleUnstake = async (amount)=>{
        await onUnstake(amount, (tx)=>{
            toastSuccess(`${t('Transaction Submitted')}!`, /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_6__/* .ToastDescriptionWithTx */ .YO, {
                txHash: tx.hash
            }));
        }, (receipt)=>{
            toastSuccess(`${t('Unstaked')}!`, /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_6__/* .ToastDescriptionWithTx */ .YO, {
                txHash: receipt.transactionHash,
                children: t('Your earnings have also been harvested to your wallet')
            }));
        }, (receipt)=>{
            toastError(t('Error'), /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_6__/* .ToastDescriptionWithTx */ .YO, {
                txHash: receipt.transactionHash,
                children: t('Please try again. Confirm the transaction and make sure you are paying enough gas!')
            }));
        });
        dispatch((0,state_farms__WEBPACK_IMPORTED_MODULE_14__/* .fetchFarmUserDataAsync */ .IV)({
            account,
            pids: [
                pid
            ]
        }));
    };
    const displayBalance = (0,react__WEBPACK_IMPORTED_MODULE_12__.useCallback)(()=>{
        const stakedBalanceBigNumber = (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_18__/* .getBalanceAmount */ .U4)(stakedBalance);
        if (stakedBalanceBigNumber.gt(0) && stakedBalanceBigNumber.lt(0.0000001)) {
            return stakedBalanceBigNumber.toFixed(10, bignumber_js__WEBPACK_IMPORTED_MODULE_3__.BigNumber.ROUND_DOWN);
        }
        if (stakedBalanceBigNumber.gt(0) && stakedBalanceBigNumber.lt(0.0001)) {
            return (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_18__/* .getFullDisplayBalance */ .NJ)(stakedBalance).toLocaleString();
        }
        return stakedBalanceBigNumber.toFixed(3, bignumber_js__WEBPACK_IMPORTED_MODULE_3__.BigNumber.ROUND_DOWN);
    }, [
        stakedBalance
    ]);
    const [onPresentDeposit] = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.useModal)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_DepositModal__WEBPACK_IMPORTED_MODULE_24__/* ["default"] */ .Z, {
        max: tokenBalance,
        lpPrice: lpPrice,
        lpLabel: lpLabel,
        apr: apr,
        displayApr: displayApr,
        stakedBalance: stakedBalance,
        onConfirm: handleStake,
        tokenName: lpSymbol,
        multiplier: multiplier,
        addLiquidityUrl: addLiquidityUrl,
        cakePrice: cakePrice
    }));
    const [onPresentWithdraw] = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.useModal)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_WithdrawModal__WEBPACK_IMPORTED_MODULE_25__/* ["default"] */ .Z, {
        max: stakedBalance,
        onConfirm: handleUnstake,
        tokenName: lpSymbol
    }));
    const lpContract = (0,hooks_useContract__WEBPACK_IMPORTED_MODULE_9__/* .useERC20 */ .X_)(lpAddress);
    const dispatch = (0,state__WEBPACK_IMPORTED_MODULE_13__/* .useAppDispatch */ .TL)();
    const { onApprove  } = (0,_hooks_useApproveFarm__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .Z)(lpContract);
    const handleApprove = (0,react__WEBPACK_IMPORTED_MODULE_12__.useCallback)(async ()=>{
        try {
            setRequestedApproval(true);
            await onApprove((tx)=>{
                toastSuccess(`${t('Transaction Submitted')}!`, /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_6__/* .ToastDescriptionWithTx */ .YO, {
                    txHash: tx.hash
                }));
            }, (receipt)=>{
                toastSuccess(t('Contract Enabled'), /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_6__/* .ToastDescriptionWithTx */ .YO, {
                    txHash: receipt.transactionHash
                }));
            }, (receipt)=>{
                toastError(t('Error'), /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_6__/* .ToastDescriptionWithTx */ .YO, {
                    txHash: receipt.transactionHash,
                    children: t('Please try again. Confirm the transaction and make sure you are paying enough gas!')
                }));
            });
            dispatch((0,state_farms__WEBPACK_IMPORTED_MODULE_14__/* .fetchFarmUserDataAsync */ .IV)({
                account,
                pids: [
                    pid
                ]
            }));
        } catch (e) {
            toastError(t('Error'), t('Please try again. Confirm the transaction and make sure you are paying enough gas!'));
            (0,utils_sentry__WEBPACK_IMPORTED_MODULE_20__/* .logError */ .H)(e);
        } finally{
            setRequestedApproval(false);
        }
    }, [
        onApprove,
        dispatch,
        account,
        pid,
        t,
        toastError,
        toastSuccess
    ]);
    if (!account) {
        return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styles__WEBPACK_IMPORTED_MODULE_26__/* .ActionContainer */ .sX, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styles__WEBPACK_IMPORTED_MODULE_26__/* .ActionTitles */ .Ad, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Text, {
                        bold: true,
                        textTransform: "uppercase",
                        color: "textSubtle",
                        fontSize: "12px",
                        children: t('Start Farming')
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styles__WEBPACK_IMPORTED_MODULE_26__/* .ActionContent */ .O6, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_ConnectWalletButton__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        width: "100%"
                    })
                })
            ]
        }));
    }
    if (isApproved) {
        if (stakedBalance.gt(0)) {
            return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styles__WEBPACK_IMPORTED_MODULE_26__/* .ActionContainer */ .sX, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styles__WEBPACK_IMPORTED_MODULE_26__/* .ActionTitles */ .Ad, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                bold: true,
                                textTransform: "uppercase",
                                color: "secondary",
                                fontSize: "12px",
                                pr: "4px",
                                children: lpSymbol
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                bold: true,
                                textTransform: "uppercase",
                                color: "textSubtle",
                                fontSize: "12px",
                                children: t('Staked')
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styles__WEBPACK_IMPORTED_MODULE_26__/* .ActionContent */ .O6, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Heading, {
                                        children: displayBalance()
                                    }),
                                    stakedBalance.gt(0) && lpPrice.gt(0) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                        fontSize: "12px",
                                        color: "textSubtle",
                                        decimals: 2,
                                        value: (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_18__/* .getBalanceNumber */ .mW)(lpPrice.times(stakedBalance)),
                                        unit: " USD",
                                        prefix: "~"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(IconButtonWrapper, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.IconButton, {
                                        variant: "secondary",
                                        onClick: onPresentWithdraw,
                                        mr: "6px",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.MinusIcon, {
                                            color: "primary",
                                            width: "14px"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.IconButton, {
                                        variant: "secondary",
                                        onClick: onPresentDeposit,
                                        disabled: [
                                            'history',
                                            'archived'
                                        ].some((item)=>router.pathname.includes(item)
                                        ),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.AddIcon, {
                                            color: "primary",
                                            width: "14px"
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }));
        }
        return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styles__WEBPACK_IMPORTED_MODULE_26__/* .ActionContainer */ .sX, {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styles__WEBPACK_IMPORTED_MODULE_26__/* .ActionTitles */ .Ad, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Text, {
                            bold: true,
                            textTransform: "uppercase",
                            color: "textSubtle",
                            fontSize: "12px",
                            pr: "4px",
                            children: t('Stake')
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Text, {
                            bold: true,
                            textTransform: "uppercase",
                            color: "secondary",
                            fontSize: "12px",
                            children: lpSymbol
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styles__WEBPACK_IMPORTED_MODULE_26__/* .ActionContent */ .O6, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Button, {
                        width: "100%",
                        onClick: onPresentDeposit,
                        variant: "secondary",
                        disabled: [
                            'history',
                            'archived'
                        ].some((item)=>router.pathname.includes(item)
                        ),
                        children: t('Stake LP')
                    })
                })
            ]
        }));
    }
    if (!userDataReady) {
        return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styles__WEBPACK_IMPORTED_MODULE_26__/* .ActionContainer */ .sX, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styles__WEBPACK_IMPORTED_MODULE_26__/* .ActionTitles */ .Ad, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Text, {
                        bold: true,
                        textTransform: "uppercase",
                        color: "textSubtle",
                        fontSize: "12px",
                        children: t('Start Farming')
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styles__WEBPACK_IMPORTED_MODULE_26__/* .ActionContent */ .O6, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Skeleton, {
                        width: 180,
                        marginBottom: 28,
                        marginTop: 14
                    })
                })
            ]
        }));
    }
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styles__WEBPACK_IMPORTED_MODULE_26__/* .ActionContainer */ .sX, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styles__WEBPACK_IMPORTED_MODULE_26__/* .ActionTitles */ .Ad, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Text, {
                    bold: true,
                    textTransform: "uppercase",
                    color: "textSubtle",
                    fontSize: "12px",
                    children: t('Enable Farm')
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styles__WEBPACK_IMPORTED_MODULE_26__/* .ActionContent */ .O6, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Button, {
                    width: "100%",
                    disabled: requestedApproval,
                    onClick: handleApprove,
                    variant: "secondary",
                    children: t('Enable')
                })
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Staked);

});

/***/ }),

/***/ 97371:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "sX": () => (/* binding */ ActionContainer),
/* harmony export */   "Ad": () => (/* binding */ ActionTitles),
/* harmony export */   "O6": () => (/* binding */ ActionContent)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const ActionContainer = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
    componentId: "sc-5ef751c-0"
})`
  padding: 16px;
  border: 2px solid ${({ theme  })=>theme.colors.input
};
  border-radius: 16px;
  flex-grow: 1;
  flex-basis: 0;
  margin-bottom: 16px;

  ${({ theme  })=>theme.mediaQueries.sm
} {
    margin-left: 12px;
    margin-right: 12px;
    margin-bottom: 0;
    max-height: 100px;
  }

  ${({ theme  })=>theme.mediaQueries.xl
} {
    margin-left: 48px;
    margin-right: 0;
    margin-bottom: 0;
    max-height: 100px;
  }
`;
const ActionTitles = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
    componentId: "sc-5ef751c-1"
})`
  display: flex;
`;
const ActionContent = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
    componentId: "sc-5ef751c-2"
})`
  display: flex;
  justify-content: space-between;
  align-items: center;
`;


/***/ }),

/***/ 46843:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var views_Farms_components_FarmCard_ApyButton__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(75313);
/* harmony import */ var config__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(33206);
/* harmony import */ var utils_getLiquidityUrlPathParts__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(51912);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([views_Farms_components_FarmCard_ApyButton__WEBPACK_IMPORTED_MODULE_3__]);
views_Farms_components_FarmCard_ApyButton__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];







const Container = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-a667dec2-0"
})`
  display: flex;
  align-items: center;
  color: ${({ theme  })=>theme.colors.text
};

  button {
    width: 20px;
    height: 20px;

    svg {
      path {
        fill: ${({ theme  })=>theme.colors.textSubtle
};
      }
    }
  }
`;
const AprWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-a667dec2-1"
})`
  min-width: 60px;
  text-align: left;
`;
const Apr = ({ value , pid , lpLabel , lpSymbol , multiplier , tokenAddress , quoteTokenAddress , cakePrice , originalValue , hideButton =false ,  })=>{
    const liquidityUrlPathParts = (0,utils_getLiquidityUrlPathParts__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)({
        quoteTokenAddress,
        tokenAddress
    });
    const addLiquidityUrl = `${config__WEBPACK_IMPORTED_MODULE_4__/* .BASE_ADD_LIQUIDITY_URL */ .wI}/${liquidityUrlPathParts}`;
    return originalValue !== 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Container, {
        children: originalValue ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(views_Farms_components_FarmCard_ApyButton__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
            variant: hideButton ? 'text' : 'text-and-button',
            pid: pid,
            lpSymbol: lpSymbol,
            lpLabel: lpLabel,
            multiplier: multiplier,
            cakePrice: cakePrice,
            apr: originalValue,
            displayApr: value,
            addLiquidityUrl: addLiquidityUrl
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AprWrapper, {
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Skeleton, {
                width: 60
            })
        })
    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Container, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(AprWrapper, {
            children: [
                originalValue,
                "%"
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Apr);

});

/***/ }),

/***/ 60091:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);



const Label = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-7f2d9644-0"
})`
  font-size: 12px;
  color: ${({ theme  })=>theme.colors.textSubtle
};
  text-align: left;
`;
const ContentContainer = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-7f2d9644-1"
})`
  min-height: 24px;
  display: flex;
  align-items: center;
`;
const CellLayout = ({ label ='' , children  })=>{
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            label && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Label, {
                children: label
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ContentContainer, {
                children: children
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CellLayout);


/***/ }),

/***/ 34691:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99150);





const Container = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-9ad362b3-0"
})`
  display: flex;
  width: 100%;
  justify-content: flex-end;
  padding-right: 8px;
  color: ${({ theme  })=>theme.colors.primary
};

  ${({ theme  })=>theme.mediaQueries.sm
} {
    padding-right: 0px;
  }
`;
const ArrowIcon = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.ChevronDownIcon).withConfig({
    componentId: "sc-9ad362b3-1"
})`
  transform: ${({ toggled  })=>toggled ? 'rotate(180deg)' : 'rotate(0)'
};
  height: 20px;
`;
const Details = ({ actionPanelToggled  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    const { isDesktop  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.useMatchBreakpoints)();
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Container, {
        children: [
            !isDesktop && t('Details'),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ArrowIcon, {
                color: "primary",
                toggled: actionPanelToggled
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Details);


/***/ }),

/***/ 47838:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);




const Amount = styled_components__WEBPACK_IMPORTED_MODULE_2___default().span.withConfig({
    componentId: "sc-7d5a560f-0"
})`
  color: ${({ earned , theme  })=>earned ? theme.colors.text : theme.colors.textDisabled
};
  display: flex;
  align-items: center;
`;
const Earned = ({ earnings , userDataReady  })=>{
    if (userDataReady) {
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Amount, {
            earned: earnings,
            children: earnings.toLocaleString()
        }));
    }
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Amount, {
        earned: 0,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Skeleton, {
            width: 60
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Earned);


/***/ }),

/***/ 39491:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var state_farms_hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8733);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99150);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var utils_formatBalance__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(65044);
/* harmony import */ var components_TokenImage__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(95239);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([state_farms_hooks__WEBPACK_IMPORTED_MODULE_3__]);
state_farms_hooks__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];








const Container = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-69335707-0"
})`
  padding-left: 16px;
  display: flex;
  align-items: center;

  ${({ theme  })=>theme.mediaQueries.sm
} {
    padding-left: 32px;
  }
`;
const TokenWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-69335707-1"
})`
  padding-right: 8px;
  width: 24px;

  ${({ theme  })=>theme.mediaQueries.sm
} {
    width: 40px;
  }
`;
const Farm = ({ token , quoteToken , label , pid  })=>{
    const { stakedBalance  } = (0,state_farms_hooks__WEBPACK_IMPORTED_MODULE_3__/* .useFarmUser */ .Dx)(pid);
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    const rawStakedBalance = (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_6__/* .getBalanceNumber */ .mW)(stakedBalance);
    const handleRenderFarming = ()=>{
        if (rawStakedBalance) {
            return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Text, {
                color: "secondary",
                fontSize: "12px",
                bold: true,
                textTransform: "uppercase",
                children: t('Farming')
            }));
        }
        return null;
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Container, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TokenWrapper, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_TokenImage__WEBPACK_IMPORTED_MODULE_7__/* .TokenPairImage */ .q, {
                    variant: "inverted",
                    primaryToken: token,
                    secondaryToken: quoteToken,
                    width: 40,
                    height: 40
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                children: [
                    handleRenderFarming(),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Text, {
                        bold: true,
                        children: label
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Farm);

});

/***/ }),

/***/ 94121:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99150);
/* harmony import */ var _Row__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(62854);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Row__WEBPACK_IMPORTED_MODULE_5__]);
_Row__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];







const Container = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-ae6b4691-0"
})`
  filter: ${({ theme  })=>theme.card.dropShadow
};
  width: 100%;
  background: ${({ theme  })=>theme.card.background
};
  border-radius: 16px;
  margin: 16px 0px;
`;
const TableWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-ae6b4691-1"
})`
  overflow: visible;
  scroll-margin-top: 64px;

  &::-webkit-scrollbar {
    display: none;
  }
`;
const StyledTable = styled_components__WEBPACK_IMPORTED_MODULE_2___default().table.withConfig({
    componentId: "sc-ae6b4691-2"
})`
  border-collapse: collapse;
  font-size: 14px;
  border-radius: 4px;
  margin-left: auto;
  margin-right: auto;
  width: 100%;
`;
const TableBody = styled_components__WEBPACK_IMPORTED_MODULE_2___default().tbody.withConfig({
    componentId: "sc-ae6b4691-3"
})`
  & tr {
    td {
      font-size: 16px;
      vertical-align: middle;
    }
  }
`;
const TableContainer = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-ae6b4691-4"
})`
  position: relative;
`;
const ScrollButtonContainer = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-ae6b4691-5"
})`
  display: flex;
  justify-content: center;
  padding-top: 5px;
  padding-bottom: 5px;
`;
const FarmTable = (props)=>{
    const tableWrapperEl = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    const { data , columns , userDataReady  } = props;
    const { rows  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.useTable)(columns, data, {
        sortable: true,
        sortColumn: 'farm'
    });
    const scrollToTop = ()=>{
        tableWrapperEl.current.scrollIntoView({
            behavior: 'smooth'
        });
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Container, {
        id: "farms-table",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(TableContainer, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TableWrapper, {
                    ref: tableWrapperEl,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledTable, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TableBody, {
                            children: rows.map((row)=>{
                                return(/*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createElement)(_Row__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                    ...row.original,
                                    userDataReady: userDataReady,
                                    key: `table-row-${row.id}`
                                }));
                            })
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ScrollButtonContainer, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Button, {
                        variant: "text",
                        onClick: scrollToTop,
                        children: [
                            t('To Top'),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.ChevronUpIcon, {
                                color: "primary"
                            })
                        ]
                    })
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FarmTable);

});

/***/ }),

/***/ 7146:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99150);





const ReferenceElement = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-66238411-0"
})`
  display: inline-block;
`;
const LiquidityWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-66238411-1"
})`
  min-width: 110px;
  font-weight: 600;
  text-align: right;
  margin-right: 14px;

  ${({ theme  })=>theme.mediaQueries.lg
} {
    text-align: left;
    margin-right: 0;
  }
`;
const Container = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-66238411-2"
})`
  display: flex;
  align-items: center;
`;
const Liquidity = ({ liquidity  })=>{
    const displayLiquidity = liquidity && liquidity.gt(0) ? `$${Number(liquidity).toLocaleString(undefined, {
        maximumFractionDigits: 0
    })}` : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Skeleton, {
        width: 60
    });
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    const { targetRef , tooltip , tooltipVisible  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.useTooltip)(t('Total value of the funds in this farm’s liquidity pool'), {
        placement: 'top-end',
        tooltipOffset: [
            20,
            10
        ]
    });
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Container, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(LiquidityWrapper, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                    children: displayLiquidity
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ReferenceElement, {
                ref: targetRef,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.HelpIcon, {
                    color: "textSubtle"
                })
            }),
            tooltipVisible && tooltip
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Liquidity);


/***/ }),

/***/ 19701:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99150);





const ReferenceElement = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-60362715-0"
})`
  display: inline-block;
`;
const MultiplierWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-60362715-1"
})`
  color: ${({ theme  })=>theme.colors.text
};
  width: 36px;
  text-align: right;
  margin-right: 14px;

  ${({ theme  })=>theme.mediaQueries.lg
} {
    text-align: left;
    margin-right: 0;
  }
`;
const Container = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-60362715-2"
})`
  display: flex;
  align-items: center;
`;
const Multiplier = ({ multiplier  })=>{
    const displayMultiplier = multiplier ? multiplier.toLowerCase() : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Skeleton, {
        width: 30
    });
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    const tooltipContent = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                children: t('The Multiplier represents the proportion of CAKE rewards each farm receives, as a proportion of the CAKE produced each block.')
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                my: "24px",
                children: t('For example, if a 1x farm received 1 CAKE per block, a 40x farm would receive 40 CAKE per block.')
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                children: t('This amount is already included in all APR calculations for the farm.')
            })
        ]
    });
    const { targetRef , tooltip , tooltipVisible  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.useTooltip)(tooltipContent, {
        placement: 'top-end',
        tooltipOffset: [
            20,
            10
        ]
    });
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Container, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(MultiplierWrapper, {
                children: displayMultiplier
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ReferenceElement, {
                ref: targetRef,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.HelpIcon, {
                    color: "textSubtle"
                })
            }),
            tooltipVisible && tooltip
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Multiplier);


/***/ }),

/***/ 62854:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99150);
/* harmony import */ var hooks_useDelayedUnmount__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(30798);
/* harmony import */ var state_farms_hooks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8733);
/* harmony import */ var _Apr__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(46843);
/* harmony import */ var _Farm__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(39491);
/* harmony import */ var _Earned__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(47838);
/* harmony import */ var _Details__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(34691);
/* harmony import */ var _Multiplier__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(19701);
/* harmony import */ var _Liquidity__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(7146);
/* harmony import */ var _Actions_ActionPanel__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(89048);
/* harmony import */ var _CellLayout__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(60091);
/* harmony import */ var _types__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(81655);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Actions_ActionPanel__WEBPACK_IMPORTED_MODULE_13__, _Apr__WEBPACK_IMPORTED_MODULE_7__, _Farm__WEBPACK_IMPORTED_MODULE_8__, state_farms_hooks__WEBPACK_IMPORTED_MODULE_6__]);
([_Actions_ActionPanel__WEBPACK_IMPORTED_MODULE_13__, _Apr__WEBPACK_IMPORTED_MODULE_7__, _Farm__WEBPACK_IMPORTED_MODULE_8__, state_farms_hooks__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);
















const cells = {
    apr: _Apr__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z,
    farm: _Farm__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z,
    earned: _Earned__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z,
    details: _Details__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z,
    multiplier: _Multiplier__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z,
    liquidity: _Liquidity__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z
};
const CellInner = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-435c2530-0"
})`
  padding: 24px 0px;
  display: flex;
  width: 100%;
  align-items: center;
  padding-right: 8px;

  ${({ theme  })=>theme.mediaQueries.xl
} {
    padding-right: 32px;
  }
`;
const StyledTr = styled_components__WEBPACK_IMPORTED_MODULE_2___default().tr.withConfig({
    componentId: "sc-435c2530-1"
})`
  cursor: pointer;
  border-bottom: 2px solid ${({ theme  })=>theme.colors.cardBorder
};
`;
const EarnedMobileCell = styled_components__WEBPACK_IMPORTED_MODULE_2___default().td.withConfig({
    componentId: "sc-435c2530-2"
})`
  padding: 16px 0 24px 16px;
`;
const AprMobileCell = styled_components__WEBPACK_IMPORTED_MODULE_2___default().td.withConfig({
    componentId: "sc-435c2530-3"
})`
  padding-top: 16px;
  padding-bottom: 24px;
`;
const FarmMobileCell = styled_components__WEBPACK_IMPORTED_MODULE_2___default().td.withConfig({
    componentId: "sc-435c2530-4"
})`
  padding-top: 24px;
`;
const Row = (props)=>{
    const { details , userDataReady  } = props;
    const hasStakedAmount = !!(0,state_farms_hooks__WEBPACK_IMPORTED_MODULE_6__/* .useFarmUser */ .Dx)(details.pid).stakedBalance.toNumber();
    const { 0: actionPanelExpanded , 1: setActionPanelExpanded  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(hasStakedAmount);
    const shouldRenderChild = (0,hooks_useDelayedUnmount__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)(actionPanelExpanded, 300);
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    const toggleActionPanel = ()=>{
        setActionPanelExpanded(!actionPanelExpanded);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setActionPanelExpanded(hasStakedAmount);
    }, [
        hasStakedAmount
    ]);
    const { isDesktop , isMobile  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.useMatchBreakpoints)();
    const isSmallerScreen = !isDesktop;
    const tableSchema = isSmallerScreen ? _types__WEBPACK_IMPORTED_MODULE_15__/* .MobileColumnSchema */ .W : _types__WEBPACK_IMPORTED_MODULE_15__/* .DesktopColumnSchema */ .X;
    const columnNames = tableSchema.map((column)=>column.name
    );
    const handleRenderRow = ()=>{
        if (!isMobile) {
            return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledTr, {
                onClick: toggleActionPanel,
                children: Object.keys(props).map((key)=>{
                    const columnIndex = columnNames.indexOf(key);
                    if (columnIndex === -1) {
                        return null;
                    }
                    switch(key){
                        case 'details':
                            return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CellInner, {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CellLayout__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Details__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                            actionPanelToggled: actionPanelExpanded
                                        })
                                    })
                                })
                            }, key));
                        case 'apr':
                            return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CellInner, {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CellLayout__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                                        label: t('APR'),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Apr__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                            ...props.apr,
                                            hideButton: isSmallerScreen
                                        })
                                    })
                                })
                            }, key));
                        default:
                            return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CellInner, {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CellLayout__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                                        label: t(tableSchema[columnIndex].label),
                                        children: /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement(cells[key], {
                                            ...props[key],
                                            userDataReady
                                        })
                                    })
                                })
                            }, key));
                    }
                })
            }));
        }
        return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(StyledTr, {
            onClick: toggleActionPanel,
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tr", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FarmMobileCell, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CellLayout__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Farm__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                        ...props.farm
                                    })
                                })
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(EarnedMobileCell, {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CellLayout__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                                        label: t('Earned'),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Earned__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                            ...props.earned,
                                            userDataReady: userDataReady
                                        })
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AprMobileCell, {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CellLayout__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                                        label: t('APR'),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Apr__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                            ...props.apr,
                                            hideButton: true
                                        })
                                    })
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CellInner, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CellLayout__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Details__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                actionPanelToggled: actionPanelExpanded
                            })
                        })
                    })
                })
            ]
        }));
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            handleRenderRow(),
            shouldRenderChild && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tr", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                    colSpan: 6,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Actions_ActionPanel__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                        ...props,
                        expanded: actionPanelExpanded
                    })
                })
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Row);

});

/***/ }),

/***/ 59901:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var state_user_actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(46245);





const Container = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-9eaf0764-0"
})`
  margin-left: -8px;

  ${({ theme  })=>theme.mediaQueries.sm
} {
    margin-left: 0;
  }
`;
const ToggleView = ({ viewMode , onToggle  })=>{
    const handleToggle = (mode)=>{
        if (viewMode !== mode) {
            onToggle(mode);
        }
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Container, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.IconButton, {
                variant: "text",
                scale: "sm",
                id: "clickFarmCardView",
                onClick: ()=>handleToggle(state_user_actions__WEBPACK_IMPORTED_MODULE_4__/* .ViewMode.CARD */ .wO.CARD)
                ,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.CardViewIcon, {
                    color: viewMode === state_user_actions__WEBPACK_IMPORTED_MODULE_4__/* .ViewMode.CARD */ .wO.CARD ? 'primary' : 'textDisabled'
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.IconButton, {
                variant: "text",
                scale: "sm",
                id: "clickFarmTableView",
                onClick: ()=>handleToggle(state_user_actions__WEBPACK_IMPORTED_MODULE_4__/* .ViewMode.TABLE */ .wO.TABLE)
                ,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.ListViewIcon, {
                    color: viewMode === state_user_actions__WEBPACK_IMPORTED_MODULE_4__/* .ViewMode.TABLE */ .wO.TABLE ? 'primary' : 'textDisabled'
                })
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ToggleView);


/***/ }),

/***/ 71154:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(34215);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(bignumber_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var components_Modal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3725);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(99150);
/* harmony import */ var utils_formatBalance__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(65044);
/* harmony import */ var hooks_useToast__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(789);
/* harmony import */ var utils_sentry__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(17226);









const WithdrawModal = ({ onConfirm , onDismiss , max , tokenName =''  })=>{
    const { 0: val , 1: setVal  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)('');
    const { toastError  } = (0,hooks_useToast__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
    const { 0: pendingTx , 1: setPendingTx  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_5__/* .useTranslation */ .$G)();
    const fullBalance = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        return (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_6__/* .getFullDisplayBalance */ .NJ)(max);
    }, [
        max
    ]);
    const valNumber = new (bignumber_js__WEBPACK_IMPORTED_MODULE_1___default())(val);
    const fullBalanceNumber = new (bignumber_js__WEBPACK_IMPORTED_MODULE_1___default())(fullBalance);
    const handleChange = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)((e)=>{
        if (e.currentTarget.validity.valid) {
            setVal(e.currentTarget.value.replace(/,/g, '.'));
        }
    }, [
        setVal
    ]);
    const handleSelectMax = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)(()=>{
        setVal(fullBalance);
    }, [
        fullBalance,
        setVal
    ]);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Modal, {
        title: t('Unstake LP tokens'),
        onDismiss: onDismiss,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Modal__WEBPACK_IMPORTED_MODULE_4__/* .ModalInput */ .S, {
                onSelectMax: handleSelectMax,
                onChange: handleChange,
                value: val,
                max: fullBalance,
                symbol: tokenName,
                inputTitle: t('Unstake')
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(components_Modal__WEBPACK_IMPORTED_MODULE_4__/* .ModalActions */ .n, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Button, {
                        variant: "secondary",
                        onClick: onDismiss,
                        width: "100%",
                        disabled: pendingTx,
                        children: t('Cancel')
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Button, {
                        disabled: pendingTx || !valNumber.isFinite() || valNumber.eq(0) || valNumber.gt(fullBalanceNumber),
                        onClick: async ()=>{
                            setPendingTx(true);
                            try {
                                await onConfirm(val);
                                onDismiss();
                            } catch (e) {
                                (0,utils_sentry__WEBPACK_IMPORTED_MODULE_8__/* .logError */ .H)(e);
                                toastError(t('Error'), t('Please try again. Confirm the transaction and make sure you are paying enough gas!'));
                            } finally{
                                setPendingTx(false);
                            }
                        },
                        width: "100%",
                        children: pendingTx ? t('Confirming') : t('Confirm')
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WithdrawModal);


/***/ }),

/***/ 81655:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "W": () => (/* binding */ MobileColumnSchema),
/* harmony export */   "X": () => (/* binding */ DesktopColumnSchema)
/* harmony export */ });
const MobileColumnSchema = [
    {
        id: 1,
        name: 'farm',
        sortable: true,
        label: ''
    },
    {
        id: 2,
        name: 'earned',
        sortable: true,
        label: 'Earned'
    },
    {
        id: 3,
        name: 'apr',
        sortable: true,
        label: 'APR'
    },
    {
        id: 6,
        name: 'details',
        sortable: true,
        label: ''
    }, 
];
const DesktopColumnSchema = [
    {
        id: 1,
        name: 'farm',
        sortable: true,
        label: ''
    },
    {
        id: 2,
        name: 'earned',
        sortable: true,
        label: 'Earned'
    },
    {
        id: 3,
        name: 'apr',
        sortable: true,
        label: 'APR'
    },
    {
        id: 4,
        name: 'liquidity',
        sortable: true,
        label: 'Liquidity'
    },
    {
        id: 5,
        name: 'multiplier',
        sortable: true,
        label: 'Multiplier'
    },
    {
        id: 6,
        name: 'details',
        sortable: true,
        label: ''
    }, 
];


/***/ }),

/***/ 76807:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ethersproject_constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(26644);
/* harmony import */ var _ethersproject_constants__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_constants__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var hooks_useContract__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(46063);
/* harmony import */ var hooks_useCallWithGasPrice__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(71228);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks_useCallWithGasPrice__WEBPACK_IMPORTED_MODULE_3__]);
hooks_useCallWithGasPrice__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];




const useApproveFarm = (lpContract)=>{
    const masterChefContract = (0,hooks_useContract__WEBPACK_IMPORTED_MODULE_2__/* .useMasterchef */ .y8)();
    const { callWithGasPrice  } = (0,hooks_useCallWithGasPrice__WEBPACK_IMPORTED_MODULE_3__/* .useCallWithGasPrice */ .d)();
    const handleApprove = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async (onTransactionSubmitted, onSuccess, onError)=>{
        const tx = await callWithGasPrice(lpContract, 'approve', [
            masterChefContract.address,
            _ethersproject_constants__WEBPACK_IMPORTED_MODULE_1__.MaxUint256
        ]);
        onTransactionSubmitted(tx);
        const receipt = await tx.wait();
        if (receipt.status) {
            onSuccess(receipt);
        } else {
            onError(receipt);
        }
    }, [
        lpContract,
        masterChefContract,
        callWithGasPrice
    ]);
    return {
        onApprove: handleApprove
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useApproveFarm);

});

/***/ }),

/***/ 86507:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var utils_calls__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(50059);
/* harmony import */ var hooks_useContract__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(46063);



const useHarvestFarm = (farmPid)=>{
    const masterChefContract = (0,hooks_useContract__WEBPACK_IMPORTED_MODULE_2__/* .useMasterchef */ .y8)();
    const handleHarvest = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async (onTransactionSubmitted, onSuccess, onError)=>{
        const tx = await (0,utils_calls__WEBPACK_IMPORTED_MODULE_1__/* .harvestFarm */ .sA)(masterChefContract, farmPid);
        onTransactionSubmitted(tx);
        const receipt = await tx.wait();
        if (receipt.status) {
            onSuccess(receipt);
        } else {
            onError(receipt);
        }
    }, [
        farmPid,
        masterChefContract
    ]);
    return {
        onReward: handleHarvest
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useHarvestFarm);


/***/ }),

/***/ 60508:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var utils_calls__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(50059);
/* harmony import */ var hooks_useContract__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(46063);



const useStakeFarms = (pid)=>{
    const masterChefContract = (0,hooks_useContract__WEBPACK_IMPORTED_MODULE_2__/* .useMasterchef */ .y8)();
    const handleStake = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async (amount, onTransactionSubmitted, onSuccess, onError)=>{
        const tx = await (0,utils_calls__WEBPACK_IMPORTED_MODULE_1__/* .stakeFarm */ .AQ)(masterChefContract, pid, amount);
        onTransactionSubmitted(tx);
        const receipt = await tx.wait();
        if (receipt.status) {
            onSuccess(receipt);
        } else {
            onError(receipt);
        }
    }, [
        masterChefContract,
        pid
    ]);
    return {
        onStake: handleStake
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useStakeFarms);


/***/ }),

/***/ 97321:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var utils_calls__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(50059);
/* harmony import */ var hooks_useContract__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(46063);



const useUnstakeFarms = (pid)=>{
    const masterChefContract = (0,hooks_useContract__WEBPACK_IMPORTED_MODULE_2__/* .useMasterchef */ .y8)();
    const handleUnstake = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async (amount, onTransactionSubmitted, onSuccess, onError)=>{
        const tx = await (0,utils_calls__WEBPACK_IMPORTED_MODULE_1__/* .unstakeFarm */ .dU)(masterChefContract, pid, amount);
        onTransactionSubmitted(tx);
        const receipt = await tx.wait();
        if (receipt.status) {
            onSuccess(receipt);
        } else {
            onError(receipt);
        }
    }, [
        masterChefContract,
        pid
    ]);
    return {
        onUnstake: handleUnstake
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useUnstakeFarms);


/***/ }),

/***/ 83210:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "S": () => (/* binding */ FarmsPageLayout),
/* harmony export */   "G": () => (/* reexport safe */ _Farms__WEBPACK_IMPORTED_MODULE_2__.GX)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Farms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(48969);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Farms__WEBPACK_IMPORTED_MODULE_2__]);
_Farms__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];



const FarmsPageLayout = ({ children  })=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Farms__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
        children: children
    }));
};


});

/***/ })

};
;
//# sourceMappingURL=234.js.map