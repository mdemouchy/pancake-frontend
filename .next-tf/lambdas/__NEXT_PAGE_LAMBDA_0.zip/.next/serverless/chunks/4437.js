"use strict";
exports.id = 4437;
exports.ids = [4437];
exports.modules = {

/***/ 74437:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "q": () => (/* binding */ useGetCollectionDistributionPB),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var state_nftMarket_helpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(86849);
/* harmony import */ var utils_addressHelpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(55878);
/* harmony import */ var utils_multicall__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(41144);
/* harmony import */ var config_abi_pancakeRabbits_json__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(32538);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1940);






const useGetCollectionDistribution = (collectionAddress)=>{
    const { 0: state , 1: setState  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({
        isFetching: false,
        data: null
    });
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        const fetchTokens = async ()=>{
            setState((prevState)=>({
                    ...prevState,
                    isFetching: true
                })
            );
            const apiResponse = await (0,state_nftMarket_helpers__WEBPACK_IMPORTED_MODULE_1__/* .getCollectionDistributionApi */ .iE)(collectionAddress);
            setState({
                isFetching: false,
                data: apiResponse.data
            });
        };
        fetchTokens();
    }, [
        collectionAddress,
        setState
    ]);
    return state;
};
const useGetCollectionDistributionPB = ()=>{
    const { 0: state , 1: setState  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({
        isFetching: false,
        data: null
    });
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        const fetchTokens = async ()=>{
            setState((prevState)=>({
                    ...prevState,
                    isFetching: true
                })
            );
            let apiResponse;
            try {
                apiResponse = await (0,state_nftMarket_helpers__WEBPACK_IMPORTED_MODULE_1__/* .getNftsFromCollectionApi */ .Rq)(_constants__WEBPACK_IMPORTED_MODULE_5__/* .pancakeBunniesAddress */ .Jr);
            } catch (error) {
                setState((prevState)=>({
                        ...prevState,
                        isFetching: false
                    })
                );
                return;
            }
            // Use on chain data to get most updated totalSupply and bunnyCount data. Nft Api Data not updated frequently.
            const tokenIds = Object.keys(apiResponse.attributesDistribution);
            const bunnyCountCalls = tokenIds.map((tokenId)=>({
                    address: (0,utils_addressHelpers__WEBPACK_IMPORTED_MODULE_2__/* .getPancakeRabbitsAddress */ .Bs)(),
                    name: 'bunnyCount',
                    params: [
                        tokenId
                    ]
                })
            );
            try {
                const response = await (0,utils_multicall__WEBPACK_IMPORTED_MODULE_3__/* .multicallv2 */ .v)(config_abi_pancakeRabbits_json__WEBPACK_IMPORTED_MODULE_4__, bunnyCountCalls);
                const tokenListResponse = response.reduce((obj, tokenCount, index)=>{
                    return {
                        ...obj,
                        [tokenIds[index]]: {
                            ...apiResponse.data[index],
                            tokenCount: tokenCount[0].toNumber()
                        }
                    };
                }, {});
                setState({
                    isFetching: false,
                    data: tokenListResponse
                });
            } catch (error1) {
                // Use nft api data if on chain multicall fails
                const tokenListResponse = Object.entries(apiResponse.data).reduce((obj, [tokenId, tokenData])=>{
                    return {
                        ...obj,
                        [tokenId]: {
                            ...tokenData,
                            tokenCount: apiResponse.attributesDistribution[tokenId]
                        }
                    };
                }, {});
                setState({
                    isFetching: false,
                    data: tokenListResponse
                });
            }
        };
        fetchTokens();
    }, []);
    return state;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useGetCollectionDistribution);


/***/ })

};
;
//# sourceMappingURL=4437.js.map