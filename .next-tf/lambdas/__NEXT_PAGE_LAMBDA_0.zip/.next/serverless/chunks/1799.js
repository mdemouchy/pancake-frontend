"use strict";
exports.id = 1799;
exports.ids = [1799];
exports.modules = {

/***/ 71418:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useCatchTxError)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(99150);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(18054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var components_Toast__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(63937);
/* harmony import */ var hooks_useToast__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(789);
/* harmony import */ var utils_sentry__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(17226);







// -32000 is insufficient funds for gas * price + value
const isGasEstimationError = (err)=>err?.data?.code === -32000
;
function useCatchTxError() {
    const { library  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_3__.useWeb3React)();
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_2__/* .useTranslation */ .$G)();
    const { toastError , toastSuccess  } = (0,hooks_useToast__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)();
    const { 0: loading , 1: setLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const handleNormalError = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((error, tx)=>{
        (0,utils_sentry__WEBPACK_IMPORTED_MODULE_6__/* .logError */ .H)(error);
        if (tx) {
            toastError(t('Error'), /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_4__/* .ToastDescriptionWithTx */ .YO, {
                txHash: tx.hash,
                children: t('Please try again. Confirm the transaction and make sure you are paying enough gas!')
            }));
        } else {
            toastError(t('Error'), t('Please try again. Confirm the transaction and make sure you are paying enough gas!'));
        }
    }, [
        t,
        toastError
    ]);
    const fetchWithCatchTxError = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(async (callTx)=>{
        let tx = null;
        try {
            setLoading(true);
            /**
         * https://github.com/vercel/swr/pull/1450
         *
         * wait for useSWRMutation finished, so we could apply SWR in case manually trigger tx call
         */ tx = await callTx();
            toastSuccess(`${t('Transaction Submitted')}!`, /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_4__/* .ToastDescriptionWithTx */ .YO, {
                txHash: tx.hash
            }));
            const receipt = await tx.wait();
            return receipt;
        } catch (error) {
            if (!(0,utils_sentry__WEBPACK_IMPORTED_MODULE_6__/* .isUserRejected */ .Z)(error)) {
                if (!tx) {
                    handleNormalError(error);
                } else {
                    library.call(tx, tx.blockNumber).then(()=>{
                        handleNormalError(error, tx);
                    }).catch((err)=>{
                        if (isGasEstimationError(err)) {
                            handleNormalError(error, tx);
                        } else {
                            (0,utils_sentry__WEBPACK_IMPORTED_MODULE_6__/* .logError */ .H)(err);
                            let recursiveErr = err;
                            let reason;
                            // for MetaMask
                            if (recursiveErr?.data?.message) {
                                reason = recursiveErr?.data?.message;
                            } else {
                                // for other wallets
                                // Reference
                                // https://github.com/Uniswap/interface/blob/ac962fb00d457bc2c4f59432d7d6d7741443dfea/src/hooks/useSwapCallback.tsx#L216-L222
                                while(recursiveErr){
                                    reason = (recursiveErr.reason ?? recursiveErr.message) ?? reason;
                                    recursiveErr = recursiveErr.error ?? recursiveErr.data?.originalError;
                                }
                            }
                            const REVERT_STR = 'execution reverted: ';
                            const indexInfo = reason?.indexOf(REVERT_STR);
                            const isRevertedError = indexInfo >= 0;
                            if (isRevertedError) reason = reason.substr(indexInfo + REVERT_STR.length);
                            toastError('Failed', /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_4__/* .ToastDescriptionWithTx */ .YO, {
                                txHash: tx.hash,
                                children: isRevertedError ? `Transaction failed with error: ${reason}` : 'Transaction failed. For detailed error message:'
                            }));
                        }
                    });
                }
            }
        } finally{
            setLoading(false);
        }
        return null;
    }, [
        handleNormalError,
        toastError,
        library,
        toastSuccess,
        t
    ]);
    return {
        fetchWithCatchTxError,
        loading
    };
};


/***/ }),

/***/ 14011:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C": () => (/* binding */ secondsToDay)
/* harmony export */ });
const secondsToDay = (s)=>Math.floor(s / (24 * 60 * 60))
;


/***/ }),

/***/ 72868:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(99150);
/* harmony import */ var state_pools_hooks__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1624);
/* harmony import */ var utils_timeHelper__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(14011);
/* harmony import */ var _hooks_useWithdrawalFeeTimer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(99119);
/* harmony import */ var _UnstakingFeeCountdownRow__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(59116);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_UnstakingFeeCountdownRow__WEBPACK_IMPORTED_MODULE_6__, state_pools_hooks__WEBPACK_IMPORTED_MODULE_4__]);
([_UnstakingFeeCountdownRow__WEBPACK_IMPORTED_MODULE_6__, state_pools_hooks__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);








const FeeSummary = ({ stakingTokenSymbol , stakeAmount , vaultKey  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_3__/* .useTranslation */ .$G)();
    const { fees: { withdrawalFee , withdrawalFeePeriod  } , userData: { lastDepositedTime  } ,  } = (0,state_pools_hooks__WEBPACK_IMPORTED_MODULE_4__/* .useVaultPoolByKey */ .eB)(vaultKey);
    const feeAsDecimal = withdrawalFee / 100;
    const feeInCake = (parseFloat(stakeAmount) * (feeAsDecimal / 100)).toFixed(4);
    const withdrawalDayPeriod = withdrawalFeePeriod ? (0,utils_timeHelper__WEBPACK_IMPORTED_MODULE_7__/* .secondsToDay */ .C)(withdrawalFeePeriod) : '-';
    const { targetRef , tooltip , tooltipVisible  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.useTooltip)(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                bold: true,
                mb: "4px",
                children: t('Unstaking fee: %fee%%', {
                    fee: feeAsDecimal
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                children: t('Only applies within %num% days of staking. Unstaking after %num% days will not include a fee. Timer resets every time you stake new CAKE in the pool.', {
                    num: withdrawalDayPeriod
                })
            })
        ]
    }), {
        placement: 'top-start'
    });
    const hasFeeToPay = lastDepositedTime && (0,_hooks_useWithdrawalFeeTimer__WEBPACK_IMPORTED_MODULE_5__/* .getHasWithdrawFee */ .D)(parseInt(lastDepositedTime, 10), withdrawalFeePeriod);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                mt: "24px",
                alignItems: "center",
                justifyContent: "space-between",
                children: [
                    tooltipVisible && tooltip,
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.TooltipText, {
                        ref: targetRef,
                        small: true,
                        children: t('Unstaking Fee')
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        fontSize: "14px",
                        children: [
                            stakeAmount && hasFeeToPay ? feeInCake : '-',
                            " ",
                            stakingTokenSymbol
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UnstakingFeeCountdownRow__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                vaultKey: vaultKey
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FeeSummary);

});

/***/ }),

/***/ 59116:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(99150);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(18054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var views_Pools_hooks_useWithdrawalFeeTimer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(99119);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(74146);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(date_fns__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var state_pools_hooks__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1624);
/* harmony import */ var utils_timeHelper__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(14011);
/* harmony import */ var _WithdrawalFeeTimer__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(22949);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([state_pools_hooks__WEBPACK_IMPORTED_MODULE_7__]);
state_pools_hooks__WEBPACK_IMPORTED_MODULE_7__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];










const UnstakingFeeCountdownRow = ({ isTableVariant , vaultKey  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_3__/* .useTranslation */ .$G)();
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_4__.useWeb3React)();
    const { userData: { lastDepositedTime , userShares  } , fees: { withdrawalFee , withdrawalFeePeriod  } ,  } = (0,state_pools_hooks__WEBPACK_IMPORTED_MODULE_7__/* .useVaultPoolByKey */ .eB)(vaultKey);
    const feeAsDecimal = withdrawalFee / 100 || '-';
    const withdrawalDayPeriod = withdrawalFeePeriod ? (0,utils_timeHelper__WEBPACK_IMPORTED_MODULE_9__/* .secondsToDay */ .C)(withdrawalFeePeriod) : '-';
    const { targetRef , tooltip , tooltipVisible  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.useTooltip)(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                bold: true,
                mb: "4px",
                children: t('Unstaking fee: %fee%%', {
                    fee: feeAsDecimal
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                children: t('Only applies within %num% days of staking. Unstaking after %num% days will not include a fee. Timer resets every time you stake new CAKE in the pool.', {
                    num: withdrawalDayPeriod
                })
            })
        ]
    }), {
        placement: 'bottom-start'
    });
    const { secondsRemaining , hasUnstakingFee  } = (0,views_Pools_hooks_useWithdrawalFeeTimer__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)(parseInt(lastDepositedTime, 10), userShares, withdrawalFeePeriod);
    // The user has made a deposit, but has no fee
    const noFeeToPay = lastDepositedTime && !hasUnstakingFee && userShares.gt(0);
    // Show the timer if a user is connected, has deposited, and has an unstaking fee
    const shouldShowTimer = account && lastDepositedTime && hasUnstakingFee;
    const withdrawalFeePeriodHour = withdrawalFeePeriod ? (0,date_fns__WEBPACK_IMPORTED_MODULE_6__.secondsToHours)(withdrawalFeePeriod) : '-';
    const getRowText = ()=>{
        if (noFeeToPay) {
            return t('Unstaking Fee');
        }
        if (shouldShowTimer) {
            return t('unstaking fee until');
        }
        return t('unstaking fee if withdrawn within %num%h', {
            num: withdrawalFeePeriodHour
        });
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
        alignItems: isTableVariant ? 'flex-start' : 'center',
        justifyContent: "space-between",
        flexDirection: isTableVariant ? 'column' : 'row',
        children: [
            tooltipVisible && tooltip,
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.TooltipText, {
                ref: targetRef,
                small: true,
                textTransform: "lowercase",
                children: [
                    noFeeToPay ? '0' : feeAsDecimal,
                    "% ",
                    getRowText()
                ]
            }),
            shouldShowTimer && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_WithdrawalFeeTimer__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                secondsRemaining: secondsRemaining
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (UnstakingFeeCountdownRow);

});

/***/ }),

/***/ 1799:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99150);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(18054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var state__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(82727);
/* harmony import */ var utils_bigNumber__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(35128);
/* harmony import */ var state_farms_hooks__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8733);
/* harmony import */ var state_pools_hooks__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1624);
/* harmony import */ var hooks_useContract__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(46063);
/* harmony import */ var hooks_useTheme__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(23917);
/* harmony import */ var views_Pools_hooks_useWithdrawalFeeTimer__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(99119);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(34215);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(bignumber_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var utils_formatBalance__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(65044);
/* harmony import */ var hooks_useToast__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(789);
/* harmony import */ var hooks_useCatchTxError__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(71418);
/* harmony import */ var state_pools__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(13591);
/* harmony import */ var state_types__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(45101);
/* harmony import */ var utils_compoundApyHelpers__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(16395);
/* harmony import */ var components_RoiCalculatorModal__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(46414);
/* harmony import */ var components_Toast__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(63937);
/* harmony import */ var config_constants_pools__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(71080);
/* harmony import */ var hooks_useCallWithGasPrice__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(71228);
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(53136);
/* harmony import */ var _FeeSummary__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(72868);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_FeeSummary__WEBPACK_IMPORTED_MODULE_24__, state_farms_hooks__WEBPACK_IMPORTED_MODULE_8__, hooks_useTheme__WEBPACK_IMPORTED_MODULE_11__, state_pools_hooks__WEBPACK_IMPORTED_MODULE_9__, hooks_useCallWithGasPrice__WEBPACK_IMPORTED_MODULE_22__]);
([_FeeSummary__WEBPACK_IMPORTED_MODULE_24__, state_farms_hooks__WEBPACK_IMPORTED_MODULE_8__, hooks_useTheme__WEBPACK_IMPORTED_MODULE_11__, state_pools_hooks__WEBPACK_IMPORTED_MODULE_9__, hooks_useCallWithGasPrice__WEBPACK_IMPORTED_MODULE_22__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);


























const StyledButton = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Button).withConfig({
    componentId: "sc-5336081b-0"
})`
  flex-grow: 1;
`;
const AnnualRoiContainer = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex).withConfig({
    componentId: "sc-5336081b-1"
})`
  cursor: pointer;
`;
const AnnualRoiDisplay = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text).withConfig({
    componentId: "sc-5336081b-2"
})`
  width: 72px;
  max-width: 72px;
  overflow: hidden;
  text-align: right;
  text-overflow: ellipsis;
`;
const CreditEndNotice = ()=>{
    const { hasEndBlockOver  } = (0,state_pools_hooks__WEBPACK_IMPORTED_MODULE_9__/* .useIfoPoolCreditBlock */ .Ab)();
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    if (!hasEndBlockOver) return null;
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Box, {
        maxWidth: "350px",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Message, {
            variant: "warning",
            mb: "16px",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.MessageText, {
                children: t('The latest credit calculation period has ended. Calculation will resume upon the next period starts.')
            })
        })
    }));
};
const VaultStakeModal = ({ pool , stakingMax , performanceFee , isRemovingStake =false , onDismiss ,  })=>{
    const dispatch = (0,state__WEBPACK_IMPORTED_MODULE_6__/* .useAppDispatch */ .TL)();
    const { stakingToken , earningToken , apr , rawApr , stakingTokenPrice , earningTokenPrice , vaultKey  } = pool;
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_5__.useWeb3React)();
    const { fetchWithCatchTxError , loading: pendingTx  } = (0,hooks_useCatchTxError__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z)();
    const vaultPoolContract = (0,hooks_useContract__WEBPACK_IMPORTED_MODULE_10__/* .useVaultPoolContract */ .Ak)(pool.vaultKey);
    const { callWithGasPrice  } = (0,hooks_useCallWithGasPrice__WEBPACK_IMPORTED_MODULE_22__/* .useCallWithGasPrice */ .d)();
    const { userData: { lastDepositedTime , userShares  } , pricePerFullShare ,  } = (0,state_pools_hooks__WEBPACK_IMPORTED_MODULE_9__/* .useVaultPoolByKey */ .eB)(pool.vaultKey);
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    const { theme  } = (0,hooks_useTheme__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z)();
    const { toastSuccess  } = (0,hooks_useToast__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z)();
    const { 0: stakeAmount , 1: setStakeAmount  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const { 0: percent , 1: setPercent  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const { 0: showRoiCalculator , 1: setShowRoiCalculator  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { hasUnstakingFee  } = (0,views_Pools_hooks_useWithdrawalFeeTimer__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z)(parseInt(lastDepositedTime, 10), userShares);
    const cakePriceBusd = (0,state_farms_hooks__WEBPACK_IMPORTED_MODULE_8__/* .usePriceCakeBusd */ .Iu)();
    const usdValueStaked = new (bignumber_js__WEBPACK_IMPORTED_MODULE_13___default())(stakeAmount).times(cakePriceBusd);
    const formattedUsdValueStaked = cakePriceBusd.gt(0) && stakeAmount ? (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_14__/* .formatNumber */ .uf)(usdValueStaked.toNumber()) : '';
    const callOptions = {
        gasLimit: config_constants_pools__WEBPACK_IMPORTED_MODULE_21__/* .vaultPoolConfig */ .Y[pool.vaultKey].gasLimit
    };
    const { cakeAsBigNumber  } = (0,_helpers__WEBPACK_IMPORTED_MODULE_23__/* .convertSharesToCake */ .ur)(userShares, pricePerFullShare);
    const interestBreakdown = (0,utils_compoundApyHelpers__WEBPACK_IMPORTED_MODULE_25__/* .getInterestBreakdown */ .A1)({
        principalInUSD: !usdValueStaked.isNaN() ? usdValueStaked.toNumber() : 0,
        apr: vaultKey ? rawApr : apr,
        earningTokenPrice,
        performanceFee
    });
    const annualRoi = interestBreakdown[3] * pool.earningTokenPrice;
    const formattedAnnualRoi = (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_14__/* .formatNumber */ .uf)(annualRoi, annualRoi > 10000 ? 0 : 2, annualRoi > 10000 ? 0 : 2);
    const getTokenLink = stakingToken.address ? `/swap?outputCurrency=${stakingToken.address}` : '/swap';
    const handleStakeInputChange = (input)=>{
        if (input) {
            const convertedInput = new (bignumber_js__WEBPACK_IMPORTED_MODULE_13___default())(input).multipliedBy(utils_bigNumber__WEBPACK_IMPORTED_MODULE_7__/* .BIG_TEN.pow */ .xp.pow(stakingToken.decimals));
            const percentage = Math.floor(convertedInput.dividedBy(stakingMax).multipliedBy(100).toNumber());
            setPercent(percentage > 100 ? 100 : percentage);
        } else {
            setPercent(0);
        }
        setStakeAmount(input);
    };
    const handleChangePercent = (sliderPercent)=>{
        if (sliderPercent > 0) {
            const percentageOfStakingMax = stakingMax.dividedBy(100).multipliedBy(sliderPercent);
            const amountToStake = (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_14__/* .getFullDisplayBalance */ .NJ)(percentageOfStakingMax, stakingToken.decimals, stakingToken.decimals);
            setStakeAmount(amountToStake);
        } else {
            setStakeAmount('');
        }
        setPercent(sliderPercent);
    };
    const handleWithdrawal = async (convertedStakeAmount)=>{
        const shareStakeToWithdraw = (0,_helpers__WEBPACK_IMPORTED_MODULE_23__/* .convertCakeToShares */ .CE)(convertedStakeAmount, pricePerFullShare);
        // trigger withdrawAll function if the withdrawal will leave 0.000001 CAKE or less
        const triggerWithdrawAllThreshold = new (bignumber_js__WEBPACK_IMPORTED_MODULE_13___default())(1000000000000);
        const sharesRemaining = userShares.minus(shareStakeToWithdraw.sharesAsBigNumber);
        const isWithdrawingAll = sharesRemaining.lte(triggerWithdrawAllThreshold);
        const receipt = await fetchWithCatchTxError(()=>{
            // .toString() being called to fix a BigNumber error in prod
            // as suggested here https://github.com/ChainSafe/web3.js/issues/2077
            return isWithdrawingAll ? callWithGasPrice(vaultPoolContract, 'withdrawAll', undefined, callOptions) : callWithGasPrice(vaultPoolContract, 'withdraw', [
                shareStakeToWithdraw.sharesAsBigNumber.toString()
            ], callOptions);
        });
        if (receipt?.status) {
            toastSuccess(t('Unstaked!'), /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_20__/* .ToastDescriptionWithTx */ .YO, {
                txHash: receipt.transactionHash,
                children: t('Your earnings have also been harvested to your wallet')
            }));
            onDismiss();
            dispatch((0,state_pools__WEBPACK_IMPORTED_MODULE_17__/* .fetchCakeVaultUserData */ .x$)({
                account
            }));
        }
    };
    const handleDeposit = async (convertedStakeAmount)=>{
        const receipt = await fetchWithCatchTxError(async ()=>{
            // .toString() being called to fix a BigNumber error in prod
            // as suggested here https://github.com/ChainSafe/web3.js/issues/2077
            return callWithGasPrice(vaultPoolContract, 'deposit', [
                convertedStakeAmount.toString()
            ], callOptions);
        });
        if (receipt?.status) {
            toastSuccess(t('Staked!'), /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_20__/* .ToastDescriptionWithTx */ .YO, {
                txHash: receipt.transactionHash,
                children: t('Your funds have been staked in the pool')
            }));
            onDismiss();
            dispatch((0,state_pools__WEBPACK_IMPORTED_MODULE_17__/* .fetchCakeVaultUserData */ .x$)({
                account
            }));
        }
    };
    const handleConfirmClick = async ()=>{
        const convertedStakeAmount = (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_14__/* .getDecimalAmount */ .Qe)(new (bignumber_js__WEBPACK_IMPORTED_MODULE_13___default())(stakeAmount), stakingToken.decimals);
        if (isRemovingStake) {
            // unstaking
            handleWithdrawal(convertedStakeAmount);
        } else {
            // staking
            handleDeposit(convertedStakeAmount);
        }
    };
    if (showRoiCalculator) {
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_RoiCalculatorModal__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z, {
            earningTokenPrice: earningTokenPrice,
            stakingTokenPrice: stakingTokenPrice,
            apr: vaultKey ? rawApr : apr,
            linkLabel: t('Get %symbol%', {
                symbol: stakingToken.symbol
            }),
            linkHref: getTokenLink,
            stakingTokenBalance: cakeAsBigNumber.plus(stakingMax),
            stakingTokenSymbol: stakingToken.symbol,
            earningTokenSymbol: earningToken.symbol,
            onBack: ()=>setShowRoiCalculator(false)
            ,
            initialValue: stakeAmount,
            performanceFee: performanceFee
        }));
    }
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Modal, {
        title: isRemovingStake ? t('Unstake') : t('Stake in Pool'),
        onDismiss: onDismiss,
        headerBackground: theme.colors.gradients.cardHeader,
        children: [
            pool.vaultKey === state_types__WEBPACK_IMPORTED_MODULE_18__/* .VaultKey.IfoPool */ .om.IfoPool && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CreditEndNotice, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                alignItems: "center",
                justifyContent: "space-between",
                mb: "8px",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                        bold: true,
                        children: [
                            isRemovingStake ? t('Unstake') : t('Stake'),
                            ":"
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                        alignItems: "center",
                        minWidth: "70px",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Image, {
                                src: `/images/tokens/${stakingToken.address}.png`,
                                width: 24,
                                height: 24,
                                alt: stakingToken.symbol
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                ml: "4px",
                                bold: true,
                                children: stakingToken.symbol
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.BalanceInput, {
                value: stakeAmount,
                onUserInput: handleStakeInputChange,
                currencyValue: cakePriceBusd.gt(0) && `~${formattedUsdValueStaked || 0} USD`,
                decimals: stakingToken.decimals
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                mt: "8px",
                ml: "auto",
                color: "textSubtle",
                fontSize: "12px",
                mb: "8px",
                children: t('Balance: %balance%', {
                    balance: (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_14__/* .getFullDisplayBalance */ .NJ)(stakingMax, stakingToken.decimals)
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Slider, {
                min: 0,
                max: 100,
                value: percent,
                onValueChanged: handleChangePercent,
                name: "stake",
                valueLabel: `${percent}%`,
                step: 1
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                alignItems: "center",
                justifyContent: "space-between",
                mt: "8px",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledButton, {
                        scale: "xs",
                        mx: "2px",
                        p: "4px 16px",
                        variant: "tertiary",
                        onClick: ()=>handleChangePercent(25)
                        ,
                        children: "25%"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledButton, {
                        scale: "xs",
                        mx: "2px",
                        p: "4px 16px",
                        variant: "tertiary",
                        onClick: ()=>handleChangePercent(50)
                        ,
                        children: "50%"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledButton, {
                        scale: "xs",
                        mx: "2px",
                        p: "4px 16px",
                        variant: "tertiary",
                        onClick: ()=>handleChangePercent(75)
                        ,
                        children: "75%"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledButton, {
                        scale: "xs",
                        mx: "2px",
                        p: "4px 16px",
                        variant: "tertiary",
                        onClick: ()=>handleChangePercent(100)
                        ,
                        children: t('Max')
                    })
                ]
            }),
            isRemovingStake && hasUnstakingFee && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_FeeSummary__WEBPACK_IMPORTED_MODULE_24__/* ["default"] */ .Z, {
                vaultKey: vaultKey,
                stakingTokenSymbol: stakingToken.symbol,
                stakeAmount: stakeAmount
            }),
            !isRemovingStake && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                mt: "24px",
                alignItems: "center",
                justifyContent: "space-between",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                        mr: "8px",
                        color: "textSubtle",
                        children: [
                            t('Annual ROI at current rates'),
                            ":"
                        ]
                    }),
                    Number.isFinite(annualRoi) ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(AnnualRoiContainer, {
                        alignItems: "center",
                        onClick: ()=>{
                            setShowRoiCalculator(true);
                        },
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(AnnualRoiDisplay, {
                                children: [
                                    "$",
                                    formattedAnnualRoi
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.IconButton, {
                                variant: "text",
                                scale: "sm",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.CalculateIcon, {
                                    color: "textSubtle",
                                    width: "18px"
                                })
                            })
                        ]
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Skeleton, {
                        width: 60
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Button, {
                isLoading: pendingTx,
                endIcon: pendingTx ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.AutoRenewIcon, {
                    spin: true,
                    color: "currentColor"
                }) : null,
                onClick: handleConfirmClick,
                disabled: !stakeAmount || parseFloat(stakeAmount) === 0,
                mt: "24px",
                children: pendingTx ? t('Confirming') : t('Confirm')
            }),
            !isRemovingStake && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Button, {
                mt: "8px",
                as: "a",
                external: true,
                href: getTokenLink,
                variant: "secondary",
                children: t('Get %symbol%', {
                    symbol: stakingToken.symbol
                })
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (VaultStakeModal);

});

/***/ }),

/***/ 22949:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var utils_getTimePeriods__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(87218);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(99150);





const WithdrawalFeeTimer = ({ secondsRemaining  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_3__/* .useTranslation */ .$G)();
    const { days , hours , minutes  } = (0,utils_getTimePeriods__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)(secondsRemaining);
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
        fontSize: "14px",
        children: t('%day%d : %hour%h : %minute%m', {
            day: days,
            hour: hours,
            minute: minutes
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WithdrawalFeeTimer);


/***/ }),

/***/ 99119:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D": () => (/* binding */ getHasWithdrawFee),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const getHasWithdrawFee = (lastDepositedTime, withdrawalFeePeriod = 259200)=>{
    const feeEndTime = lastDepositedTime + withdrawalFeePeriod;
    const currentSeconds = Math.floor(Date.now() / 1000);
    const secondsRemainingCalc = feeEndTime - currentSeconds;
    return secondsRemainingCalc > 0;
};
const useWithdrawalFeeTimer = (lastDepositedTime, userShares, withdrawalFeePeriod = 259200)=>{
    const { 0: secondsRemaining , 1: setSecondsRemaining  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const { 0: hasUnstakingFee , 1: setHasUnstakingFee  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const { 0: currentSeconds , 1: setCurrentSeconds  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(Math.floor(Date.now() / 1000));
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        const feeEndTime = lastDepositedTime + withdrawalFeePeriod;
        const secondsRemainingCalc = feeEndTime - currentSeconds;
        const doesUnstakingFeeApply = userShares.gt(0) && secondsRemainingCalc > 0;
        const tick = ()=>{
            setCurrentSeconds((prevSeconds)=>prevSeconds + 1
            );
        };
        const timerInterval = setInterval(()=>tick()
        , 1000);
        if (doesUnstakingFeeApply) {
            setSecondsRemaining(secondsRemainingCalc);
            setHasUnstakingFee(true);
        } else {
            setHasUnstakingFee(false);
            clearInterval(timerInterval);
        }
        return ()=>clearInterval(timerInterval)
        ;
    }, [
        lastDepositedTime,
        withdrawalFeePeriod,
        setSecondsRemaining,
        currentSeconds,
        userShares
    ]);
    return {
        hasUnstakingFee,
        secondsRemaining
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useWithdrawalFeeTimer);


/***/ })

};
;
//# sourceMappingURL=1799.js.map