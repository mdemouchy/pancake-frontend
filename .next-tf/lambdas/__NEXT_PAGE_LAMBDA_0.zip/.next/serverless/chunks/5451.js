"use strict";
exports.id = 5451;
exports.ids = [5451];
exports.modules = {

/***/ 75451:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "FP": () => (/* binding */ TradingViewLabel),
  "ZP": () => (/* binding */ components_TradingView),
  "xm": () => (/* binding */ useTradingViewEvent)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
// EXTERNAL MODULE: external "@pancakeswap/uikit"
var uikit_ = __webpack_require__(2829);
// EXTERNAL MODULE: ./src/contexts/Localization/index.tsx + 3 modules
var Localization = __webpack_require__(99150);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
;// CONCATENATED MODULE: ./src/hooks/useScript.ts

function useScript(src) {
    const { 0: status , 1: setStatus  } = (0,external_react_.useState)(src ? 'loading' : 'idle');
    (0,external_react_.useEffect)(()=>{
        if (!src) {
            setStatus('idle');
            return;
        }
        // Fetch existing script element by src
        // It may have been added by another instance of this hook
        let script = document.querySelector(`script[src="${src}"]`);
        if (!script) {
            // Create script
            script = document.createElement('script');
            script.src = src;
            script.async = true;
            script.setAttribute('data-status', 'loading');
            // Add script to document body
            document.body.appendChild(script);
            // Store status in attribute on script
            // This can be read by other instances of this hook
            const setAttributeFromEvent = (event)=>{
                script?.setAttribute('data-status', event.type === 'load' ? 'ready' : 'error');
            };
            script.addEventListener('load', setAttributeFromEvent);
            script.addEventListener('error', setAttributeFromEvent);
        } else {
            // Grab existing script status from attribute and set to state.
            setStatus(script.getAttribute('data-status'));
        }
        // Script event handler to update status in state
        // Note: Even if the script already exists we still need to add
        // event handlers to update the state for *this* hook instance.
        const setStateFromEvent = (event)=>{
            setStatus(event.type === 'load' ? 'ready' : 'error');
        };
        // Add event listeners
        script.addEventListener('load', setStateFromEvent);
        script.addEventListener('error', setStateFromEvent);
        // Remove event listeners on cleanup
        // eslint-disable-next-line consistent-return
        return ()=>{
            if (script) {
                script.removeEventListener('load', setStateFromEvent);
                script.removeEventListener('error', setStateFromEvent);
            }
        };
    }, [
        src
    ]);
    return status;
}
/* harmony default export */ const hooks_useScript = (useScript);

// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(57518);
;// CONCATENATED MODULE: ./src/components/TradingView.tsx






/**
 * When the script tag is injected the TradingView object is not immediately
 * available on the window. So we listen for when it gets set
 */ const tradingViewListener = async ()=>new Promise((resolve)=>Object.defineProperty(window, 'TradingView', {
            configurable: true,
            set (value) {
                this.tv = value;
                resolve(value);
            }
        })
    )
;
const initializeTradingView = (TradingViewObj, theme, localeCode, opts)=>{
    let timezone = 'Etc/UTC';
    try {
        timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    } catch (e) {
    // noop
    }
    /* eslint-disable new-cap */ /* eslint-disable no-new */ // @ts-ignore
    return new TradingViewObj.widget({
        // Advanced Chart Widget uses the legacy embedding scheme,
        // an id property should be specified in the settings object
        id: opts.container_id,
        autosize: true,
        height: '100%',
        symbol: 'BINANCE:BNBUSDT',
        interval: '5',
        timezone,
        theme: theme.isDark ? 'dark' : 'light',
        style: '1',
        locale: localeCode,
        toolbar_bg: '#f1f3f6',
        enable_publishing: false,
        allow_symbol_change: true,
        hide_side_toolbar: false,
        enabled_features: [
            'header_fullscreen_button'
        ],
        ...opts
    });
};
const TradingView = ({ id , symbol  })=>{
    const { currentLanguage  } = (0,Localization/* useTranslation */.$G)();
    const theme = (0,external_styled_components_.useTheme)();
    const widgetRef = (0,external_react_.useRef)();
    const { isMobile  } = (0,uikit_.useMatchBreakpoints)();
    hooks_useScript('https://s3.tradingview.com/tv.js');
    (0,external_react_.useEffect)(()=>{
        const opts = {
            container_id: id,
            symbol
        };
        if (isMobile) {
            opts.hide_side_toolbar = true;
        }
        // @ts-ignore
        if (window.tv) {
            // @ts-ignore
            widgetRef.current = initializeTradingView(window.tv, theme, currentLanguage.code, opts);
        } else {
            tradingViewListener().then((tv)=>{
                widgetRef.current = initializeTradingView(tv, theme, currentLanguage.code, opts);
            });
        }
    // Ignore isMobile to avoid re-render TV
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        theme,
        currentLanguage,
        id,
        symbol
    ]);
    return(/*#__PURE__*/ jsx_runtime_.jsx(uikit_.Box, {
        overflow: "hidden",
        className: "tradingview_container",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            id: id
        })
    }));
};
function useTradingViewEvent({ id , onNoDataEvent , onLoadedEvent  }) {
    (0,external_react_.useEffect)(()=>{
        const onNoDataAvailable = (event)=>{
            const payload = event.data;
            if (payload.name === 'tv-widget-no-data') {
                if (id && payload.frameElementId === id) {
                    onNoDataEvent?.();
                }
            }
            if (payload.name === 'tv-widget-load') {
                if (id && payload.frameElementId === id) {
                    onLoadedEvent?.();
                }
            }
        };
        window.addEventListener('message', onNoDataAvailable);
        // eslint-disable-next-line consistent-return
        return ()=>{
            window.removeEventListener('message', onNoDataAvailable);
        };
    }, [
        id,
        onNoDataEvent,
        onLoadedEvent
    ]);
}
// Required to link to TradingView website for the widget
const TradingViewLabel = ({ symbol , ...props })=>{
    const { t  } = (0,Localization/* useTranslation */.$G)();
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(uikit_.Flex, {
        alignItems: "center",
        px: "24px",
        ...props,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(uikit_.Link, {
                fontSize: "14px",
                href: `https://www.tradingview.com/symbols/${symbol}`,
                external: true,
                children: [
                    "BNB ",
                    t('Chart')
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(uikit_.Text, {
                fontSize: "14px",
                ml: "4px",
                children: [
                    t('by'),
                    " TradingView"
                ]
            })
        ]
    }));
};
/* harmony default export */ const components_TradingView = (TradingView);


/***/ })

};
;
//# sourceMappingURL=5451.js.map