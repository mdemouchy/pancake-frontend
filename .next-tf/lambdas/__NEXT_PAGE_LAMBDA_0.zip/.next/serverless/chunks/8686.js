"use strict";
exports.id = 8686;
exports.ids = [8686];
exports.modules = {

/***/ 62996:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "N": () => (/* binding */ ActivityFilter)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var state__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(82727);
/* harmony import */ var state_nftMarket_reducer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(38263);
/* harmony import */ var state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(13968);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(99150);
/* harmony import */ var _state_nftMarket_types__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(75186);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_6__]);
state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];









const TriggerButton = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Button).withConfig({
    componentId: "sc-2437d490-0"
})`
  ${({ hasItem  })=>hasItem && `  
    border-top-right-radius: 0;
    border-bottom-right-radius: 0;
    padding-right: 8px;
  `
}
`;
const CloseButton = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.IconButton).withConfig({
    componentId: "sc-2437d490-1"
})`
  border-top-left-radius: 0;
  border-bottom-left-radius: 0;
`;
const eventName = (t, eventType)=>{
    switch(eventType){
        case _state_nftMarket_types__WEBPACK_IMPORTED_MODULE_8__/* .MarketEvent.CANCEL */ .YG.CANCEL:
            return t('Delisted');
        case _state_nftMarket_types__WEBPACK_IMPORTED_MODULE_8__/* .MarketEvent.MODIFY */ .YG.MODIFY:
            return t('Modified');
        case _state_nftMarket_types__WEBPACK_IMPORTED_MODULE_8__/* .MarketEvent.NEW */ .YG.NEW:
            return t('Listed');
        case _state_nftMarket_types__WEBPACK_IMPORTED_MODULE_8__/* .MarketEvent.SELL */ .YG.SELL:
            return t('Sold');
        default:
            return '';
    }
};
const ActivityFilter = ({ eventType , collectionAddress  })=>{
    const nftActivityFilters = (0,state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_6__/* .useGetNftActivityFilters */ .ly)(collectionAddress);
    const dispatch = (0,state__WEBPACK_IMPORTED_MODULE_4__/* .useAppDispatch */ .TL)();
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_7__/* .useTranslation */ .$G)();
    const isEventSelected = nftActivityFilters.typeFilters.some((nftActivityFilter)=>nftActivityFilter === eventType
    );
    const handleMenuClick = ()=>{
        if (!isEventSelected) {
            dispatch((0,state_nftMarket_reducer__WEBPACK_IMPORTED_MODULE_5__/* .addActivityTypeFilters */ .I$)({
                collection: collectionAddress,
                field: eventType
            }));
        }
    };
    const handleClearItem = ()=>{
        dispatch((0,state_nftMarket_reducer__WEBPACK_IMPORTED_MODULE_5__/* .removeActivityTypeFilters */ .QP)({
            collection: collectionAddress,
            field: eventType
        }));
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
        alignItems: "center",
        mr: "4px",
        mb: "4px",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Box, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TriggerButton, {
                    onClick: handleMenuClick,
                    variant: isEventSelected ? 'subtle' : 'light',
                    scale: "sm",
                    hasItem: isEventSelected,
                    children: eventName(t, eventType)
                })
            }),
            isEventSelected && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CloseButton, {
                variant: isEventSelected ? 'subtle' : 'light',
                scale: "sm",
                onClick: handleClearItem,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.CloseIcon, {
                    color: "currentColor",
                    width: "18px"
                })
            })
        ]
    }));
};

});

/***/ }),

/***/ 92026:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export Container */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(89699);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(13968);
/* harmony import */ var state_nftMarket_types__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(75186);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(99150);
/* harmony import */ var _ClearAllButton__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(11711);
/* harmony import */ var _ActivityFilter__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(62996);
/* harmony import */ var _components_Filters_ListCollectionFilter__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(69728);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_ActivityFilter__WEBPACK_IMPORTED_MODULE_9__, _components_Filters_ListCollectionFilter__WEBPACK_IMPORTED_MODULE_10__, state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_5__]);
([_ActivityFilter__WEBPACK_IMPORTED_MODULE_9__, _components_Filters_ListCollectionFilter__WEBPACK_IMPORTED_MODULE_10__, state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);











const Container = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex).withConfig({
    componentId: "sc-bdf04220-0"
})`
  gap: 16px;

  ${({ theme  })=>theme.mediaQueries.sm
} {
    align-items: center;
    flex-grow: 2;
  }
`;
const ScrollableFlexContainer = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex).withConfig({
    componentId: "sc-bdf04220-1"
})`
  align-items: center;
  flex: 1;
  flex-wrap: nowrap;
  overflow-x: auto;
  -webkit-overflow-scrolling: touch;

  ${({ theme  })=>theme.mediaQueries.md
} {
    flex-wrap: wrap;
    overflow-x: revert;
  }
`;
const ActivityFilters = ({ collection  })=>{
    const { address  } = collection || {
        address: ''
    };
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_7__/* .useTranslation */ .$G)();
    const nftActivityFilters = (0,state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_5__/* .useGetNftActivityFilters */ .ly)(address);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Container, {
        justifyContent: "space-between",
        flexDirection: [
            'column',
            'column',
            'row'
        ],
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                textTransform: "uppercase",
                color: "textSubtle",
                fontSize: "12px",
                bold: true,
                children: t('Filter by')
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ScrollableFlexContainer, {
                children: [
                    address === '' && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Filters_ListCollectionFilter__WEBPACK_IMPORTED_MODULE_10__/* .ListCollectionFilter */ .H, {}),
                    [
                        state_nftMarket_types__WEBPACK_IMPORTED_MODULE_6__/* .MarketEvent.NEW */ .YG.NEW,
                        state_nftMarket_types__WEBPACK_IMPORTED_MODULE_6__/* .MarketEvent.CANCEL */ .YG.CANCEL,
                        state_nftMarket_types__WEBPACK_IMPORTED_MODULE_6__/* .MarketEvent.MODIFY */ .YG.MODIFY,
                        state_nftMarket_types__WEBPACK_IMPORTED_MODULE_6__/* .MarketEvent.SELL */ .YG.SELL
                    ].map((eventType)=>{
                        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ActivityFilter__WEBPACK_IMPORTED_MODULE_9__/* .ActivityFilter */ .N, {
                            eventType: eventType,
                            collectionAddress: address
                        }, eventType));
                    })
                ]
            }),
            !lodash_isEmpty__WEBPACK_IMPORTED_MODULE_4___default()(nftActivityFilters.typeFilters) || !lodash_isEmpty__WEBPACK_IMPORTED_MODULE_4___default()(nftActivityFilters.collectionFilters) ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ClearAllButton__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                collectionAddress: address
            }) : null
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ActivityFilters);

});

/***/ }),

/***/ 58686:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(38328);
/* harmony import */ var state__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(82727);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var state_nftMarket_helpers__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(86849);
/* harmony import */ var components_Layout_Container__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(55027);
/* harmony import */ var components_TableLoader__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(26710);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(99150);
/* harmony import */ var hooks_useBUSDPrice__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(90834);
/* harmony import */ var hooks_useTheme__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(23917);
/* harmony import */ var hooks_useLastUpdated__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(71685);
/* harmony import */ var state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(13968);
/* harmony import */ var _components_PaginationButtons__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(72818);
/* harmony import */ var _components_Activity_NoNftsImage__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(7402);
/* harmony import */ var _ActivityFilters__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(92026);
/* harmony import */ var _components_Activity_ActivityRow__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(6348);
/* harmony import */ var _utils_sortActivity__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(11527);
/* harmony import */ var _utils_fetchActivityNftMetadata__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(90366);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Activity_ActivityRow__WEBPACK_IMPORTED_MODULE_16__, _ActivityFilters__WEBPACK_IMPORTED_MODULE_15__, hooks_useBUSDPrice__WEBPACK_IMPORTED_MODULE_9__, hooks_useTheme__WEBPACK_IMPORTED_MODULE_10__, state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_12__]);
([_components_Activity_ActivityRow__WEBPACK_IMPORTED_MODULE_16__, _ActivityFilters__WEBPACK_IMPORTED_MODULE_15__, hooks_useBUSDPrice__WEBPACK_IMPORTED_MODULE_9__, hooks_useTheme__WEBPACK_IMPORTED_MODULE_10__, state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);



















const MAX_PER_PAGE = 8;
const MAX_PER_QUERY = 100;
const ActivityHistory = ({ collection  })=>{
    const dispatch = (0,state__WEBPACK_IMPORTED_MODULE_3__/* .useAppDispatch */ .TL)();
    const { address: collectionAddress  } = collection || {
        address: ''
    };
    const nftActivityFilters = (0,state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_12__/* .useGetNftActivityFilters */ .ly)(collectionAddress);
    const { theme  } = (0,hooks_useTheme__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)();
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_8__/* .useTranslation */ .$G)();
    const { 0: paginationData , 1: setPaginationData  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        activity: [],
        currentPage: 1,
        maxPage: 1
    });
    const { 0: activitiesSlice , 1: setActivitiesSlice  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const { 0: nftMetadata , 1: setNftMetadata  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const { 0: isLoading , 1: setIsLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const { 0: isInitialized , 1: setIsInitialized  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: queryPage , 1: setQueryPage  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(1);
    const { lastUpdated , setLastUpdated: refresh  } = (0,hooks_useLastUpdated__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z)();
    const bnbBusdPrice = (0,hooks_useBUSDPrice__WEBPACK_IMPORTED_MODULE_9__/* .useBNBBusdPrice */ .Hf)();
    const { isXs , isSm  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.useMatchBreakpoints)();
    const nftActivityFiltersString = JSON.stringify(nftActivityFilters);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const fetchCollectionActivity = async ()=>{
            try {
                setIsLoading(true);
                const nftActivityFiltersParsed = JSON.parse(nftActivityFiltersString);
                const collectionActivity = await (0,state_nftMarket_helpers__WEBPACK_IMPORTED_MODULE_5__/* .getCollectionActivity */ .Du)(collectionAddress.toLowerCase(), nftActivityFiltersParsed, MAX_PER_QUERY);
                const activity = (0,_utils_sortActivity__WEBPACK_IMPORTED_MODULE_17__/* .sortActivity */ .f)(collectionActivity);
                setPaginationData({
                    activity,
                    currentPage: 1,
                    maxPage: Math.ceil(activity.length / MAX_PER_PAGE) || 1
                });
                setIsLoading(false);
                setIsInitialized(true);
            } catch (error) {
                console.error('Failed to fetch collection activity', error);
            }
        };
        if (collectionAddress && (0,utils__WEBPACK_IMPORTED_MODULE_2__/* .isAddress */ .UJ)(collectionAddress) || collectionAddress === '') {
            fetchCollectionActivity();
        }
    }, [
        dispatch,
        collectionAddress,
        nftActivityFiltersString,
        lastUpdated
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const fetchNftMetadata = async ()=>{
            const nfts = await (0,_utils_fetchActivityNftMetadata__WEBPACK_IMPORTED_MODULE_18__/* .fetchActivityNftMetadata */ .M)(activitiesSlice);
            setNftMetadata(nfts);
        };
        if (activitiesSlice.length > 0) {
            fetchNftMetadata();
        }
    }, [
        activitiesSlice
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const slice = paginationData.activity.slice(MAX_PER_PAGE * (paginationData.currentPage - 1), MAX_PER_PAGE * paginationData.currentPage);
        setActivitiesSlice(slice);
    }, [
        paginationData
    ]);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Box, {
        py: "32px",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Layout_Container__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                px: [
                    0,
                    null,
                    '24px'
                ],
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Flex, {
                    style: {
                        gap: '16px',
                        padding: '0 16px'
                    },
                    alignItems: [
                        null,
                        null,
                        'center'
                    ],
                    flexDirection: [
                        'column',
                        'column',
                        'row'
                    ],
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ActivityFilters__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                            collection: collection
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Button, {
                            scale: "sm",
                            disabled: isLoading,
                            onClick: ()=>{
                                refresh();
                            },
                            children: t('Refresh')
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Layout_Container__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                style: {
                    overflowX: 'auto'
                },
                children: paginationData.activity.length === 0 && nftMetadata.length === 0 && activitiesSlice.length === 0 && !isLoading ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Flex, {
                    p: "24px",
                    flexDirection: "column",
                    alignItems: "center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Activity_NoNftsImage__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                            pt: "8px",
                            bold: true,
                            children: t('No NFT market history found')
                        })
                    ]
                }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Table, {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Th, {
                                                textAlign: [
                                                    'center',
                                                    null,
                                                    'left'
                                                ],
                                                children: [
                                                    " ",
                                                    t('Item')
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Th, {
                                                textAlign: "right",
                                                children: [
                                                    " ",
                                                    t('Event')
                                                ]
                                            }),
                                            isXs || isSm ? null : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Th, {
                                                        textAlign: "right",
                                                        children: [
                                                            " ",
                                                            t('Price')
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Th, {
                                                        textAlign: "center",
                                                        children: [
                                                            " ",
                                                            t('From')
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Th, {
                                                        textAlign: "center",
                                                        children: [
                                                            " ",
                                                            t('To')
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Th, {
                                                textAlign: "center",
                                                children: [
                                                    " ",
                                                    t('Date')
                                                ]
                                            }),
                                            isXs || isSm ? null : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Th, {})
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                    children: !isInitialized ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_TableLoader__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {}) : activitiesSlice.map((activity)=>{
                                        const nftMeta = nftMetadata.find((metaNft)=>metaNft.tokenId === activity.nft.tokenId
                                        );
                                        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Activity_ActivityRow__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                                            activity: activity,
                                            nft: nftMeta,
                                            bnbBusdPrice: bnbBusdPrice
                                        }, `${activity.marketEvent}#${activity.nft.tokenId}#${activity.timestamp}#${activity.tx}`));
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Flex, {
                            borderTop: `1px ${theme.colors.cardBorder} solid`,
                            pt: "24px",
                            flexDirection: "column",
                            justifyContent: "space-between",
                            height: "100%",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_PaginationButtons__WEBPACK_IMPORTED_MODULE_13__/* .PageButtons */ .O, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_PaginationButtons__WEBPACK_IMPORTED_MODULE_13__/* .Arrow */ .E, {
                                        onClick: ()=>{
                                            if (paginationData.currentPage !== 1) {
                                                setPaginationData((prevState)=>({
                                                        ...prevState,
                                                        currentPage: prevState.currentPage - 1
                                                    })
                                                );
                                            }
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.ArrowBackIcon, {
                                            color: paginationData.currentPage === 1 ? 'textDisabled' : 'primary'
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                                        children: t('Page %page% of %maxPage%', {
                                            page: paginationData.currentPage,
                                            maxPage: paginationData.maxPage
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_PaginationButtons__WEBPACK_IMPORTED_MODULE_13__/* .Arrow */ .E, {
                                        onClick: async ()=>{
                                            if (paginationData.currentPage !== paginationData.maxPage) {
                                                setPaginationData((prevState)=>({
                                                        ...prevState,
                                                        currentPage: prevState.currentPage + 1
                                                    })
                                                );
                                                if (paginationData.maxPage - paginationData.currentPage === 1 && paginationData.activity.length === MAX_PER_QUERY * queryPage) {
                                                    try {
                                                        setIsLoading(true);
                                                        const nftActivityFiltersParsed = JSON.parse(nftActivityFiltersString);
                                                        const collectionActivity = await (0,state_nftMarket_helpers__WEBPACK_IMPORTED_MODULE_5__/* .getCollectionActivity */ .Du)(collectionAddress.toLowerCase(), nftActivityFiltersParsed, MAX_PER_QUERY * (queryPage + 1));
                                                        const activity = (0,_utils_sortActivity__WEBPACK_IMPORTED_MODULE_17__/* .sortActivity */ .f)(collectionActivity);
                                                        setPaginationData((prevState)=>{
                                                            return {
                                                                ...prevState,
                                                                activity,
                                                                maxPage: Math.ceil(activity.length / MAX_PER_PAGE) || 1
                                                            };
                                                        });
                                                        setIsLoading(false);
                                                        setQueryPage((prevState)=>prevState + 1
                                                        );
                                                    } catch (error) {
                                                        console.error('Failed to fetch collection activity', error);
                                                    }
                                                }
                                            }
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.ArrowForwardIcon, {
                                            color: paginationData.currentPage === paginationData.maxPage ? 'textDisabled' : 'primary'
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                })
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ActivityHistory);

});

/***/ }),

/***/ 11711:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(99150);
/* harmony import */ var state__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(82727);
/* harmony import */ var state_nftMarket_reducer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(38263);






const ClearAllButton = ({ collectionAddress , ...props })=>{
    const dispatch = (0,state__WEBPACK_IMPORTED_MODULE_4__/* .useAppDispatch */ .TL)();
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_3__/* .useTranslation */ .$G)();
    const clearAll = ()=>{
        dispatch((0,state_nftMarket_reducer__WEBPACK_IMPORTED_MODULE_5__/* .removeAllActivityFilters */ .MD)(collectionAddress));
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
        variant: "text",
        scale: "sm",
        onClick: clearAll,
        ...props,
        children: t('Clear')
    }, "clear-all"));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ClearAllButton);


/***/ }),

/***/ 69728:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "H": () => (/* binding */ ListCollectionFilter)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(49949);
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lodash_orderBy__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var state__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(82727);
/* harmony import */ var state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(13968);
/* harmony import */ var state_nftMarket_reducer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(38263);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(99150);
/* harmony import */ var _ListFilter_styles__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(62627);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(67207);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_5__]);
state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];










const ListCollectionFilter = ()=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_7__/* .useTranslation */ .$G)();
    const { 0: isOpen , 1: setIsOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: query , 1: setQuery  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const { 0: orderState , 1: setOrderState  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        orderKey: 'label',
        orderDir: 'asc'
    });
    const collections = (0,state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_5__/* .useGetCollections */ .t8)();
    const wrapperRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const menuRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const dispatch = (0,state__WEBPACK_IMPORTED_MODULE_4__/* .useAppDispatch */ .TL)();
    const { orderKey , orderDir  } = orderState;
    const nftActivityFilters = (0,state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_5__/* .useGetNftActivityFilters */ .ly)('');
    const isAnyCollectionSelected = nftActivityFilters.collectionFilters.length > 0;
    const filteredCollections = (query && query.length > 1 ? Object.values(collections).filter((item)=>item.name.toLowerCase().indexOf(query.toLowerCase()) !== -1
    ) : Object.values(collections)).map((item)=>{
        const isItemSelected = nftActivityFilters.collectionFilters.some((collectionAddress)=>{
            return item.address.toLowerCase() === collectionAddress.toLowerCase();
        });
        return {
            ...item,
            isSelected: isItemSelected
        };
    });
    const handleClearFilter = ()=>{
        dispatch((0,state_nftMarket_reducer__WEBPACK_IMPORTED_MODULE_6__/* .removeAllActivityCollectionFilters */ .G4)());
    };
    const handleMenuClick = ()=>setIsOpen(!isOpen)
    ;
    const handleChange = (evt)=>{
        const { value  } = evt.target;
        setQuery(value);
    };
    const handleItemClick = (evt, collection)=>{
        if (evt.target.checked) {
            dispatch((0,state_nftMarket_reducer__WEBPACK_IMPORTED_MODULE_6__/* .addActivityCollectionFilters */ .eN)({
                collection: collection.address.toLowerCase()
            }));
        } else {
            dispatch((0,state_nftMarket_reducer__WEBPACK_IMPORTED_MODULE_6__/* .removeActivityCollectionFilters */ .Rk)({
                collection: collection.address.toLowerCase()
            }));
        }
    };
    const toggleSort = (newOrderKey)=>()=>{
            setOrderState((prevOrderDir)=>{
                if (prevOrderDir.orderKey !== newOrderKey) {
                    return {
                        orderKey: newOrderKey,
                        orderDir: 'asc'
                    };
                }
                return {
                    orderKey: newOrderKey,
                    orderDir: prevOrderDir.orderDir === 'asc' ? 'desc' : 'asc'
                };
            });
        }
    ;
    // @TODO Fix this in the Toolkit
    // This is a fix to ensure the "isOpen" value is aligned with the menus's (to avoid a double click)
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const handleClickOutside = ({ target  })=>{
            if (wrapperRef.current && menuRef.current && !menuRef.current.contains(target) && !wrapperRef.current.contains(target)) {
                setIsOpen(false);
            }
        };
        document.addEventListener('click', handleClickOutside);
        return ()=>{
            document.removeEventListener('click', handleClickOutside);
        };
    }, [
        setIsOpen,
        wrapperRef,
        menuRef
    ]);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
        alignItems: "center",
        mr: "4px",
        mb: "4px",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Box, {
                ref: wrapperRef,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.InlineMenu, {
                    component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ListFilter_styles__WEBPACK_IMPORTED_MODULE_8__/* .TriggerButton */ .yR, {
                        onClick: handleMenuClick,
                        variant: isAnyCollectionSelected ? 'subtle' : 'light',
                        scale: "sm",
                        hasItem: isAnyCollectionSelected,
                        children: t('Collection')
                    }),
                    isOpen: isOpen,
                    options: {
                        placement: 'bottom'
                    },
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Box, {
                        maxWidth: "375px",
                        ref: menuRef,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ListFilter_styles__WEBPACK_IMPORTED_MODULE_8__/* .SearchWrapper */ ._8, {
                                alignItems: "center",
                                p: "16px",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.InputGroup, {
                                    startIcon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.SearchIcon, {
                                        color: "textSubtle"
                                    }),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Input, {
                                        name: "query",
                                        placeholder: t('Search'),
                                        onChange: handleChange,
                                        value: query
                                    })
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                                alignItems: "center",
                                p: "16px",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_ListFilter_styles__WEBPACK_IMPORTED_MODULE_8__/* .FilterButton */ .Lb, {
                                        onClick: toggleSort('name'),
                                        style: {
                                            flex: 1
                                        },
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                                fontSize: "12px",
                                                color: "secondary",
                                                fontWeight: "bold",
                                                textTransform: "uppercase",
                                                children: t('Name')
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Box, {
                                                width: "18px",
                                                children: [
                                                    orderKey === 'name' && orderDir === 'asc' && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.ArrowUpIcon, {
                                                        width: "18px",
                                                        color: "secondary"
                                                    }),
                                                    orderKey === 'name' && orderDir === 'desc' && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.ArrowDownIcon, {
                                                        width: "18px",
                                                        color: "secondary"
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_ListFilter_styles__WEBPACK_IMPORTED_MODULE_8__/* .FilterButton */ .Lb, {
                                        onClick: toggleSort('isSelected'),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                                fontSize: "12px",
                                                color: "secondary",
                                                fontWeight: "bold",
                                                textTransform: "uppercase",
                                                children: t('Filter')
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Box, {
                                                width: "18px",
                                                children: [
                                                    orderKey === 'isSelected' && orderDir === 'asc' && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.ArrowUpIcon, {
                                                        width: "18px",
                                                        color: "secondary"
                                                    }),
                                                    orderKey === 'isSelected' && orderDir === 'desc' && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.ArrowDownIcon, {
                                                        width: "18px",
                                                        color: "secondary"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Box, {
                                height: "240px",
                                overflowY: "auto",
                                children: filteredCollections.length > 0 ? lodash_orderBy__WEBPACK_IMPORTED_MODULE_2___default()(filteredCollections, orderKey, orderDir).map((collection)=>{
                                    const handleClick = (evt)=>handleItemClick(evt, collection)
                                    ;
                                    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styles__WEBPACK_IMPORTED_MODULE_9__/* .CollectionItemRow */ .t, {
                                        item: {
                                            label: collection.name,
                                            collectionAddress: collection.address
                                        },
                                        isSelected: collection.isSelected,
                                        onClick: handleClick
                                    }, collection.address));
                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                                    alignItems: "center",
                                    justifyContent: "center",
                                    height: "230px",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                        color: "textDisabled",
                                        textAlign: "center",
                                        children: t('No results found')
                                    })
                                })
                            })
                        ]
                    })
                })
            }),
            isAnyCollectionSelected && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ListFilter_styles__WEBPACK_IMPORTED_MODULE_8__/* .CloseButton */ .PZ, {
                variant: isAnyCollectionSelected ? 'subtle' : 'light',
                scale: "sm",
                onClick: handleClearFilter,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.CloseIcon, {
                    color: "currentColor",
                    width: "18px"
                })
            })
        ]
    }));
};

});

/***/ }),

/***/ 67207:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "t": () => (/* binding */ CollectionItemRow)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ListFilter_styles__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(62627);




const CollectionItemRow = ({ item , isSelected , onClick  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_ListFilter_styles__WEBPACK_IMPORTED_MODULE_3__/* .StyledItemRow */ .Ak, {
        alignItems: "center",
        px: "16px",
        py: "8px",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                style: {
                    flex: 1
                },
                children: item.label
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                ml: "24px",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Checkbox, {
                    name: "item-select",
                    scale: "sm",
                    onChange: onClick,
                    checked: isSelected,
                    value: item.collectionAddress
                })
            })
        ]
    })
;


/***/ })

};
;
//# sourceMappingURL=8686.js.map