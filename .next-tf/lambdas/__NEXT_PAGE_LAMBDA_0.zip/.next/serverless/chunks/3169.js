"use strict";
exports.id = 3169;
exports.ids = [3169];
exports.modules = {

/***/ 31113:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(99150);
/* harmony import */ var views_Nft_market_constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1940);
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(38328);
/* harmony import */ var _shared_styles__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(33482);







// Initial stage when user wants to edit already listed NFT (i.e. adjust price or remove from sale)
const EditStage = ({ nftToSell , lowestPrice , continueToAdjustPriceStage , continueToRemoveFromMarketStage ,  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_3__/* .useTranslation */ .$G)();
    const itemPageUrlId = nftToSell.collectionAddress.toLowerCase() === views_Nft_market_constants__WEBPACK_IMPORTED_MODULE_4__/* .pancakeBunniesAddress.toLowerCase */ .Jr.toLowerCase() ? nftToSell.attributes[0].value : nftToSell.tokenId;
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                p: "16px",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_shared_styles__WEBPACK_IMPORTED_MODULE_6__/* .RoundedImage */ ._v, {
                        src: nftToSell.image.thumbnail,
                        height: 68,
                        width: 68,
                        mr: "8px"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                        flex: "1",
                        gridTemplateColumns: "1fr 1fr",
                        alignItems: "center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                bold: true,
                                children: nftToSell.name
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                fontSize: "12px",
                                color: "textSubtle",
                                textAlign: "right",
                                children: nftToSell.collectionName
                            }),
                            lowestPrice && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                        small: true,
                                        color: "textSubtle",
                                        children: t('Lowest price')
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                                        alignItems: "center",
                                        justifyContent: "flex-end",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.BinanceIcon, {
                                                width: 16,
                                                height: 16,
                                                mr: "4px"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                                small: true,
                                                children: lowestPrice
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                small: true,
                                color: "textSubtle",
                                children: t('Your price')
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                                alignItems: "center",
                                justifyContent: "flex-end",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.BinanceIcon, {
                                        width: 16,
                                        height: 16,
                                        mr: "4px"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                        small: true,
                                        children: nftToSell.marketData.currentAskPrice
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                justifyContent: "space-between",
                px: "16px",
                mt: "8px",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        flex: "2",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                            small: true,
                            color: "textSubtle",
                            children: t('Token ID: %id%', {
                                id: nftToSell.tokenId
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        justifyContent: "space-between",
                        flex: "3",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                                as: _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Link,
                                p: "0px",
                                height: "16px",
                                external: true,
                                variant: "text",
                                href: `${views_Nft_market_constants__WEBPACK_IMPORTED_MODULE_4__/* .nftsBaseUrl */ .Vf}/collections/${nftToSell.collectionAddress}/${itemPageUrlId}`,
                                children: t('View Item')
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_shared_styles__WEBPACK_IMPORTED_MODULE_6__/* .HorizontalDivider */ .EL, {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.LinkExternal, {
                                p: "0px",
                                height: "16px",
                                href: (0,utils__WEBPACK_IMPORTED_MODULE_5__/* .getBscScanLinkForNft */ .z)(nftToSell.collectionAddress, nftToSell.tokenId),
                                children: "BscScan"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_shared_styles__WEBPACK_IMPORTED_MODULE_6__/* .Divider */ .iz, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                flexDirection: "column",
                px: "16px",
                pb: "16px",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                        mb: "8px",
                        onClick: continueToAdjustPriceStage,
                        children: t('Adjust Sale Price')
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                        variant: "danger",
                        onClick: continueToRemoveFromMarketStage,
                        children: t('Remove from Market')
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EditStage);


/***/ }),

/***/ 52725:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(99150);
/* harmony import */ var _shared_styles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(33482);





const RemoveStage = ({ continueToNextStage  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_3__/* .useTranslation */ .$G)();
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Box, {
                p: "16px",
                maxWidth: "360px",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        fontSize: "24px",
                        bold: true,
                        children: t('Remove from Market')
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        mt: "24px",
                        color: "textSubtle",
                        children: t('Removing this NFT from the marketplace will return it to your wallet.')
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        mt: "16px",
                        color: "textSubtle",
                        children: t('Continue?')
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_shared_styles__WEBPACK_IMPORTED_MODULE_4__/* .Divider */ .iz, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                flexDirection: "column",
                px: "16px",
                pb: "16px",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                    mb: "8px",
                    onClick: continueToNextStage,
                    children: t('Confirm')
                })
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RemoveStage);


/***/ }),

/***/ 41141:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(99150);
/* harmony import */ var views_Nft_market_constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1940);
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(38328);
/* harmony import */ var views_Nft_market_Profile_components_EditProfileModal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(92583);
/* harmony import */ var state_profile_hooks__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(89424);
/* harmony import */ var _shared_styles__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(33482);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([views_Nft_market_Profile_components_EditProfileModal__WEBPACK_IMPORTED_MODULE_6__, state_profile_hooks__WEBPACK_IMPORTED_MODULE_7__]);
([views_Nft_market_Profile_components_EditProfileModal__WEBPACK_IMPORTED_MODULE_6__, state_profile_hooks__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);









// Initial stage when user wants to put their NFT for sale or transfer to another wallet
const SellStage = ({ nftToSell , lowestPrice , continueToNextStage , continueToTransferStage , onSuccessEditProfile ,  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_3__/* .useTranslation */ .$G)();
    const { hasProfile  } = (0,state_profile_hooks__WEBPACK_IMPORTED_MODULE_7__/* .useProfile */ .Un)();
    const itemPageUrlId = nftToSell.collectionAddress.toLowerCase() === views_Nft_market_constants__WEBPACK_IMPORTED_MODULE_4__/* .pancakeBunniesAddress.toLowerCase */ .Jr.toLowerCase() ? nftToSell.attributes[0].value : nftToSell.tokenId;
    const [onEditProfileModal] = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.useModal)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(views_Nft_market_Profile_components_EditProfileModal__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
        onSuccess: onSuccessEditProfile
    }), false);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                p: "16px",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_shared_styles__WEBPACK_IMPORTED_MODULE_8__/* .RoundedImage */ ._v, {
                        src: nftToSell.image.thumbnail,
                        height: 68,
                        width: 68,
                        mr: "8px"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                        flex: "1",
                        gridTemplateColumns: "1fr 1fr",
                        alignItems: "center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                bold: true,
                                children: nftToSell.name
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                fontSize: "12px",
                                color: "textSubtle",
                                textAlign: "right",
                                children: nftToSell.collectionName
                            }),
                            lowestPrice && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                        small: true,
                                        color: "textSubtle",
                                        children: t('Lowest price')
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                                        alignItems: "center",
                                        justifyContent: "flex-end",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.BinanceIcon, {
                                                width: 16,
                                                height: 16,
                                                mr: "4px"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                                small: true,
                                                children: lowestPrice.toLocaleString(undefined, {
                                                    minimumFractionDigits: 3,
                                                    maximumFractionDigits: 3
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                justifyContent: "space-between",
                px: "16px",
                mt: "8px",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        flex: "2",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                            small: true,
                            color: "textSubtle",
                            children: t('Token ID: %id%', {
                                id: nftToSell.tokenId
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        justifyContent: "space-between",
                        flex: "3",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                                as: _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Link,
                                p: "0px",
                                height: "16px",
                                external: true,
                                variant: "text",
                                href: `${views_Nft_market_constants__WEBPACK_IMPORTED_MODULE_4__/* .nftsBaseUrl */ .Vf}/collections/${nftToSell.collectionAddress}/${itemPageUrlId}`,
                                children: t('View Item')
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_shared_styles__WEBPACK_IMPORTED_MODULE_8__/* .HorizontalDivider */ .EL, {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.LinkExternal, {
                                p: "0px",
                                height: "16px",
                                href: (0,utils__WEBPACK_IMPORTED_MODULE_5__/* .getBscScanLinkForNft */ .z)(nftToSell.collectionAddress, nftToSell.tokenId),
                                children: "BscScan"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_shared_styles__WEBPACK_IMPORTED_MODULE_8__/* .Divider */ .iz, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                flexDirection: "column",
                px: "16px",
                pb: "16px",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                        mb: "8px",
                        onClick: continueToNextStage,
                        children: t('Sell')
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                        mb: "8px",
                        variant: "secondary",
                        onClick: continueToTransferStage,
                        children: t('Transfer')
                    }),
                    hasProfile && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                        variant: "secondary",
                        onClick: onEditProfileModal,
                        children: t('Set as Profile Pic')
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SellStage);

});

/***/ }),

/***/ 94907:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var utils_prices__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7879);
/* harmony import */ var hooks_useBUSDPrice__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(90834);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(99150);
/* harmony import */ var state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(13968);
/* harmony import */ var _shared_styles__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(33482);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(72495);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_styles__WEBPACK_IMPORTED_MODULE_8__, hooks_useBUSDPrice__WEBPACK_IMPORTED_MODULE_4__, state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_6__]);
([_styles__WEBPACK_IMPORTED_MODULE_8__, hooks_useBUSDPrice__WEBPACK_IMPORTED_MODULE_4__, state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);









const MIN_PRICE = 0.005;
const MAX_PRICE = 10000;
// Stage where user puts price for NFT they're about to put on sale
// Also shown when user wants to adjust the price of already listed NFT
const SetPriceStage = ({ nftToSell , variant , lowestPrice , currentPrice , price , setPrice , continueToNextStage ,  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_5__/* .useTranslation */ .$G)();
    const inputRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    const adjustedPriceIsTheSame = variant === 'adjust' && parseFloat(currentPrice) === parseFloat(price);
    const priceIsValid = !price || Number.isNaN(parseFloat(price)) || parseFloat(price) <= 0;
    const { creatorFee , tradingFee  } = (0,state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_6__/* .useGetCollection */ .YD)(nftToSell.collectionAddress);
    const creatorFeeAsNumber = parseFloat(creatorFee);
    const tradingFeeAsNumber = parseFloat(tradingFee);
    const bnbPrice = (0,hooks_useBUSDPrice__WEBPACK_IMPORTED_MODULE_4__/* .useBNBBusdPrice */ .Hf)();
    const priceAsFloat = parseFloat(price);
    const priceInUsd = (0,utils_prices__WEBPACK_IMPORTED_MODULE_3__/* .multiplyPriceByAmount */ .as)(bnbPrice, priceAsFloat);
    const priceIsOutOfRange = priceAsFloat > MAX_PRICE || priceAsFloat < MIN_PRICE;
    const { tooltip , tooltipVisible , targetRef  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.useTooltip)(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                children: t('When selling NFTs from this collection, a portion of the BNB paid will be diverted before reaching the seller:')
            }),
            creatorFeeAsNumber > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                children: t('%percentage%% royalties to the collection owner', {
                    percentage: creatorFee
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                children: t('%percentage%% trading fee will be used to buy & burn CAKE', {
                    percentage: tradingFee
                })
            })
        ]
    }), {
        placement: 'auto'
    });
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (inputRef && inputRef.current) {
            inputRef.current.focus();
        }
    }, [
        inputRef
    ]);
    const getButtonText = ()=>{
        if (variant === 'adjust') {
            if (adjustedPriceIsTheSame || priceIsValid) {
                return t('Input New Sale Price');
            }
            return t('Confirm');
        }
        return t('Enable Listing');
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                fontSize: "24px",
                bold: true,
                p: "16px",
                children: variant === 'set' ? t('Set Price') : t('Adjust Sale Price')
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styles__WEBPACK_IMPORTED_MODULE_8__/* .GreyedOutContainer */ .V0, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        fontSize: "12px",
                        color: "secondary",
                        textTransform: "uppercase",
                        bold: true,
                        children: t('Set Price')
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                                flex: "1",
                                alignItems: "center",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.BinanceIcon, {
                                        width: 24,
                                        height: 24,
                                        mr: "4px"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                        bold: true,
                                        children: "WBNB"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                                flex: "2",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styles__WEBPACK_IMPORTED_MODULE_8__/* .RightAlignedInput */ .Bp, {
                                    scale: "sm",
                                    type: "number",
                                    inputMode: "decimal",
                                    value: price,
                                    ref: inputRef,
                                    isWarning: priceIsOutOfRange,
                                    onChange: (e)=>setPrice(e.target.value)
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        alignItems: "center",
                        height: "21px",
                        justifyContent: "flex-end",
                        children: !Number.isNaN(priceInUsd) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                            fontSize: "12px",
                            color: "textSubtle",
                            children: `$${priceInUsd.toLocaleString(undefined, {
                                minimumFractionDigits: 2,
                                maximumFractionDigits: 2
                            })}`
                        })
                    }),
                    priceIsOutOfRange && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        fontSize: "12px",
                        color: "failure",
                        children: t('Allowed price range is between %minPrice% and %maxPrice% WBNB', {
                            minPrice: MIN_PRICE,
                            maxPrice: MAX_PRICE
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        mt: "8px",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                small: true,
                                color: "textSubtle",
                                mr: "8px",
                                children: t('Seller pays %percentage%% platform fee on sale', {
                                    percentage: creatorFeeAsNumber + tradingFeeAsNumber
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                ref: targetRef,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.ErrorIcon, {})
                            }),
                            tooltipVisible && tooltip
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        justifyContent: "space-between",
                        alignItems: "center",
                        mt: "16px",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                small: true,
                                color: "textSubtle",
                                children: t('Platform fee if sold')
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styles__WEBPACK_IMPORTED_MODULE_8__/* .FeeAmountCell */ .tz, {
                                bnbAmount: priceAsFloat,
                                creatorFee: creatorFeeAsNumber,
                                tradingFee: tradingFeeAsNumber
                            })
                        ]
                    }),
                    lowestPrice && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        justifyContent: "space-between",
                        alignItems: "center",
                        mt: "16px",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                small: true,
                                color: "textSubtle",
                                children: t('Lowest price on market')
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styles__WEBPACK_IMPORTED_MODULE_8__/* .BnbAmountCell */ .U2, {
                                bnbAmount: lowestPrice
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                gridTemplateColumns: "32px 1fr",
                p: "16px",
                maxWidth: "360px",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        alignSelf: "flex-start",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.ErrorIcon, {
                            width: 24,
                            height: 24,
                            color: "textSubtle"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Box, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                small: true,
                                color: "textSubtle",
                                children: t('The NFT will be removed from your wallet and put on sale at this price.')
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                small: true,
                                color: "textSubtle",
                                children: t('Sales are in WBNB. You can swap WBNB to BNB 1:1 for free with PancakeSwap.')
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_shared_styles__WEBPACK_IMPORTED_MODULE_7__/* .Divider */ .iz, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                flexDirection: "column",
                px: "16px",
                pb: "16px",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                    mb: "8px",
                    onClick: continueToNextStage,
                    disabled: priceIsValid || adjustedPriceIsTheSame || priceIsOutOfRange,
                    children: getButtonText()
                })
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SetPriceStage);

});

/***/ }),

/***/ 16006:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(18054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99150);
/* harmony import */ var _shared_styles__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(33482);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(72495);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_styles__WEBPACK_IMPORTED_MODULE_6__]);
_styles__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];







const TransferStage = ({ nftToSell , lowestPrice , transferAddress , setTransferAddress , isInvalidTransferAddress , continueToNextStage ,  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_3__.useWeb3React)();
    const transferAddressEqualsConnectedAddress = transferAddress.toLowerCase() === account.toLowerCase();
    const getErrorText = ()=>{
        if (isInvalidTransferAddress) {
            return t('That’s not a Binance Smart Chain wallet address.');
        }
        if (transferAddressEqualsConnectedAddress) {
            return t('This address is the one that is currently connected');
        }
        return null;
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                fontSize: "24px",
                bold: true,
                px: "16px",
                pt: "16px",
                children: t('Transfer to New Wallet')
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                p: "16px",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_shared_styles__WEBPACK_IMPORTED_MODULE_5__/* .RoundedImage */ ._v, {
                        src: nftToSell.image.thumbnail,
                        height: 68,
                        width: 68,
                        mr: "8px"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                        flex: "1",
                        gridTemplateColumns: "1fr 1fr",
                        alignItems: "center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                bold: true,
                                children: nftToSell.name
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                fontSize: "12px",
                                color: "textSubtle",
                                textAlign: "right",
                                children: nftToSell.collectionName
                            }),
                            lowestPrice && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                        small: true,
                                        color: "textSubtle",
                                        children: t('Lowest price')
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                                        alignItems: "center",
                                        justifyContent: "flex-end",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.BinanceIcon, {
                                                width: 16,
                                                height: 16,
                                                mr: "4px"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                                small: true,
                                                children: lowestPrice
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styles__WEBPACK_IMPORTED_MODULE_6__/* .GreyedOutContainer */ .V0, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        fontSize: "12px",
                        color: "secondary",
                        textTransform: "uppercase",
                        bold: true,
                        children: t('Receiving address')
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Input, {
                        scale: "sm",
                        isWarning: isInvalidTransferAddress || transferAddressEqualsConnectedAddress,
                        placeholder: t('Paste BSC address'),
                        value: transferAddress,
                        onChange: (e)=>setTransferAddress(e.target.value)
                    }),
                    isInvalidTransferAddress || transferAddressEqualsConnectedAddress && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        fontSize: "12px",
                        color: "failure",
                        mt: "4px",
                        children: getErrorText()
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                gridTemplateColumns: "32px 1fr",
                p: "16px",
                maxWidth: "360px",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        alignSelf: "flex-start",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.ErrorIcon, {
                            width: 24,
                            height: 24,
                            color: "textSubtle"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        small: true,
                        color: "textSubtle",
                        children: t('This action will send your NFT to the address you have indicated above. Make sure it’s the correct')
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_shared_styles__WEBPACK_IMPORTED_MODULE_5__/* .Divider */ .iz, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                flexDirection: "column",
                px: "16px",
                pb: "16px",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                    mb: "8px",
                    onClick: continueToNextStage,
                    disabled: isInvalidTransferAddress || transferAddress.length === 0 || transferAddressEqualsConnectedAddress,
                    children: t('Confirm')
                })
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TransferStage);

});

/***/ }),

/***/ 79728:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export modalTitles */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(18054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ethersproject_units__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(93138);
/* harmony import */ var _ethersproject_units__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_units__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var hooks_useTheme__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(23917);
/* harmony import */ var hooks_useApproveConfirmTransaction__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(67218);
/* harmony import */ var hooks_useCallWithGasPrice__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(71228);
/* harmony import */ var hooks_useToast__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(789);
/* harmony import */ var components_Toast__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(63937);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(99150);
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(38328);
/* harmony import */ var hooks_useContract__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(46063);
/* harmony import */ var views_Nft_market_hooks_useGetLowestPrice__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(35780);
/* harmony import */ var _SellStage__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(41141);
/* harmony import */ var _SetPriceStage__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(94907);
/* harmony import */ var _EditStage__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(31113);
/* harmony import */ var _shared_ApproveAndConfirmStage__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(95491);
/* harmony import */ var _shared_TransactionConfirmed__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(49903);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(72495);
/* harmony import */ var _types__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(22537);
/* harmony import */ var _shared_ConfirmStage__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(18017);
/* harmony import */ var _RemoveStage__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(52725);
/* harmony import */ var _TransferStage__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(16006);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_TransferStage__WEBPACK_IMPORTED_MODULE_22__, _SetPriceStage__WEBPACK_IMPORTED_MODULE_14__, _SellStage__WEBPACK_IMPORTED_MODULE_13__, _styles__WEBPACK_IMPORTED_MODULE_18__, views_Nft_market_hooks_useGetLowestPrice__WEBPACK_IMPORTED_MODULE_12__, hooks_useCallWithGasPrice__WEBPACK_IMPORTED_MODULE_6__, hooks_useTheme__WEBPACK_IMPORTED_MODULE_4__]);
([_TransferStage__WEBPACK_IMPORTED_MODULE_22__, _SetPriceStage__WEBPACK_IMPORTED_MODULE_14__, _SellStage__WEBPACK_IMPORTED_MODULE_13__, _styles__WEBPACK_IMPORTED_MODULE_18__, views_Nft_market_hooks_useGetLowestPrice__WEBPACK_IMPORTED_MODULE_12__, hooks_useCallWithGasPrice__WEBPACK_IMPORTED_MODULE_6__, hooks_useTheme__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);























const modalTitles = (stage, t)=>{
    switch(stage){
        // Sell flow
        case _types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.SELL */ ._.SELL:
            return t('Details');
        case _types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.SET_PRICE */ ._.SET_PRICE:
        case _types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.APPROVE_AND_CONFIRM_SELL */ ._.APPROVE_AND_CONFIRM_SELL:
            return t('Back');
        // Adjust price flow
        case _types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.EDIT */ ._.EDIT:
            return t('Details');
        case _types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.ADJUST_PRICE */ ._.ADJUST_PRICE:
            return t('Back');
        case _types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.CONFIRM_ADJUST_PRICE */ ._.CONFIRM_ADJUST_PRICE:
            return t('Confirm transaction');
        // Remove from market flow
        case _types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.REMOVE_FROM_MARKET */ ._.REMOVE_FROM_MARKET:
            return t('Back');
        case _types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.CONFIRM_REMOVE_FROM_MARKET */ ._.CONFIRM_REMOVE_FROM_MARKET:
            return t('Confirm transaction');
        // Transfer flow
        case _types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.TRANSFER */ ._.TRANSFER:
            return t('Back');
        case _types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.CONFIRM_TRANSFER */ ._.CONFIRM_TRANSFER:
            return t('Confirm transaction');
        // Common
        case _types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.TX_CONFIRMED */ ._.TX_CONFIRMED:
            return t('Transaction Confirmed');
        default:
            return '';
    }
};
const getToastText = (variant, stage, t)=>{
    if (stage === _types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.CONFIRM_REMOVE_FROM_MARKET */ ._.CONFIRM_REMOVE_FROM_MARKET) {
        return t('Your NFT has been returned to your wallet');
    }
    if (stage === _types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.CONFIRM_TRANSFER */ ._.CONFIRM_TRANSFER) {
        return t('Your NFT has been transferred to another wallet');
    }
    if (variant === 'sell') {
        return t('Your NFT has been listed for sale!');
    }
    return t('Your NFT listing has been changed.');
};
const SellModal = ({ variant , nftToSell , onDismiss , onSuccessSale , onSuccessEditProfile ,  })=>{
    const { 0: stage , 1: setStage  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(variant === 'sell' ? _types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.SELL */ ._.SELL : _types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.EDIT */ ._.EDIT);
    const { 0: price , 1: setPrice  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(variant === 'sell' ? '' : nftToSell.marketData.currentAskPrice);
    const { 0: transferAddress , 1: setTransferAddress  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const { 0: confirmedTxHash , 1: setConfirmedTxHash  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_9__/* .useTranslation */ .$G)();
    const { theme  } = (0,hooks_useTheme__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)();
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_2__.useWeb3React)();
    const { callWithGasPrice  } = (0,hooks_useCallWithGasPrice__WEBPACK_IMPORTED_MODULE_6__/* .useCallWithGasPrice */ .d)();
    const { toastSuccess  } = (0,hooks_useToast__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
    const collectionContract = (0,hooks_useContract__WEBPACK_IMPORTED_MODULE_11__/* .useErc721CollectionContract */ .HQ)(nftToSell.collectionAddress);
    const nftMarketContract = (0,hooks_useContract__WEBPACK_IMPORTED_MODULE_11__/* .useNftMarketContract */ .DU)();
    const isInvalidTransferAddress = transferAddress.length > 0 && !(0,utils__WEBPACK_IMPORTED_MODULE_10__/* .isAddress */ .UJ)(transferAddress);
    const { lowestPrice  } = (0,views_Nft_market_hooks_useGetLowestPrice__WEBPACK_IMPORTED_MODULE_12__/* .useGetLowestPriceFromNft */ .O)(nftToSell);
    const goBack = ()=>{
        switch(stage){
            case _types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.SET_PRICE */ ._.SET_PRICE:
                setStage(_types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.SELL */ ._.SELL);
                break;
            case _types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.APPROVE_AND_CONFIRM_SELL */ ._.APPROVE_AND_CONFIRM_SELL:
                setStage(_types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.SET_PRICE */ ._.SET_PRICE);
                break;
            case _types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.ADJUST_PRICE */ ._.ADJUST_PRICE:
                setPrice(nftToSell.marketData.currentAskPrice);
                setStage(_types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.EDIT */ ._.EDIT);
                break;
            case _types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.CONFIRM_ADJUST_PRICE */ ._.CONFIRM_ADJUST_PRICE:
                setStage(_types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.ADJUST_PRICE */ ._.ADJUST_PRICE);
                break;
            case _types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.REMOVE_FROM_MARKET */ ._.REMOVE_FROM_MARKET:
                setStage(_types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.EDIT */ ._.EDIT);
                break;
            case _types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.CONFIRM_REMOVE_FROM_MARKET */ ._.CONFIRM_REMOVE_FROM_MARKET:
                setStage(_types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.REMOVE_FROM_MARKET */ ._.REMOVE_FROM_MARKET);
                break;
            case _types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.TRANSFER */ ._.TRANSFER:
                setStage(_types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.SELL */ ._.SELL);
                break;
            case _types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.CONFIRM_TRANSFER */ ._.CONFIRM_TRANSFER:
                setStage(_types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.TRANSFER */ ._.TRANSFER);
                break;
            default:
                break;
        }
    };
    const continueToNextStage = ()=>{
        switch(stage){
            case _types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.SELL */ ._.SELL:
                setStage(_types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.SET_PRICE */ ._.SET_PRICE);
                break;
            case _types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.SET_PRICE */ ._.SET_PRICE:
                setStage(_types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.APPROVE_AND_CONFIRM_SELL */ ._.APPROVE_AND_CONFIRM_SELL);
                break;
            case _types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.EDIT */ ._.EDIT:
                setStage(_types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.ADJUST_PRICE */ ._.ADJUST_PRICE);
                break;
            case _types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.ADJUST_PRICE */ ._.ADJUST_PRICE:
                setStage(_types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.CONFIRM_ADJUST_PRICE */ ._.CONFIRM_ADJUST_PRICE);
                break;
            case _types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.REMOVE_FROM_MARKET */ ._.REMOVE_FROM_MARKET:
                setStage(_types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.CONFIRM_REMOVE_FROM_MARKET */ ._.CONFIRM_REMOVE_FROM_MARKET);
                break;
            case _types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.TRANSFER */ ._.TRANSFER:
                setStage(_types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.CONFIRM_TRANSFER */ ._.CONFIRM_TRANSFER);
                break;
            default:
                break;
        }
    };
    const continueToRemoveFromMarketStage = ()=>{
        setStage(_types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.REMOVE_FROM_MARKET */ ._.REMOVE_FROM_MARKET);
    };
    const continueToTransferStage = ()=>{
        setStage(_types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.TRANSFER */ ._.TRANSFER);
    };
    const { isApproving , isApproved , isConfirming , handleApprove , handleConfirm  } = (0,hooks_useApproveConfirmTransaction__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)({
        onRequiresApproval: async ()=>{
            try {
                const approvedForContract = await collectionContract.isApprovedForAll(account, nftMarketContract.address);
                return approvedForContract;
            } catch (error) {
                return false;
            }
        },
        onApprove: ()=>{
            return callWithGasPrice(collectionContract, 'setApprovalForAll', [
                nftMarketContract.address,
                true
            ]);
        },
        onApproveSuccess: async ({ receipt  })=>{
            toastSuccess(t('Contract approved - you can now put your NFT for sale!'), /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_8__/* .ToastDescriptionWithTx */ .YO, {
                txHash: receipt.transactionHash
            }));
        },
        onConfirm: ()=>{
            if (stage === _types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.CONFIRM_REMOVE_FROM_MARKET */ ._.CONFIRM_REMOVE_FROM_MARKET) {
                return callWithGasPrice(nftMarketContract, 'cancelAskOrder', [
                    nftToSell.collectionAddress,
                    nftToSell.tokenId
                ]);
            }
            if (stage === _types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.CONFIRM_TRANSFER */ ._.CONFIRM_TRANSFER) {
                return callWithGasPrice(collectionContract, 'safeTransferFrom(address,address,uint256)', [
                    account,
                    transferAddress,
                    nftToSell.tokenId, 
                ]);
            }
            const methodName = variant === 'sell' ? 'createAskOrder' : 'modifyAskOrder';
            const askPrice = (0,_ethersproject_units__WEBPACK_IMPORTED_MODULE_3__.parseUnits)(price);
            return callWithGasPrice(nftMarketContract, methodName, [
                nftToSell.collectionAddress,
                nftToSell.tokenId,
                askPrice
            ]);
        },
        onSuccess: async ({ receipt  })=>{
            toastSuccess(getToastText(variant, stage, t), /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_8__/* .ToastDescriptionWithTx */ .YO, {
                txHash: receipt.transactionHash
            }));
            onSuccessSale();
            setConfirmedTxHash(receipt.transactionHash);
            setStage(_types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.TX_CONFIRMED */ ._.TX_CONFIRMED);
        }
    });
    const showBackButton = _styles__WEBPACK_IMPORTED_MODULE_18__/* .stagesWithBackButton.includes */ .BF.includes(stage) && !isConfirming && !isApproving;
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styles__WEBPACK_IMPORTED_MODULE_18__/* .StyledModal */ .oA, {
        title: modalTitles(stage, t),
        stage: stage,
        onDismiss: onDismiss,
        onBack: showBackButton ? goBack : null,
        headerBackground: theme.colors.gradients.cardHeader,
        children: [
            stage === _types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.SELL */ ._.SELL && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SellStage__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                nftToSell: nftToSell,
                lowestPrice: lowestPrice,
                continueToNextStage: continueToNextStage,
                continueToTransferStage: continueToTransferStage,
                onSuccessEditProfile: onSuccessEditProfile
            }),
            stage === _types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.SET_PRICE */ ._.SET_PRICE && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SetPriceStage__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                nftToSell: nftToSell,
                variant: "set",
                continueToNextStage: continueToNextStage,
                lowestPrice: lowestPrice,
                price: price,
                setPrice: setPrice
            }),
            stage === _types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.APPROVE_AND_CONFIRM_SELL */ ._.APPROVE_AND_CONFIRM_SELL && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_shared_ApproveAndConfirmStage__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                variant: "sell",
                isApproved: isApproved,
                isApproving: isApproving,
                isConfirming: isConfirming,
                handleApprove: handleApprove,
                handleConfirm: handleConfirm
            }),
            stage === _types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.TX_CONFIRMED */ ._.TX_CONFIRMED && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_shared_TransactionConfirmed__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                txHash: confirmedTxHash,
                onDismiss: onDismiss
            }),
            stage === _types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.EDIT */ ._.EDIT && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_EditStage__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                nftToSell: nftToSell,
                lowestPrice: lowestPrice,
                continueToAdjustPriceStage: continueToNextStage,
                continueToRemoveFromMarketStage: continueToRemoveFromMarketStage
            }),
            stage === _types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.ADJUST_PRICE */ ._.ADJUST_PRICE && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SetPriceStage__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                nftToSell: nftToSell,
                variant: "adjust",
                continueToNextStage: continueToNextStage,
                currentPrice: nftToSell.marketData.currentAskPrice,
                lowestPrice: lowestPrice,
                price: price,
                setPrice: setPrice
            }),
            stage === _types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.CONFIRM_ADJUST_PRICE */ ._.CONFIRM_ADJUST_PRICE && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_shared_ConfirmStage__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {
                isConfirming: isConfirming,
                handleConfirm: handleConfirm
            }),
            stage === _types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.REMOVE_FROM_MARKET */ ._.REMOVE_FROM_MARKET && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_RemoveStage__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .Z, {
                continueToNextStage: continueToNextStage
            }),
            stage === _types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.CONFIRM_REMOVE_FROM_MARKET */ ._.CONFIRM_REMOVE_FROM_MARKET && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_shared_ConfirmStage__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {
                isConfirming: isConfirming,
                handleConfirm: handleConfirm
            }),
            stage === _types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.TRANSFER */ ._.TRANSFER && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TransferStage__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .Z, {
                nftToSell: nftToSell,
                lowestPrice: lowestPrice,
                continueToNextStage: continueToNextStage,
                transferAddress: transferAddress,
                setTransferAddress: setTransferAddress,
                isInvalidTransferAddress: isInvalidTransferAddress
            }),
            stage === _types__WEBPACK_IMPORTED_MODULE_19__/* .SellingStage.CONFIRM_TRANSFER */ ._.CONFIRM_TRANSFER && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_shared_ConfirmStage__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {
                isConfirming: isConfirming,
                handleConfirm: handleConfirm
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SellModal);

});

/***/ }),

/***/ 72495:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BF": () => (/* binding */ stagesWithBackButton),
/* harmony export */   "oA": () => (/* binding */ StyledModal),
/* harmony export */   "V0": () => (/* binding */ GreyedOutContainer),
/* harmony export */   "Bp": () => (/* binding */ RightAlignedInput),
/* harmony export */   "U2": () => (/* binding */ BnbAmountCell),
/* harmony export */   "tz": () => (/* binding */ FeeAmountCell)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var hooks_useBUSDPrice__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(90834);
/* harmony import */ var utils_prices__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7879);
/* harmony import */ var _types__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(22537);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks_useBUSDPrice__WEBPACK_IMPORTED_MODULE_4__]);
hooks_useBUSDPrice__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];







const stagesWithBackButton = [
    _types__WEBPACK_IMPORTED_MODULE_6__/* .SellingStage.SET_PRICE */ ._.SET_PRICE,
    _types__WEBPACK_IMPORTED_MODULE_6__/* .SellingStage.ADJUST_PRICE */ ._.ADJUST_PRICE,
    _types__WEBPACK_IMPORTED_MODULE_6__/* .SellingStage.APPROVE_AND_CONFIRM_SELL */ ._.APPROVE_AND_CONFIRM_SELL,
    _types__WEBPACK_IMPORTED_MODULE_6__/* .SellingStage.CONFIRM_ADJUST_PRICE */ ._.CONFIRM_ADJUST_PRICE,
    _types__WEBPACK_IMPORTED_MODULE_6__/* .SellingStage.REMOVE_FROM_MARKET */ ._.REMOVE_FROM_MARKET,
    _types__WEBPACK_IMPORTED_MODULE_6__/* .SellingStage.CONFIRM_REMOVE_FROM_MARKET */ ._.CONFIRM_REMOVE_FROM_MARKET,
    _types__WEBPACK_IMPORTED_MODULE_6__/* .SellingStage.TRANSFER */ ._.TRANSFER,
    _types__WEBPACK_IMPORTED_MODULE_6__/* .SellingStage.CONFIRM_TRANSFER */ ._.CONFIRM_TRANSFER, 
];
const StyledModal = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Modal).withConfig({
    componentId: "sc-a3790fca-0"
})`
  width: 360px;
  & > div:last-child {
    padding: 0;
  }
  & h2:first-of-type {
    ${({ stage , theme  })=>stagesWithBackButton.includes(stage) ? `color: ${theme.colors.textSubtle}` : null
};
  }
  & svg:first-of-type {
    ${({ stage , theme  })=>stagesWithBackButton.includes(stage) ? `fill: ${theme.colors.textSubtle}` : null
};
  }
`;
const GreyedOutContainer = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Box).withConfig({
    componentId: "sc-a3790fca-1"
})`
  background-color: ${({ theme  })=>theme.colors.dropdown
};
  padding: 16px;
`;
const RightAlignedInput = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Input).withConfig({
    componentId: "sc-a3790fca-2"
})`
  text-align: right;
`;
const BnbAmountCell = ({ bnbAmount  })=>{
    const bnbBusdPrice = (0,hooks_useBUSDPrice__WEBPACK_IMPORTED_MODULE_4__/* .useBNBBusdPrice */ .Hf)();
    if (!bnbAmount || bnbAmount === 0) {
        return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
            alignItems: "center",
            justifyContent: "flex-end",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.BinanceIcon, {
                    width: 16,
                    height: 16,
                    mr: "4px"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                    bold: true,
                    mr: "4px",
                    children: "-"
                })
            ]
        }));
    }
    const usdAmount = (0,utils_prices__WEBPACK_IMPORTED_MODULE_5__/* .multiplyPriceByAmount */ .as)(bnbBusdPrice, bnbAmount);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
        alignItems: "center",
        justifyContent: "flex-end",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.BinanceIcon, {
                width: 16,
                height: 16,
                mr: "4px"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                bold: true,
                mr: "4px",
                children: `${bnbAmount.toLocaleString(undefined, {
                    minimumFractionDigits: 3,
                    maximumFractionDigits: 3
                })}`
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                small: true,
                color: "textSubtle",
                textAlign: "right",
                children: `($${usdAmount.toLocaleString(undefined, {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                })})`
            })
        ]
    }));
};
const FeeAmountCell = ({ bnbAmount , creatorFee , tradingFee  })=>{
    if (!bnbAmount || bnbAmount === 0) {
        return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
            alignItems: "center",
            justifyContent: "flex-end",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.BinanceIcon, {
                    width: 16,
                    height: 16,
                    mr: "4px"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                    bold: true,
                    mr: "4px",
                    children: "-"
                })
            ]
        }));
    }
    const totalFee = creatorFee + tradingFee;
    const totalFeeAsDecimal = totalFee / 100;
    const feeAmount = bnbAmount * totalFeeAsDecimal;
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
        alignItems: "center",
        justifyContent: "flex-end",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.BinanceIcon, {
                width: 16,
                height: 16,
                mr: "4px"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                bold: true,
                mr: "4px",
                children: `${feeAmount.toLocaleString(undefined, {
                    minimumFractionDigits: 3,
                    maximumFractionDigits: 6
                })}`
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                small: true,
                color: "textSubtle",
                textAlign: "right",
                children: [
                    "(",
                    totalFee,
                    "%)"
                ]
            })
        ]
    }));
};

});

/***/ }),

/***/ 22537:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "_": () => (/* binding */ SellingStage)
/* harmony export */ });
var SellingStage;
(function(SellingStage) {
    SellingStage[SellingStage[// Sell flow
    "SELL"] = 0] = "SELL";
    SellingStage[SellingStage["SET_PRICE"] = 1] = "SET_PRICE";
    SellingStage[SellingStage["APPROVE_AND_CONFIRM_SELL"] = 2] = "APPROVE_AND_CONFIRM_SELL";
    SellingStage[SellingStage[// Adjust price flow
    "EDIT"] = 3] = "EDIT";
    SellingStage[SellingStage["ADJUST_PRICE"] = 4] = "ADJUST_PRICE";
    SellingStage[SellingStage["CONFIRM_ADJUST_PRICE"] = 5] = "CONFIRM_ADJUST_PRICE";
    SellingStage[SellingStage[// Remove from market flow
    "REMOVE_FROM_MARKET"] = 6] = "REMOVE_FROM_MARKET";
    SellingStage[SellingStage["CONFIRM_REMOVE_FROM_MARKET"] = 7] = "CONFIRM_REMOVE_FROM_MARKET";
    SellingStage[SellingStage[// Transfer flow
    "TRANSFER"] = 8] = "TRANSFER";
    SellingStage[SellingStage["CONFIRM_TRANSFER"] = 9] = "CONFIRM_TRANSFER";
    SellingStage[SellingStage[// Common
    "TX_CONFIRMED"] = 10] = "TX_CONFIRMED";
})(SellingStage || (SellingStage = {}));


/***/ }),

/***/ 95491:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(99150);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(33482);





// Buy Flow:
// Shown if user wants to pay with WBNB and contract isn't approved yet
// Sell Flow:
// Shown the first time user puts NFT for sale
const ApproveAndConfirmStage = ({ variant , isApproved , isApproving , isConfirming , handleApprove , handleConfirm ,  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_3__/* .useTranslation */ .$G)();
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
        p: "16px",
        flexDirection: "column",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                mb: "8px",
                alignItems: "center",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        flexDirection: "column",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                                alignItems: "center",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styles__WEBPACK_IMPORTED_MODULE_4__/* .StepIndicator */ .OR, {
                                        success: isApproved,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                            fontSize: "20px",
                                            bold: true,
                                            color: "invertedContrast",
                                            children: "1"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                        fontSize: "20px",
                                        color: isApproved ? 'success' : 'secondary',
                                        bold: true,
                                        children: isApproved ? t('Enabled') : t('Enable')
                                    })
                                ]
                            }),
                            !isApproved && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                mt: "8px",
                                maxWidth: "275px",
                                small: true,
                                color: "textSubtle",
                                children: variant === 'buy' ? t('Please enable WBNB spending in your wallet') : t('Please enable your NFT to be sent to the market')
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        flex: "0 0 64px",
                        width: "64px",
                        children: isApproving && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Spinner, {
                            size: 64
                        })
                    })
                ]
            }),
            !isApproved && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                variant: "secondary",
                disabled: isApproving,
                onClick: handleApprove,
                children: isApproving ? `${t('Enabling')}...` : t('Enable')
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                alignItems: "center",
                mt: "8px",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        flexDirection: "column",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                                alignItems: "center",
                                mt: "16px",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styles__WEBPACK_IMPORTED_MODULE_4__/* .StepIndicator */ .OR, {
                                        success: !!0,
                                        disabled: !isApproved,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                            fontSize: "20px",
                                            bold: true,
                                            color: !isApproved ? 'textDisabled' : 'invertedContrast',
                                            children: "2"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                        fontSize: "20px",
                                        bold: true,
                                        color: isApproved ? 'secondary' : 'textDisabled',
                                        children: t('Confirm')
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                small: true,
                                color: isApproved ? 'textSubtle' : 'textDisabled',
                                children: t('Please confirm the transaction in your wallet')
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        flex: "0 0 64px",
                        width: "64px",
                        children: isConfirming && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Spinner, {
                            size: 64
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                mt: "16px",
                disabled: !isApproved || isConfirming,
                onClick: handleConfirm,
                variant: "secondary",
                children: isConfirming ? t('Confirming') : t('Confirm')
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ApproveAndConfirmStage);


/***/ }),

/***/ 18017:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(99150);




// Buy Flow:
// Shown in case user wants to pay with BNB
// or if user wants to pay with WBNB and it is already approved
// Sell Flow:
// Shown if user adjusts the price or removes NFT from the market
const ConfirmStage = ({ isConfirming , handleConfirm  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_3__/* .useTranslation */ .$G)();
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
        p: "16px",
        flexDirection: "column",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                alignItems: "center",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        flexDirection: "column",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                                alignItems: "center",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                    fontSize: "20px",
                                    bold: true,
                                    color: "secondary",
                                    children: t('Confirm')
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                small: true,
                                color: "textSubtle",
                                children: t('Please confirm the transaction in your wallet')
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        flex: "0 0 64px",
                        height: "72px",
                        width: "64px",
                        children: isConfirming && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Spinner, {
                            size: 64
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                mt: "24px",
                disabled: isConfirming,
                onClick: handleConfirm,
                variant: "secondary",
                children: isConfirming ? `${t('Confirming')}...` : t('Confirm')
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ConfirmStage);


/***/ }),

/***/ 49903:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(99150);
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(38328);
/* harmony import */ var hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(64011);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(33482);







const TransactionConfirmed = ({ txHash , onDismiss  })=>{
    const { chainId  } = (0,hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)();
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_3__/* .useTranslation */ .$G)();
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                p: "16px",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "space-between",
                height: "150px",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.ArrowUpIcon, {
                        width: "64px",
                        height: "64px",
                        color: "primary"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        bold: true,
                        children: t('Transaction Confirmed')
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.LinkExternal, {
                        href: (0,utils__WEBPACK_IMPORTED_MODULE_4__/* .getBscScanLink */ .s6)(txHash, 'transaction', chainId),
                        children: t('View on BscScan')
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styles__WEBPACK_IMPORTED_MODULE_6__/* .Divider */ .iz, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                px: "16px",
                pb: "16px",
                justifyContent: "center",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                    onClick: onDismiss,
                    variant: "secondary",
                    width: "100%",
                    children: t('Close')
                })
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TransactionConfirmed);


/***/ }),

/***/ 33482:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "_v": () => (/* binding */ RoundedImage),
/* harmony export */   "iz": () => (/* binding */ Divider),
/* harmony export */   "EL": () => (/* binding */ HorizontalDivider),
/* harmony export */   "OR": () => (/* binding */ StepIndicator)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__);


const RoundedImage = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Image).withConfig({
    componentId: "sc-fd207d6c-0"
})`
  border-radius: ${({ theme  })=>theme.radii.small
};
  overflow: hidden;
`;
const Divider = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
    componentId: "sc-fd207d6c-1"
})`
  margin: 16px 0;
  border-bottom: 1px solid ${({ theme  })=>theme.colors.cardBorder
};
`;
const HorizontalDivider = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
    componentId: "sc-fd207d6c-2"
})`
  border-right: 1px solid ${({ theme  })=>theme.colors.cardBorder
};
`;
const StepIndicator = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Flex).withConfig({
    componentId: "sc-fd207d6c-3"
})`
  border-radius: 50%;
  background-color: ${({ theme , success , disabled  })=>{
    if (disabled) {
        return 'none';
    }
    return success ? theme.colors.success : theme.colors.secondary;
}};
  border: ${({ theme , disabled  })=>disabled ? `1px solid ${theme.colors.textDisabled}` : 'none'
};
  height: 32px;
  width: 32px;
  justify-content: center;
  align-items: center;
  margin-right: 8px;
`;


/***/ }),

/***/ 70739:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export StyledModal */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var hooks_useTheme__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(23917);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(99150);
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(38328);
/* harmony import */ var _BuySellModals_shared_styles__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(33482);
/* harmony import */ var _Profile_components_EditProfileModal__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(92583);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1940);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks_useTheme__WEBPACK_IMPORTED_MODULE_3__, _Profile_components_EditProfileModal__WEBPACK_IMPORTED_MODULE_8__]);
([hooks_useTheme__WEBPACK_IMPORTED_MODULE_3__, _Profile_components_EditProfileModal__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);










const StyledModal = styled_components__WEBPACK_IMPORTED_MODULE_4___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Modal).withConfig({
    componentId: "sc-9a5c0e0c-0"
})`
  & > div:last-child {
    padding: 0;
  }
`;
const TextWrapper = styled_components__WEBPACK_IMPORTED_MODULE_4___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex).withConfig({
    componentId: "sc-9a5c0e0c-1"
})`
  background-color: ${({ theme  })=>theme.colors.dropdown
};
`;
const ProfileNftModal = ({ nft , onDismiss , onSuccess  })=>{
    const [onEditProfileModal] = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.useModal)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Profile_components_EditProfileModal__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
        onSuccess: onSuccess
    }), false);
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_5__/* .useTranslation */ .$G)();
    const { theme  } = (0,hooks_useTheme__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)();
    const itemPageUrlId = nft.collectionAddress === _constants__WEBPACK_IMPORTED_MODULE_9__/* .pancakeBunniesAddress */ .Jr ? nft.attributes[0].value : nft.tokenId;
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledModal, {
        title: t('Details'),
        onDismiss: onDismiss,
        headerBackground: theme.colors.gradients.cardHeader,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
            flexDirection: "column",
            maxWidth: "350px",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                    p: "16px",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_BuySellModals_shared_styles__WEBPACK_IMPORTED_MODULE_7__/* .RoundedImage */ ._v, {
                            src: nft.image.thumbnail,
                            height: 68,
                            width: 68,
                            mr: "16px"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                            flex: "1",
                            gridTemplateColumns: "1fr 1fr",
                            alignItems: "center",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                    bold: true,
                                    children: nft.name
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                    fontSize: "12px",
                                    color: "textSubtle",
                                    textAlign: "right",
                                    children: nft.collectionName
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                    justifyContent: "space-between",
                    px: "16px",
                    mb: "16px",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                            flex: "2",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                small: true,
                                color: "textSubtle",
                                children: t('Token ID: %id%', {
                                    id: nft.tokenId
                                })
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                            justifyContent: "space-between",
                            flex: "3",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                                    as: _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Link,
                                    p: "0px",
                                    height: "16px",
                                    external: true,
                                    variant: "text",
                                    href: `${_constants__WEBPACK_IMPORTED_MODULE_9__/* .nftsBaseUrl */ .Vf}/collections/${nft.collectionAddress}/${itemPageUrlId}`,
                                    children: t('View Item')
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_BuySellModals_shared_styles__WEBPACK_IMPORTED_MODULE_7__/* .HorizontalDivider */ .EL, {}),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.LinkExternal, {
                                    p: "0px",
                                    height: "16px",
                                    href: (0,utils__WEBPACK_IMPORTED_MODULE_6__/* .getBscScanLinkForNft */ .z)(nft.collectionAddress, nft.tokenId),
                                    children: "BscScan"
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(TextWrapper, {
                    p: "24px 16px",
                    flexDirection: "column",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                            mb: "16px",
                            children: t("You're using this NFT as your Pancake Profile picture")
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                            color: "textSubtle",
                            mb: "16px",
                            fontSize: "14px",
                            children: t('Removing it will suspend your profile, and you won’t be able to earn points, participate in team activities, or be eligible for new NFT drops.')
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                            color: "textSubtle",
                            fontSize: "14px",
                            children: t('Go to your profile page to continue.')
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                    flexDirection: "column",
                    py: "16px",
                    px: "16px",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                        onClick: onEditProfileModal,
                        width: "100%",
                        variant: "secondary",
                        children: t('Remove Profile Pic')
                    })
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProfileNftModal);

});

/***/ })

};
;
//# sourceMappingURL=3169.js.map