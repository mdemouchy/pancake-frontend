"use strict";
exports.id = 570;
exports.ids = [570];
exports.modules = {

/***/ 90570:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ uriToHttp)
/* harmony export */ });
/* eslint-disable no-case-declarations */ /**
 * Given a URI that may be ipfs, ipns, http, or https protocol, return the fetch-able http(s) URLs for the same content
 * @param uri to convert to fetch-able http url
 */ function uriToHttp(uri) {
    const protocol = uri.split(':')[0].toLowerCase();
    switch(protocol){
        case 'https':
            return [
                uri
            ];
        case 'http':
            return [
                `https${uri.substr(4)}`,
                uri
            ];
        case 'ipfs':
            const hash = uri.match(/^ipfs:(\/\/)?(.*)$/i)?.[2];
            return [
                `https://cloudflare-ipfs.com/ipfs/${hash}/`,
                `https://ipfs.io/ipfs/${hash}/`
            ];
        case 'ipns':
            const name = uri.match(/^ipns:(\/\/)?(.*)$/i)?.[2];
            return [
                `https://cloudflare-ipfs.com/ipns/${name}/`,
                `https://ipfs.io/ipns/${name}/`
            ];
        default:
            return [];
    }
};


/***/ })

};
;
//# sourceMappingURL=570.js.map