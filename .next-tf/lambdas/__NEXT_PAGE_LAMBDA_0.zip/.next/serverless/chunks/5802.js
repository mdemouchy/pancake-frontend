"use strict";
exports.id = 5802;
exports.ids = [5802];
exports.modules = {

/***/ 36196:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _Layout_Page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9770);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Layout_Page__WEBPACK_IMPORTED_MODULE_4__]);
_Layout_Page__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];





const Wrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_Layout_Page__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z).withConfig({
    componentId: "sc-6c1c763b-0"
})`
  display: flex;
  justify-content: center;
  align-items: center;
`;
const PageLoader = ()=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Wrapper, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Spinner, {})
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PageLoader);

});

/***/ }),

/***/ 13968:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "vD": () => (/* binding */ useFetchCollections),
/* harmony export */   "TX": () => (/* binding */ useFetchCollection),
/* harmony export */   "Cp": () => (/* binding */ useFetchByBunnyIdAndUpdate),
/* harmony export */   "$C": () => (/* binding */ useLoadingState),
/* harmony export */   "t8": () => (/* binding */ useGetCollections),
/* harmony export */   "YD": () => (/* binding */ useGetCollection),
/* harmony export */   "aA": () => (/* binding */ useNftsFromCollection),
/* harmony export */   "Uc": () => (/* binding */ useGetAllBunniesByBunnyId),
/* harmony export */   "l2": () => (/* binding */ useGetNFTInitializationState),
/* harmony export */   "mN": () => (/* binding */ useApprovalNfts),
/* harmony export */   "DI": () => (/* binding */ useGetNftFilters),
/* harmony export */   "fm": () => (/* binding */ useGetNftFilterLoadingState),
/* harmony export */   "D7": () => (/* binding */ useGetNftOrdering),
/* harmony export */   "q4": () => (/* binding */ useGetNftShowOnlyOnSale),
/* harmony export */   "ly": () => (/* binding */ useGetNftActivityFilters)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var state__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(82727);
/* harmony import */ var views_Nft_market_constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1940);
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(38328);
/* harmony import */ var config_constants_types__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(97971);
/* harmony import */ var config_abi_erc721_json__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(53400);
/* harmony import */ var hooks_useSWRContract__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(38472);
/* harmony import */ var utils_constantObjects__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1243);
/* harmony import */ var utils_addressHelpers__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(55878);
/* harmony import */ var _reducer__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(38263);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks_useSWRContract__WEBPACK_IMPORTED_MODULE_7__]);
hooks_useSWRContract__WEBPACK_IMPORTED_MODULE_7__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];











const DEFAULT_NFT_ORDERING = {
    field: 'currentAskPrice',
    direction: 'asc'
};
const DEFAULT_NFT_ACTIVITY_FILTER = {
    typeFilters: [],
    collectionFilters: []
};
const useFetchCollections = ()=>{
    const dispatch = (0,state__WEBPACK_IMPORTED_MODULE_2__/* .useAppDispatch */ .TL)();
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        dispatch((0,_reducer__WEBPACK_IMPORTED_MODULE_10__/* .fetchCollections */ .XK)());
    }, [
        dispatch
    ]);
};
const useFetchCollection = (collectionAddress)=>{
    const dispatch = (0,state__WEBPACK_IMPORTED_MODULE_2__/* .useAppDispatch */ .TL)();
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        dispatch((0,_reducer__WEBPACK_IMPORTED_MODULE_10__/* .fetchCollection */ .lA)(collectionAddress));
    }, [
        dispatch,
        collectionAddress
    ]);
};
// Returns a function that fetches more NFTs for specified bunny id
// as well as updating existing PB NFTs in state
// Note: PancakeBunny specific
const useFetchByBunnyIdAndUpdate = (bunnyId)=>{
    const dispatch = (0,state__WEBPACK_IMPORTED_MODULE_2__/* .useAppDispatch */ .TL)();
    const { latestPancakeBunniesUpdateAt , isUpdatingPancakeBunnies  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.nftMarket.data.loadingState
    );
    // Extra guard in case market data shifts
    // we don't wanna fetch same tokens multiple times
    const existingBunniesInState = useGetAllBunniesByBunnyId(bunnyId);
    const existingTokensWithBunnyId = existingBunniesInState ? existingBunniesInState.map((nft)=>nft.tokenId
    ) : [];
    const allPancakeBunnies = useNftsFromCollection(views_Nft_market_constants__WEBPACK_IMPORTED_MODULE_3__/* .pancakeBunniesAddress */ .Jr);
    const allExistingPBTokenIds = allPancakeBunnies ? allPancakeBunnies.map((nft)=>nft.tokenId
    ) : [];
    const firstBunny = existingBunniesInState.length > 0 ? existingBunniesInState[0] : null;
    // If we already have NFT with this bunny id in state - we can reuse its metadata without making API request
    const existingMetadata = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        return firstBunny ? {
            name: firstBunny.name,
            description: firstBunny.description,
            collection: {
                name: firstBunny.collectionName
            },
            image: firstBunny.image
        } : null;
    }, [
        firstBunny
    ]);
    // This fetches more bunnies when called
    const fetchMorePancakeBunnies = (orderDirection)=>{
        dispatch((0,_reducer__WEBPACK_IMPORTED_MODULE_10__/* .fetchNewPBAndUpdateExisting */ .SF)({
            bunnyId,
            existingTokensWithBunnyId,
            allExistingPBTokenIds,
            existingMetadata,
            orderDirection
        }));
    };
    return {
        isUpdatingPancakeBunnies,
        latestPancakeBunniesUpdateAt,
        fetchMorePancakeBunnies
    };
};
const useLoadingState = ()=>{
    return (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.nftMarket.data.loadingState
    );
};
const useGetCollections = ()=>{
    return (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.nftMarket.data.collections
    );
};
const useGetCollection = (collectionAddress)=>{
    const checksummedCollectionAddress = (0,utils__WEBPACK_IMPORTED_MODULE_4__/* .isAddress */ .UJ)(collectionAddress) || '';
    const collections = useGetCollections();
    return collections[checksummedCollectionAddress];
};
const useNftsFromCollection = (collectionAddress)=>{
    const checksummedCollectionAddress = (0,utils__WEBPACK_IMPORTED_MODULE_4__/* .isAddress */ .UJ)(collectionAddress) || '';
    const nfts = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.nftMarket.data.nfts[checksummedCollectionAddress]
    );
    return nfts;
};
const useGetAllBunniesByBunnyId = (bunnyId)=>{
    const nfts = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.nftMarket.data.nfts[views_Nft_market_constants__WEBPACK_IMPORTED_MODULE_3__/* .pancakeBunniesAddress */ .Jr]
    );
    return nfts ? nfts.filter((nft)=>nft.attributes[0].value === bunnyId && nft.marketData.isTradable
    ) : utils_constantObjects__WEBPACK_IMPORTED_MODULE_8__/* .EMPTY_ARRAY */ .L;
};
const useGetNFTInitializationState = ()=>{
    return (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.nftMarket.initializationState
    );
};
const useApprovalNfts = (nftsInWallet)=>{
    const nftApprovalCalls = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>nftsInWallet.map((nft)=>{
            const { tokenId , collectionAddress  } = nft;
            return {
                address: collectionAddress,
                name: 'getApproved',
                params: [
                    tokenId
                ]
            };
        })
    , [
        nftsInWallet
    ]);
    const { data  } = (0,hooks_useSWRContract__WEBPACK_IMPORTED_MODULE_7__/* .useSWRMulticall */ .d5)(config_abi_erc721_json__WEBPACK_IMPORTED_MODULE_6__, nftApprovalCalls);
    const approvedTokenIds = Array.isArray(data) ? data.flat().reduce((acc, address, index)=>({
            ...acc,
            [nftsInWallet[index].tokenId]: (0,utils_addressHelpers__WEBPACK_IMPORTED_MODULE_9__/* .getPancakeProfileAddress */ .Re)() === address
        })
    , {}) : null;
    return {
        data: approvedTokenIds
    };
};
const useGetNftFilters = (collectionAddress)=>{
    const collectionFilter = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.nftMarket.data.filters[collectionAddress]
    );
    return collectionFilter ? collectionFilter.activeFilters : utils_constantObjects__WEBPACK_IMPORTED_MODULE_8__/* .EMPTY_OBJECT */ .N;
};
const useGetNftFilterLoadingState = (collectionAddress)=>{
    const collectionFilter = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.nftMarket.data.filters[collectionAddress]
    );
    return collectionFilter ? collectionFilter.loadingState : config_constants_types__WEBPACK_IMPORTED_MODULE_5__/* .FetchStatus.Idle */ .iF.Idle;
};
const useGetNftOrdering = (collectionAddress)=>{
    const collectionFilter = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.nftMarket.data.filters[collectionAddress]
    );
    return collectionFilter ? collectionFilter.ordering : DEFAULT_NFT_ORDERING;
};
const useGetNftShowOnlyOnSale = (collectionAddress)=>{
    const collectionFilter = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.nftMarket.data.filters[collectionAddress]
    );
    return collectionFilter ? collectionFilter.showOnlyOnSale : true;
};
const useGetNftActivityFilters = (collectionAddress)=>{
    const collectionFilter = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.nftMarket.data.activityFilters[collectionAddress]
    );
    return collectionFilter || DEFAULT_NFT_ACTIVITY_FILTER;
};

});

/***/ }),

/***/ 1243:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "N": () => (/* binding */ EMPTY_OBJECT),
/* harmony export */   "L": () => (/* binding */ EMPTY_ARRAY)
/* harmony export */ });
const EMPTY_OBJECT = {};
const EMPTY_ARRAY = [];


/***/ })

};
;
//# sourceMappingURL=5802.js.map