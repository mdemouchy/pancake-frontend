"use strict";
exports.id = 5500;
exports.ids = [5500];
exports.modules = {

/***/ 54282:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Kd": () => (/* binding */ BNBAmountLabel),
/* harmony export */   "NR": () => (/* binding */ CostLabel),
/* harmony export */   "Qf": () => (/* binding */ MetaRow),
/* harmony export */   "VD": () => (/* binding */ StyledCollectibleCard),
/* harmony export */   "QG": () => (/* binding */ LowestPriceMetaRow)
/* harmony export */ });
/* unused harmony exports Footer, NftTag, ProfileNftTag, WalletNftTag, SellingNftTag */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(99150);
/* harmony import */ var utils_prices__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7879);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_5__);






const Footer = ({ children , ...props })=>/*#__PURE__*/ _jsx(Box, {
        borderTop: [
            null,
            null,
            null,
            '1px solid'
        ],
        borderColor: "cardBorder",
        pt: "8px",
        ...props,
        children: children
    })
;
const BNBAmountLabel = ({ amount , ...props })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
        alignItems: "center",
        ...props,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.BinanceIcon, {
                width: "16px",
                mx: "4px"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                fontWeight: "600",
                children: amount.toLocaleString(undefined, {
                    minimumFractionDigits: 0,
                    maximumFractionDigits: 5
                })
            })
        ]
    })
;
const CostLabel = ({ cost , bnbBusdPrice , ...props })=>{
    const priceInUsd = (0,utils_prices__WEBPACK_IMPORTED_MODULE_4__/* .multiplyPriceByAmount */ .as)(bnbBusdPrice, cost);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
        alignItems: "center",
        ...props,
        children: [
            priceInUsd > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                fontSize: "12px",
                color: "textSubtle",
                children: `($${priceInUsd.toLocaleString(undefined, {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                })})`
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(BNBAmountLabel, {
                amount: cost
            })
        ]
    }));
};
const MetaRow = ({ title , children , ...props })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
        alignItems: "center",
        justifyContent: "space-between",
        ...props,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                fontSize: "12px",
                color: "textSubtle",
                maxWidth: "120px",
                ellipsis: true,
                title: title,
                children: title
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Box, {
                children: children
            })
        ]
    })
;
const NftTag = ({ icon , color ='text' , children , ...props })=>/*#__PURE__*/ _jsxs(Flex, {
        display: "inline-flex",
        alignItems: "center",
        height: "24px",
        ...props,
        children: [
            icon,
            /*#__PURE__*/ _jsx(Text, {
                color: color,
                fontSize: "14px",
                fontWeight: "600",
                children: children
            })
        ]
    })
;
const ProfileNftTag = (props)=>{
    const { t  } = useTranslation();
    return(/*#__PURE__*/ _jsx(NftTag, {
        icon: /*#__PURE__*/ _jsx(CameraIcon, {
            mr: "4px",
            width: "16px",
            color: "textSubtle"
        }),
        color: "textSubtle",
        ...props,
        children: t('Profile')
    }));
};
const WalletNftTag = (props)=>{
    const { t  } = useTranslation();
    return(/*#__PURE__*/ _jsx(NftTag, {
        icon: /*#__PURE__*/ _jsx(WalletFilledIcon, {
            mr: "4px",
            width: "16px",
            color: "secondary"
        }),
        color: "secondary",
        ...props,
        children: t('Wallet')
    }));
};
const SellingNftTag = (props)=>{
    const { t  } = useTranslation();
    return(/*#__PURE__*/ _jsx(NftTag, {
        icon: /*#__PURE__*/ _jsx(SellIcon, {
            mr: "4px",
            width: "16px",
            color: "failure"
        }),
        color: "failure",
        ...props,
        children: t('Selling')
    }));
};
const StyledCollectibleCard = styled_components__WEBPACK_IMPORTED_MODULE_5___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Card).withConfig({
    componentId: "sc-e7bb64fc-0"
})`
  border-radius: 8px;
  max-width: 320px;
  transition: opacity 200ms;

  & > div {
    border-radius: 8px;
  }

  ${({ theme  })=>theme.mediaQueries.lg
} {
    &:hover {
      cursor: pointer;
      opacity: 0.6;
    }
  }
`;
const LowestPriceMetaRow = ({ lowestPrice , isFetching , bnbBusdPrice  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_3__/* .useTranslation */ .$G)();
    if (!isFetching && !lowestPrice) {
        return null;
    }
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(MetaRow, {
        title: t('Lowest price'),
        children: isFetching ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Skeleton, {
            height: "24px",
            width: "30px"
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CostLabel, {
            cost: lowestPrice,
            bnbBusdPrice: bnbBusdPrice
        })
    }));
};


/***/ }),

/***/ 35780:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "l": () => (/* binding */ useGetLowestPriceFromBunnyId),
/* harmony export */   "O": () => (/* binding */ useGetLowestPriceFromNft)
/* harmony export */ });
/* harmony import */ var config_constants_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(97971);
/* harmony import */ var state_nftMarket_helpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(86849);
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(15941);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1940);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swr__WEBPACK_IMPORTED_MODULE_2__]);
swr__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];




const getBunnyIdFromNft = (nft)=>{
    const bunnyId = nft.attributes?.find((attr)=>attr.traitType === 'bunnyId'
    )?.value;
    return bunnyId ? bunnyId.toString() : null;
};
const useGetLowestPriceFromBunnyId = (bunnyId)=>{
    const { data , status  } = (0,swr__WEBPACK_IMPORTED_MODULE_2__["default"])(bunnyId ? [
        'bunnyLowestPrice',
        bunnyId
    ] : null, async ()=>{
        const response = await (0,state_nftMarket_helpers__WEBPACK_IMPORTED_MODULE_1__/* .getNftsMarketData */ .T5)({
            otherId: bunnyId,
            isTradable: true
        }, 1, 'currentAskPrice', 'asc');
        if (response.length > 0) {
            const [tokenMarketData] = response;
            return parseFloat(tokenMarketData.currentAskPrice);
        }
        return null;
    });
    return {
        isFetching: status !== config_constants_types__WEBPACK_IMPORTED_MODULE_0__/* .FetchStatus.Fetched */ .iF.Fetched,
        lowestPrice: data
    };
};
const useGetLowestPriceFromNft = (nft)=>{
    const isPancakeBunny = nft.collectionAddress?.toLowerCase() === _constants__WEBPACK_IMPORTED_MODULE_3__/* .pancakeBunniesAddress.toLowerCase */ .Jr.toLowerCase();
    const bunnyIdAttr = isPancakeBunny && getBunnyIdFromNft(nft);
    return useGetLowestPriceFromBunnyId(bunnyIdAttr);
};

});

/***/ })

};
;
//# sourceMappingURL=5500.js.map