"use strict";
exports.id = 8695;
exports.ids = [8695];
exports.modules = {

/***/ 98695:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var state_nftMarket_helpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(86849);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1940);



// If collection is PancakeBunnies - gets all available bunnies, otherwise - null
const useAllPancakeBunnyNfts = (collectionAddress)=>{
    const { 0: allPancakeBunnyNfts , 1: setAllPancakeBunnyNfts  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const isPBCollection = collectionAddress === _constants__WEBPACK_IMPORTED_MODULE_2__/* .pancakeBunniesAddress */ .Jr;
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        const fetchPancakeBunnies = async ()=>{
            // In order to not define special TS type just for PancakeBunnies display we're hacking a little bit into NftToken type.
            // On this page we just want to display all bunnies with their lowest prices and updates on the market
            // Since some bunnies might not be on the market at all, we don't refer to the redux nfts state (which stores NftToken with actual token ids)
            // We merely request from API all available bunny ids with their metadata and query subgraph for lowest price and latest updates.
            const { data  } = await (0,state_nftMarket_helpers__WEBPACK_IMPORTED_MODULE_1__/* .getNftsFromCollectionApi */ .Rq)(_constants__WEBPACK_IMPORTED_MODULE_2__/* .pancakeBunniesAddress */ .Jr);
            const bunnyIds = Object.keys(data);
            const lowestPrices = await (0,state_nftMarket_helpers__WEBPACK_IMPORTED_MODULE_1__/* .getAllPancakeBunniesLowestPrice */ .LU)(bunnyIds);
            const latestUpdates = await (0,state_nftMarket_helpers__WEBPACK_IMPORTED_MODULE_1__/* .getAllPancakeBunniesRecentUpdatedAt */ .nP)(bunnyIds);
            const allBunnies = bunnyIds.map((bunnyId)=>{
                return {
                    // tokenId here is just a dummy one to satisfy TS. TokenID does not play any role in gird display below
                    tokenId: data[bunnyId].name,
                    name: data[bunnyId].name,
                    description: data[bunnyId].description,
                    collectionAddress: _constants__WEBPACK_IMPORTED_MODULE_2__/* .pancakeBunniesAddress */ .Jr,
                    collectionName: data[bunnyId].collection.name,
                    image: data[bunnyId].image,
                    attributes: [
                        {
                            traitType: 'bunnyId',
                            value: bunnyId,
                            displayType: null
                        }, 
                    ],
                    meta: {
                        currentAskPrice: lowestPrices[bunnyId],
                        updatedAt: latestUpdates[bunnyId]
                    }
                };
            });
            setAllPancakeBunnyNfts(allBunnies);
        };
        if (isPBCollection && !allPancakeBunnyNfts) {
            fetchPancakeBunnies();
        }
    }, [
        isPBCollection,
        allPancakeBunnyNfts
    ]);
    return allPancakeBunnyNfts;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useAllPancakeBunnyNfts);


/***/ })

};
;
//# sourceMappingURL=8695.js.map