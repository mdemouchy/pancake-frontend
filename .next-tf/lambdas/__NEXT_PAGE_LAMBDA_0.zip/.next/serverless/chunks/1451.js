"use strict";
exports.id = 1451;
exports.ids = [1451];
exports.modules = {

/***/ 36196:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _Layout_Page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9770);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Layout_Page__WEBPACK_IMPORTED_MODULE_4__]);
_Layout_Page__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];





const Wrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_Layout_Page__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z).withConfig({
    componentId: "sc-6c1c763b-0"
})`
  display: flex;
  justify-content: center;
  align-items: center;
`;
const PageLoader = ()=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Wrapper, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Spinner, {})
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PageLoader);

});

/***/ }),

/***/ 95790:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "dm": () => (/* binding */ useGetSortedRounds),
/* harmony export */   "n3": () => (/* binding */ useGetBetByEpoch),
/* harmony export */   "Wx": () => (/* binding */ useGetIsClaimable),
/* harmony export */   "y2": () => (/* binding */ useGetEarliestEpoch),
/* harmony export */   "e": () => (/* binding */ useIsHistoryPaneOpen),
/* harmony export */   "YF": () => (/* binding */ useIsChartPaneOpen),
/* harmony export */   "dJ": () => (/* binding */ useGetCurrentEpoch),
/* harmony export */   "m3": () => (/* binding */ useGetIntervalSeconds),
/* harmony export */   "hU": () => (/* binding */ useGetPredictionsStatus),
/* harmony export */   "J7": () => (/* binding */ useGetHistoryFilter),
/* harmony export */   "ds": () => (/* binding */ useGetHasHistoryLoaded),
/* harmony export */   "Gc": () => (/* binding */ useGetCurrentHistoryPage),
/* harmony export */   "eI": () => (/* binding */ useGetMinBetAmount),
/* harmony export */   "XM": () => (/* binding */ useGetBufferSeconds),
/* harmony export */   "dW": () => (/* binding */ useGetIsFetchingHistory),
/* harmony export */   "pw": () => (/* binding */ useGetHistory),
/* harmony export */   "uW": () => (/* binding */ useGetLastOraclePrice),
/* harmony export */   "Ch": () => (/* binding */ useGetCurrentRoundLockTimestamp),
/* harmony export */   "AC": () => (/* binding */ useGetLeaderboardLoadingState),
/* harmony export */   "HF": () => (/* binding */ useGetLeaderboardResults),
/* harmony export */   "YY": () => (/* binding */ useGetLeaderboardFilters),
/* harmony export */   "Ok": () => (/* binding */ useGetLeaderboardSkip),
/* harmony export */   "Gy": () => (/* binding */ useGetLeaderboardHasMoreResults),
/* harmony export */   "nB": () => (/* binding */ useGetOrFetchLeaderboardAddressResult),
/* harmony export */   "Xx": () => (/* binding */ useGetSelectedAddress)
/* harmony export */ });
/* unused harmony exports useGetRounds, useGetRound, useGetCurrentRound, useGetAddressResult */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(49949);
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lodash_orderBy__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var lodash_minBy__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9318);
/* harmony import */ var lodash_minBy__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(lodash_minBy__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(65757);
/* harmony import */ var _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(38328);
/* harmony import */ var state__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(82727);
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(88925);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(67774);









const useGetRounds = ()=>{
    const rounds = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.predictions.rounds
    );
    return Object.keys(rounds).reduce((accum, epoch)=>{
        return {
            ...accum,
            [epoch]: (0,_helpers__WEBPACK_IMPORTED_MODULE_7__/* .parseBigNumberObj */ .zN)(rounds[epoch])
        };
    }, {});
};
const useGetRound = (epoch)=>{
    const round = useSelector((state)=>state.predictions.rounds[epoch]
    );
    return parseBigNumberObj(round);
};
const useGetSortedRounds = ()=>{
    const roundData = useGetRounds();
    return lodash_orderBy__WEBPACK_IMPORTED_MODULE_2___default()(Object.values(roundData), [
        'epoch'
    ], [
        'asc'
    ]);
};
const useGetBetByEpoch = (account, epoch)=>{
    const bets = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.predictions.ledgers
    );
    if (!bets[account]) {
        return null;
    }
    if (!bets[account][epoch]) {
        return null;
    }
    return (0,_helpers__WEBPACK_IMPORTED_MODULE_7__/* .parseBigNumberObj */ .zN)(bets[account][epoch]);
};
const useGetIsClaimable = (epoch)=>{
    const claimableStatuses = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.predictions.claimableStatuses
    );
    return claimableStatuses[epoch] || false;
};
/**
 * Used to get the range of rounds to poll for
 */ const useGetEarliestEpoch = ()=>{
    return (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>{
        const earliestRound = lodash_minBy__WEBPACK_IMPORTED_MODULE_3___default()(Object.values(state.predictions.rounds), 'epoch');
        return earliestRound?.epoch;
    });
};
const useIsHistoryPaneOpen = ()=>{
    return (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.predictions.isHistoryPaneOpen
    );
};
const useIsChartPaneOpen = ()=>{
    return (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.predictions.isChartPaneOpen
    );
};
const useGetCurrentEpoch = ()=>{
    return (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.predictions.currentEpoch
    );
};
const useGetIntervalSeconds = ()=>{
    return (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.predictions.intervalSeconds
    );
};
const useGetCurrentRound = ()=>{
    const currentEpoch = useGetCurrentEpoch();
    const rounds = useGetRounds();
    return rounds[currentEpoch];
};
const useGetPredictionsStatus = ()=>{
    return (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.predictions.status
    );
};
const useGetHistoryFilter = ()=>{
    return (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.predictions.historyFilter
    );
};
const useGetHasHistoryLoaded = ()=>{
    return (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.predictions.hasHistoryLoaded
    );
};
const useGetCurrentHistoryPage = ()=>{
    return (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.predictions.currentHistoryPage
    );
};
const useGetMinBetAmount = ()=>{
    const minBetAmount = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.predictions.minBetAmount
    );
    return (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_4__.BigNumber.from(minBetAmount)
    , [
        minBetAmount
    ]);
};
const useGetBufferSeconds = ()=>{
    return (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.predictions.bufferSeconds
    );
};
const useGetIsFetchingHistory = ()=>{
    return (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.predictions.isFetchingHistory
    );
};
const useGetHistory = ()=>{
    return (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.predictions.history
    );
};
const useGetLastOraclePrice = ()=>{
    const lastOraclePrice = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.predictions.lastOraclePrice
    );
    return (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        return _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_4__.BigNumber.from(lastOraclePrice);
    }, [
        lastOraclePrice
    ]);
};
/**
 * The current round's lock timestamp will not be set immediately so we return an estimate until then
 */ const useGetCurrentRoundLockTimestamp = ()=>{
    const currentRound = useGetCurrentRound();
    const intervalSeconds = useGetIntervalSeconds();
    if (!currentRound.lockTimestamp) {
        return currentRound.startTimestamp + intervalSeconds;
    }
    return currentRound.lockTimestamp;
};
// Leaderboard
const useGetLeaderboardLoadingState = ()=>{
    return (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.predictions.leaderboard.loadingState
    );
};
const useGetLeaderboardResults = ()=>{
    return (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.predictions.leaderboard.results
    );
};
const useGetLeaderboardFilters = ()=>{
    return (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.predictions.leaderboard.filters
    );
};
const useGetLeaderboardSkip = ()=>{
    return (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.predictions.leaderboard.skip
    );
};
const useGetLeaderboardHasMoreResults = ()=>{
    return (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.predictions.leaderboard.hasMoreResults
    );
};
const useGetAddressResult = (account)=>{
    return (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.predictions.leaderboard.addressResults[account]
    );
};
const useGetOrFetchLeaderboardAddressResult = (account)=>{
    const addressResult = useGetAddressResult(account);
    const dispatch = (0,state__WEBPACK_IMPORTED_MODULE_6__/* .useAppDispatch */ .TL)();
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        const address = (0,utils__WEBPACK_IMPORTED_MODULE_5__/* .isAddress */ .UJ)(account);
        // If address result is null it means we already tried fetching the results and none came back
        if (!addressResult && addressResult !== null && address) {
            dispatch((0,___WEBPACK_IMPORTED_MODULE_8__/* .fetchAddressResult */ .nI)(account));
        }
    }, [
        dispatch,
        account,
        addressResult
    ]);
    return addressResult;
};
const useGetSelectedAddress = ()=>{
    return (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.predictions.leaderboard.selectedAddress
    );
};


/***/ })

};
;
//# sourceMappingURL=1451.js.map