"use strict";
exports.id = 7963;
exports.ids = [7963];
exports.modules = {

/***/ 10746:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "t": () => (/* binding */ useTeam),
/* harmony export */   "y": () => (/* binding */ useTeams)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var state__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(82727);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(65926);




const useTeam = (id)=>{
    const team = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.teams.data[id]
    );
    const dispatch = (0,state__WEBPACK_IMPORTED_MODULE_2__/* .useAppDispatch */ .TL)();
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        dispatch((0,___WEBPACK_IMPORTED_MODULE_3__/* .fetchTeam */ .y$)(id));
    }, [
        id,
        dispatch
    ]);
    return team;
};
const useTeams = ()=>{
    const { isInitialized , isLoading , data  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.teams
    );
    const dispatch = (0,state__WEBPACK_IMPORTED_MODULE_2__/* .useAppDispatch */ .TL)();
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        dispatch((0,___WEBPACK_IMPORTED_MODULE_3__/* .fetchTeams */ .ZZ)());
    }, [
        dispatch
    ]);
    return {
        teams: data,
        isInitialized,
        isLoading
    };
};


/***/ }),

/***/ 68269:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(99150);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(41664);





const NoProfileCard = ()=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_3__/* .useTranslation */ .$G)();
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Card, {
        mb: "32px",
        isActive: true,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.CardBody, {
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                alignItems: [
                    'start',
                    null,
                    'center'
                ],
                justifyContent: [
                    'start',
                    null,
                    'space-between'
                ],
                flexDirection: [
                    'column',
                    null,
                    'row'
                ],
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Heading, {
                                scale: "lg",
                                mb: "8px",
                                children: t('You haven’t set up your profile yet!')
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                children: t('You can do this at any time by clicking on your profile picture in the menu')
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_4__["default"], {
                        href: "/create-profile",
                        passHref: true,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                            as: "a",
                            id: "teamsPageSetUpProfile",
                            mt: [
                                '16px',
                                null,
                                0
                            ],
                            children: t('Set up now')
                        })
                    })
                ]
            })
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NoProfileCard);


/***/ }),

/***/ 73650:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var state_profile_hooks__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(89424);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(99150);
/* harmony import */ var _NoProfileCard__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(68269);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([state_profile_hooks__WEBPACK_IMPORTED_MODULE_4__]);
state_profile_hooks__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];







const HeaderWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-843e5a10-0"
})`
  border-bottom: 2px solid ${({ theme  })=>theme.colors.textSubtle
};
  margin-bottom: 24px;
  padding-bottom: 24px;
`;
const TeamHeader = ()=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_5__/* .useTranslation */ .$G)();
    const { isInitialized , profile  } = (0,state_profile_hooks__WEBPACK_IMPORTED_MODULE_4__/* .useProfile */ .Un)();
    const showProfileCallout = isInitialized && !profile;
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            showProfileCallout && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_NoProfileCard__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(HeaderWrapper, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Heading, {
                        as: "h1",
                        scale: "xxl",
                        color: "secondary",
                        children: t('Teams & Profiles')
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                        bold: true,
                        children: t('Show off your stats and collectibles with your unique profile. Team features will be revealed soon!')
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TeamHeader);

});

/***/ })

};
;
//# sourceMappingURL=7963.js.map