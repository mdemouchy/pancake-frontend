"use strict";
exports.id = 1365;
exports.ids = [1365];
exports.modules = {

/***/ 75279:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "z": () => (/* binding */ NftMarketLayout)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_Loader_PageLoader__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(36196);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(13968);
/* harmony import */ var state_nftMarket_types__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(75186);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([components_Loader_PageLoader__WEBPACK_IMPORTED_MODULE_1__, state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_3__]);
([components_Loader_PageLoader__WEBPACK_IMPORTED_MODULE_1__, state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);





const NftMarketLayout = ({ children  })=>{
    const initializationState = (0,state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_3__/* .useGetNFTInitializationState */ .l2)();
    (0,state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_3__/* .useFetchCollections */ .vD)();
    if (initializationState !== state_nftMarket_types__WEBPACK_IMPORTED_MODULE_4__/* .NFTMarketInitializationState.INITIALIZED */ .IB.INITIALIZED) {
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Loader_PageLoader__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {}));
    }
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: children
    }));
};

});

/***/ }),

/***/ 15206:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_AddressInputSelect__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(27288);
/* harmony import */ var views_Nft_market_constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1940);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);





const SearchBar = (props)=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const handleAddressClick = (value)=>{
        router.push(`${views_Nft_market_constants__WEBPACK_IMPORTED_MODULE_3__/* .nftsBaseUrl */ .Vf}/profile/${value}`);
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_AddressInputSelect__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        onAddressClick: handleAddressClick,
        ...props
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SearchBar);


/***/ })

};
;
//# sourceMappingURL=1365.js.map