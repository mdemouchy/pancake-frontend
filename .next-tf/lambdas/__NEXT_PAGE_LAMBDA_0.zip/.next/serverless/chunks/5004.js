"use strict";
exports.id = 5004;
exports.ids = [5004];
exports.modules = {

/***/ 5004:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var views_Info_components_InfoCharts_LineChart__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(45091);
/* harmony import */ var views_Info_components_InfoCharts_BarChart__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(55224);
/* harmony import */ var components_TabToggle__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(77041);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(99150);
/* harmony import */ var views_Info_utils_formatInfoNumbers__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(83589);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(74146);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(date_fns__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5152);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([views_Info_components_InfoCharts_BarChart__WEBPACK_IMPORTED_MODULE_4__, views_Info_components_InfoCharts_LineChart__WEBPACK_IMPORTED_MODULE_3__]);
([views_Info_components_InfoCharts_BarChart__WEBPACK_IMPORTED_MODULE_4__, views_Info_components_InfoCharts_LineChart__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);










const CandleChart = (0,next_dynamic__WEBPACK_IMPORTED_MODULE_9__["default"])(null, {
    loadableGenerated: {
        modules: [
            "../views/Info/components/InfoCharts/ChartCard/index.tsx -> " + "views/Info/components/InfoCharts/CandleChart"
        ]
    },
    ssr: false
});
var ChartView;
(function(ChartView) {
    ChartView[ChartView["LIQUIDITY"] = 0] = "LIQUIDITY";
    ChartView[ChartView["VOLUME"] = 1] = "VOLUME";
    ChartView[ChartView["PRICE"] = 2] = "PRICE";
})(ChartView || (ChartView = {}));
const ChartCard = ({ variant , chartData , tokenData , tokenPriceData  })=>{
    const { 0: view , 1: setView  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(ChartView.VOLUME);
    const { 0: hoverValue , 1: setHoverValue  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { 0: hoverDate , 1: setHoverDate  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { t , currentLanguage: { locale  } ,  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_6__/* .useTranslation */ .$G)();
    const currentDate = new Date().toLocaleString(locale, {
        month: 'short',
        year: 'numeric',
        day: 'numeric'
    });
    const formattedTvlData = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        if (chartData) {
            return chartData.map((day)=>{
                return {
                    time: (0,date_fns__WEBPACK_IMPORTED_MODULE_8__.fromUnixTime)(day.date),
                    value: day.liquidityUSD
                };
            });
        }
        return [];
    }, [
        chartData
    ]);
    const formattedVolumeData = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        if (chartData) {
            return chartData.map((day)=>{
                return {
                    time: (0,date_fns__WEBPACK_IMPORTED_MODULE_8__.fromUnixTime)(day.date),
                    value: day.volumeUSD
                };
            });
        }
        return [];
    }, [
        chartData
    ]);
    const getLatestValueDisplay = ()=>{
        let valueToDisplay = null;
        if (hoverValue) {
            valueToDisplay = (0,views_Info_utils_formatInfoNumbers__WEBPACK_IMPORTED_MODULE_7__/* .formatAmount */ .d)(hoverValue);
        } else if (view === ChartView.VOLUME && formattedVolumeData.length > 0) {
            valueToDisplay = (0,views_Info_utils_formatInfoNumbers__WEBPACK_IMPORTED_MODULE_7__/* .formatAmount */ .d)(formattedVolumeData[formattedVolumeData.length - 1]?.value);
        } else if (view === ChartView.LIQUIDITY && formattedTvlData.length > 0) {
            valueToDisplay = (0,views_Info_utils_formatInfoNumbers__WEBPACK_IMPORTED_MODULE_7__/* .formatAmount */ .d)(formattedTvlData[formattedTvlData.length - 1]?.value);
        } else if (view === ChartView.PRICE && tokenData?.priceUSD) {
            valueToDisplay = (0,views_Info_utils_formatInfoNumbers__WEBPACK_IMPORTED_MODULE_7__/* .formatAmount */ .d)(tokenData.priceUSD);
        }
        return valueToDisplay ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
            fontSize: "24px",
            bold: true,
            children: [
                "$",
                valueToDisplay
            ]
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Skeleton, {
            height: "36px",
            width: "128px"
        });
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Card, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(components_TabToggle__WEBPACK_IMPORTED_MODULE_5__/* .TabToggleGroup */ ._, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_TabToggle__WEBPACK_IMPORTED_MODULE_5__/* .TabToggle */ .o, {
                        isActive: view === ChartView.VOLUME,
                        onClick: ()=>setView(ChartView.VOLUME)
                        ,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                            children: t('Volume')
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_TabToggle__WEBPACK_IMPORTED_MODULE_5__/* .TabToggle */ .o, {
                        isActive: view === ChartView.LIQUIDITY,
                        onClick: ()=>setView(ChartView.LIQUIDITY)
                        ,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                            children: t('Liquidity')
                        })
                    }),
                    variant === 'token' && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_TabToggle__WEBPACK_IMPORTED_MODULE_5__/* .TabToggle */ .o, {
                        isActive: view === ChartView.PRICE,
                        onClick: ()=>setView(ChartView.PRICE)
                        ,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                            children: t('Price')
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                flexDirection: "column",
                px: "24px",
                pt: "24px",
                children: [
                    getLatestValueDisplay(),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        small: true,
                        color: "secondary",
                        children: hoverDate || currentDate
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Box, {
                px: "24px",
                height: variant === 'token' ? '250px' : '335px',
                children: view === ChartView.LIQUIDITY ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(views_Info_components_InfoCharts_LineChart__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    data: formattedTvlData,
                    setHoverValue: setHoverValue,
                    setHoverDate: setHoverDate
                }) : view === ChartView.VOLUME ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(views_Info_components_InfoCharts_BarChart__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                    data: formattedVolumeData,
                    setHoverValue: setHoverValue,
                    setHoverDate: setHoverDate
                }) : view === ChartView.PRICE ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CandleChart, {
                    data: tokenPriceData,
                    setValue: setHoverValue,
                    setLabel: setHoverDate
                }) : null
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ChartCard);

});

/***/ })

};
;
//# sourceMappingURL=5004.js.map