"use strict";
exports.id = 6538;
exports.ids = [6538];
exports.modules = {

/***/ 76538:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const useIntersectionObserver = ()=>{
    const { 0: observerRefElement , 1: setObserverRefElement  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const { 0: observerRef  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(()=>(element)=>setObserverRefElement(element)
    );
    const intersectionObserverRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const { 0: observerIsSet , 1: setObserverIsSet  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const { 0: isIntersecting , 1: setIsIntersecting  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        const checkObserverIsIntersecting = ([entry])=>{
            setIsIntersecting(entry.isIntersecting);
        };
        if (!observerIsSet && observerRefElement) {
            intersectionObserverRef.current = new IntersectionObserver(checkObserverIsIntersecting, {
                rootMargin: '0px',
                threshold: 1
            });
            intersectionObserverRef.current.observe(observerRefElement);
            setObserverIsSet(true);
        }
        return ()=>{
            if (intersectionObserverRef.current && observerIsSet) {
                intersectionObserverRef.current.disconnect();
            }
        };
    }, [
        observerRefElement,
        observerIsSet
    ]);
    return {
        observerRef,
        isIntersecting
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useIntersectionObserver);


/***/ })

};
;
//# sourceMappingURL=6538.js.map