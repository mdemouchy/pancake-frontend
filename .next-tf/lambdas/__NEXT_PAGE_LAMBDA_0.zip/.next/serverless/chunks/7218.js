"use strict";
exports.id = 7218;
exports.ids = [7218];
exports.modules = {

/***/ 67218:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var lodash_noop__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(87553);
/* harmony import */ var lodash_noop__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lodash_noop__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(18054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var hooks_useToast__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(789);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(99150);
/* harmony import */ var utils_sentry__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(17226);
/* harmony import */ var components_Toast__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(63937);








const initialState = {
    approvalState: 'idle',
    confirmState: 'idle'
};
const reducer = (state, actions)=>{
    switch(actions.type){
        case 'requires_approval':
            return {
                ...state,
                approvalState: 'success'
            };
        case 'approve_sending':
            return {
                ...state,
                approvalState: 'loading'
            };
        case 'approve_receipt':
            return {
                ...state,
                approvalState: 'success'
            };
        case 'approve_error':
            return {
                ...state,
                approvalState: 'fail'
            };
        case 'confirm_sending':
            return {
                ...state,
                confirmState: 'loading'
            };
        case 'confirm_receipt':
            return {
                ...state,
                confirmState: 'success'
            };
        case 'confirm_error':
            return {
                ...state,
                confirmState: 'fail'
            };
        default:
            return state;
    }
};
const useApproveConfirmTransaction = ({ onApprove , onConfirm , onRequiresApproval , onSuccess =(lodash_noop__WEBPACK_IMPORTED_MODULE_2___default()) , onApproveSuccess =(lodash_noop__WEBPACK_IMPORTED_MODULE_2___default())  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_5__/* .useTranslation */ .$G)();
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_3__.useWeb3React)();
    const { 0: state , 1: dispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useReducer)(reducer, initialState);
    const handlePreApprove = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(onRequiresApproval);
    const { toastSuccess , toastError  } = (0,hooks_useToast__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)();
    const handleApprove = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(async ()=>{
        try {
            const tx = await onApprove();
            toastSuccess(`${t('Transaction Submitted')}!`, /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_7__/* .ToastDescriptionWithTx */ .YO, {
                txHash: tx.hash
            }));
            dispatch({
                type: 'approve_sending'
            });
            const receipt = await tx.wait();
            if (receipt.status) {
                dispatch({
                    type: 'approve_receipt'
                });
                onApproveSuccess({
                    state,
                    receipt
                });
            }
        } catch (error) {
            dispatch({
                type: 'approve_error'
            });
            (0,utils_sentry__WEBPACK_IMPORTED_MODULE_6__/* .logError */ .H)(error);
            toastError(t('Error'), t('Please try again. Confirm the transaction and make sure you are paying enough gas!'));
        }
    }, [
        toastSuccess,
        onApprove,
        t,
        onApproveSuccess,
        state,
        toastError
    ]);
    const handleConfirm = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(async (params = {})=>{
        dispatch({
            type: 'confirm_sending'
        });
        try {
            const tx = await onConfirm(params);
            toastSuccess(`${t('Transaction Submitted')}!`, /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_7__/* .ToastDescriptionWithTx */ .YO, {
                txHash: tx.hash
            }));
            const receipt = await tx.wait();
            if (receipt.status) {
                dispatch({
                    type: 'confirm_receipt'
                });
                onSuccess({
                    state,
                    receipt
                });
            }
        } catch (error) {
            dispatch({
                type: 'confirm_error'
            });
            (0,utils_sentry__WEBPACK_IMPORTED_MODULE_6__/* .logError */ .H)(error);
            toastError(t('Error'), t('Please try again. Confirm the transaction and make sure you are paying enough gas!'));
        }
    }, [
        onConfirm,
        dispatch,
        onSuccess,
        state,
        t,
        toastError,
        toastSuccess
    ]);
    // Check if approval is necessary, re-check if account changes
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (account && handlePreApprove.current) {
            handlePreApprove.current().then((result)=>{
                if (result) {
                    dispatch({
                        type: 'requires_approval'
                    });
                }
            });
        }
    }, [
        account,
        handlePreApprove,
        dispatch
    ]);
    return {
        isApproving: state.approvalState === 'loading',
        isApproved: state.approvalState === 'success',
        isConfirming: state.confirmState === 'loading',
        isConfirmed: state.confirmState === 'success',
        hasApproveFailed: state.approvalState === 'fail',
        hasConfirmFailed: state.confirmState === 'fail',
        handleApprove,
        handleConfirm
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useApproveConfirmTransaction);


/***/ }),

/***/ 17226:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ isUserRejected),
/* harmony export */   "H": () => (/* binding */ logError)
/* harmony export */ });
/* harmony import */ var _sentry_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(15427);
/* harmony import */ var _sentry_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_sentry_react__WEBPACK_IMPORTED_MODULE_0__);

const assignError = (maybeError)=>{
    if (typeof maybeError === 'string') {
        return new Error(maybeError);
    }
    if (typeof maybeError === 'object') {
        const error = new Error(maybeError?.message ?? String(maybeError));
        if (maybeError?.stack) {
            error.stack = maybeError.stack;
        }
        if (maybeError?.code) {
            error.name = maybeError.code;
        }
        return error;
    }
    return maybeError;
};
const isUserRejected = (err)=>{
    // provider user rejected error code
    return typeof err === 'object' && 'code' in err && err.code === 4001;
};
const logError = (error)=>{
    if (error instanceof Error) {
        _sentry_react__WEBPACK_IMPORTED_MODULE_0__.captureException(error);
    } else {
        _sentry_react__WEBPACK_IMPORTED_MODULE_0__.captureException(assignError(error), error);
    }
    console.error(error);
};


/***/ })

};
;
//# sourceMappingURL=7218.js.map