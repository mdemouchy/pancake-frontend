"use strict";
exports.id = 7023;
exports.ids = [7023];
exports.modules = {

/***/ 27935:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(34215);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(bignumber_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(99150);
/* harmony import */ var utils_formatBalance__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(65044);
/* harmony import */ var state_farms_hooks__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8733);
/* harmony import */ var state_pools_hooks__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1624);
/* harmony import */ var components_Balance__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(20922);
/* harmony import */ var _BountyModal__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(13044);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_BountyModal__WEBPACK_IMPORTED_MODULE_10__, state_farms_hooks__WEBPACK_IMPORTED_MODULE_7__, state_pools_hooks__WEBPACK_IMPORTED_MODULE_8__]);
([_BountyModal__WEBPACK_IMPORTED_MODULE_10__, state_farms_hooks__WEBPACK_IMPORTED_MODULE_7__, state_pools_hooks__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);











const StyledCard = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Card).withConfig({
    componentId: "sc-d7620470-0"
})`
  width: 100%;
  flex: 1;
  ${({ theme  })=>theme.mediaQueries.sm
} {
    min-width: 240px;
  }
`;
const BountyCard = ()=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_5__/* .useTranslation */ .$G)();
    const { estimatedCakeBountyReward , fees: { callFee  } ,  } = (0,state_pools_hooks__WEBPACK_IMPORTED_MODULE_8__/* .useCakeVault */ .Xo)();
    const cakePriceBusd = (0,state_farms_hooks__WEBPACK_IMPORTED_MODULE_7__/* .usePriceCakeBusd */ .Iu)();
    const estimatedDollarBountyReward = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        return new (bignumber_js__WEBPACK_IMPORTED_MODULE_2___default())(estimatedCakeBountyReward).multipliedBy(cakePriceBusd);
    }, [
        cakePriceBusd,
        estimatedCakeBountyReward
    ]);
    const hasFetchedDollarBounty = estimatedDollarBountyReward.gte(0);
    const hasFetchedCakeBounty = estimatedCakeBountyReward ? estimatedCakeBountyReward.gte(0) : false;
    const dollarBountyToDisplay = hasFetchedDollarBounty ? (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_6__/* .getBalanceNumber */ .mW)(estimatedDollarBountyReward, 18) : 0;
    const cakeBountyToDisplay = hasFetchedCakeBounty ? (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_6__/* .getBalanceNumber */ .mW)(estimatedCakeBountyReward, 18) : 0;
    const TooltipComponent = ({ fee  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                    mb: "16px",
                    children: t('This bounty is given as a reward for providing a service to other users.')
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                    mb: "16px",
                    children: t('Whenever you successfully claim the bounty, you’re also helping out by activating the Auto CAKE Pool’s compounding function for everyone.')
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                    style: {
                        fontWeight: 'bold'
                    },
                    children: t('Auto-Compound Bounty: %fee%% of all Auto CAKE pool users pending yield', {
                        fee: fee / 100
                    })
                })
            ]
        })
    ;
    const [onPresentBountyModal] = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.useModal)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_BountyModal__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
        TooltipComponent: TooltipComponent
    }));
    const { targetRef , tooltip , tooltipVisible  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.useTooltip)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TooltipComponent, {
        fee: callFee
    }), {
        placement: 'bottom-end',
        tooltipOffset: [
            20,
            10
        ]
    });
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            tooltipVisible && tooltip,
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledCard, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.CardBody, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Flex, {
                            flexDirection: "column",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Flex, {
                                alignItems: "center",
                                mb: "12px",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                                        fontSize: "16px",
                                        bold: true,
                                        color: "textSubtle",
                                        mr: "4px",
                                        children: t('Auto CAKE Bounty')
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Box, {
                                        ref: targetRef,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.HelpIcon, {
                                            color: "textSubtle"
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Flex, {
                            alignItems: "center",
                            justifyContent: "space-between",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Flex, {
                                    flexDirection: "column",
                                    mr: "12px",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Heading, {
                                            children: hasFetchedCakeBounty ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                fontSize: "20px",
                                                bold: true,
                                                value: cakeBountyToDisplay,
                                                decimals: 3
                                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Skeleton, {
                                                height: 20,
                                                width: 96,
                                                mb: "2px"
                                            })
                                        }),
                                        hasFetchedDollarBounty ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                            fontSize: "12px",
                                            color: "textSubtle",
                                            value: dollarBountyToDisplay,
                                            decimals: 2,
                                            unit: " USD",
                                            prefix: "~"
                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Skeleton, {
                                            height: 16,
                                            width: 62
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Button, {
                                    disabled: !dollarBountyToDisplay || !cakeBountyToDisplay || !callFee,
                                    onClick: onPresentBountyModal,
                                    scale: "sm",
                                    id: "clickClaimVaultBounty",
                                    children: t('Claim')
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BountyCard);

});

/***/ }),

/***/ 13044:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(34215);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(bignumber_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(18054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var utils_formatBalance__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(65044);
/* harmony import */ var hooks_useContract__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(46063);
/* harmony import */ var hooks_useTheme__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(23917);
/* harmony import */ var hooks_useToast__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(789);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(99150);
/* harmony import */ var components_ConnectWalletButton__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(30621);
/* harmony import */ var components_Toast__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(63937);
/* harmony import */ var components_Balance__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(20922);
/* harmony import */ var state_farms_hooks__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(8733);
/* harmony import */ var state_pools_hooks__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(1624);
/* harmony import */ var hooks_useCallWithGasPrice__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(71228);
/* harmony import */ var utils_sentry__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(17226);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([state_farms_hooks__WEBPACK_IMPORTED_MODULE_14__, hooks_useCallWithGasPrice__WEBPACK_IMPORTED_MODULE_16__, state_pools_hooks__WEBPACK_IMPORTED_MODULE_15__, hooks_useTheme__WEBPACK_IMPORTED_MODULE_8__]);
([state_farms_hooks__WEBPACK_IMPORTED_MODULE_14__, hooks_useCallWithGasPrice__WEBPACK_IMPORTED_MODULE_16__, state_pools_hooks__WEBPACK_IMPORTED_MODULE_15__, hooks_useTheme__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);


















const Divider = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
    componentId: "sc-379bb6e6-0"
})`
  background-color: ${({ theme  })=>theme.colors.backgroundDisabled
};
  height: 1px;
  margin: 16px auto;
  width: 100%;
`;
const BountyModal = ({ onDismiss , TooltipComponent  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_10__/* .useTranslation */ .$G)();
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_3__.useWeb3React)();
    const { theme  } = (0,hooks_useTheme__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
    const { toastError , toastSuccess  } = (0,hooks_useToast__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)();
    const cakeVaultContract = (0,hooks_useContract__WEBPACK_IMPORTED_MODULE_7__/* .useCakeVaultContract */ .Us)();
    const { 0: pendingTx , 1: setPendingTx  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { estimatedCakeBountyReward , totalPendingCakeHarvest , fees: { callFee  } ,  } = (0,state_pools_hooks__WEBPACK_IMPORTED_MODULE_15__/* .useCakeVault */ .Xo)();
    const { callWithGasPrice  } = (0,hooks_useCallWithGasPrice__WEBPACK_IMPORTED_MODULE_16__/* .useCallWithGasPrice */ .d)();
    const cakePriceBusd = (0,state_farms_hooks__WEBPACK_IMPORTED_MODULE_14__/* .usePriceCakeBusd */ .Iu)();
    const callFeeAsDecimal = callFee / 100;
    const totalYieldToDisplay = (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_6__/* .getBalanceNumber */ .mW)(totalPendingCakeHarvest, 18);
    const estimatedDollarBountyReward = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        return new (bignumber_js__WEBPACK_IMPORTED_MODULE_2___default())(estimatedCakeBountyReward).multipliedBy(cakePriceBusd);
    }, [
        cakePriceBusd,
        estimatedCakeBountyReward
    ]);
    const hasFetchedDollarBounty = estimatedDollarBountyReward.gte(0);
    const hasFetchedCakeBounty = estimatedCakeBountyReward ? estimatedCakeBountyReward.gte(0) : false;
    const dollarBountyToDisplay = hasFetchedDollarBounty ? (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_6__/* .getBalanceNumber */ .mW)(estimatedDollarBountyReward, 18) : 0;
    const cakeBountyToDisplay = hasFetchedCakeBounty ? (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_6__/* .getBalanceNumber */ .mW)(estimatedCakeBountyReward, 18) : 0;
    const { targetRef , tooltip , tooltipVisible  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.useTooltip)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TooltipComponent, {
        fee: callFee
    }), {
        placement: 'bottom',
        tooltipPadding: {
            right: 15
        }
    });
    const handleConfirmClick = async ()=>{
        setPendingTx(true);
        try {
            const tx = await callWithGasPrice(cakeVaultContract, 'harvest', undefined, {
                gasLimit: 300000
            });
            toastSuccess(`${t('Transaction Submitted')}!`, /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_12__/* .ToastDescriptionWithTx */ .YO, {
                txHash: tx.hash
            }));
            const receipt = await tx.wait();
            if (receipt.status) {
                toastSuccess(t('Bounty collected!'), /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_12__/* .ToastDescriptionWithTx */ .YO, {
                    txHash: receipt.transactionHash,
                    children: t('CAKE bounty has been sent to your wallet.')
                }));
                setPendingTx(false);
                onDismiss();
            }
        } catch (error) {
            (0,utils_sentry__WEBPACK_IMPORTED_MODULE_17__/* .logError */ .H)(error);
            toastError(t('Error'), t('Please try again. Confirm the transaction and make sure you are paying enough gas!'));
            setPendingTx(false);
        }
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Modal, {
        title: t('Claim Bounty'),
        onDismiss: onDismiss,
        headerBackground: theme.colors.gradients.cardHeader,
        children: [
            tooltipVisible && tooltip,
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Message, {
                variant: "warning",
                mb: "16px",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.MessageText, {
                    children: t('Remember that you will pay the gas fee.')
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Flex, {
                alignItems: "flex-start",
                justifyContent: "space-between",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Text, {
                        children: t('You’ll claim')
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Flex, {
                        flexDirection: "column",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                bold: true,
                                value: cakeBountyToDisplay,
                                decimals: 7,
                                unit: " CAKE"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Text, {
                                fontSize: "12px",
                                color: "textSubtle",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                    fontSize: "12px",
                                    color: "textSubtle",
                                    value: dollarBountyToDisplay,
                                    decimals: 2,
                                    unit: " USD",
                                    prefix: "~"
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Divider, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Flex, {
                alignItems: "center",
                justifyContent: "space-between",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Text, {
                        fontSize: "14px",
                        color: "textSubtle",
                        children: t('Pool total pending yield')
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                        color: "textSubtle",
                        value: totalYieldToDisplay,
                        unit: " CAKE"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Flex, {
                alignItems: "center",
                justifyContent: "space-between",
                mb: "24px",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Text, {
                        fontSize: "14px",
                        color: "textSubtle",
                        children: t('Bounty')
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Text, {
                        fontSize: "14px",
                        color: "textSubtle",
                        children: [
                            callFeeAsDecimal,
                            "%"
                        ]
                    })
                ]
            }),
            account ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Button, {
                isLoading: pendingTx,
                disabled: !dollarBountyToDisplay || !cakeBountyToDisplay || !callFee,
                endIcon: pendingTx ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.AutoRenewIcon, {
                    spin: true,
                    color: "currentColor"
                }) : null,
                onClick: handleConfirmClick,
                mb: "28px",
                id: "autoCakeConfirmBounty",
                children: pendingTx ? t('Confirming') : t('Confirm')
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_ConnectWalletButton__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                mb: "28px"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Flex, {
                justifyContent: "center",
                alignItems: "center",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Text, {
                        fontSize: "16px",
                        bold: true,
                        color: "textSubtle",
                        mr: "4px",
                        children: t('What’s this?')
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        ref: targetRef,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.HelpIcon, {
                            color: "textSubtle"
                        })
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BountyModal);

});

/***/ }),

/***/ 56310:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99150);





const ButtonText = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text).withConfig({
    componentId: "sc-24af00a1-0"
})`
  display: none;
  ${({ theme  })=>theme.mediaQueries.xs
} {
    display: block;
  }
`;
const Container = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-24af00a1-1"
})`
  margin-right: 16px;
  display: flex;
  justify-content: flex-end;

  ${({ theme  })=>theme.mediaQueries.sm
} {
    flex: 1;
  }
`;
const StyledLink = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Link).withConfig({
    componentId: "sc-24af00a1-2"
})`
  &:hover {
    text-decoration: none;
  }
`;
const HelpButton = ()=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Container, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledLink, {
            external: true,
            href: "https://docs.pancakeswap.finance/products/syrup-pool/syrup-pool-faq",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Button, {
                px: [
                    '14px',
                    null,
                    null,
                    null,
                    '20px'
                ],
                variant: "subtle",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ButtonText, {
                        color: "backgroundAlt",
                        bold: true,
                        fontSize: "16px",
                        children: t('Help')
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.HelpIcon, {
                        color: "backgroundAlt",
                        ml: [
                            null,
                            null,
                            null,
                            0,
                            '6px'
                        ]
                    })
                ]
            })
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HelpButton);


/***/ }),

/***/ 87336:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(99150);
/* harmony import */ var hooks_useContract__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(46063);
/* harmony import */ var _hooks_useApprove__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(86534);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_useApprove__WEBPACK_IMPORTED_MODULE_5__]);
_hooks_useApprove__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];






const ApprovalAction = ({ pool , isLoading =false  })=>{
    const { sousId , stakingToken , earningToken  } = pool;
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_3__/* .useTranslation */ .$G)();
    const stakingTokenContract = (0,hooks_useContract__WEBPACK_IMPORTED_MODULE_4__/* .useERC20 */ .X_)(stakingToken.address || '');
    const { handleApprove , requestedApproval  } = (0,_hooks_useApprove__WEBPACK_IMPORTED_MODULE_5__/* .useApprovePool */ .iB)(stakingTokenContract, sousId, earningToken.symbol);
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: isLoading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Skeleton, {
            width: "100%",
            height: "52px"
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
            isLoading: requestedApproval,
            endIcon: requestedApproval ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.AutoRenewIcon, {
                spin: true,
                color: "currentColor"
            }) : null,
            disabled: requestedApproval,
            onClick: handleApprove,
            width: "100%",
            children: t('Enable')
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ApprovalAction);

});

/***/ }),

/***/ 97258:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(99150);
/* harmony import */ var utils_formatBalance__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(65044);
/* harmony import */ var components_Balance__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(20922);
/* harmony import */ var _Modals_CollectModal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(73068);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Modals_CollectModal__WEBPACK_IMPORTED_MODULE_6__]);
_Modals_CollectModal__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];







const HarvestActions = ({ earnings , earningToken , sousId , isBnbPool , earningTokenPrice , isLoading =false ,  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_3__/* .useTranslation */ .$G)();
    const earningTokenBalance = (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_4__/* .getBalanceNumber */ .mW)(earnings, earningToken.decimals);
    const formattedBalance = (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_4__/* .formatNumber */ .uf)(earningTokenBalance, 3, 3);
    const earningTokenDollarBalance = (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_4__/* .getBalanceNumber */ .mW)(earnings.multipliedBy(earningTokenPrice), earningToken.decimals);
    const fullBalance = (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_4__/* .getFullDisplayBalance */ .NJ)(earnings, earningToken.decimals);
    const hasEarnings = earnings.toNumber() > 0;
    const isCompoundPool = sousId === 0;
    const [onPresentCollect] = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.useModal)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Modals_CollectModal__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
        formattedBalance: formattedBalance,
        fullBalance: fullBalance,
        earningToken: earningToken,
        earningsDollarValue: earningTokenDollarBalance,
        sousId: sousId,
        isBnbPool: isBnbPool,
        isCompoundPool: isCompoundPool
    }));
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
        justifyContent: "space-between",
        alignItems: "center",
        mb: "16px",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                flexDirection: "column",
                children: isLoading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Skeleton, {
                    width: "80px",
                    height: "48px"
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: hasEarnings ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                bold: true,
                                fontSize: "20px",
                                decimals: 5,
                                value: earningTokenBalance
                            }),
                            earningTokenPrice > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                display: "inline",
                                fontSize: "12px",
                                color: "textSubtle",
                                decimals: 2,
                                prefix: "~",
                                value: earningTokenDollarBalance,
                                unit: " USD"
                            })
                        ]
                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Heading, {
                                color: "textDisabled",
                                children: "0"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                fontSize: "12px",
                                color: "textDisabled",
                                children: "0 USD"
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                disabled: !hasEarnings,
                onClick: onPresentCollect,
                children: isCompoundPool ? t('Collect') : t('Harvest')
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HarvestActions);

});

/***/ }),

/***/ 20889:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(99150);
/* harmony import */ var utils_formatBalance__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(65044);
/* harmony import */ var components_Balance__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(20922);
/* harmony import */ var _Modals_NotEnoughTokensModal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(67576);
/* harmony import */ var _Modals_StakeModal__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(54231);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Modals_StakeModal__WEBPACK_IMPORTED_MODULE_7__, _Modals_NotEnoughTokensModal__WEBPACK_IMPORTED_MODULE_6__]);
([_Modals_StakeModal__WEBPACK_IMPORTED_MODULE_7__, _Modals_NotEnoughTokensModal__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);








const StakeAction = ({ pool , stakingTokenBalance , stakedBalance , isBnbPool , isStaked , isLoading =false ,  })=>{
    const { stakingToken , stakingTokenPrice , stakingLimit , isFinished , userData  } = pool;
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_3__/* .useTranslation */ .$G)();
    const stakedTokenBalance = (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_4__/* .getBalanceNumber */ .mW)(stakedBalance, stakingToken.decimals);
    const stakedTokenDollarBalance = (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_4__/* .getBalanceNumber */ .mW)(stakedBalance.multipliedBy(stakingTokenPrice), stakingToken.decimals);
    const [onPresentTokenRequired] = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.useModal)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Modals_NotEnoughTokensModal__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
        tokenSymbol: stakingToken.symbol
    }));
    const [onPresentStake] = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.useModal)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Modals_StakeModal__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
        isBnbPool: isBnbPool,
        pool: pool,
        stakingTokenBalance: stakingTokenBalance,
        stakingTokenPrice: stakingTokenPrice
    }));
    const [onPresentUnstake] = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.useModal)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Modals_StakeModal__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
        stakingTokenBalance: stakingTokenBalance,
        isBnbPool: isBnbPool,
        pool: pool,
        stakingTokenPrice: stakingTokenPrice,
        isRemovingStake: true
    }));
    const { targetRef , tooltip , tooltipVisible  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.useTooltip)(t('You’ve already staked the maximum amount you can stake in this pool!'), {
        placement: 'bottom'
    });
    const reachStakingLimit = stakingLimit.gt(0) && userData.stakedBalance.gte(stakingLimit);
    const renderStakeAction = ()=>{
        return isStaked ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
            justifyContent: "space-between",
            alignItems: "center",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                    flexDirection: "column",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                bold: true,
                                fontSize: "20px",
                                decimals: 3,
                                value: stakedTokenBalance
                            }),
                            stakingTokenPrice !== 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                fontSize: "12px",
                                color: "textSubtle",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                    fontSize: "12px",
                                    color: "textSubtle",
                                    decimals: 2,
                                    value: stakedTokenDollarBalance,
                                    prefix: "~",
                                    unit: " USD"
                                })
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.IconButton, {
                            variant: "secondary",
                            onClick: onPresentUnstake,
                            mr: "6px",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.MinusIcon, {
                                color: "primary",
                                width: "24px"
                            })
                        }),
                        reachStakingLimit ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            ref: targetRef,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.IconButton, {
                                variant: "secondary",
                                disabled: true,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.AddIcon, {
                                    color: "textDisabled",
                                    width: "24px",
                                    height: "24px"
                                })
                            })
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.IconButton, {
                            variant: "secondary",
                            onClick: stakingTokenBalance.gt(0) ? onPresentStake : onPresentTokenRequired,
                            disabled: isFinished,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.AddIcon, {
                                color: "primary",
                                width: "24px",
                                height: "24px"
                            })
                        })
                    ]
                }),
                tooltipVisible && tooltip
            ]
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
            disabled: isFinished,
            onClick: stakingTokenBalance.gt(0) ? onPresentStake : onPresentTokenRequired,
            children: t('Stake')
        });
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
        flexDirection: "column",
        children: isLoading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Skeleton, {
            width: "100%",
            height: "52px"
        }) : renderStakeAction()
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (StakeAction);

});

/***/ }),

/***/ 40230:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(34215);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(bignumber_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var utils_bigNumber__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(35128);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(99150);
/* harmony import */ var config_constants_types__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(97971);
/* harmony import */ var _ApprovalAction__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(87336);
/* harmony import */ var _StakeActions__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(20889);
/* harmony import */ var _HarvestActions__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(97258);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_StakeActions__WEBPACK_IMPORTED_MODULE_9__, _ApprovalAction__WEBPACK_IMPORTED_MODULE_8__, _HarvestActions__WEBPACK_IMPORTED_MODULE_10__]);
([_StakeActions__WEBPACK_IMPORTED_MODULE_9__, _ApprovalAction__WEBPACK_IMPORTED_MODULE_8__, _HarvestActions__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);











const InlineText = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Text).withConfig({
    componentId: "sc-f9f16377-0"
})`
  display: inline;
`;
const CardActions = ({ pool , stakedBalance  })=>{
    const { sousId , stakingToken , earningToken , harvest , poolCategory , userData , earningTokenPrice  } = pool;
    // Pools using native BNB behave differently than pools using a token
    const isBnbPool = poolCategory === config_constants_types__WEBPACK_IMPORTED_MODULE_7__/* .PoolCategory.BINANCE */ .jh.BINANCE;
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_6__/* .useTranslation */ .$G)();
    const allowance = userData?.allowance ? new (bignumber_js__WEBPACK_IMPORTED_MODULE_1___default())(userData.allowance) : utils_bigNumber__WEBPACK_IMPORTED_MODULE_4__/* .BIG_ZERO */ .HW;
    const stakingTokenBalance = userData?.stakingTokenBalance ? new (bignumber_js__WEBPACK_IMPORTED_MODULE_1___default())(userData.stakingTokenBalance) : utils_bigNumber__WEBPACK_IMPORTED_MODULE_4__/* .BIG_ZERO */ .HW;
    const earnings = userData?.pendingReward ? new (bignumber_js__WEBPACK_IMPORTED_MODULE_1___default())(userData.pendingReward) : utils_bigNumber__WEBPACK_IMPORTED_MODULE_4__/* .BIG_ZERO */ .HW;
    const needsApproval = !allowance.gt(0) && !isBnbPool;
    const isStaked = stakedBalance.gt(0);
    const isLoading = !userData;
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Flex, {
        flexDirection: "column",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Flex, {
            flexDirection: "column",
            children: [
                harvest && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Box, {
                            display: "inline",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(InlineText, {
                                    color: "secondary",
                                    textTransform: "uppercase",
                                    bold: true,
                                    fontSize: "12px",
                                    children: `${earningToken.symbol} `
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(InlineText, {
                                    color: "textSubtle",
                                    textTransform: "uppercase",
                                    bold: true,
                                    fontSize: "12px",
                                    children: t('Earned')
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_HarvestActions__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                            earnings: earnings,
                            earningToken: earningToken,
                            sousId: sousId,
                            earningTokenPrice: earningTokenPrice,
                            isBnbPool: isBnbPool,
                            isLoading: isLoading
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_5__.Box, {
                    display: "inline",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(InlineText, {
                            color: isStaked ? 'secondary' : 'textSubtle',
                            textTransform: "uppercase",
                            bold: true,
                            fontSize: "12px",
                            children: [
                                isStaked ? stakingToken.symbol : t('Stake'),
                                ' '
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(InlineText, {
                            color: isStaked ? 'textSubtle' : 'secondary',
                            textTransform: "uppercase",
                            bold: true,
                            fontSize: "12px",
                            children: isStaked ? t('Staked') : `${stakingToken.symbol}`
                        })
                    ]
                }),
                needsApproval ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ApprovalAction__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                    pool: pool,
                    isLoading: isLoading
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_StakeActions__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                    isLoading: isLoading,
                    pool: pool,
                    stakingTokenBalance: stakingTokenBalance,
                    stakedBalance: stakedBalance,
                    isBnbPool: isBnbPool,
                    isStaked: isStaked
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CardActions);

});

/***/ }),

/***/ 73068:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(99150);
/* harmony import */ var hooks_useTheme__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(23917);
/* harmony import */ var hooks_useToast__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(789);
/* harmony import */ var components_Toast__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(63937);
/* harmony import */ var utils_formatBalance__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(65044);
/* harmony import */ var utils_sentry__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(17226);
/* harmony import */ var _hooks_useHarvestPool__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(81291);
/* harmony import */ var _hooks_useStakePool__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2930);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks_useTheme__WEBPACK_IMPORTED_MODULE_4__]);
hooks_useTheme__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];











const CollectModal = ({ formattedBalance , fullBalance , earningToken , earningsDollarValue , sousId , isBnbPool , isCompoundPool =false , onDismiss ,  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_3__/* .useTranslation */ .$G)();
    const { theme  } = (0,hooks_useTheme__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)();
    const { toastSuccess , toastError  } = (0,hooks_useToast__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)();
    const { onReward  } = (0,_hooks_useHarvestPool__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)(sousId, isBnbPool);
    const { onStake  } = (0,_hooks_useStakePool__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)(sousId, isBnbPool);
    const { 0: pendingTx , 1: setPendingTx  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: shouldCompound , 1: setShouldCompound  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(isCompoundPool);
    const { targetRef , tooltip , tooltipVisible  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.useTooltip)(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                mb: "12px",
                children: t('Compound: collect and restake CAKE into pool.')
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                children: t('Harvest: collect CAKE and send to wallet')
            })
        ]
    }), {
        placement: 'bottom-end',
        tooltipOffset: [
            20,
            10
        ]
    });
    const handleHarvestConfirm = async ()=>{
        setPendingTx(true);
        // compounding
        if (shouldCompound) {
            try {
                await onStake(fullBalance, earningToken.decimals, (tx)=>{
                    toastSuccess(`${t('Transaction Submitted')}!`, /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_6__/* .ToastDescriptionWithTx */ .YO, {
                        txHash: tx.hash
                    }));
                }, (receipt)=>{
                    toastSuccess(`${t('Compounded')}!`, /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_6__/* .ToastDescriptionWithTx */ .YO, {
                        txHash: receipt.transactionHash,
                        children: t('Your %symbol% earnings have been re-invested into the pool!', {
                            symbol: earningToken.symbol
                        })
                    }));
                }, (receipt)=>{
                    toastError(t('Error'), /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_6__/* .ToastDescriptionWithTx */ .YO, {
                        txHash: receipt.transactionHash,
                        children: t('Please try again. Confirm the transaction and make sure you are paying enough gas!')
                    }));
                });
                setPendingTx(false);
                onDismiss();
            } catch (e) {
                toastError(t('Error'), t('Please try again. Confirm the transaction and make sure you are paying enough gas!'));
                (0,utils_sentry__WEBPACK_IMPORTED_MODULE_8__/* .logError */ .H)(e);
                setPendingTx(false);
            }
        } else {
            // harvesting
            try {
                await onReward((tx)=>{
                    toastSuccess(`${t('Transaction Submitted')}!`, /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_6__/* .ToastDescriptionWithTx */ .YO, {
                        txHash: tx.hash
                    }));
                }, (receipt)=>{
                    toastSuccess(`${t('Harvested')}!`, /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_6__/* .ToastDescriptionWithTx */ .YO, {
                        txHash: receipt.transactionHash,
                        children: t('Your %symbol% earnings have been sent to your wallet!', {
                            symbol: earningToken.symbol
                        })
                    }));
                }, (receipt)=>{
                    toastError(t('Error'), /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_6__/* .ToastDescriptionWithTx */ .YO, {
                        txHash: receipt.transactionHash,
                        children: t('Please try again. Confirm the transaction and make sure you are paying enough gas!')
                    }));
                });
                setPendingTx(false);
                onDismiss();
            } catch (e) {
                toastError(t('Error'), t('Please try again. Confirm the transaction and make sure you are paying enough gas!'));
                (0,utils_sentry__WEBPACK_IMPORTED_MODULE_8__/* .logError */ .H)(e);
                setPendingTx(false);
            }
        }
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Modal, {
        title: `${earningToken.symbol} ${isCompoundPool ? t('Collect') : t('Harvest')}`,
        onDismiss: onDismiss,
        headerBackground: theme.colors.gradients.cardHeader,
        children: [
            isCompoundPool && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                justifyContent: "center",
                alignItems: "center",
                mb: "24px",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.ButtonMenu, {
                        activeIndex: shouldCompound ? 0 : 1,
                        scale: "sm",
                        variant: "subtle",
                        onItemClick: (index)=>setShouldCompound(!index)
                        ,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.ButtonMenuItem, {
                                as: "button",
                                children: t('Compound')
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.ButtonMenuItem, {
                                as: "button",
                                children: t('Harvest')
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        ml: "10px",
                        ref: targetRef,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.HelpIcon, {
                            color: "textSubtle"
                        })
                    }),
                    tooltipVisible && tooltip
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                justifyContent: "space-between",
                alignItems: "center",
                mb: "24px",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        children: [
                            shouldCompound ? t('Compounding') : t('Harvesting'),
                            ":"
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        flexDirection: "column",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Heading, {
                                children: [
                                    formattedBalance,
                                    " ",
                                    earningToken.symbol
                                ]
                            }),
                            earningsDollarValue > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                fontSize: "12px",
                                color: "textSubtle",
                                children: `~${(0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_7__/* .formatNumber */ .uf)(earningsDollarValue)} USD`
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                mt: "8px",
                onClick: handleHarvestConfirm,
                isLoading: pendingTx,
                endIcon: pendingTx ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.AutoRenewIcon, {
                    spin: true,
                    color: "currentColor"
                }) : null,
                children: pendingTx ? t('Confirming') : t('Confirm')
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                variant: "text",
                onClick: onDismiss,
                pb: "0px",
                children: t('Close Window')
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CollectModal);

});

/***/ }),

/***/ 71603:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(34215);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(bignumber_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var components_ConnectWalletButton__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(30621);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(99150);
/* harmony import */ var utils_bigNumber__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(35128);
/* harmony import */ var components_TokenImage__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(95239);
/* harmony import */ var _AprRow__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3779);
/* harmony import */ var _StyledCard__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(12020);
/* harmony import */ var _CardFooter__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(73322);
/* harmony import */ var _PoolCardHeader__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(68624);
/* harmony import */ var _CardActions__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(40230);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_CardFooter__WEBPACK_IMPORTED_MODULE_10__, _CardActions__WEBPACK_IMPORTED_MODULE_12__]);
([_CardFooter__WEBPACK_IMPORTED_MODULE_10__, _CardActions__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);













const PoolCard = ({ pool , account  })=>{
    const { sousId , stakingToken , earningToken , isFinished , userData  } = pool;
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_5__/* .useTranslation */ .$G)();
    const stakedBalance = userData?.stakedBalance ? new (bignumber_js__WEBPACK_IMPORTED_MODULE_1___default())(userData.stakedBalance) : utils_bigNumber__WEBPACK_IMPORTED_MODULE_6__/* .BIG_ZERO */ .HW;
    const accountHasStakedBalance = stakedBalance.gt(0);
    const isCakePool = earningToken.symbol === 'CAKE' && stakingToken.symbol === 'CAKE';
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_StyledCard__WEBPACK_IMPORTED_MODULE_9__/* .StyledCard */ .r, {
        isFinished: isFinished && sousId !== 0,
        ribbon: isFinished && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.CardRibbon, {
            variantColor: "textDisabled",
            text: t('Finished')
        }),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_PoolCardHeader__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                isStaking: accountHasStakedBalance,
                isFinished: isFinished && sousId !== 0,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PoolCardHeader__WEBPACK_IMPORTED_MODULE_11__/* .PoolCardHeaderTitle */ .e, {
                        title: isCakePool ? t('Manual') : t('Earn %asset%', {
                            asset: earningToken.symbol
                        }),
                        subTitle: isCakePool ? t('Earn CAKE, stake CAKE') : t('Stake %symbol%', {
                            symbol: stakingToken.symbol
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_TokenImage__WEBPACK_IMPORTED_MODULE_7__/* .TokenPairImage */ .q, {
                        primaryToken: earningToken,
                        secondaryToken: stakingToken,
                        width: 64,
                        height: 64
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.CardBody, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_AprRow__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                        pool: pool,
                        stakedBalance: stakedBalance
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                        mt: "24px",
                        flexDirection: "column",
                        children: account ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CardActions__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                            pool: pool,
                            stakedBalance: stakedBalance
                        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                    mb: "10px",
                                    textTransform: "uppercase",
                                    fontSize: "12px",
                                    color: "textSubtle",
                                    bold: true,
                                    children: t('Start earning')
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_ConnectWalletButton__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CardFooter__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                pool: pool,
                account: account
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PoolCard);

});

/***/ }),

/***/ 26361:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_PoolTabButtons)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
// EXTERNAL MODULE: ./src/components/NextLink.tsx
var NextLink = __webpack_require__(53629);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(71853);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(57518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: external "@pancakeswap/uikit"
var uikit_ = __webpack_require__(2829);
// EXTERNAL MODULE: ./src/contexts/Localization/index.tsx + 3 modules
var Localization = __webpack_require__(99150);
// EXTERNAL MODULE: ./src/state/user/actions.ts
var actions = __webpack_require__(46245);
;// CONCATENATED MODULE: ./src/views/Pools/components/ToggleView/ToggleView.tsx





const Container = external_styled_components_default().div.withConfig({
    componentId: "sc-10815f02-0"
})`
  margin-right: 0px;
  margin-left: -8px;

  ${({ theme  })=>theme.mediaQueries.sm
} {
    margin-left: 0;
    margin-right: 16px;
  }
`;
const ToggleView = ({ viewMode , onToggle  })=>{
    const handleToggle = (mode)=>{
        if (viewMode !== mode) {
            onToggle(mode);
        }
    };
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(Container, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(uikit_.IconButton, {
                variant: "text",
                scale: "sm",
                id: "clickPoolCardView",
                onClick: ()=>handleToggle(actions/* ViewMode.CARD */.wO.CARD)
                ,
                children: /*#__PURE__*/ jsx_runtime_.jsx(uikit_.CardViewIcon, {
                    color: viewMode === actions/* ViewMode.CARD */.wO.CARD ? 'primary' : 'textDisabled'
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(uikit_.IconButton, {
                variant: "text",
                scale: "sm",
                id: "clickPoolTableView",
                onClick: ()=>handleToggle(actions/* ViewMode.TABLE */.wO.TABLE)
                ,
                children: /*#__PURE__*/ jsx_runtime_.jsx(uikit_.ListViewIcon, {
                    color: viewMode === actions/* ViewMode.TABLE */.wO.TABLE ? 'primary' : 'textDisabled'
                })
            })
        ]
    }));
};
/* harmony default export */ const ToggleView_ToggleView = (ToggleView);

;// CONCATENATED MODULE: ./src/views/Pools/components/PoolTabButtons.tsx








const ToggleWrapper = external_styled_components_default().div.withConfig({
    componentId: "sc-50917716-0"
})`
  display: flex;
  align-items: center;
  margin-left: 10px;

  ${uikit_.Text} {
    margin-left: 8px;
  }
`;
const ViewControls = external_styled_components_default().div.withConfig({
    componentId: "sc-50917716-1"
})`
  flex-wrap: wrap;
  justify-content: space-between;
  display: flex;
  align-items: center;
  width: 100%;

  > div {
    padding: 8px 0px;
  }

  ${({ theme  })=>theme.mediaQueries.sm
} {
    justify-content: flex-start;
    width: auto;

    > div {
      padding: 0;
    }
  }
`;
const Wrapper = external_styled_components_default().div.withConfig({
    componentId: "sc-50917716-2"
})`
  display: flex;
  justify-content: center;
  align-items: center;

  a {
    padding-left: 12px;
    padding-right: 12px;
  }

  ${({ theme  })=>theme.mediaQueries.sm
} {
    margin-left: 16px;
  }
`;
const PoolTabButtons = ({ stakedOnly , setStakedOnly , hasStakeInFinishedPools , viewMode , setViewMode  })=>{
    const router = (0,router_.useRouter)();
    const { t  } = (0,Localization/* useTranslation */.$G)();
    const isExact = router.asPath === '/pools';
    const viewModeToggle = /*#__PURE__*/ jsx_runtime_.jsx(ToggleView_ToggleView, {
        viewMode: viewMode,
        onToggle: (mode)=>setViewMode(mode)
    });
    const liveOrFinishedSwitch = /*#__PURE__*/ jsx_runtime_.jsx(Wrapper, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(uikit_.ButtonMenu, {
            activeIndex: isExact ? 0 : 1,
            scale: "sm",
            variant: "subtle",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(uikit_.ButtonMenuItem, {
                    as: NextLink/* NextLinkFromReactRouter */.a,
                    to: "/pools",
                    replace: true,
                    children: t('Live')
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(uikit_.NotificationDot, {
                    show: hasStakeInFinishedPools,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(uikit_.ButtonMenuItem, {
                        id: "finished-pools-button",
                        as: NextLink/* NextLinkFromReactRouter */.a,
                        to: "/pools/history",
                        replace: true,
                        children: t('Finished')
                    })
                })
            ]
        })
    });
    const stakedOnlySwitch = /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ToggleWrapper, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Toggle, {
                checked: stakedOnly,
                onChange: ()=>setStakedOnly(!stakedOnly)
                ,
                scale: "sm"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(uikit_.Text, {
                children: [
                    " ",
                    t('Staked only')
                ]
            })
        ]
    });
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(ViewControls, {
        children: [
            viewModeToggle,
            stakedOnlySwitch,
            liveOrFinishedSwitch
        ]
    }));
};
/* harmony default export */ const components_PoolTabButtons = (PoolTabButtons);


/***/ }),

/***/ 6154:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var config__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(33206);
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(38328);
/* harmony import */ var state_block_hooks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(37063);
/* harmony import */ var state_pools_hooks__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1624);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(34215);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(bignumber_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(99150);
/* harmony import */ var components_Balance__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(20922);
/* harmony import */ var components_Tags__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(69160);
/* harmony import */ var utils_addressHelpers__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(55878);
/* harmony import */ var utils_bigNumber__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(35128);
/* harmony import */ var utils_wallet__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(49058);
/* harmony import */ var utils_formatBalance__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(65044);
/* harmony import */ var views_Pools_helpers__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(53136);
/* harmony import */ var config_constants_pools__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(71080);
/* harmony import */ var _Harvest__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(24971);
/* harmony import */ var _Stake__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(86437);
/* harmony import */ var _Apr__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(98087);
/* harmony import */ var _AutoHarvest__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(93312);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Stake__WEBPACK_IMPORTED_MODULE_19__, _Harvest__WEBPACK_IMPORTED_MODULE_18__, _AutoHarvest__WEBPACK_IMPORTED_MODULE_21__, state_pools_hooks__WEBPACK_IMPORTED_MODULE_7__, state_block_hooks__WEBPACK_IMPORTED_MODULE_6__]);
([_Stake__WEBPACK_IMPORTED_MODULE_19__, _Harvest__WEBPACK_IMPORTED_MODULE_18__, _AutoHarvest__WEBPACK_IMPORTED_MODULE_21__, state_pools_hooks__WEBPACK_IMPORTED_MODULE_7__, state_block_hooks__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);






















const expandAnimation = styled_components__WEBPACK_IMPORTED_MODULE_2__.keyframes`
  from {
    max-height: 0px;
  }
  to {
    max-height: 700px;
  }
`;
const collapseAnimation = styled_components__WEBPACK_IMPORTED_MODULE_2__.keyframes`
  from {
    max-height: 700px;
  }
  to {
    max-height: 0px;
  }
`;
const StyledActionPanel = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-baa18b02-0"
})`
  animation: ${({ expanded  })=>expanded ? styled_components__WEBPACK_IMPORTED_MODULE_2__.css`
          ${expandAnimation} 300ms linear forwards
        ` : styled_components__WEBPACK_IMPORTED_MODULE_2__.css`
          ${collapseAnimation} 300ms linear forwards
        `
};
  overflow: hidden;
  background: ${({ theme  })=>theme.colors.dropdown
};
  display: flex;
  flex-direction: column-reverse;
  justify-content: center;
  padding: 12px;

  ${({ theme  })=>theme.mediaQueries.lg
} {
    flex-direction: row;
    padding: 16px 32px;
  }
`;
const ActionContainer = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-baa18b02-1"
})`
  display: flex;
  flex-direction: column;

  ${({ theme  })=>theme.mediaQueries.sm
} {
    flex-direction: row;
    align-items: center;
    flex-grow: 1;
    flex-basis: 0;
  }
`;
const InfoSection = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Box).withConfig({
    componentId: "sc-baa18b02-2"
})`
  flex-grow: 0;
  flex-shrink: 0;
  flex-basis: auto;
  padding: 8px 8px;
  ${({ theme  })=>theme.mediaQueries.lg
} {
    padding: 0;
    flex-basis: 230px;
  }
`;
const ActionPanel = ({ account , pool , userDataLoaded , expanded , breakpoints  })=>{
    const { sousId , stakingToken , earningToken , totalStaked , startBlock , endBlock , stakingLimit , contractAddress , userData , vaultKey ,  } = pool;
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_9__/* .useTranslation */ .$G)();
    const poolContractAddress = (0,utils_addressHelpers__WEBPACK_IMPORTED_MODULE_12__/* .getAddress */ .Kn)(contractAddress);
    const vaultContractAddress = (0,utils_addressHelpers__WEBPACK_IMPORTED_MODULE_12__/* .getVaultPoolAddress */ .ZX)(vaultKey);
    const currentBlock = (0,state_block_hooks__WEBPACK_IMPORTED_MODULE_6__/* .useCurrentBlock */ .je)();
    const { isXs , isSm , isMd  } = breakpoints;
    const showSubtitle = (isXs || isSm) && sousId === 0;
    const { shouldShowBlockCountdown , blocksUntilStart , blocksRemaining , hasPoolStarted , blocksToDisplay  } = (0,views_Pools_helpers__WEBPACK_IMPORTED_MODULE_16__/* .getPoolBlockInfo */ .zy)(pool, currentBlock);
    const isMetaMaskInScope = !!window.ethereum?.isMetaMask;
    const tokenAddress = earningToken.address || '';
    const { totalCakeInVault , userData: { userShares  } , fees: { performanceFeeAsDecimal  } , pricePerFullShare ,  } = (0,state_pools_hooks__WEBPACK_IMPORTED_MODULE_7__/* .useVaultPoolByKey */ .eB)(vaultKey);
    const vaultPools = (0,state_pools_hooks__WEBPACK_IMPORTED_MODULE_7__/* .useVaultPools */ .KV)();
    const cakeInVaults = Object.values(vaultPools).reduce((total, vault)=>{
        return total.plus(vault.totalCakeInVault);
    }, utils_bigNumber__WEBPACK_IMPORTED_MODULE_13__/* .BIG_ZERO */ .HW);
    const stakingTokenBalance = userData?.stakingTokenBalance ? new (bignumber_js__WEBPACK_IMPORTED_MODULE_8___default())(userData.stakingTokenBalance) : utils_bigNumber__WEBPACK_IMPORTED_MODULE_13__/* .BIG_ZERO */ .HW;
    const stakedBalance = userData?.stakedBalance ? new (bignumber_js__WEBPACK_IMPORTED_MODULE_8___default())(userData.stakedBalance) : utils_bigNumber__WEBPACK_IMPORTED_MODULE_13__/* .BIG_ZERO */ .HW;
    const { cakeAsBigNumber  } = (0,views_Pools_helpers__WEBPACK_IMPORTED_MODULE_16__/* .convertSharesToCake */ .ur)(userShares, pricePerFullShare);
    const poolStakingTokenBalance = vaultKey ? cakeAsBigNumber.plus(stakingTokenBalance) : stakedBalance.plus(stakingTokenBalance);
    const isManualCakePool = sousId === 0;
    const getTotalStakedBalance = ()=>{
        if (vaultKey) {
            return (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_15__/* .getBalanceNumber */ .mW)(totalCakeInVault, stakingToken.decimals);
        }
        if (isManualCakePool) {
            const manualCakeTotalMinusAutoVault = new (bignumber_js__WEBPACK_IMPORTED_MODULE_8___default())(totalStaked).minus(cakeInVaults);
            return (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_15__/* .getBalanceNumber */ .mW)(manualCakeTotalMinusAutoVault, stakingToken.decimals);
        }
        return (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_15__/* .getBalanceNumber */ .mW)(totalStaked, stakingToken.decimals);
    };
    const { targetRef: totalStakedTargetRef , tooltip: totalStakedTooltip , tooltipVisible: totalStakedTooltipVisible ,  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.useTooltip)(t('Total amount of %symbol% staked in this pool', {
        symbol: stakingToken.symbol
    }), {
        placement: 'bottom'
    });
    const manualTooltipText = t('You must harvest and compound your earnings from this pool manually.');
    const autoTooltipText = t('Any funds you stake in this pool will be automagically harvested and restaked (compounded) for you.');
    const { targetRef: tagTargetRef , tooltip: tagTooltip , tooltipVisible: tagTooltipVisible ,  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.useTooltip)(vaultKey ? autoTooltipText : manualTooltipText, {
        placement: 'bottom-start'
    });
    const maxStakeRow = stakingLimit.gt(0) ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
        mb: "8px",
        justifyContent: "space-between",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                children: [
                    t('Max. stake per user'),
                    ":"
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                children: `${(0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_15__/* .getFullDisplayBalance */ .NJ)(stakingLimit, stakingToken.decimals, 0)} ${stakingToken.symbol}`
            })
        ]
    }) : null;
    const blocksRow = blocksRemaining || blocksUntilStart ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
        mb: "8px",
        justifyContent: "space-between",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                children: [
                    hasPoolStarted ? t('Ends in') : t('Starts in'),
                    ":"
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Link, {
                    external: true,
                    href: (0,utils__WEBPACK_IMPORTED_MODULE_5__/* .getBscScanLink */ .s6)(hasPoolStarted ? endBlock : startBlock, 'countdown'),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                            fontSize: "16px",
                            value: blocksToDisplay,
                            decimals: 0,
                            color: "primary"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                            ml: "4px",
                            color: "primary",
                            textTransform: "lowercase",
                            children: t('Blocks')
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.TimerIcon, {
                            ml: "4px",
                            color: "primary"
                        })
                    ]
                })
            })
        ]
    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Skeleton, {
        width: "56px",
        height: "16px"
    });
    const aprRow = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
        justifyContent: "space-between",
        alignItems: "center",
        mb: "8px",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                children: [
                    vaultKey ? t('APY') : t('APR'),
                    ":"
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Apr__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {
                pool: pool,
                showIcon: true,
                stakedBalance: poolStakingTokenBalance,
                performanceFee: vaultKey ? performanceFeeAsDecimal : 0
            })
        ]
    });
    const totalStakedRow = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
        justifyContent: "space-between",
        alignItems: "center",
        mb: "8px",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                maxWidth: [
                    '50px',
                    '100%'
                ],
                children: [
                    t('Total staked'),
                    ":"
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                alignItems: "center",
                children: [
                    totalStaked && totalStaked.gte(0) ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                fontSize: "16px",
                                value: getTotalStakedBalance(),
                                decimals: 0,
                                unit: ` ${stakingToken.symbol}`
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                ref: totalStakedTargetRef,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.HelpIcon, {
                                    color: "textSubtle",
                                    width: "20px",
                                    ml: "4px"
                                })
                            })
                        ]
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Skeleton, {
                        width: "56px",
                        height: "16px"
                    }),
                    totalStakedTooltipVisible && totalStakedTooltip
                ]
            })
        ]
    });
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(StyledActionPanel, {
        expanded: expanded,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(InfoSection, {
                children: [
                    maxStakeRow,
                    (isXs || isSm) && aprRow,
                    (isXs || isSm || isMd) && totalStakedRow,
                    shouldShowBlockCountdown && blocksRow,
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                        mb: "8px",
                        justifyContent: [
                            'flex-end',
                            'flex-end',
                            'flex-start'
                        ],
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.LinkExternal, {
                            href: `/info/token/${earningToken.address}`,
                            bold: false,
                            children: t('See Token Info')
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                        mb: "8px",
                        justifyContent: [
                            'flex-end',
                            'flex-end',
                            'flex-start'
                        ],
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.LinkExternal, {
                            href: earningToken.projectLink,
                            bold: false,
                            children: t('View Project Site')
                        })
                    }),
                    poolContractAddress && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                        mb: "8px",
                        justifyContent: [
                            'flex-end',
                            'flex-end',
                            'flex-start'
                        ],
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.LinkExternal, {
                            href: `${config__WEBPACK_IMPORTED_MODULE_4__/* .BASE_BSC_SCAN_URL */ .OS}/address/${vaultKey ? vaultContractAddress : poolContractAddress}`,
                            bold: false,
                            children: t('View Contract')
                        })
                    }),
                    account && isMetaMaskInScope && tokenAddress && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                        mb: "8px",
                        justifyContent: [
                            'flex-end',
                            'flex-end',
                            'flex-start'
                        ],
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Button, {
                            variant: "text",
                            p: "0",
                            height: "auto",
                            onClick: ()=>(0,utils_wallet__WEBPACK_IMPORTED_MODULE_14__/* .registerToken */ .$)(tokenAddress, earningToken.symbol, earningToken.decimals)
                            ,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                    color: "primary",
                                    children: t('Add to Metamask')
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.MetamaskIcon, {
                                    ml: "4px"
                                })
                            ]
                        })
                    }),
                    vaultKey ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Tags__WEBPACK_IMPORTED_MODULE_11__/* .CompoundingPoolTag */ .yd, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Tags__WEBPACK_IMPORTED_MODULE_11__/* .ManualPoolTag */ .EM, {}),
                    tagTooltipVisible && tagTooltip,
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        ref: tagTargetRef,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.HelpIcon, {
                            ml: "4px",
                            width: "20px",
                            height: "20px",
                            color: "textSubtle"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ActionContainer, {
                children: [
                    showSubtitle && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                        mt: "4px",
                        mb: "16px",
                        color: "textSubtle",
                        children: vaultKey ? t(config_constants_pools__WEBPACK_IMPORTED_MODULE_17__/* .vaultPoolConfig */ .Y[vaultKey].description) : `${t('Earn')} CAKE ${t('Stake').toLocaleLowerCase()} CAKE`
                    }),
                    pool.vaultKey ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_AutoHarvest__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .Z, {
                        ...pool,
                        userDataLoaded: userDataLoaded
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Harvest__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {
                        ...pool,
                        userDataLoaded: userDataLoaded
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Stake__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z, {
                        pool: pool,
                        userDataLoaded: userDataLoaded
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ActionPanel);

});

/***/ }),

/***/ 93312:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(18054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var views_Pools_helpers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(53136);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(99150);
/* harmony import */ var components_Balance__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(20922);
/* harmony import */ var state_pools_hooks__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1624);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4985);
/* harmony import */ var _CakeVaultCard_UnstakingFeeCountdownRow__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(59116);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_CakeVaultCard_UnstakingFeeCountdownRow__WEBPACK_IMPORTED_MODULE_9__, state_pools_hooks__WEBPACK_IMPORTED_MODULE_7__]);
([_CakeVaultCard_UnstakingFeeCountdownRow__WEBPACK_IMPORTED_MODULE_9__, state_pools_hooks__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);










const AutoHarvestAction = ({ userDataLoaded , earningTokenPrice , vaultKey ,  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_5__/* .useTranslation */ .$G)();
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_3__.useWeb3React)();
    const { userData: { cakeAtLastUserAction , userShares  } , pricePerFullShare , fees: { performanceFee  } ,  } = (0,state_pools_hooks__WEBPACK_IMPORTED_MODULE_7__/* .useVaultPoolByKey */ .eB)(vaultKey);
    const { hasAutoEarnings , autoCakeToDisplay , autoUsdToDisplay  } = (0,views_Pools_helpers__WEBPACK_IMPORTED_MODULE_4__/* .getCakeVaultEarnings */ .UN)(account, cakeAtLastUserAction, userShares, pricePerFullShare, earningTokenPrice);
    const earningTokenBalance = autoCakeToDisplay;
    const earningTokenDollarBalance = autoUsdToDisplay;
    const hasEarnings = hasAutoEarnings;
    const { targetRef , tooltip , tooltipVisible  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.useTooltip)(t('Subtracted automatically from each yield harvest and burned.'), {
        placement: 'bottom-start'
    });
    const actionTitle = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
        fontSize: "12px",
        bold: true,
        color: "secondary",
        as: "span",
        textTransform: "uppercase",
        children: t('Recent CAKE profit')
    });
    if (!account) {
        return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styles__WEBPACK_IMPORTED_MODULE_8__/* .ActionContainer */ .sX, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styles__WEBPACK_IMPORTED_MODULE_8__/* .ActionTitles */ .Ad, {
                    children: actionTitle
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styles__WEBPACK_IMPORTED_MODULE_8__/* .ActionContent */ .O6, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Heading, {
                        children: "0"
                    })
                })
            ]
        }));
    }
    if (!userDataLoaded) {
        return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styles__WEBPACK_IMPORTED_MODULE_8__/* .ActionContainer */ .sX, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styles__WEBPACK_IMPORTED_MODULE_8__/* .ActionTitles */ .Ad, {
                    children: actionTitle
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styles__WEBPACK_IMPORTED_MODULE_8__/* .ActionContent */ .O6, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Skeleton, {
                        width: 180,
                        height: "32px",
                        marginTop: 14
                    })
                })
            ]
        }));
    }
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styles__WEBPACK_IMPORTED_MODULE_8__/* .ActionContainer */ .sX, {
        isAutoVault: true,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styles__WEBPACK_IMPORTED_MODULE_8__/* .ActionTitles */ .Ad, {
                children: actionTitle
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styles__WEBPACK_IMPORTED_MODULE_8__/* .ActionContent */ .O6, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        flex: "1",
                        pt: "16px",
                        flexDirection: "column",
                        alignSelf: "flex-start",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: hasEarnings ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                        lineHeight: "1",
                                        bold: true,
                                        fontSize: "20px",
                                        decimals: 5,
                                        value: earningTokenBalance
                                    }),
                                    earningTokenPrice > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                        display: "inline",
                                        fontSize: "12px",
                                        color: "textSubtle",
                                        decimals: 2,
                                        prefix: "~",
                                        value: earningTokenDollarBalance,
                                        unit: " USD"
                                    })
                                ]
                            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Heading, {
                                        color: "textDisabled",
                                        children: "0"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                        fontSize: "12px",
                                        color: "textDisabled",
                                        children: "0 USD"
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        flex: "1.3",
                        flexDirection: "column",
                        alignSelf: "flex-start",
                        alignItems: "flex-start",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CakeVaultCard_UnstakingFeeCountdownRow__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                vaultKey: vaultKey,
                                isTableVariant: true
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                                mb: "2px",
                                justifyContent: "space-between",
                                alignItems: "center",
                                children: [
                                    tooltipVisible && tooltip,
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.TooltipText, {
                                        ref: targetRef,
                                        small: true,
                                        children: t('Performance Fee')
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                                        alignItems: "center",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                            ml: "4px",
                                            small: true,
                                            children: [
                                                performanceFee / 100,
                                                "%"
                                            ]
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AutoHarvestAction);

});

/***/ }),

/***/ 24971:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(34215);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(bignumber_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(18054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var config_constants_types__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(97971);
/* harmony import */ var utils_formatBalance__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(65044);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(99150);
/* harmony import */ var components_Balance__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(20922);
/* harmony import */ var utils_bigNumber__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(35128);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4985);
/* harmony import */ var _PoolCard_Modals_CollectModal__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(73068);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_PoolCard_Modals_CollectModal__WEBPACK_IMPORTED_MODULE_11__]);
_PoolCard_Modals_CollectModal__WEBPACK_IMPORTED_MODULE_11__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];












const HarvestAction = ({ sousId , poolCategory , earningToken , userData , userDataLoaded , earningTokenPrice ,  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_7__/* .useTranslation */ .$G)();
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_4__.useWeb3React)();
    const earnings = userData?.pendingReward ? new (bignumber_js__WEBPACK_IMPORTED_MODULE_3___default())(userData.pendingReward) : utils_bigNumber__WEBPACK_IMPORTED_MODULE_9__/* .BIG_ZERO */ .HW;
    const earningTokenBalance = (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_6__/* .getBalanceNumber */ .mW)(earnings, earningToken.decimals);
    const earningTokenDollarBalance = (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_6__/* .getBalanceNumber */ .mW)(earnings.multipliedBy(earningTokenPrice), earningToken.decimals);
    const hasEarnings = earnings.gt(0);
    const fullBalance = (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_6__/* .getFullDisplayBalance */ .NJ)(earnings, earningToken.decimals);
    const formattedBalance = (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_6__/* .formatNumber */ .uf)(earningTokenBalance, 3, 3);
    const isCompoundPool = sousId === 0;
    const isBnbPool = poolCategory === config_constants_types__WEBPACK_IMPORTED_MODULE_5__/* .PoolCategory.BINANCE */ .jh.BINANCE;
    const [onPresentCollect] = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.useModal)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PoolCard_Modals_CollectModal__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
        formattedBalance: formattedBalance,
        fullBalance: fullBalance,
        earningToken: earningToken,
        earningsDollarValue: earningTokenDollarBalance,
        sousId: sousId,
        isBnbPool: isBnbPool,
        isCompoundPool: isCompoundPool
    }));
    const actionTitle = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                fontSize: "12px",
                bold: true,
                color: "secondary",
                as: "span",
                textTransform: "uppercase",
                children: [
                    earningToken.symbol,
                    ' '
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                fontSize: "12px",
                bold: true,
                color: "textSubtle",
                as: "span",
                textTransform: "uppercase",
                children: t('Earned')
            })
        ]
    });
    if (!account) {
        return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styles__WEBPACK_IMPORTED_MODULE_10__/* .ActionContainer */ .sX, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styles__WEBPACK_IMPORTED_MODULE_10__/* .ActionTitles */ .Ad, {
                    children: actionTitle
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styles__WEBPACK_IMPORTED_MODULE_10__/* .ActionContent */ .O6, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Heading, {
                            children: "0"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                            disabled: true,
                            children: isCompoundPool ? t('Collect') : t('Harvest')
                        })
                    ]
                })
            ]
        }));
    }
    if (!userDataLoaded) {
        return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styles__WEBPACK_IMPORTED_MODULE_10__/* .ActionContainer */ .sX, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styles__WEBPACK_IMPORTED_MODULE_10__/* .ActionTitles */ .Ad, {
                    children: actionTitle
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styles__WEBPACK_IMPORTED_MODULE_10__/* .ActionContent */ .O6, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Skeleton, {
                        width: 180,
                        height: "32px",
                        marginTop: 14
                    })
                })
            ]
        }));
    }
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styles__WEBPACK_IMPORTED_MODULE_10__/* .ActionContainer */ .sX, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styles__WEBPACK_IMPORTED_MODULE_10__/* .ActionTitles */ .Ad, {
                children: actionTitle
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styles__WEBPACK_IMPORTED_MODULE_10__/* .ActionContent */ .O6, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        flex: "1",
                        pt: "16px",
                        flexDirection: "column",
                        alignSelf: "flex-start",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: hasEarnings ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                        lineHeight: "1",
                                        bold: true,
                                        fontSize: "20px",
                                        decimals: 5,
                                        value: earningTokenBalance
                                    }),
                                    earningTokenPrice > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                        display: "inline",
                                        fontSize: "12px",
                                        color: "textSubtle",
                                        decimals: 2,
                                        prefix: "~",
                                        value: earningTokenDollarBalance,
                                        unit: " USD"
                                    })
                                ]
                            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Heading, {
                                        color: "textDisabled",
                                        children: "0"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                        fontSize: "12px",
                                        color: "textDisabled",
                                        children: "0 USD"
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                        disabled: !hasEarnings,
                        onClick: onPresentCollect,
                        children: isCompoundPool ? t('Collect') : t('Harvest')
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HarvestAction);

});

/***/ }),

/***/ 98087:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var components_RoiCalculatorModal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(46414);
/* harmony import */ var components_Balance__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(20922);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(99150);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(34215);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(bignumber_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var utils_bigNumber__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(35128);
/* harmony import */ var config_constants_pools__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(71080);










const AprLabelContainer = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex).withConfig({
    componentId: "sc-8315451b-0"
})`
  &:hover {
    opacity: 0.5;
  }
`;
const Apr = ({ pool , showIcon , stakedBalance , performanceFee =0 , ...props })=>{
    const { stakingToken , earningToken , isFinished , earningTokenPrice , stakingTokenPrice , userData , apr , rawApr , vaultKey ,  } = pool;
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_6__/* .useTranslation */ .$G)();
    const stakingTokenBalance = userData?.stakingTokenBalance ? new (bignumber_js__WEBPACK_IMPORTED_MODULE_7___default())(userData.stakingTokenBalance) : utils_bigNumber__WEBPACK_IMPORTED_MODULE_8__/* .BIG_ZERO */ .HW;
    const apyModalLink = stakingToken.address ? `/swap?outputCurrency=${stakingToken.address}` : '/swap';
    const [onPresentApyModal] = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.useModal)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_RoiCalculatorModal__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
        earningTokenPrice: earningTokenPrice,
        stakingTokenPrice: stakingTokenPrice,
        stakingTokenBalance: stakedBalance.plus(stakingTokenBalance),
        apr: vaultKey ? rawApr : apr,
        stakingTokenSymbol: stakingToken.symbol,
        linkLabel: t('Get %symbol%', {
            symbol: stakingToken.symbol
        }),
        linkHref: apyModalLink,
        earningTokenSymbol: earningToken.symbol,
        autoCompoundFrequency: config_constants_pools__WEBPACK_IMPORTED_MODULE_9__/* .vaultPoolConfig */ .Y[vaultKey]?.autoCompoundFrequency ?? 0,
        performanceFee: performanceFee
    }));
    const openRoiModal = (event)=>{
        event.stopPropagation();
        onPresentApyModal();
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AprLabelContainer, {
        alignItems: "center",
        justifyContent: "flex-start",
        ...props,
        children: apr || isFinished ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                    onClick: openRoiModal,
                    fontSize: "16px",
                    isDisabled: isFinished,
                    value: isFinished ? 0 : apr,
                    decimals: 2,
                    unit: "%"
                }),
                !isFinished && showIcon && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Button, {
                    onClick: openRoiModal,
                    variant: "text",
                    width: "20px",
                    height: "20px",
                    padding: "0px",
                    marginLeft: "4px",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.CalculateIcon, {
                        color: "textSubtle",
                        width: "20px"
                    })
                })
            ]
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Skeleton, {
            width: "80px",
            height: "16px"
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Apr);


/***/ }),

/***/ 81401:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var utils_bigNumber__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(35128);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(34215);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(bignumber_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(99150);
/* harmony import */ var _BaseCell__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(70709);
/* harmony import */ var _Apr__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(98087);








const AprCell = ({ pool  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_5__/* .useTranslation */ .$G)();
    const { isMobile  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.useMatchBreakpoints)();
    const { userData  } = pool;
    const stakedBalance = userData?.stakedBalance ? new (bignumber_js__WEBPACK_IMPORTED_MODULE_4___default())(userData.stakedBalance) : utils_bigNumber__WEBPACK_IMPORTED_MODULE_2__/* .BIG_ZERO */ .HW;
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_BaseCell__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
        role: "cell",
        flex: [
            '1 0 50px',
            '1 0 50px',
            '2 0 100px',
            '2 0 100px',
            '1 0 120px'
        ],
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_BaseCell__WEBPACK_IMPORTED_MODULE_6__/* .CellContent */ .J, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                    fontSize: "12px",
                    color: "textSubtle",
                    textAlign: "left",
                    children: t('APR')
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Apr__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                    pool: pool,
                    stakedBalance: stakedBalance,
                    showIcon: !isMobile
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AprCell);


/***/ }),

/***/ 64030:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var state_pools_hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1624);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99150);
/* harmony import */ var _BaseCell__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(70709);
/* harmony import */ var _Apr__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(98087);
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(53136);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([state_pools_hooks__WEBPACK_IMPORTED_MODULE_3__]);
state_pools_hooks__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];








const AutoAprCell = ({ pool  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    const { isMobile  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.useMatchBreakpoints)();
    const { userData: { userShares  } , fees: { performanceFeeAsDecimal  } , pricePerFullShare ,  } = (0,state_pools_hooks__WEBPACK_IMPORTED_MODULE_3__/* .useVaultPoolByKey */ .eB)(pool.vaultKey);
    const { cakeAsBigNumber  } = (0,_helpers__WEBPACK_IMPORTED_MODULE_7__/* .convertSharesToCake */ .ur)(userShares, pricePerFullShare);
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_BaseCell__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
        role: "cell",
        flex: [
            '1 0 50px',
            '1 0 50px',
            '2 0 100px',
            '2 0 100px',
            '1 0 120px'
        ],
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_BaseCell__WEBPACK_IMPORTED_MODULE_5__/* .CellContent */ .J, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                    fontSize: "12px",
                    color: "textSubtle",
                    textAlign: "left",
                    children: t('APY')
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Apr__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                    pool: pool,
                    stakedBalance: cakeAsBigNumber,
                    performanceFee: performanceFeeAsDecimal,
                    showIcon: !isMobile
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AutoAprCell);

});

/***/ }),

/***/ 39442:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var components_Balance__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(20922);
/* harmony import */ var state_pools_hooks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1624);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(99150);
/* harmony import */ var views_Pools_helpers__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(53136);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(74146);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(date_fns__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var utils_formatBalance__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(65044);
/* harmony import */ var utils_compoundApyHelpers__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(16395);
/* harmony import */ var config_constants_pools__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(71080);
/* harmony import */ var _BaseCell__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(70709);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([state_pools_hooks__WEBPACK_IMPORTED_MODULE_5__]);
state_pools_hooks__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];













const StyledCell = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_BaseCell__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z).withConfig({
    componentId: "sc-10a15279-0"
})`
  flex: 4.5;
  ${({ theme  })=>theme.mediaQueries.sm
} {
    flex: 1 0 120px;
  }
`;
const HelpIconWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-10a15279-1"
})`
  align-self: center;
`;
const getAutoEarningsInterestBreakdown = (pool, lastActionInMs, earningTokenDollarBalance, userShares, pricePerFullShare, performanceFeeAsDecimal)=>{
    const { stakingTokenPrice , earningTokenPrice , rawApr  } = pool;
    const autoCompoundFrequency = config_constants_pools__WEBPACK_IMPORTED_MODULE_10__/* .vaultPoolConfig */ .Y[pool.vaultKey]?.autoCompoundFrequency ?? 0;
    const { cakeAsBigNumber  } = (0,views_Pools_helpers__WEBPACK_IMPORTED_MODULE_7__/* .convertSharesToCake */ .ur)(userShares, pricePerFullShare);
    return (0,utils_compoundApyHelpers__WEBPACK_IMPORTED_MODULE_12__/* .getInterestBreakdown */ .A1)({
        principalInUSD: (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_9__/* .getBalanceNumber */ .mW)(cakeAsBigNumber.times(stakingTokenPrice)),
        apr: rawApr,
        earningTokenPrice,
        compoundFrequency: autoCompoundFrequency,
        performanceFee: performanceFeeAsDecimal
    });
};
const getAutoEarningsRoiTimePeriod = (timePeriod, interestBreakdown, earningTokenPrice)=>{
    const hasInterest = Number.isFinite(interestBreakdown[timePeriod]);
    const roiTokens = hasInterest ? interestBreakdown[timePeriod] : 0;
    return hasInterest ? roiTokens * earningTokenPrice : 0;
};
const AutoEarningsCell = ({ pool , account  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_6__/* .useTranslation */ .$G)();
    const { isMobile  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.useMatchBreakpoints)();
    const { earningTokenPrice  } = pool;
    const { userData: { isLoading: userDataLoading , cakeAtLastUserAction , userShares , lastUserActionTime  } , fees: { performanceFeeAsDecimal  } , pricePerFullShare ,  } = (0,state_pools_hooks__WEBPACK_IMPORTED_MODULE_5__/* .useVaultPoolByKey */ .eB)(pool.vaultKey);
    const { hasAutoEarnings , autoCakeToDisplay , autoUsdToDisplay  } = (0,views_Pools_helpers__WEBPACK_IMPORTED_MODULE_7__/* .getCakeVaultEarnings */ .UN)(account, cakeAtLastUserAction, userShares, pricePerFullShare, earningTokenPrice);
    const labelText = t('Recent CAKE profit');
    const earningTokenBalance = autoCakeToDisplay;
    const hasEarnings = hasAutoEarnings;
    const earningTokenDollarBalance = autoUsdToDisplay;
    const lastActionInMs = lastUserActionTime ? parseInt(lastUserActionTime) * 1000 : 0;
    const hourDiffSinceLastAction = (0,date_fns__WEBPACK_IMPORTED_MODULE_8__.differenceInHours)(Date.now(), lastActionInMs);
    const earnedCakePerHour = hourDiffSinceLastAction ? earningTokenBalance / hourDiffSinceLastAction : 0;
    const earnedUsdPerHour = hourDiffSinceLastAction ? earningTokenDollarBalance / hourDiffSinceLastAction : 0;
    const interestBreakdown = getAutoEarningsInterestBreakdown(pool, lastActionInMs, earningTokenDollarBalance, userShares, pricePerFullShare, performanceFeeAsDecimal);
    const roiDay = getAutoEarningsRoiTimePeriod(0, interestBreakdown, earningTokenPrice);
    const roiWeek = getAutoEarningsRoiTimePeriod(1, interestBreakdown, earningTokenPrice);
    const roiMonth = getAutoEarningsRoiTimePeriod(2, interestBreakdown, earningTokenPrice);
    const roiYear = getAutoEarningsRoiTimePeriod(3, interestBreakdown, earningTokenPrice);
    const { targetRef , tooltip , tooltipVisible  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.useTooltip)(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                bold: true,
                children: [
                    autoCakeToDisplay.toFixed(3),
                    ' CAKE'
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                bold: true,
                children: [
                    "~$",
                    autoUsdToDisplay.toFixed(2)
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                children: [
                    t('Earned since your last action'),
                    ":"
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                children: new Date(lastActionInMs).toLocaleString()
            }),
            hourDiffSinceLastAction ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                        children: [
                            t('Your average per hour'),
                            ":"
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                        bold: true,
                        children: t('CAKE per hour: %amount%', {
                            amount: earnedCakePerHour.toFixed(2)
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                        bold: true,
                        children: t('per hour: ~$%amount%', {
                            amount: earnedUsdPerHour.toFixed(2)
                        })
                    })
                ]
            }) : null,
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                children: [
                    t('At this rate, you would earn'),
                    ":"
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                bold: true,
                children: t('per 1d: ~$%amount%', {
                    amount: roiDay.toFixed(2)
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                bold: true,
                children: t('per 7d: ~$%amount%', {
                    amount: roiWeek.toFixed(2)
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                bold: true,
                children: t('per 30d: ~$%amount%', {
                    amount: roiMonth.toFixed(2)
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                bold: true,
                children: t('per 365d: ~$%amount%', {
                    amount: roiYear.toFixed(2)
                })
            })
        ]
    }), {
        placement: 'bottom'
    });
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledCell, {
        role: "cell",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_BaseCell__WEBPACK_IMPORTED_MODULE_11__/* .CellContent */ .J, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                    fontSize: "12px",
                    color: "textSubtle",
                    textAlign: "left",
                    children: labelText
                }),
                userDataLoading && account ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Skeleton, {
                    width: "80px",
                    height: "16px"
                }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: [
                        tooltipVisible && tooltip,
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Box, {
                                    mr: "8px",
                                    height: "32px",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                            mt: "4px",
                                            bold: !isMobile,
                                            fontSize: isMobile ? '14px' : '16px',
                                            color: hasEarnings ? 'primary' : 'textDisabled',
                                            decimals: hasEarnings ? 5 : 1,
                                            value: hasEarnings ? earningTokenBalance : 0
                                        }),
                                        hasEarnings ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                            children: earningTokenPrice > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                display: "inline",
                                                fontSize: "12px",
                                                color: "textSubtle",
                                                decimals: 2,
                                                prefix: "~",
                                                value: earningTokenDollarBalance,
                                                unit: " USD"
                                            })
                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                            mt: "4px",
                                            fontSize: "12px",
                                            color: "textDisabled",
                                            children: "0 USD"
                                        })
                                    ]
                                }),
                                hasEarnings && !isMobile && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(HelpIconWrapper, {
                                    ref: targetRef,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.HelpIcon, {
                                        color: "textSubtle"
                                    })
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AutoEarningsCell);

});

/***/ }),

/***/ 70709:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "J": () => (/* binding */ CellContent),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);


const BaseCell = styled_components__WEBPACK_IMPORTED_MODULE_1___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_0__.Flex).withConfig({
    componentId: "sc-2af072c6-0"
})`
  color: black;

  padding: 24px 8px;

  flex-direction: column;
  justify-content: flex-start;
`;
const CellContent = styled_components__WEBPACK_IMPORTED_MODULE_1___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_0__.Flex).withConfig({
    componentId: "sc-2af072c6-1"
})`
  flex-direction: column;
  justify-content: center;
  max-height: 40px;
  ${_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_0__.Text} {
    line-height: 1;
  }
`;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BaseCell);


/***/ }),

/***/ 81286:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(34215);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(bignumber_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var config_constants_types__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(97971);
/* harmony import */ var utils_bigNumber__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(35128);
/* harmony import */ var utils_formatBalance__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(65044);
/* harmony import */ var components_Balance__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(20922);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(99150);
/* harmony import */ var _BaseCell__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(70709);
/* harmony import */ var _PoolCard_Modals_CollectModal__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(73068);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_PoolCard_Modals_CollectModal__WEBPACK_IMPORTED_MODULE_11__]);
_PoolCard_Modals_CollectModal__WEBPACK_IMPORTED_MODULE_11__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];












const StyledCell = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_BaseCell__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z).withConfig({
    componentId: "sc-464cdba1-0"
})`
  flex: 4.5;
  ${({ theme  })=>theme.mediaQueries.sm
} {
    flex: 1 0 120px;
  }
`;
const EarningsCell = ({ pool , account , userDataLoaded  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_9__/* .useTranslation */ .$G)();
    const { isMobile  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.useMatchBreakpoints)();
    const { sousId , earningToken , poolCategory , userData , earningTokenPrice  } = pool;
    const isManualCakePool = sousId === 0;
    const earnings = userData?.pendingReward ? new (bignumber_js__WEBPACK_IMPORTED_MODULE_4___default())(userData.pendingReward) : utils_bigNumber__WEBPACK_IMPORTED_MODULE_6__/* .BIG_ZERO */ .HW;
    const earningTokenBalance = (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_7__/* .getBalanceNumber */ .mW)(earnings, earningToken.decimals);
    const earningTokenDollarBalance = (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_7__/* .getBalanceNumber */ .mW)(earnings.multipliedBy(earningTokenPrice), earningToken.decimals);
    const hasEarnings = account && earnings.gt(0);
    const fullBalance = (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_7__/* .getFullDisplayBalance */ .NJ)(earnings, earningToken.decimals);
    const formattedBalance = (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_7__/* .formatNumber */ .uf)(earningTokenBalance, 3, 3);
    const isBnbPool = poolCategory === config_constants_types__WEBPACK_IMPORTED_MODULE_5__/* .PoolCategory.BINANCE */ .jh.BINANCE;
    const labelText = t('%asset% Earned', {
        asset: earningToken.symbol
    });
    const [onPresentCollect] = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.useModal)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PoolCard_Modals_CollectModal__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
        formattedBalance: formattedBalance,
        fullBalance: fullBalance,
        earningToken: earningToken,
        earningsDollarValue: earningTokenDollarBalance,
        sousId: sousId,
        isBnbPool: isBnbPool,
        isCompoundPool: isManualCakePool
    }));
    const handleEarningsClick = (event)=>{
        event.stopPropagation();
        onPresentCollect();
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledCell, {
        role: "cell",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_BaseCell__WEBPACK_IMPORTED_MODULE_10__/* .CellContent */ .J, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                    fontSize: "12px",
                    color: "textSubtle",
                    textAlign: "left",
                    children: labelText
                }),
                !userDataLoaded && account ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Skeleton, {
                    width: "80px",
                    height: "16px"
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Box, {
                            mr: "8px",
                            height: "32px",
                            onClick: hasEarnings ? handleEarningsClick : undefined,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                    mt: "4px",
                                    bold: !isMobile,
                                    fontSize: isMobile ? '14px' : '16px',
                                    color: hasEarnings ? 'primary' : 'textDisabled',
                                    decimals: hasEarnings ? 5 : 1,
                                    value: hasEarnings ? earningTokenBalance : 0
                                }),
                                hasEarnings ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: earningTokenPrice > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                        display: "inline",
                                        fontSize: "12px",
                                        color: "textSubtle",
                                        decimals: 2,
                                        prefix: "~",
                                        value: earningTokenDollarBalance,
                                        unit: " USD"
                                    })
                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                    mt: "4px",
                                    fontSize: "12px",
                                    color: "textDisabled",
                                    children: "0 USD"
                                })
                            ]
                        })
                    })
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EarningsCell);

});

/***/ }),

/***/ 67306:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(38328);
/* harmony import */ var state_block_hooks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(37063);
/* harmony import */ var components_Balance__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(20922);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(99150);
/* harmony import */ var views_Pools_helpers__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(53136);
/* harmony import */ var _BaseCell__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(70709);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([state_block_hooks__WEBPACK_IMPORTED_MODULE_5__]);
state_block_hooks__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];










const StyledCell = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_BaseCell__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z).withConfig({
    componentId: "sc-eb7f8d89-0"
})`
  flex: 2 0 100px;
`;
const EndsInCell = ({ pool  })=>{
    const { sousId , totalStaked , startBlock , endBlock , isFinished  } = pool;
    const currentBlock = (0,state_block_hooks__WEBPACK_IMPORTED_MODULE_5__/* .useCurrentBlock */ .je)();
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_7__/* .useTranslation */ .$G)();
    const { shouldShowBlockCountdown , blocksUntilStart , blocksRemaining , hasPoolStarted , blocksToDisplay  } = (0,views_Pools_helpers__WEBPACK_IMPORTED_MODULE_8__/* .getPoolBlockInfo */ .zy)(pool, currentBlock);
    const isCakePool = sousId === 0;
    const renderBlocks = shouldShowBlockCountdown ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
        alignItems: "center",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                flex: "1.3",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                        fontSize: "16px",
                        value: blocksToDisplay,
                        decimals: 0
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                        ml: "4px",
                        textTransform: "lowercase",
                        children: t('Blocks')
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                flex: "1",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Link, {
                    external: true,
                    href: (0,utils__WEBPACK_IMPORTED_MODULE_4__/* .getBscScanLink */ .s6)(hasPoolStarted ? endBlock : startBlock, 'countdown'),
                    onClick: (e)=>e.stopPropagation()
                    ,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.TimerIcon, {
                        ml: "4px"
                    })
                })
            })
        ]
    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
        children: "-"
    });
    // A bit hacky way to determine if public data is loading relying on totalStaked
    // Opted to go for this since we don't really need a separate publicDataLoaded flag
    // anywhere else
    const isLoadingBlockData = !currentBlock || !blocksRemaining && !blocksUntilStart;
    const isLoadingPublicData = hasPoolStarted ? !totalStaked.gt(0) || isLoadingBlockData : isLoadingBlockData;
    const showLoading = isLoadingPublicData && !isCakePool && !isFinished;
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledCell, {
        role: "cell",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_BaseCell__WEBPACK_IMPORTED_MODULE_9__/* .CellContent */ .J, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                    fontSize: "12px",
                    color: "textSubtle",
                    textAlign: "left",
                    children: hasPoolStarted || !shouldShowBlockCountdown ? t('Ends in') : t('Starts in')
                }),
                showLoading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Skeleton, {
                    width: "80px",
                    height: "16px"
                }) : renderBlocks
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EndsInCell);

});

/***/ }),

/***/ 52079:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99150);
/* harmony import */ var _BaseCell__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(70709);






const StyledCell = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_BaseCell__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z).withConfig({
    componentId: "sc-5cfd99ac-0"
})`
  flex-direction: row;
  justify-content: flex-end;
  align-items: center;
  flex: 1;
  padding-right: 12px;
  padding-left: 0px;
  ${({ theme  })=>theme.mediaQueries.md
} {
    flex: 0 0 120px;
    padding-right: 32px;
    padding-left: 8px;
  }
`;
const ArrowIcon = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.ChevronDownIcon).withConfig({
    componentId: "sc-5cfd99ac-1"
})`
  transform: ${({ toggled  })=>toggled ? 'rotate(180deg)' : 'rotate(0)'
};
  height: 24px;
`;
const TotalStakedCell = ({ expanded , isFullLayout  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(StyledCell, {
        role: "cell",
        children: [
            isFullLayout && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                color: "primary",
                bold: true,
                children: expanded ? t('Hide') : t('Details')
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ArrowIcon, {
                color: "primary",
                toggled: expanded
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TotalStakedCell);


/***/ }),

/***/ 9785:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_Balance__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(20922);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(99150);
/* harmony import */ var hooks_useBUSDPrice__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(90834);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var state_types__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(45101);
/* harmony import */ var state_pools_hooks__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1624);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var utils_formatBalance__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(65044);
/* harmony import */ var _BaseCell__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(70709);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks_useBUSDPrice__WEBPACK_IMPORTED_MODULE_4__, state_pools_hooks__WEBPACK_IMPORTED_MODULE_7__]);
([hooks_useBUSDPrice__WEBPACK_IMPORTED_MODULE_4__, state_pools_hooks__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);











const StyledCell = styled_components__WEBPACK_IMPORTED_MODULE_8___default()(_BaseCell__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z).withConfig({
    componentId: "sc-3bac1c65-0"
})`
  flex: 4.5;
  ${({ theme  })=>theme.mediaQueries.sm
} {
    flex: 1 0 120px;
  }
  ${({ theme  })=>theme.mediaQueries.lg
} {
    flex: 2 0 100px;
  }
`;
const HelpIconWrapper = styled_components__WEBPACK_IMPORTED_MODULE_8___default().div.withConfig({
    componentId: "sc-3bac1c65-1"
})`
  align-self: center;
`;
const IFOCreditCell = ({ account  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_3__/* .useTranslation */ .$G)();
    const { isMobile  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.useMatchBreakpoints)();
    const { userData: { isLoading: userDataLoading  } ,  } = (0,state_pools_hooks__WEBPACK_IMPORTED_MODULE_7__/* .useVaultPoolByKey */ .eB)(state_types__WEBPACK_IMPORTED_MODULE_6__/* .VaultKey.IfoPool */ .om.IfoPool);
    const credit = (0,state_pools_hooks__WEBPACK_IMPORTED_MODULE_7__/* .useIfoPoolCredit */ .Eo)();
    const hasCredit = credit.gt(0);
    const cakeAsNumberBalance = (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_9__/* .getBalanceNumber */ .mW)(credit);
    const avgBalanceDollarValue = (0,hooks_useBUSDPrice__WEBPACK_IMPORTED_MODULE_4__/* .useBUSDCakeAmount */ .Tx)(cakeAsNumberBalance);
    const labelText = t('IFO Credit');
    const { targetRef , tooltip , tooltipVisible  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.useTooltip)(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Text, {
                children: t('Your entry limit in the next IFO sale is determined by your IFO credit. This is calculated by the average CAKE balance of the principal amount in the IFO pool during the last credit calculation period.')
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Text, {
                children: t('Please note: even the pool is auto compounding. Amount of profits will not be included during IFO credit calculations.')
            })
        ]
    }), {
        placement: 'bottom'
    });
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledCell, {
        role: "cell",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_BaseCell__WEBPACK_IMPORTED_MODULE_10__/* .CellContent */ .J, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Text, {
                    fontSize: "12px",
                    color: "textSubtle",
                    textAlign: "left",
                    children: labelText
                }),
                userDataLoading && account ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Skeleton, {
                    width: "80px",
                    height: "16px"
                }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: [
                        tooltipVisible && tooltip,
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                    mr: "8px",
                                    height: "32px",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            mt: "4px",
                                            bold: !isMobile,
                                            fontSize: isMobile ? '14px' : '16px',
                                            color: hasCredit ? 'primary' : 'textDisabled',
                                            decimals: hasCredit ? 5 : 1,
                                            value: hasCredit ? cakeAsNumberBalance : 0
                                        }),
                                        hasCredit ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            display: "inline",
                                            fontSize: "12px",
                                            color: "textSubtle",
                                            decimals: 2,
                                            prefix: "~",
                                            value: avgBalanceDollarValue || 0,
                                            unit: " USD"
                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                            mt: "4px",
                                            fontSize: "12px",
                                            color: "textDisabled",
                                            children: "0 USD"
                                        })
                                    ]
                                }),
                                hasCredit && !isMobile && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(HelpIconWrapper, {
                                    ref: targetRef,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.HelpIcon, {
                                        color: "textSubtle"
                                    })
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (IFOCreditCell);

});

/***/ }),

/***/ 14405:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(34215);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(bignumber_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(99150);
/* harmony import */ var state_pools_hooks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1624);
/* harmony import */ var utils_bigNumber__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(35128);
/* harmony import */ var config_constants_pools__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(71080);
/* harmony import */ var components_TokenImage__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(95239);
/* harmony import */ var _BaseCell__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(70709);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([state_pools_hooks__WEBPACK_IMPORTED_MODULE_6__]);
state_pools_hooks__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];











const StyledCell = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_BaseCell__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z).withConfig({
    componentId: "sc-ec896873-0"
})`
  flex: 5;
  flex-direction: row;
  padding-left: 12px;
  ${({ theme  })=>theme.mediaQueries.sm
} {
    flex: 1 0 150px;
    padding-left: 32px;
  }
`;
const NameCell = ({ pool  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_5__/* .useTranslation */ .$G)();
    const { isMobile  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.useMatchBreakpoints)();
    const { sousId , stakingToken , earningToken , userData , isFinished , vaultKey  } = pool;
    const { userData: { userShares  } ,  } = (0,state_pools_hooks__WEBPACK_IMPORTED_MODULE_6__/* .useVaultPoolByKey */ .eB)(pool.vaultKey);
    const hasVaultShares = userShares && userShares.gt(0);
    const stakingTokenSymbol = stakingToken.symbol;
    const earningTokenSymbol = earningToken.symbol;
    const stakedBalance = userData?.stakedBalance ? new (bignumber_js__WEBPACK_IMPORTED_MODULE_3___default())(userData.stakedBalance) : utils_bigNumber__WEBPACK_IMPORTED_MODULE_7__/* .BIG_ZERO */ .HW;
    const isStaked = stakedBalance.gt(0);
    const isManualCakePool = sousId === 0;
    const showStakedTag = vaultKey ? hasVaultShares : isStaked;
    let title = `${t('Earn')} ${earningTokenSymbol}`;
    let subtitle = `${t('Stake')} ${stakingTokenSymbol}`;
    const showSubtitle = sousId !== 0 || sousId === 0 && !isMobile;
    if (vaultKey) {
        title = t(config_constants_pools__WEBPACK_IMPORTED_MODULE_8__/* .vaultPoolConfig */ .Y[vaultKey].name);
        subtitle = t(config_constants_pools__WEBPACK_IMPORTED_MODULE_8__/* .vaultPoolConfig */ .Y[vaultKey].description);
    } else if (isManualCakePool) {
        title = t('Manual CAKE');
        subtitle = `${t('Earn')} CAKE ${t('Stake').toLocaleLowerCase()} CAKE`;
    }
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(StyledCell, {
        role: "cell",
        children: [
            vaultKey ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.TokenPairImage, {
                ...config_constants_pools__WEBPACK_IMPORTED_MODULE_8__/* .vaultPoolConfig */ .Y[vaultKey].tokenImage,
                mr: "8px",
                width: 40,
                height: 40
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_TokenImage__WEBPACK_IMPORTED_MODULE_9__/* .TokenPairImage */ .q, {
                primaryToken: earningToken,
                secondaryToken: stakingToken,
                mr: "8px",
                width: 40,
                height: 40
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_BaseCell__WEBPACK_IMPORTED_MODULE_10__/* .CellContent */ .J, {
                children: [
                    showStakedTag && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                        fontSize: "12px",
                        bold: true,
                        color: isFinished ? 'failure' : 'secondary',
                        textTransform: "uppercase",
                        children: t('Staked')
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                        bold: !isMobile,
                        small: isMobile,
                        children: title
                    }),
                    showSubtitle && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                        fontSize: "12px",
                        color: "textSubtle",
                        children: subtitle
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NameCell);

});

/***/ }),

/***/ 37431:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(34215);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(bignumber_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var components_Balance__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(20922);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99150);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var state_pools_hooks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1624);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var utils_bigNumber__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(35128);
/* harmony import */ var utils_formatBalance__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(65044);
/* harmony import */ var views_Pools_helpers__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(53136);
/* harmony import */ var _BaseCell__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(70709);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([state_pools_hooks__WEBPACK_IMPORTED_MODULE_6__]);
state_pools_hooks__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];












const StyledCell = styled_components__WEBPACK_IMPORTED_MODULE_7___default()(_BaseCell__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z).withConfig({
    componentId: "sc-db8d4125-0"
})`
  flex: 2 0 100px;
`;
const StakedCell = ({ pool , account , userDataLoaded  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    const { isMobile  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.useMatchBreakpoints)();
    // vault
    const { userData: { isLoading: vaultUserDataLoading , userShares  } , pricePerFullShare ,  } = (0,state_pools_hooks__WEBPACK_IMPORTED_MODULE_6__/* .useVaultPoolByKey */ .eB)(pool.vaultKey);
    const hasSharesStaked = userShares && userShares.gt(0);
    const isVaultWithShares = pool.vaultKey && hasSharesStaked;
    const { cakeAsBigNumber , cakeAsNumberBalance  } = (0,views_Pools_helpers__WEBPACK_IMPORTED_MODULE_10__/* .convertSharesToCake */ .ur)(userShares, pricePerFullShare);
    // pool
    const { stakingTokenPrice , stakingToken , userData  } = pool;
    const stakedAutoDollarValue = (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_9__/* .getBalanceNumber */ .mW)(cakeAsBigNumber.multipliedBy(stakingTokenPrice), stakingToken.decimals);
    const stakedBalance = userData?.stakedBalance ? new (bignumber_js__WEBPACK_IMPORTED_MODULE_2___default())(userData.stakedBalance) : utils_bigNumber__WEBPACK_IMPORTED_MODULE_8__/* .BIG_ZERO */ .HW;
    const stakedTokenBalance = (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_9__/* .getBalanceNumber */ .mW)(stakedBalance, stakingToken.decimals);
    const stakedTokenDollarBalance = (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_9__/* .getBalanceNumber */ .mW)(stakedBalance.multipliedBy(stakingTokenPrice), stakingToken.decimals);
    const labelText = `${pool.stakingToken.symbol} ${t('Staked')}`;
    const hasStaked = stakedBalance.gt(0) || isVaultWithShares;
    const userDataLoading = pool.vaultKey ? vaultUserDataLoading : !userDataLoaded;
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledCell, {
        role: "cell",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_BaseCell__WEBPACK_IMPORTED_MODULE_11__/* .CellContent */ .J, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Text, {
                    fontSize: "12px",
                    color: "textSubtle",
                    textAlign: "left",
                    children: labelText
                }),
                userDataLoading && account ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Skeleton, {
                    width: "80px",
                    height: "16px"
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Box, {
                            mr: "8px",
                            height: "32px",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                    mt: "4px",
                                    bold: !isMobile,
                                    fontSize: isMobile ? '14px' : '16px',
                                    color: hasStaked ? 'primary' : 'textDisabled',
                                    decimals: hasStaked ? 5 : 1,
                                    value: pool.vaultKey ? Number.isNaN(cakeAsNumberBalance) ? 0 : cakeAsNumberBalance : stakedTokenBalance
                                }),
                                hasStaked ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                    display: "inline",
                                    fontSize: "12px",
                                    color: "textSubtle",
                                    decimals: 2,
                                    prefix: "~",
                                    value: pool.vaultKey ? stakedAutoDollarValue : stakedTokenDollarBalance,
                                    unit: " USD"
                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                    mt: "4px",
                                    fontSize: "12px",
                                    color: "textDisabled",
                                    children: "0 USD"
                                })
                            ]
                        })
                    })
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (StakedCell);

});

/***/ }),

/***/ 66804:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99150);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(34215);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(bignumber_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var components_Balance__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(20922);
/* harmony import */ var state_pools_hooks__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1624);
/* harmony import */ var utils_formatBalance__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(65044);
/* harmony import */ var utils_bigNumber__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(35128);
/* harmony import */ var _BaseCell__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(70709);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([state_pools_hooks__WEBPACK_IMPORTED_MODULE_7__]);
state_pools_hooks__WEBPACK_IMPORTED_MODULE_7__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];











const StyledCell = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(_BaseCell__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z).withConfig({
    componentId: "sc-9fe68392-0"
})`
  flex: 2 0 100px;
`;
const TotalStakedCell = ({ pool  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    const { sousId , stakingToken , totalStaked , vaultKey  } = pool;
    const { totalCakeInVault  } = (0,state_pools_hooks__WEBPACK_IMPORTED_MODULE_7__/* .useVaultPoolByKey */ .eB)(vaultKey);
    const vaultPools = (0,state_pools_hooks__WEBPACK_IMPORTED_MODULE_7__/* .useVaultPools */ .KV)();
    const cakeInVaults = Object.values(vaultPools).reduce((total, vault)=>{
        return total.plus(vault.totalCakeInVault);
    }, utils_bigNumber__WEBPACK_IMPORTED_MODULE_9__/* .BIG_ZERO */ .HW);
    const isManualCakePool = sousId === 0;
    const totalStakedBalance = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        if (vaultKey) {
            return (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_8__/* .getBalanceNumber */ .mW)(totalCakeInVault, stakingToken.decimals);
        }
        if (isManualCakePool) {
            const manualCakeTotalMinusAutoVault = new (bignumber_js__WEBPACK_IMPORTED_MODULE_5___default())(totalStaked).minus(cakeInVaults);
            return (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_8__/* .getBalanceNumber */ .mW)(manualCakeTotalMinusAutoVault, stakingToken.decimals);
        }
        return (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_8__/* .getBalanceNumber */ .mW)(totalStaked, stakingToken.decimals);
    }, [
        vaultKey,
        totalCakeInVault,
        isManualCakePool,
        totalStaked,
        stakingToken.decimals,
        cakeInVaults
    ]);
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledCell, {
        role: "cell",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_BaseCell__WEBPACK_IMPORTED_MODULE_10__/* .CellContent */ .J, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                    fontSize: "12px",
                    color: "textSubtle",
                    textAlign: "left",
                    children: t('Total staked')
                }),
                totalStaked && totalStaked.gte(0) ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                    height: "20px",
                    alignItems: "center",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Balance__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                        fontSize: "16px",
                        value: totalStakedBalance,
                        decimals: 0,
                        unit: ` ${stakingToken.symbol}`
                    })
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Skeleton, {
                    width: "80px",
                    height: "16px"
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TotalStakedCell);

});

/***/ }),

/***/ 13670:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var state_types__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(45101);
/* harmony import */ var hooks_useDelayedUnmount__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(30798);
/* harmony import */ var _Cells_NameCell__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(14405);
/* harmony import */ var _Cells_EarningsCell__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(81286);
/* harmony import */ var _Cells_IFOCreditCell__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9785);
/* harmony import */ var _Cells_AprCell__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(81401);
/* harmony import */ var _Cells_TotalStakedCell__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(66804);
/* harmony import */ var _Cells_EndsInCell__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(67306);
/* harmony import */ var _Cells_ExpandActionCell__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(52079);
/* harmony import */ var _ActionPanel_ActionPanel__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(6154);
/* harmony import */ var _Cells_AutoEarningsCell__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(39442);
/* harmony import */ var _Cells_AutoAprCell__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(64030);
/* harmony import */ var _Cells_StakedCell__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(37431);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_ActionPanel_ActionPanel__WEBPACK_IMPORTED_MODULE_13__, _Cells_EndsInCell__WEBPACK_IMPORTED_MODULE_11__, _Cells_TotalStakedCell__WEBPACK_IMPORTED_MODULE_10__, _Cells_AutoAprCell__WEBPACK_IMPORTED_MODULE_15__, _Cells_StakedCell__WEBPACK_IMPORTED_MODULE_16__, _Cells_IFOCreditCell__WEBPACK_IMPORTED_MODULE_8__, _Cells_EarningsCell__WEBPACK_IMPORTED_MODULE_7__, _Cells_AutoEarningsCell__WEBPACK_IMPORTED_MODULE_14__, _Cells_NameCell__WEBPACK_IMPORTED_MODULE_6__]);
([_ActionPanel_ActionPanel__WEBPACK_IMPORTED_MODULE_13__, _Cells_EndsInCell__WEBPACK_IMPORTED_MODULE_11__, _Cells_TotalStakedCell__WEBPACK_IMPORTED_MODULE_10__, _Cells_AutoAprCell__WEBPACK_IMPORTED_MODULE_15__, _Cells_StakedCell__WEBPACK_IMPORTED_MODULE_16__, _Cells_IFOCreditCell__WEBPACK_IMPORTED_MODULE_8__, _Cells_EarningsCell__WEBPACK_IMPORTED_MODULE_7__, _Cells_AutoEarningsCell__WEBPACK_IMPORTED_MODULE_14__, _Cells_NameCell__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);

















const StyledRow = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-2dcab32a-0"
})`
  background-color: transparent;
  display: flex;
  cursor: pointer;
`;
const PoolRow = ({ pool , account , userDataLoaded  })=>{
    const { isXs , isSm , isMd , isLg , isXl , isXxl , isTablet , isDesktop  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.useMatchBreakpoints)();
    const isLargerScreen = isLg || isXl || isXxl;
    const isXLargerScreen = isXl || isXxl;
    const { 0: expanded , 1: setExpanded  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const shouldRenderActionPanel = (0,hooks_useDelayedUnmount__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)(expanded, 300);
    const toggleExpanded = ()=>{
        setExpanded((prev)=>!prev
        );
    };
    const isCakePool = pool.sousId === 0;
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(StyledRow, {
                role: "row",
                onClick: toggleExpanded,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Cells_NameCell__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                        pool: pool
                    }),
                    pool.vaultKey ? (isXLargerScreen && pool.vaultKey === state_types__WEBPACK_IMPORTED_MODULE_4__/* .VaultKey.IfoPool */ .om.IfoPool || pool.vaultKey === state_types__WEBPACK_IMPORTED_MODULE_4__/* .VaultKey.CakeVault */ .om.CakeVault) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Cells_AutoEarningsCell__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                        pool: pool,
                        account: account
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Cells_EarningsCell__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        pool: pool,
                        account: account,
                        userDataLoaded: userDataLoaded
                    }),
                    pool.vaultKey === state_types__WEBPACK_IMPORTED_MODULE_4__/* .VaultKey.IfoPool */ .om.IfoPool ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Cells_IFOCreditCell__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                        account: account
                    }) : isXLargerScreen && isCakePool ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Cells_StakedCell__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                        pool: pool,
                        account: account,
                        userDataLoaded: userDataLoaded
                    }) : null,
                    isLargerScreen && !isCakePool && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Cells_TotalStakedCell__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                        pool: pool
                    }),
                    pool.vaultKey ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Cells_AutoAprCell__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                        pool: pool
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Cells_AprCell__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                        pool: pool
                    }),
                    isLargerScreen && isCakePool && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Cells_TotalStakedCell__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                        pool: pool
                    }),
                    isDesktop && !isCakePool && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Cells_EndsInCell__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                        pool: pool
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Cells_ExpandActionCell__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                        expanded: expanded,
                        isFullLayout: isTablet || isDesktop
                    })
                ]
            }),
            shouldRenderActionPanel && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ActionPanel_ActionPanel__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                account: account,
                pool: pool,
                userDataLoaded: userDataLoaded,
                expanded: expanded,
                breakpoints: {
                    isXs,
                    isSm,
                    isMd,
                    isLg,
                    isXl,
                    isXxl
                }
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PoolRow);

});

/***/ }),

/***/ 36547:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99150);
/* harmony import */ var _PoolRow__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(13670);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_PoolRow__WEBPACK_IMPORTED_MODULE_5__]);
_PoolRow__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];






const StyledTable = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-af2ac366-0"
})`
  border-radius: ${({ theme  })=>theme.radii.card
};
  scroll-margin-top: 64px;

  background-color: ${({ theme  })=>theme.card.background
};
  > div:not(:last-child) {
    border-bottom: 2px solid ${({ theme  })=>theme.colors.disabled
};
  }
`;
const StyledTableBorder = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-af2ac366-1"
})`
  border-radius: ${({ theme  })=>theme.radii.card
};
  background-color: ${({ theme  })=>theme.colors.cardBorder
};
  padding: 1px 1px 3px 1px;
  background-size: 400% 400%;
`;
const ScrollButtonContainer = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-af2ac366-2"
})`
  display: flex;
  justify-content: center;
  padding-top: 5px;
  padding-bottom: 5px;
`;
const PoolsTable = ({ pools , userDataLoaded , account  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    const tableWrapperEl = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const scrollToTop = ()=>{
        tableWrapperEl.current.scrollIntoView({
            behavior: 'smooth'
        });
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledTableBorder, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(StyledTable, {
            id: "pools-table",
            role: "table",
            ref: tableWrapperEl,
            children: [
                pools.map((pool)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PoolRow__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        pool: pool,
                        account: account,
                        userDataLoaded: userDataLoaded
                    }, pool.vaultKey ?? pool.sousId)
                ),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ScrollButtonContainer, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Button, {
                        variant: "text",
                        onClick: scrollToTop,
                        children: [
                            t('To Top'),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.ChevronUpIcon, {
                                color: "primary"
                            })
                        ]
                    })
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PoolsTable);

});

/***/ }),

/***/ 81291:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var state__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(82727);
/* harmony import */ var state_actions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(89969);
/* harmony import */ var utils_calls__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(50059);
/* harmony import */ var utils_bigNumber__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(35128);
/* harmony import */ var utils_getGasPrice__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(76582);
/* harmony import */ var hooks_useContract__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(46063);
/* harmony import */ var config__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(33206);









const options = {
    gasLimit: config__WEBPACK_IMPORTED_MODULE_8__/* .DEFAULT_GAS_LIMIT */ .QL
};
const harvestPool = async (sousChefContract)=>{
    const gasPrice = (0,utils_getGasPrice__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)();
    return sousChefContract.deposit('0', {
        ...options,
        gasPrice
    });
};
const harvestPoolBnb = async (sousChefContract)=>{
    const gasPrice = (0,utils_getGasPrice__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)();
    return sousChefContract.deposit({
        ...options,
        value: utils_bigNumber__WEBPACK_IMPORTED_MODULE_5__/* .BIG_ZERO */ .HW,
        gasPrice
    });
};
const useHarvestPool = (sousId, isUsingBnb = false)=>{
    const dispatch = (0,state__WEBPACK_IMPORTED_MODULE_2__/* .useAppDispatch */ .TL)();
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_1__.useWeb3React)();
    const sousChefContract = (0,hooks_useContract__WEBPACK_IMPORTED_MODULE_7__/* .useSousChef */ .AP)(sousId);
    const masterChefContract = (0,hooks_useContract__WEBPACK_IMPORTED_MODULE_7__/* .useMasterchef */ .y8)();
    const handleHarvest = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async (onTransactionSubmitted, onSuccess, onError)=>{
        let tx;
        if (sousId === 0) {
            tx = await (0,utils_calls__WEBPACK_IMPORTED_MODULE_4__/* .harvestFarm */ .sA)(masterChefContract, 0);
        } else if (isUsingBnb) {
            tx = await harvestPoolBnb(sousChefContract);
        } else {
            tx = await harvestPool(sousChefContract);
        }
        onTransactionSubmitted(tx);
        const receipt = await tx.wait();
        if (receipt.status) {
            onSuccess(receipt);
            dispatch((0,state_actions__WEBPACK_IMPORTED_MODULE_3__/* .updateUserPendingReward */ .J4)(sousId, account));
            dispatch((0,state_actions__WEBPACK_IMPORTED_MODULE_3__/* .updateUserBalance */ .yi)(sousId, account));
        } else {
            onError(receipt);
        }
    }, [
        account,
        dispatch,
        isUsingBnb,
        masterChefContract,
        sousChefContract,
        sousId
    ]);
    return {
        onReward: handleHarvest
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useHarvestPool);


/***/ }),

/***/ 37023:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(65757);
/* harmony import */ var _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _ethersproject_units__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(93138);
/* harmony import */ var _ethersproject_units__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_units__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(34215);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(bignumber_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(18054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(49949);
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(lodash_orderBy__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var lodash_partition__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(32027);
/* harmony import */ var lodash_partition__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(lodash_partition__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(99150);
/* harmony import */ var hooks_useIntersectionObserver__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(76538);
/* harmony import */ var state_pools_hooks__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1624);
/* harmony import */ var utils_latinise__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(11438);
/* harmony import */ var components_Layout_Flex__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(40508);
/* harmony import */ var components_Layout_Page__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(9770);
/* harmony import */ var components_PageHeader__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(44482);
/* harmony import */ var components_SearchInput__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(14450);
/* harmony import */ var components_Select_Select__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(37370);
/* harmony import */ var state_user_hooks__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(68605);
/* harmony import */ var views_Home_hooks_useGetTopPoolsByApr__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(81587);
/* harmony import */ var state_user_actions__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(46245);
/* harmony import */ var utils_bigNumber__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(35128);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var components_Loading__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(8080);
/* harmony import */ var _components_PoolCard__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(71603);
/* harmony import */ var _components_CakeVaultCard__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(70061);
/* harmony import */ var _components_PoolTabButtons__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(26361);
/* harmony import */ var _components_BountyCard__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(27935);
/* harmony import */ var _components_HelpButton__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(56310);
/* harmony import */ var _components_PoolsTable_PoolsTable__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(36547);
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(53136);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([components_Layout_Page__WEBPACK_IMPORTED_MODULE_15__, _components_BountyCard__WEBPACK_IMPORTED_MODULE_28__, _components_PoolsTable_PoolsTable__WEBPACK_IMPORTED_MODULE_30__, _components_PoolCard__WEBPACK_IMPORTED_MODULE_25__, _components_CakeVaultCard__WEBPACK_IMPORTED_MODULE_26__, state_pools_hooks__WEBPACK_IMPORTED_MODULE_12__, views_Home_hooks_useGetTopPoolsByApr__WEBPACK_IMPORTED_MODULE_20__, state_user_hooks__WEBPACK_IMPORTED_MODULE_19__]);
([components_Layout_Page__WEBPACK_IMPORTED_MODULE_15__, _components_BountyCard__WEBPACK_IMPORTED_MODULE_28__, _components_PoolsTable_PoolsTable__WEBPACK_IMPORTED_MODULE_30__, _components_PoolCard__WEBPACK_IMPORTED_MODULE_25__, _components_CakeVaultCard__WEBPACK_IMPORTED_MODULE_26__, state_pools_hooks__WEBPACK_IMPORTED_MODULE_12__, views_Home_hooks_useGetTopPoolsByApr__WEBPACK_IMPORTED_MODULE_20__, state_user_hooks__WEBPACK_IMPORTED_MODULE_19__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);
































const CardLayout = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(components_Layout_Flex__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z).withConfig({
    componentId: "sc-d0edfd0-0"
})`
  justify-content: center;
`;
const PoolControls = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-d0edfd0-1"
})`
  display: flex;
  width: 100%;
  align-items: center;
  position: relative;

  justify-content: space-between;
  flex-direction: column;
  margin-bottom: 32px;

  ${({ theme  })=>theme.mediaQueries.sm
} {
    flex-direction: row;
    flex-wrap: wrap;
    padding: 16px 32px;
    margin-bottom: 0;
  }
`;
const FilterContainer = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-d0edfd0-2"
})`
  display: flex;
  align-items: center;
  width: 100%;
  padding: 8px 0px;

  ${({ theme  })=>theme.mediaQueries.sm
} {
    width: auto;
    padding: 0;
  }
`;
const LabelWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-d0edfd0-3"
})`
  > ${_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_7__.Text} {
    font-size: 12px;
  }
`;
const ControlStretch = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_7__.Flex).withConfig({
    componentId: "sc-d0edfd0-4"
})`
  > div {
    flex: 1;
  }
`;
const NUMBER_OF_POOLS_VISIBLE = 12;
const Pools = ()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_23__.useRouter)();
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_10__/* .useTranslation */ .$G)();
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_6__.useWeb3React)();
    const { userDataLoaded  } = (0,state_pools_hooks__WEBPACK_IMPORTED_MODULE_12__/* .usePools */ .Oh)();
    const [stakedOnly, setStakedOnly] = (0,state_user_hooks__WEBPACK_IMPORTED_MODULE_19__/* .useUserPoolStakedOnly */ .tw)();
    const [viewMode, setViewMode] = (0,state_user_hooks__WEBPACK_IMPORTED_MODULE_19__/* .useUserPoolsViewMode */ .Yi)();
    const { 0: numberOfPoolsVisible , 1: setNumberOfPoolsVisible  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(NUMBER_OF_POOLS_VISIBLE);
    const { observerRef , isIntersecting  } = (0,hooks_useIntersectionObserver__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z)();
    const { 0: searchQuery , 1: setSearchQuery  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const { 0: sortOption , 1: setSortOption  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('hot');
    const chosenPoolsLength = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(0);
    const vaultPools = (0,state_pools_hooks__WEBPACK_IMPORTED_MODULE_12__/* .useVaultPools */ .KV)();
    const cakeInVaults = Object.values(vaultPools).reduce((total, vault)=>{
        return total.plus(vault.totalCakeInVault);
    }, utils_bigNumber__WEBPACK_IMPORTED_MODULE_22__/* .BIG_ZERO */ .HW);
    const pools = (0,views_Home_hooks_useGetTopPoolsByApr__WEBPACK_IMPORTED_MODULE_20__/* .usePoolsWithVault */ .f)();
    // TODO aren't arrays in dep array checked just by reference, i.e. it will rerender every time reference changes?
    const { 0: finishedPools , 1: openPools  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>lodash_partition__WEBPACK_IMPORTED_MODULE_9___default()(pools, (pool)=>pool.isFinished
        )
    , [
        pools
    ]);
    const stakedOnlyFinishedPools = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>finishedPools.filter((pool)=>{
            if (pool.vaultKey) {
                return vaultPools[pool.vaultKey].userData.userShares && vaultPools[pool.vaultKey].userData.userShares.gt(0);
            }
            return pool.userData && new (bignumber_js__WEBPACK_IMPORTED_MODULE_5___default())(pool.userData.stakedBalance).isGreaterThan(0);
        })
    , [
        finishedPools,
        vaultPools
    ]);
    const stakedOnlyOpenPools = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>openPools.filter((pool)=>{
            if (pool.vaultKey) {
                return vaultPools[pool.vaultKey].userData.userShares && vaultPools[pool.vaultKey].userData.userShares.gt(0);
            }
            return pool.userData && new (bignumber_js__WEBPACK_IMPORTED_MODULE_5___default())(pool.userData.stakedBalance).isGreaterThan(0);
        })
    , [
        openPools,
        vaultPools
    ]);
    const hasStakeInFinishedPools = stakedOnlyFinishedPools.length > 0;
    (0,state_pools_hooks__WEBPACK_IMPORTED_MODULE_12__/* .useFetchCakeVault */ .wx)();
    (0,state_pools_hooks__WEBPACK_IMPORTED_MODULE_12__/* .useFetchIfoPool */ .HV)(false);
    (0,state_pools_hooks__WEBPACK_IMPORTED_MODULE_12__/* .useFetchPublicPoolsData */ .DM)();
    (0,state_pools_hooks__WEBPACK_IMPORTED_MODULE_12__/* .useFetchUserPools */ .ad)(account);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (isIntersecting) {
            setNumberOfPoolsVisible((poolsCurrentlyVisible)=>{
                if (poolsCurrentlyVisible <= chosenPoolsLength.current) {
                    return poolsCurrentlyVisible + NUMBER_OF_POOLS_VISIBLE;
                }
                return poolsCurrentlyVisible;
            });
        }
    }, [
        isIntersecting
    ]);
    const showFinishedPools = router.pathname.includes('history');
    const handleChangeSearchQuery = (event)=>{
        setSearchQuery(event.target.value);
    };
    const handleSortOptionChange = (option)=>{
        setSortOption(option.value);
    };
    const sortPools = (poolsToSort)=>{
        switch(sortOption){
            case 'apr':
                // Ternary is needed to prevent pools without APR (like MIX) getting top spot
                return lodash_orderBy__WEBPACK_IMPORTED_MODULE_8___default()(poolsToSort, (pool)=>pool.apr ? pool.apr : 0
                , 'desc');
            case 'earned':
                return lodash_orderBy__WEBPACK_IMPORTED_MODULE_8___default()(poolsToSort, (pool)=>{
                    if (!pool.userData || !pool.earningTokenPrice) {
                        return 0;
                    }
                    return pool.vaultKey ? (0,_helpers__WEBPACK_IMPORTED_MODULE_31__/* .getCakeVaultEarnings */ .UN)(account, vaultPools[pool.vaultKey].userData.cakeAtLastUserAction, vaultPools[pool.vaultKey].userData.userShares, vaultPools[pool.vaultKey].pricePerFullShare, pool.earningTokenPrice).autoUsdToDisplay : pool.userData.pendingReward.times(pool.earningTokenPrice).toNumber();
                }, 'desc');
            case 'totalStaked':
                return lodash_orderBy__WEBPACK_IMPORTED_MODULE_8___default()(poolsToSort, (pool)=>{
                    let totalStaked = Number.NaN;
                    if (pool.vaultKey) {
                        if (pool.stakingTokenPrice && vaultPools[pool.vaultKey].totalCakeInVault.isFinite()) {
                            totalStaked = +(0,_ethersproject_units__WEBPACK_IMPORTED_MODULE_4__.formatUnits)(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_3__.BigNumber.from(vaultPools[pool.vaultKey].totalCakeInVault.toString()), pool.stakingToken.decimals) * pool.stakingTokenPrice;
                        }
                    } else if (pool.sousId === 0) {
                        if (pool.totalStaked?.isFinite() && pool.stakingTokenPrice && cakeInVaults.isFinite()) {
                            const manualCakeTotalMinusAutoVault = _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_3__.BigNumber.from(pool.totalStaked.toString()).sub(cakeInVaults.toString());
                            totalStaked = +(0,_ethersproject_units__WEBPACK_IMPORTED_MODULE_4__.formatUnits)(manualCakeTotalMinusAutoVault, pool.stakingToken.decimals) * pool.stakingTokenPrice;
                        }
                    } else if (pool.totalStaked?.isFinite() && pool.stakingTokenPrice) {
                        totalStaked = +(0,_ethersproject_units__WEBPACK_IMPORTED_MODULE_4__.formatUnits)(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_3__.BigNumber.from(pool.totalStaked.toString()), pool.stakingToken.decimals) * pool.stakingTokenPrice;
                    }
                    return Number.isFinite(totalStaked) ? totalStaked : 0;
                }, 'desc');
            default:
                return poolsToSort;
        }
    };
    let chosenPools;
    if (showFinishedPools) {
        chosenPools = stakedOnly ? stakedOnlyFinishedPools : finishedPools;
    } else {
        chosenPools = stakedOnly ? stakedOnlyOpenPools : openPools;
    }
    if (searchQuery) {
        const lowercaseQuery = (0,utils_latinise__WEBPACK_IMPORTED_MODULE_13__/* .latinise */ .b)(searchQuery.toLowerCase());
        chosenPools = chosenPools.filter((pool)=>(0,utils_latinise__WEBPACK_IMPORTED_MODULE_13__/* .latinise */ .b)(pool.earningToken.symbol.toLowerCase()).includes(lowercaseQuery)
        );
    }
    chosenPools = sortPools(chosenPools).slice(0, numberOfPoolsVisible);
    chosenPoolsLength.current = chosenPools.length;
    const cardLayout = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CardLayout, {
        children: chosenPools.map((pool)=>pool.vaultKey ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_CakeVaultCard__WEBPACK_IMPORTED_MODULE_26__/* ["default"] */ .Z, {
                pool: pool,
                showStakedOnly: stakedOnly
            }, pool.vaultKey) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_PoolCard__WEBPACK_IMPORTED_MODULE_25__/* ["default"] */ .Z, {
                pool: pool,
                account: account
            }, pool.sousId)
        )
    });
    const tableLayout = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_PoolsTable_PoolsTable__WEBPACK_IMPORTED_MODULE_30__/* ["default"] */ .Z, {
        pools: chosenPools,
        account: account,
        userDataLoaded: userDataLoaded
    });
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_PageHeader__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_7__.Flex, {
                    justifyContent: "space-between",
                    flexDirection: [
                        'column',
                        null,
                        null,
                        'row'
                    ],
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_7__.Flex, {
                            flex: "1",
                            flexDirection: "column",
                            mr: [
                                '8px',
                                0
                            ],
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_7__.Heading, {
                                    as: "h1",
                                    scale: "xxl",
                                    color: "secondary",
                                    mb: "24px",
                                    children: t('Syrup Pools')
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_7__.Heading, {
                                    scale: "md",
                                    color: "text",
                                    children: t('Just stake some tokens to earn.')
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_7__.Heading, {
                                    scale: "md",
                                    color: "text",
                                    children: t('High APR, low risk.')
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_7__.Flex, {
                            flex: "1",
                            height: "fit-content",
                            justifyContent: "center",
                            alignItems: "center",
                            mt: [
                                '24px',
                                null,
                                '0'
                            ],
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_HelpButton__WEBPACK_IMPORTED_MODULE_29__/* ["default"] */ .Z, {}),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_BountyCard__WEBPACK_IMPORTED_MODULE_28__/* ["default"] */ .Z, {})
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(components_Layout_Page__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(PoolControls, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_PoolTabButtons__WEBPACK_IMPORTED_MODULE_27__/* ["default"] */ .Z, {
                                stakedOnly: stakedOnly,
                                setStakedOnly: setStakedOnly,
                                hasStakeInFinishedPools: hasStakeInFinishedPools,
                                viewMode: viewMode,
                                setViewMode: setViewMode
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(FilterContainer, {
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(LabelWrapper, {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_7__.Text, {
                                                fontSize: "12px",
                                                bold: true,
                                                color: "textSubtle",
                                                textTransform: "uppercase",
                                                children: t('Sort by')
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ControlStretch, {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Select_Select__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {
                                                    options: [
                                                        {
                                                            label: t('Hot'),
                                                            value: 'hot'
                                                        },
                                                        {
                                                            label: t('APR'),
                                                            value: 'apr'
                                                        },
                                                        {
                                                            label: t('Earned'),
                                                            value: 'earned'
                                                        },
                                                        {
                                                            label: t('Total staked'),
                                                            value: 'totalStaked'
                                                        }, 
                                                    ],
                                                    onOptionChange: handleSortOptionChange
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(LabelWrapper, {
                                        style: {
                                            marginLeft: 16
                                        },
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_7__.Text, {
                                                fontSize: "12px",
                                                bold: true,
                                                color: "textSubtle",
                                                textTransform: "uppercase",
                                                children: t('Search')
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_SearchInput__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                                                onChange: handleChangeSearchQuery,
                                                placeholder: "Search Pools"
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    showFinishedPools && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_7__.Text, {
                        fontSize: "20px",
                        color: "failure",
                        pb: "32px",
                        children: t('These pools are no longer distributing rewards. Please unstake your tokens.')
                    }),
                    account && !userDataLoaded && stakedOnly && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_7__.Flex, {
                        justifyContent: "center",
                        mb: "4px",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Loading__WEBPACK_IMPORTED_MODULE_24__/* ["default"] */ .Z, {})
                    }),
                    viewMode === state_user_actions__WEBPACK_IMPORTED_MODULE_21__/* .ViewMode.CARD */ .wO.CARD ? cardLayout : tableLayout,
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        ref: observerRef
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_7__.Image, {
                        mx: "auto",
                        mt: "12px",
                        src: "/images/decorations/3d-syrup-bunnies.png",
                        alt: "Pancake illustration",
                        width: 192,
                        height: 184.5
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Pools);

});

/***/ })

};
;
//# sourceMappingURL=7023.js.map