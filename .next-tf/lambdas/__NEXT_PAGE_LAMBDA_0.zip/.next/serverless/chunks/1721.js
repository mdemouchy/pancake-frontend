"use strict";
exports.id = 1721;
exports.ids = [1721];
exports.modules = {

/***/ 47826:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ CommonBases)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(42877);
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(99150);
/* harmony import */ var _config_constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3862);
/* harmony import */ var _Layout_Column__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(41914);
/* harmony import */ var _QuestionHelper__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(45061);
/* harmony import */ var _Layout_Row__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(39475);
/* harmony import */ var _Logo__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(83356);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Logo__WEBPACK_IMPORTED_MODULE_10__]);
_Logo__WEBPACK_IMPORTED_MODULE_10__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];











const BaseWrapper = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
    componentId: "sc-8c20c6ab-0"
})`
  border: 1px solid ${({ theme , disable  })=>disable ? 'transparent' : theme.colors.dropdown
};
  border-radius: 10px;
  display: flex;
  padding: 6px;

  align-items: center;
  :hover {
    cursor: ${({ disable  })=>!disable && 'pointer'
};
    background-color: ${({ theme , disable  })=>!disable && theme.colors.background
};
  }

  background-color: ${({ theme , disable  })=>disable && theme.colors.dropdown
};
  opacity: ${({ disable  })=>disable && '0.4'
};
`;
function CommonBases({ chainId , onSelect , selectedCurrency  }) {
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_5__/* .useTranslation */ .$G)();
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Layout_Column__WEBPACK_IMPORTED_MODULE_7__/* .AutoColumn */ .Tz, {
        gap: "md",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Layout_Row__WEBPACK_IMPORTED_MODULE_9__/* .AutoRow */ .BA, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                        fontSize: "14px",
                        children: t('Common bases')
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_QuestionHelper__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                        text: t('These tokens are commonly paired with other tokens.'),
                        ml: "4px"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Layout_Row__WEBPACK_IMPORTED_MODULE_9__/* .AutoRow */ .BA, {
                gap: "auto",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(BaseWrapper, {
                        onClick: ()=>{
                            if (!selectedCurrency || !(0,_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_2__.currencyEquals)(selectedCurrency, _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_2__.ETHER)) {
                                onSelect(_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_2__.ETHER);
                            }
                        },
                        disable: selectedCurrency === _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_2__.ETHER,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Logo__WEBPACK_IMPORTED_MODULE_10__/* .CurrencyLogo */ .Xw, {
                                currency: _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_2__.ETHER,
                                style: {
                                    marginRight: 8
                                }
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                children: "BNB"
                            })
                        ]
                    }),
                    (chainId ? _config_constants__WEBPACK_IMPORTED_MODULE_6__/* .SUGGESTED_BASES */ .kx[chainId] : []).map((token)=>{
                        const selected = selectedCurrency instanceof _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_2__.Token && selectedCurrency.address === token.address;
                        return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(BaseWrapper, {
                            onClick: ()=>!selected && onSelect(token)
                            ,
                            disable: selected,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Logo__WEBPACK_IMPORTED_MODULE_10__/* .CurrencyLogo */ .Xw, {
                                    currency: token,
                                    style: {
                                        marginRight: 8
                                    }
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                    children: token.symbol
                                })
                            ]
                        }, token.address));
                    })
                ]
            })
        ]
    }));
};

});

/***/ }),

/***/ 30546:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ CurrencyList)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(42877);
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_window__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(80551);
/* harmony import */ var react_window__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_window__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(53854);
/* harmony import */ var components_Card__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(36261);
/* harmony import */ var components_QuestionHelper__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(45061);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(99150);
/* harmony import */ var hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(64011);
/* harmony import */ var _state_lists_hooks__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(97952);
/* harmony import */ var _state_wallet_hooks__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(71900);
/* harmony import */ var _hooks_Tokens__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(86435);
/* harmony import */ var _Layout_Column__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(41914);
/* harmony import */ var _Layout_Row__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(39475);
/* harmony import */ var _Logo__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(83356);
/* harmony import */ var _Loader_CircleLoader__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(7010);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(38328);
/* harmony import */ var _ImportRow__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(87908);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_ImportRow__WEBPACK_IMPORTED_MODULE_19__, _hooks_Tokens__WEBPACK_IMPORTED_MODULE_13__, _Logo__WEBPACK_IMPORTED_MODULE_16__, _state_wallet_hooks__WEBPACK_IMPORTED_MODULE_12__]);
([_ImportRow__WEBPACK_IMPORTED_MODULE_19__, _hooks_Tokens__WEBPACK_IMPORTED_MODULE_13__, _Logo__WEBPACK_IMPORTED_MODULE_16__, _state_wallet_hooks__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);




















function currencyKey(currency) {
    return currency instanceof _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_2__.Token ? currency.address : currency === _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_2__.ETHER ? 'ETHER' : '';
}
const StyledBalanceText = styled_components__WEBPACK_IMPORTED_MODULE_4___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text).withConfig({
    componentId: "sc-33de652f-0"
})`
  white-space: nowrap;
  overflow: hidden;
  max-width: 5rem;
  text-overflow: ellipsis;
`;
const FixedContentRow = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
    componentId: "sc-33de652f-1"
})`
  padding: 4px 20px;
  height: 56px;
  display: grid;
  grid-gap: 16px;
  align-items: center;
`;
function Balance({ balance  }) {
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledBalanceText, {
        title: balance.toExact(),
        children: balance.toSignificant(4)
    }));
}
const MenuItem = styled_components__WEBPACK_IMPORTED_MODULE_4___default()(_Layout_Row__WEBPACK_IMPORTED_MODULE_15__/* .RowBetween */ .m0).withConfig({
    componentId: "sc-33de652f-2"
})`
  padding: 4px 20px;
  height: 56px;
  display: grid;
  grid-template-columns: auto minmax(auto, 1fr) minmax(0, 72px);
  grid-gap: 8px;
  cursor: ${({ disabled  })=>!disabled && 'pointer'
};
  pointer-events: ${({ disabled  })=>disabled && 'none'
};
  :hover {
    background-color: ${({ theme , disabled  })=>!disabled && theme.colors.background
};
  }
  opacity: ${({ disabled , selected  })=>disabled || selected ? 0.5 : 1
};
`;
function CurrencyRow({ currency , onSelect , isSelected , otherSelected , style  }) {
    const { account  } = (0,hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)();
    const key = currencyKey(currency);
    const selectedTokenList = (0,_state_lists_hooks__WEBPACK_IMPORTED_MODULE_11__/* .useCombinedActiveList */ .z0)();
    const isOnSelectedList = (0,_utils__WEBPACK_IMPORTED_MODULE_18__/* .isTokenOnList */ .wK)(selectedTokenList, currency);
    const customAdded = (0,_hooks_Tokens__WEBPACK_IMPORTED_MODULE_13__/* .useIsUserAddedToken */ .EH)(currency);
    const balance = (0,_state_wallet_hooks__WEBPACK_IMPORTED_MODULE_12__/* .useCurrencyBalance */ ._h)(account ?? undefined, currency);
    // only show add or remove buttons if not on selected list
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(MenuItem, {
        style: style,
        className: `token-item-${key}`,
        onClick: ()=>isSelected ? null : onSelect()
        ,
        disabled: isSelected,
        selected: otherSelected,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Logo__WEBPACK_IMPORTED_MODULE_16__/* .CurrencyLogo */ .Xw, {
                currency: currency,
                size: "24px"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Layout_Column__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .ZP, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                        bold: true,
                        children: currency.symbol
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                        color: "textSubtle",
                        small: true,
                        ellipsis: true,
                        maxWidth: "200px",
                        children: [
                            !isOnSelectedList && customAdded && 'Added by user •',
                            " ",
                            currency.name
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Layout_Row__WEBPACK_IMPORTED_MODULE_15__/* .RowFixed */ .DA, {
                style: {
                    justifySelf: 'flex-end'
                },
                children: balance ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Balance, {
                    balance: balance
                }) : account ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Loader_CircleLoader__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {}) : null
            })
        ]
    }));
}
function CurrencyList({ height , currencies , selectedCurrency , onCurrencySelect , otherCurrency , fixedListRef , showETH , showImportView , setImportToken , breakIndex  }) {
    const itemData = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        let formatted = showETH ? [
            _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_2__.Currency.ETHER,
            ...currencies
        ] : currencies;
        if (breakIndex !== undefined) {
            formatted = [
                ...formatted.slice(0, breakIndex),
                undefined,
                ...formatted.slice(breakIndex, formatted.length)
            ];
        }
        return formatted;
    }, [
        breakIndex,
        currencies,
        showETH
    ]);
    const { chainId  } = (0,hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)();
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_9__/* .useTranslation */ .$G)();
    const inactiveTokens = (0,_hooks_Tokens__WEBPACK_IMPORTED_MODULE_13__/* .useAllInactiveTokens */ .EK)();
    const Row = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(({ data , index , style  })=>{
        const currency = data[index];
        const isSelected = Boolean(selectedCurrency && (0,_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_2__.currencyEquals)(selectedCurrency, currency));
        const otherSelected = Boolean(otherCurrency && (0,_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_2__.currencyEquals)(otherCurrency, currency));
        const handleSelect = ()=>onCurrencySelect(currency)
        ;
        const token = (0,utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_6__/* .wrappedCurrency */ .pu)(currency, chainId);
        const showImport = inactiveTokens && token && Object.keys(inactiveTokens).includes(token.address);
        if (index === breakIndex || !data) {
            return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FixedContentRow, {
                style: style,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Card__WEBPACK_IMPORTED_MODULE_7__/* .LightGreyCard */ .m5, {
                    padding: "8px 12px",
                    borderRadius: "8px",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Layout_Row__WEBPACK_IMPORTED_MODULE_15__/* .RowBetween */ .m0, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                small: true,
                                children: t('Expanded results from inactive Token Lists')
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_QuestionHelper__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                text: t("Tokens from inactive lists. Import specific tokens below or click 'Manage' to activate more lists."),
                                ml: "4px"
                            })
                        ]
                    })
                })
            }));
        }
        if (showImport && token) {
            return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ImportRow__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z, {
                style: style,
                token: token,
                showImportView: showImportView,
                setImportToken: setImportToken,
                dim: true
            }));
        }
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CurrencyRow, {
            style: style,
            currency: currency,
            isSelected: isSelected,
            onSelect: handleSelect,
            otherSelected: otherSelected
        }));
    }, [
        chainId,
        inactiveTokens,
        onCurrencySelect,
        otherCurrency,
        selectedCurrency,
        setImportToken,
        showImportView,
        breakIndex,
        t, 
    ]);
    const itemKey = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((index, data)=>currencyKey(data[index])
    , []);
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_window__WEBPACK_IMPORTED_MODULE_5__.FixedSizeList, {
        height: height,
        ref: fixedListRef,
        width: "100%",
        itemData: itemData,
        itemCount: itemData.length,
        itemSize: 56,
        itemKey: itemKey,
        children: Row
    }));
};

});

/***/ }),

/***/ 87032:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(42877);
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99150);
/* harmony import */ var state_user_hooks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(68605);
/* harmony import */ var hooks_useDebounce__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(55999);
/* harmony import */ var hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(64011);
/* harmony import */ var _hooks_Tokens__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(86435);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(38328);
/* harmony import */ var _Layout_Column__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(41914);
/* harmony import */ var _Layout_Row__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(39475);
/* harmony import */ var _CommonBases__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(47826);
/* harmony import */ var _CurrencyList__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(30546);
/* harmony import */ var _filtering__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(37910);
/* harmony import */ var _sorting__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(24963);
/* harmony import */ var _swapSound__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(18357);
/* harmony import */ var _ImportRow__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(87908);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_CurrencyList__WEBPACK_IMPORTED_MODULE_13__, _ImportRow__WEBPACK_IMPORTED_MODULE_16__, _CommonBases__WEBPACK_IMPORTED_MODULE_12__, _hooks_Tokens__WEBPACK_IMPORTED_MODULE_8__, _sorting__WEBPACK_IMPORTED_MODULE_15__, state_user_hooks__WEBPACK_IMPORTED_MODULE_5__]);
([_CurrencyList__WEBPACK_IMPORTED_MODULE_13__, _ImportRow__WEBPACK_IMPORTED_MODULE_16__, _CommonBases__WEBPACK_IMPORTED_MODULE_12__, _hooks_Tokens__WEBPACK_IMPORTED_MODULE_8__, _sorting__WEBPACK_IMPORTED_MODULE_15__, state_user_hooks__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);


















function CurrencySearch({ selectedCurrency , onCurrencySelect , otherSelectedCurrency , showCommonBases , showImportView , setImportToken  }) {
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    const { chainId  } = (0,hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
    // refs for fixed size lists
    const fixedList = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    const { 0: searchQuery , 1: setSearchQuery  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const debouncedQuery = (0,hooks_useDebounce__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)(searchQuery, 200);
    const { 0: invertSearchOrder  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const allTokens = (0,_hooks_Tokens__WEBPACK_IMPORTED_MODULE_8__/* .useAllTokens */ .e_)();
    // if they input an address, use it
    const searchToken = (0,_hooks_Tokens__WEBPACK_IMPORTED_MODULE_8__/* .useToken */ .dQ)(debouncedQuery);
    const searchTokenIsAdded = (0,_hooks_Tokens__WEBPACK_IMPORTED_MODULE_8__/* .useIsUserAddedToken */ .EH)(searchToken);
    const [audioPlay] = (0,state_user_hooks__WEBPACK_IMPORTED_MODULE_5__/* .useAudioModeManager */ .TO)();
    const showETH = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        const s = debouncedQuery.toLowerCase().trim();
        return s === '' || s === 'b' || s === 'bn' || s === 'bnb';
    }, [
        debouncedQuery
    ]);
    const tokenComparator = (0,_sorting__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z)(invertSearchOrder);
    const filteredTokens = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        return (0,_filtering__WEBPACK_IMPORTED_MODULE_14__/* .filterTokens */ .l)(Object.values(allTokens), debouncedQuery);
    }, [
        allTokens,
        debouncedQuery
    ]);
    const sortedTokens = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        return filteredTokens.sort(tokenComparator);
    }, [
        filteredTokens,
        tokenComparator
    ]);
    const filteredSortedTokens = (0,_filtering__WEBPACK_IMPORTED_MODULE_14__/* .useSortedTokensByQuery */ .T)(sortedTokens, debouncedQuery);
    const handleCurrencySelect = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((currency)=>{
        onCurrencySelect(currency);
        if (audioPlay) {
            (0,_swapSound__WEBPACK_IMPORTED_MODULE_17__/* .getSwapSound */ .C)().play();
        }
    }, [
        audioPlay,
        onCurrencySelect
    ]);
    // manage focus on modal show
    const inputRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        inputRef.current.focus();
    }, []);
    const handleInput = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((event)=>{
        const input = event.target.value;
        const checksummedInput = (0,_utils__WEBPACK_IMPORTED_MODULE_9__/* .isAddress */ .UJ)(input);
        setSearchQuery(checksummedInput || input);
        fixedList.current?.scrollTo(0);
    }, []);
    const handleEnter = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((e)=>{
        if (e.key === 'Enter') {
            const s = debouncedQuery.toLowerCase().trim();
            if (s === 'bnb') {
                handleCurrencySelect(_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_2__.ETHER);
            } else if (filteredSortedTokens.length > 0) {
                if (filteredSortedTokens[0].symbol?.toLowerCase() === debouncedQuery.trim().toLowerCase() || filteredSortedTokens.length === 1) {
                    handleCurrencySelect(filteredSortedTokens[0]);
                }
            }
        }
    }, [
        filteredSortedTokens,
        handleCurrencySelect,
        debouncedQuery
    ]);
    // if no results on main list, show option to expand into inactive
    const inactiveTokens = (0,_hooks_Tokens__WEBPACK_IMPORTED_MODULE_8__/* .useFoundOnInactiveList */ .FM)(debouncedQuery);
    const filteredInactiveTokens = (0,_filtering__WEBPACK_IMPORTED_MODULE_14__/* .useSortedTokensByQuery */ .T)(inactiveTokens, debouncedQuery);
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Layout_Column__WEBPACK_IMPORTED_MODULE_10__/* .AutoColumn */ .Tz, {
                    gap: "16px",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Layout_Row__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .ZP, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Input, {
                                id: "token-search-input",
                                placeholder: t('Search name or paste address'),
                                scale: "lg",
                                autoComplete: "off",
                                value: searchQuery,
                                ref: inputRef,
                                onChange: handleInput,
                                onKeyDown: handleEnter
                            })
                        }),
                        showCommonBases && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CommonBases__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                            chainId: chainId,
                            onSelect: handleCurrencySelect,
                            selectedCurrency: selectedCurrency
                        })
                    ]
                }),
                searchToken && !searchTokenIsAdded ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Layout_Column__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .ZP, {
                    style: {
                        padding: '20px 0',
                        height: '100%'
                    },
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ImportRow__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                        token: searchToken,
                        showImportView: showImportView,
                        setImportToken: setImportToken
                    })
                }) : filteredSortedTokens?.length > 0 || filteredInactiveTokens?.length > 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Box, {
                    margin: "24px -24px",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CurrencyList__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                        height: 390,
                        showETH: showETH,
                        currencies: filteredInactiveTokens ? filteredSortedTokens.concat(filteredInactiveTokens) : filteredSortedTokens,
                        breakIndex: inactiveTokens && filteredSortedTokens ? filteredSortedTokens.length : undefined,
                        onCurrencySelect: handleCurrencySelect,
                        otherCurrency: otherSelectedCurrency,
                        selectedCurrency: selectedCurrency,
                        fixedListRef: fixedList,
                        showImportView: showImportView,
                        setImportToken: setImportToken
                    })
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Layout_Column__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .ZP, {
                    style: {
                        padding: '20px',
                        height: '100%'
                    },
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                        color: "textSubtle",
                        textAlign: "center",
                        mb: "20px",
                        children: t('No results found.')
                    })
                })
            ]
        })
    }));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CurrencySearch);

});

/***/ }),

/***/ 31721:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ CurrencySearchModal)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var hooks_usePreviousValue__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6199);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(99150);
/* harmony import */ var _CurrencySearch__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(87032);
/* harmony import */ var _ImportToken__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9189);
/* harmony import */ var _Manage__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(22768);
/* harmony import */ var _ImportList__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(52907);
/* harmony import */ var _types__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(40330);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Manage__WEBPACK_IMPORTED_MODULE_8__, _ImportList__WEBPACK_IMPORTED_MODULE_9__, _ImportToken__WEBPACK_IMPORTED_MODULE_7__, _CurrencySearch__WEBPACK_IMPORTED_MODULE_6__]);
([_Manage__WEBPACK_IMPORTED_MODULE_8__, _ImportList__WEBPACK_IMPORTED_MODULE_9__, _ImportToken__WEBPACK_IMPORTED_MODULE_7__, _CurrencySearch__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);











const Footer = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
    componentId: "sc-c8e9b7de-0"
})`
  width: 100%;
  background-color: ${({ theme  })=>theme.colors.backgroundAlt
};
  text-align: center;
`;
const StyledModalContainer = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.ModalContainer).withConfig({
    componentId: "sc-c8e9b7de-1"
})`
  max-width: 420px;
  width: 100%;
`;
const StyledModalBody = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.ModalBody).withConfig({
    componentId: "sc-c8e9b7de-2"
})`
  padding: 24px;
  overflow-y: auto;
  -ms-overflow-style: none;
  scrollbar-width: none;
  &::-webkit-scrollbar {
    display: none;
  }
`;
function CurrencySearchModal({ onDismiss =()=>null
 , onCurrencySelect , selectedCurrency , otherSelectedCurrency , showCommonBases =false  }) {
    const { 0: modalView , 1: setModalView  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(_types__WEBPACK_IMPORTED_MODULE_10__/* .CurrencyModalView.search */ .H.search);
    const handleCurrencySelect = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((currency)=>{
        onDismiss();
        onCurrencySelect(currency);
    }, [
        onDismiss,
        onCurrencySelect
    ]);
    // for token import view
    const prevView = (0,hooks_usePreviousValue__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)(modalView);
    // used for import token flow
    const { 0: importToken , 1: setImportToken  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    // used for import list
    const { 0: importList , 1: setImportList  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { 0: listURL , 1: setListUrl  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_5__/* .useTranslation */ .$G)();
    const config = {
        [_types__WEBPACK_IMPORTED_MODULE_10__/* .CurrencyModalView.search */ .H.search]: {
            title: t('Select a Token'),
            onBack: undefined
        },
        [_types__WEBPACK_IMPORTED_MODULE_10__/* .CurrencyModalView.manage */ .H.manage]: {
            title: t('Manage'),
            onBack: ()=>setModalView(_types__WEBPACK_IMPORTED_MODULE_10__/* .CurrencyModalView.search */ .H.search)
        },
        [_types__WEBPACK_IMPORTED_MODULE_10__/* .CurrencyModalView.importToken */ .H.importToken]: {
            title: t('Import Tokens'),
            onBack: ()=>setModalView(prevView && prevView !== _types__WEBPACK_IMPORTED_MODULE_10__/* .CurrencyModalView.importToken */ .H.importToken ? prevView : _types__WEBPACK_IMPORTED_MODULE_10__/* .CurrencyModalView.search */ .H.search)
        },
        [_types__WEBPACK_IMPORTED_MODULE_10__/* .CurrencyModalView.importList */ .H.importList]: {
            title: t('Import List'),
            onBack: ()=>setModalView(_types__WEBPACK_IMPORTED_MODULE_10__/* .CurrencyModalView.search */ .H.search)
        }
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(StyledModalContainer, {
        minWidth: "320px",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.ModalHeader, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.ModalTitle, {
                        children: [
                            config[modalView].onBack && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.ModalBackButton, {
                                onBack: config[modalView].onBack
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Heading, {
                                children: config[modalView].title
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.ModalCloseButton, {
                        onDismiss: onDismiss
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(StyledModalBody, {
                children: [
                    modalView === _types__WEBPACK_IMPORTED_MODULE_10__/* .CurrencyModalView.search */ .H.search ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CurrencySearch__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                        onCurrencySelect: handleCurrencySelect,
                        selectedCurrency: selectedCurrency,
                        otherSelectedCurrency: otherSelectedCurrency,
                        showCommonBases: showCommonBases,
                        showImportView: ()=>setModalView(_types__WEBPACK_IMPORTED_MODULE_10__/* .CurrencyModalView.importToken */ .H.importToken)
                        ,
                        setImportToken: setImportToken
                    }) : modalView === _types__WEBPACK_IMPORTED_MODULE_10__/* .CurrencyModalView.importToken */ .H.importToken && importToken ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ImportToken__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        tokens: [
                            importToken
                        ],
                        handleCurrencySelect: handleCurrencySelect
                    }) : modalView === _types__WEBPACK_IMPORTED_MODULE_10__/* .CurrencyModalView.importList */ .H.importList && importList && listURL ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ImportList__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                        list: importList,
                        listURL: listURL,
                        onImport: ()=>setModalView(_types__WEBPACK_IMPORTED_MODULE_10__/* .CurrencyModalView.manage */ .H.manage)
                    }) : modalView === _types__WEBPACK_IMPORTED_MODULE_10__/* .CurrencyModalView.manage */ .H.manage ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Manage__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                        setModalView: setModalView,
                        setImportToken: setImportToken,
                        setImportList: setImportList,
                        setListUrl: setListUrl
                    }) : '',
                    modalView === _types__WEBPACK_IMPORTED_MODULE_10__/* .CurrencyModalView.search */ .H.search && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Footer, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                            scale: "sm",
                            variant: "text",
                            onClick: ()=>setModalView(_types__WEBPACK_IMPORTED_MODULE_10__/* .CurrencyModalView.manage */ .H.manage)
                            ,
                            className: "list-token-manage-button",
                            children: t('Manage Tokens')
                        })
                    })
                ]
            })
        ]
    }));
};

});

/***/ }),

/***/ 52907:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var components_Card__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(36261);
/* harmony import */ var components_Layout_Column__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(41914);
/* harmony import */ var components_Layout_Row__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(39475);
/* harmony import */ var hooks_useTheme__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(23917);
/* harmony import */ var components_Logo__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(83356);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var hooks_useFetchListCallback__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(58339);
/* harmony import */ var state_lists_actions__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(48412);
/* harmony import */ var state_lists_hooks__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(97952);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(99150);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([components_Logo__WEBPACK_IMPORTED_MODULE_8__, hooks_useTheme__WEBPACK_IMPORTED_MODULE_7__]);
([components_Logo__WEBPACK_IMPORTED_MODULE_8__, hooks_useTheme__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);














const Wrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-6538459d-0"
})`
  position: relative;
  width: 100%;
`;
const TextDot = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-6538459d-1"
})`
  height: 3px;
  width: 3px;
  background-color: ${({ theme  })=>theme.colors.text
};
  border-radius: 50%;
`;
function ImportList({ listURL , list , onImport  }) {
    const { theme  } = (0,hooks_useTheme__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_9__.useDispatch)();
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_13__/* .useTranslation */ .$G)();
    // user must accept
    const { 0: confirmed , 1: setConfirmed  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const lists = (0,state_lists_hooks__WEBPACK_IMPORTED_MODULE_12__/* .useAllLists */ .R0)();
    const fetchList = (0,hooks_useFetchListCallback__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)();
    // monitor is list is loading
    const adding = Boolean(lists[listURL]?.loadingRequestId);
    const { 0: addError , 1: setAddError  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const handleAddList = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        if (adding) return;
        setAddError(null);
        fetchList(listURL).then(()=>{
            dispatch((0,state_lists_actions__WEBPACK_IMPORTED_MODULE_11__/* .enableList */ .ic)(listURL));
            onImport();
        }).catch((error)=>{
            setAddError(error.message);
            dispatch((0,state_lists_actions__WEBPACK_IMPORTED_MODULE_11__/* .removeList */ .J_)(listURL));
        });
    }, [
        adding,
        dispatch,
        fetchList,
        listURL,
        onImport
    ]);
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Wrapper, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Layout_Column__WEBPACK_IMPORTED_MODULE_5__/* .AutoColumn */ .Tz, {
            gap: "md",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(components_Layout_Column__WEBPACK_IMPORTED_MODULE_5__/* .AutoColumn */ .Tz, {
                gap: "md",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Card__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP, {
                        padding: "12px 20px",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Layout_Row__WEBPACK_IMPORTED_MODULE_6__/* .RowBetween */ .m0, {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(components_Layout_Row__WEBPACK_IMPORTED_MODULE_6__/* .RowFixed */ .DA, {
                                children: [
                                    list.logoURI && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Logo__WEBPACK_IMPORTED_MODULE_8__/* .ListLogo */ ._r, {
                                        logoURI: list.logoURI,
                                        size: "40px"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(components_Layout_Column__WEBPACK_IMPORTED_MODULE_5__/* .AutoColumn */ .Tz, {
                                        gap: "sm",
                                        style: {
                                            marginLeft: '20px'
                                        },
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(components_Layout_Row__WEBPACK_IMPORTED_MODULE_6__/* .RowFixed */ .DA, {
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                                        bold: true,
                                                        mr: "6px",
                                                        children: list.name
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TextDot, {}),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                                        small: true,
                                                        color: "textSubtle",
                                                        ml: "6px",
                                                        children: [
                                                            list.tokens.length,
                                                            " tokens"
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Link, {
                                                small: true,
                                                external: true,
                                                ellipsis: true,
                                                maxWidth: "90%",
                                                href: `https://tokenlists.org/token-list?url=${listURL}`,
                                                children: listURL
                                            })
                                        ]
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Message, {
                        variant: "danger",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                            flexDirection: "column",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                    fontSize: "20px",
                                    textAlign: "center",
                                    color: theme.colors.failure,
                                    mb: "16px",
                                    children: t('Import at your own risk')
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                    color: theme.colors.failure,
                                    mb: "8px",
                                    children: t('By adding this list you are implicitly trusting that the data is correct. Anyone can create a list, including creating fake versions of existing lists and lists that claim to represent projects that do not have one.')
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                    bold: true,
                                    color: theme.colors.failure,
                                    mb: "16px",
                                    children: typeof 'If you purchase a token from this list, you may not be able to sell it back.'
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                                    alignItems: "center",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Checkbox, {
                                            name: "confirmed",
                                            type: "checkbox",
                                            checked: confirmed,
                                            onChange: ()=>setConfirmed(!confirmed)
                                            ,
                                            scale: "sm"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                            ml: "10px",
                                            style: {
                                                userSelect: 'none'
                                            },
                                            children: t('I understand')
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Button, {
                        disabled: !confirmed,
                        onClick: handleAddList,
                        children: t('Import')
                    }),
                    addError ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                        color: "failure",
                        style: {
                            textOverflow: 'ellipsis',
                            overflow: 'hidden'
                        },
                        children: addError
                    }) : null
                ]
            })
        })
    }));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ImportList);

});

/***/ }),

/***/ 87908:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ImportRow)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var components_Layout_Row__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(39475);
/* harmony import */ var components_Layout_Column__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(41914);
/* harmony import */ var components_Logo_CurrencyLogo__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(34966);
/* harmony import */ var components_Logo__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(83356);
/* harmony import */ var hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(64011);
/* harmony import */ var state_lists_hooks__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(97952);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var hooks_Tokens__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(86435);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(99150);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([components_Logo__WEBPACK_IMPORTED_MODULE_6__, components_Logo_CurrencyLogo__WEBPACK_IMPORTED_MODULE_5__, hooks_Tokens__WEBPACK_IMPORTED_MODULE_10__]);
([components_Logo__WEBPACK_IMPORTED_MODULE_6__, components_Logo_CurrencyLogo__WEBPACK_IMPORTED_MODULE_5__, hooks_Tokens__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);












const TokenSection = styled_components__WEBPACK_IMPORTED_MODULE_9___default().div.withConfig({
    componentId: "sc-7854bc26-0"
})`
  padding: 4px 20px;
  height: 56px;
  display: grid;
  grid-template-columns: auto minmax(auto, 1fr) auto;
  grid-gap: 16px;
  align-items: center;

  opacity: ${({ dim  })=>dim ? '0.4' : '1'
};
`;
const CheckIcon = styled_components__WEBPACK_IMPORTED_MODULE_9___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.CheckmarkCircleIcon).withConfig({
    componentId: "sc-7854bc26-1"
})`
  height: 16px;
  width: 16px;
  margin-right: 6px;
  stroke: ${({ theme  })=>theme.colors.success
};
`;
const NameOverflow = styled_components__WEBPACK_IMPORTED_MODULE_9___default().div.withConfig({
    componentId: "sc-7854bc26-2"
})`
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  max-width: 140px;
  font-size: 12px;
`;
function ImportRow({ token , style , dim , showImportView , setImportToken  }) {
    // globals
    const { chainId  } = (0,hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_11__/* .useTranslation */ .$G)();
    // check if token comes from list
    const inactiveTokenList = (0,state_lists_hooks__WEBPACK_IMPORTED_MODULE_8__/* .useCombinedInactiveList */ .qB)();
    const list = chainId && inactiveTokenList?.[chainId]?.[token.address]?.list;
    // check if already active on list or local storage tokens
    const isAdded = (0,hooks_Tokens__WEBPACK_IMPORTED_MODULE_10__/* .useIsUserAddedToken */ .EH)(token);
    const isActive = (0,hooks_Tokens__WEBPACK_IMPORTED_MODULE_10__/* .useIsTokenActive */ .ZN)(token);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(TokenSection, {
        style: style,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Logo_CurrencyLogo__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                currency: token,
                size: "24px",
                style: {
                    opacity: dim ? '0.6' : '1'
                }
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(components_Layout_Column__WEBPACK_IMPORTED_MODULE_4__/* .AutoColumn */ .Tz, {
                gap: "4px",
                style: {
                    opacity: dim ? '0.6' : '1'
                },
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(components_Layout_Row__WEBPACK_IMPORTED_MODULE_3__/* .AutoRow */ .BA, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                children: token.symbol
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                color: "textDisabled",
                                ml: "8px",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(NameOverflow, {
                                    title: token.name,
                                    children: token.name
                                })
                            })
                        ]
                    }),
                    list && list.logoURI && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(components_Layout_Row__WEBPACK_IMPORTED_MODULE_3__/* .RowFixed */ .DA, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                small: true,
                                mr: "4px",
                                color: "textSubtle",
                                children: [
                                    t('via'),
                                    " ",
                                    list.name
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Logo__WEBPACK_IMPORTED_MODULE_6__/* .ListLogo */ ._r, {
                                logoURI: list.logoURI,
                                size: "12px"
                            })
                        ]
                    })
                ]
            }),
            !isActive && !isAdded ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                width: "fit-content",
                onClick: ()=>{
                    if (setImportToken) {
                        setImportToken(token);
                    }
                    showImportView();
                },
                children: t('Import')
            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(components_Layout_Row__WEBPACK_IMPORTED_MODULE_3__/* .RowFixed */ .DA, {
                style: {
                    minWidth: 'fit-content'
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CheckIcon, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        color: "success",
                        children: "Active"
                    })
                ]
            })
        ]
    }));
};

});

/***/ }),

/***/ 9189:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var components_Layout_Column__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(41914);
/* harmony import */ var state_user_hooks__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(68605);
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(38328);
/* harmony import */ var utils_truncateHash__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(53467);
/* harmony import */ var hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(64011);
/* harmony import */ var state_lists_hooks__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(97952);
/* harmony import */ var components_Logo__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(83356);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(99150);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([components_Logo__WEBPACK_IMPORTED_MODULE_8__, state_user_hooks__WEBPACK_IMPORTED_MODULE_4__]);
([components_Logo__WEBPACK_IMPORTED_MODULE_8__, state_user_hooks__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);











function ImportToken({ tokens , handleCurrencySelect  }) {
    const { chainId  } = (0,hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)();
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_9__/* .useTranslation */ .$G)();
    const { 0: confirmed , 1: setConfirmed  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const addToken = (0,state_user_hooks__WEBPACK_IMPORTED_MODULE_4__/* .useAddUserToken */ ._E)();
    // use for showing import source on inactive tokens
    const inactiveTokenList = (0,state_lists_hooks__WEBPACK_IMPORTED_MODULE_7__/* .useCombinedInactiveList */ .qB)();
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(components_Layout_Column__WEBPACK_IMPORTED_MODULE_3__/* .AutoColumn */ .Tz, {
        gap: "lg",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Message, {
                variant: "warning",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                    children: [
                        t('Anyone can create a BEP20 token on BSC with any name, including creating fake versions of existing tokens and tokens that claim to represent projects that do not have a token.'),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                        t('If you purchase an arbitrary token, you may be unable to sell it back.')
                    ]
                })
            }),
            tokens.map((token)=>{
                const list = chainId && inactiveTokenList?.[chainId]?.[token.address]?.list;
                const address = token.address ? `${(0,utils_truncateHash__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)(token.address)}` : null;
                return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                    gridTemplateRows: "1fr 1fr 1fr",
                    gridGap: "4px",
                    children: [
                        list !== undefined ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Tag, {
                            variant: "success",
                            outline: true,
                            scale: "sm",
                            startIcon: list.logoURI && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Logo__WEBPACK_IMPORTED_MODULE_8__/* .ListLogo */ ._r, {
                                logoURI: list.logoURI,
                                size: "12px"
                            }),
                            children: [
                                t('via'),
                                " ",
                                list.name
                            ]
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Tag, {
                            variant: "failure",
                            outline: true,
                            scale: "sm",
                            startIcon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.ErrorIcon, {
                                color: "failure"
                            }),
                            children: t('Unknown Source')
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                            alignItems: "center",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                    mr: "8px",
                                    children: token.name
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                    children: [
                                        "(",
                                        token.symbol,
                                        ")"
                                    ]
                                })
                            ]
                        }),
                        chainId && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                            justifyContent: "space-between",
                            width: "100%",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                    mr: "4px",
                                    children: address
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Link, {
                                    href: (0,utils__WEBPACK_IMPORTED_MODULE_5__/* .getBscScanLink */ .s6)(token.address, 'address', chainId),
                                    external: true,
                                    children: [
                                        "(",
                                        t('View on BscScan'),
                                        ")"
                                    ]
                                })
                            ]
                        })
                    ]
                }, token.address));
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                justifyContent: "space-between",
                alignItems: "center",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        alignItems: "center",
                        onClick: ()=>setConfirmed(!confirmed)
                        ,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Checkbox, {
                                scale: "sm",
                                name: "confirmed",
                                type: "checkbox",
                                checked: confirmed,
                                onChange: ()=>setConfirmed(!confirmed)
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                ml: "8px",
                                style: {
                                    userSelect: 'none'
                                },
                                children: t('I understand')
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                        variant: "danger",
                        disabled: !confirmed,
                        onClick: ()=>{
                            tokens.forEach((token)=>addToken(token)
                            );
                            if (handleCurrencySelect) {
                                handleCurrencySelect(tokens[0]);
                            }
                        },
                        className: ".token-dismiss-button",
                        children: t('Import')
                    })
                ]
            })
        ]
    }));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ImportToken);

});

/***/ }),

/***/ 22768:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Manage)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99150);
/* harmony import */ var _ManageLists__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(52025);
/* harmony import */ var _ManageTokens__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8529);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_ManageTokens__WEBPACK_IMPORTED_MODULE_6__, _ManageLists__WEBPACK_IMPORTED_MODULE_5__]);
([_ManageTokens__WEBPACK_IMPORTED_MODULE_6__, _ManageLists__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);







const StyledButtonMenu = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.ButtonMenu).withConfig({
    componentId: "sc-968aa33d-0"
})`
  width: 100%;
`;
function Manage({ setModalView , setImportList , setImportToken , setListUrl  }) {
    const { 0: showLists , 1: setShowLists  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.ModalBody, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(StyledButtonMenu, {
                activeIndex: showLists ? 0 : 1,
                onItemClick: ()=>setShowLists((prev)=>!prev
                    )
                ,
                scale: "sm",
                variant: "subtle",
                mb: "32px",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.ButtonMenuItem, {
                        width: "50%",
                        children: t('Lists')
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.ButtonMenuItem, {
                        width: "50%",
                        children: t('Tokens')
                    })
                ]
            }),
            showLists ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ManageLists__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                setModalView: setModalView,
                setImportList: setImportList,
                setListUrl: setListUrl
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ManageTokens__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                setModalView: setModalView,
                setImportToken: setImportToken
            })
        ]
    }));
};

});

/***/ }),

/***/ 52025:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var components_Card__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(36261);
/* harmony import */ var config_constants_lists__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(90428);
/* harmony import */ var utils_ENS_parseENSAddress__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(12188);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(99150);
/* harmony import */ var _hooks_useFetchListCallback__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(58339);
/* harmony import */ var _state_lists_actions__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(48412);
/* harmony import */ var _state_lists_hooks__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(97952);
/* harmony import */ var _utils_uriToHttp__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(90570);
/* harmony import */ var _Layout_Column__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(41914);
/* harmony import */ var _Logo__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(83356);
/* harmony import */ var _Layout_Row__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(39475);
/* harmony import */ var _types__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(40330);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Logo__WEBPACK_IMPORTED_MODULE_12__]);
_Logo__WEBPACK_IMPORTED_MODULE_12__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];

















function listVersionLabel(version) {
    return `v${version.major}.${version.minor}.${version.patch}`;
}
const Wrapper = styled_components__WEBPACK_IMPORTED_MODULE_4___default()(_Layout_Column__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .ZP).withConfig({
    componentId: "sc-5c5df0d3-0"
})`
  width: 100%;
  height: 100%;
`;
const RowWrapper = styled_components__WEBPACK_IMPORTED_MODULE_4___default()(_Layout_Row__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .ZP).withConfig({
    componentId: "sc-5c5df0d3-1"
})`
  background-color: ${({ active , theme  })=>active ? `${theme.colors.success}19` : 'transparent'
};
  border: solid 1px;
  border-color: ${({ active , theme  })=>active ? theme.colors.success : theme.colors.tertiary
};
  transition: 200ms;
  align-items: center;
  padding: 1rem;
  border-radius: 20px;
`;
function listUrlRowHTMLId(listUrl) {
    return `list-row-${listUrl.replace(/\./g, '-')}`;
}
const ListRow = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.memo)(function ListRow({ listUrl  }) {
    const listsByUrl = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useSelector)((state)=>state.lists.byUrl
    );
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useDispatch)();
    const { current: list , pendingUpdate: pending  } = listsByUrl[listUrl];
    const isActive = (0,_state_lists_hooks__WEBPACK_IMPORTED_MODULE_10__/* .useIsListActive */ .EF)(listUrl);
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_7__/* .useTranslation */ .$G)();
    const handleAcceptListUpdate = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        if (!pending) return;
        dispatch((0,_state_lists_actions__WEBPACK_IMPORTED_MODULE_9__/* .acceptListUpdate */ .xJ)(listUrl));
    }, [
        dispatch,
        listUrl,
        pending
    ]);
    const handleRemoveList = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        // eslint-disable-next-line no-alert
        if (window.confirm('Please confirm you would like to remove this list')) {
            dispatch((0,_state_lists_actions__WEBPACK_IMPORTED_MODULE_9__/* .removeList */ .J_)(listUrl));
        }
    }, [
        dispatch,
        listUrl
    ]);
    const handleEnableList = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        dispatch((0,_state_lists_actions__WEBPACK_IMPORTED_MODULE_9__/* .enableList */ .ic)(listUrl));
    }, [
        dispatch,
        listUrl
    ]);
    const handleDisableList = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        dispatch((0,_state_lists_actions__WEBPACK_IMPORTED_MODULE_9__/* .disableList */ .K$)(listUrl));
    }, [
        dispatch,
        listUrl
    ]);
    const { targetRef , tooltip , tooltipVisible  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.useTooltip)(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                children: list && listVersionLabel(list.version)
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.LinkExternal, {
                external: true,
                href: `https://tokenlists.org/token-list?url=${listUrl}`,
                children: t('See')
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                variant: "danger",
                scale: "xs",
                onClick: handleRemoveList,
                disabled: Object.keys(listsByUrl).length === 1,
                children: t('Remove')
            }),
            pending && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                variant: "text",
                onClick: handleAcceptListUpdate,
                style: {
                    fontSize: '12px'
                },
                children: t('Update list')
            })
        ]
    }), {
        placement: 'right-end',
        trigger: 'click'
    });
    if (!list) return null;
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(RowWrapper, {
        active: isActive,
        id: listUrlRowHTMLId(listUrl),
        children: [
            tooltipVisible && tooltip,
            list.logoURI ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Logo__WEBPACK_IMPORTED_MODULE_12__/* .ListLogo */ ._r, {
                size: "40px",
                style: {
                    marginRight: '1rem'
                },
                logoURI: list.logoURI,
                alt: `${list.name} list logo`
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                style: {
                    width: '24px',
                    height: '24px',
                    marginRight: '1rem'
                }
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Layout_Column__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .ZP, {
                style: {
                    flex: '1'
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Layout_Row__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .ZP, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                            bold: true,
                            children: list.name
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Layout_Row__WEBPACK_IMPORTED_MODULE_13__/* .RowFixed */ .DA, {
                        mt: "4px",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                fontSize: "12px",
                                mr: "6px",
                                textTransform: "lowercase",
                                children: [
                                    list.tokens.length,
                                    " ",
                                    t('Tokens')
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                ref: targetRef,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.CogIcon, {
                                    color: "text",
                                    width: "12px"
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Toggle, {
                checked: isActive,
                onChange: ()=>{
                    if (isActive) {
                        handleDisableList();
                    } else {
                        handleEnableList();
                    }
                }
            })
        ]
    }, listUrl));
});
const ListContainer = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
    componentId: "sc-5c5df0d3-2"
})`
  padding: 1rem 0;
  height: 100%;
  overflow: auto;
`;
function ManageLists({ setModalView , setImportList , setListUrl  }) {
    const { 0: listUrlInput , 1: setListUrlInput  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_7__/* .useTranslation */ .$G)();
    const lists = (0,_state_lists_hooks__WEBPACK_IMPORTED_MODULE_10__/* .useAllLists */ .R0)();
    // sort by active but only if not visible
    const activeListUrls = (0,_state_lists_hooks__WEBPACK_IMPORTED_MODULE_10__/* .useActiveListUrls */ .v0)();
    const { 0: activeCopy , 1: setActiveCopy  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (!activeCopy && activeListUrls) {
            setActiveCopy(activeListUrls);
        }
    }, [
        activeCopy,
        activeListUrls
    ]);
    const handleInput = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((e)=>{
        setListUrlInput(e.target.value);
    }, []);
    const fetchList = (0,_hooks_useFetchListCallback__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
    const validUrl = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        return (0,_utils_uriToHttp__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z)(listUrlInput).length > 0 || Boolean((0,utils_ENS_parseENSAddress__WEBPACK_IMPORTED_MODULE_16__/* .parseENSAddress */ .y)(listUrlInput));
    }, [
        listUrlInput
    ]);
    const sortedLists = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        const listUrls = Object.keys(lists);
        return listUrls.filter((listUrl)=>{
            // only show loaded lists, hide unsupported lists
            return Boolean(lists[listUrl].current) && !config_constants_lists__WEBPACK_IMPORTED_MODULE_6__/* .UNSUPPORTED_LIST_URLS.includes */ .US.includes(listUrl);
        }).sort((u1, u2)=>{
            const { current: l1  } = lists[u1];
            const { current: l2  } = lists[u2];
            // first filter on active lists
            if (activeCopy?.includes(u1) && !activeCopy?.includes(u2)) {
                return -1;
            }
            if (!activeCopy?.includes(u1) && activeCopy?.includes(u2)) {
                return 1;
            }
            if (l1 && l2) {
                return l1.name.toLowerCase() < l2.name.toLowerCase() ? -1 : l1.name.toLowerCase() === l2.name.toLowerCase() ? 0 : 1;
            }
            if (l1) return -1;
            if (l2) return 1;
            return 0;
        });
    }, [
        lists,
        activeCopy
    ]);
    // temporary fetched list for import flow
    const { 0: tempList , 1: setTempList  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { 0: addError , 1: setAddError  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        async function fetchTempList() {
            fetchList(listUrlInput, false).then((list)=>setTempList(list)
            ).catch(()=>setAddError('Error importing list')
            );
        }
        // if valid url, fetch details for card
        if (validUrl) {
            fetchTempList();
        } else {
            setTempList(undefined);
            if (listUrlInput !== '') {
                setAddError('Enter valid list location');
            }
        }
        // reset error
        if (listUrlInput === '') {
            setAddError(undefined);
        }
    }, [
        fetchList,
        listUrlInput,
        validUrl
    ]);
    // check if list is already imported
    const isImported = Object.keys(lists).includes(listUrlInput);
    // set list values and have parent modal switch to import list view
    const handleImport = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        if (!tempList) return;
        setImportList(tempList);
        setModalView(_types__WEBPACK_IMPORTED_MODULE_14__/* .CurrencyModalView.importList */ .H.importList);
        setListUrl(listUrlInput);
    }, [
        listUrlInput,
        setImportList,
        setListUrl,
        setModalView,
        tempList
    ]);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Wrapper, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Layout_Column__WEBPACK_IMPORTED_MODULE_11__/* .AutoColumn */ .Tz, {
                gap: "14px",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Layout_Row__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .ZP, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Input, {
                            id: "list-add-input",
                            scale: "lg",
                            placeholder: t('https:// or ipfs:// or ENS name'),
                            value: listUrlInput,
                            onChange: handleInput
                        })
                    }),
                    addError ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        color: "failure",
                        style: {
                            textOverflow: 'ellipsis',
                            overflow: 'hidden'
                        },
                        children: addError
                    }) : null
                ]
            }),
            tempList && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Layout_Column__WEBPACK_IMPORTED_MODULE_11__/* .AutoColumn */ .Tz, {
                style: {
                    paddingTop: 0
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Card__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP, {
                    padding: "12px 20px",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Layout_Row__WEBPACK_IMPORTED_MODULE_13__/* .RowBetween */ .m0, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Layout_Row__WEBPACK_IMPORTED_MODULE_13__/* .RowFixed */ .DA, {
                                children: [
                                    tempList.logoURI && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Logo__WEBPACK_IMPORTED_MODULE_12__/* .ListLogo */ ._r, {
                                        logoURI: tempList.logoURI,
                                        size: "40px"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Layout_Column__WEBPACK_IMPORTED_MODULE_11__/* .AutoColumn */ .Tz, {
                                        gap: "4px",
                                        style: {
                                            marginLeft: '20px'
                                        },
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                                bold: true,
                                                children: tempList.name
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                                color: "textSubtle",
                                                small: true,
                                                textTransform: "lowercase",
                                                children: [
                                                    tempList.tokens.length,
                                                    " ",
                                                    t('Tokens')
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }),
                            isImported ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Layout_Row__WEBPACK_IMPORTED_MODULE_13__/* .RowFixed */ .DA, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.CheckmarkIcon, {
                                        width: "16px",
                                        mr: "10px"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                        children: t('Loaded')
                                    })
                                ]
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                                width: "fit-content",
                                onClick: handleImport,
                                children: t('Import')
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ListContainer, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Layout_Column__WEBPACK_IMPORTED_MODULE_11__/* .AutoColumn */ .Tz, {
                    gap: "md",
                    children: sortedLists.map((listUrl)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ListRow, {
                            listUrl: listUrl
                        }, listUrl)
                    )
                })
            })
        ]
    }));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ManageLists);

});

/***/ }),

/***/ 8529:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ManageTokens)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var components_Layout_Row__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(39475);
/* harmony import */ var hooks_Tokens__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(86435);
/* harmony import */ var state_user_hooks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(68605);
/* harmony import */ var state_user_hooks_useUserAddedTokens__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(44797);
/* harmony import */ var components_Logo__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(83356);
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(38328);
/* harmony import */ var hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(64011);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(99150);
/* harmony import */ var _Layout_Column__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(41914);
/* harmony import */ var _ImportRow__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(87908);
/* harmony import */ var _types__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(40330);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_ImportRow__WEBPACK_IMPORTED_MODULE_13__, components_Logo__WEBPACK_IMPORTED_MODULE_8__, state_user_hooks__WEBPACK_IMPORTED_MODULE_6__, hooks_Tokens__WEBPACK_IMPORTED_MODULE_5__]);
([_ImportRow__WEBPACK_IMPORTED_MODULE_13__, components_Logo__WEBPACK_IMPORTED_MODULE_8__, state_user_hooks__WEBPACK_IMPORTED_MODULE_6__, hooks_Tokens__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);















const Wrapper = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
    componentId: "sc-45fe4e95-0"
})`
  width: 100%;
  height: calc(100% - 60px);
  position: relative;
  padding-bottom: 60px;
`;
const Footer = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
    componentId: "sc-45fe4e95-1"
})`
  position: absolute;
  bottom: 0;
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
`;
function ManageTokens({ setModalView , setImportToken  }) {
    const { chainId  } = (0,hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)();
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_11__/* .useTranslation */ .$G)();
    const { 0: searchQuery , 1: setSearchQuery  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    // manage focus on modal show
    const inputRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    const handleInput = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((event)=>{
        const input = event.target.value;
        const checksummedInput = (0,utils__WEBPACK_IMPORTED_MODULE_9__/* .isAddress */ .UJ)(input);
        setSearchQuery(checksummedInput || input);
    }, []);
    // if they input an address, use it
    const searchToken = (0,hooks_Tokens__WEBPACK_IMPORTED_MODULE_5__/* .useToken */ .dQ)(searchQuery);
    // all tokens for local list
    const userAddedTokens = (0,state_user_hooks_useUserAddedTokens__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
    const removeToken = (0,state_user_hooks__WEBPACK_IMPORTED_MODULE_6__/* .useRemoveUserAddedToken */ .QG)();
    const handleRemoveAll = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        if (chainId && userAddedTokens) {
            userAddedTokens.forEach((token)=>{
                return removeToken(chainId, token.address);
            });
        }
    }, [
        removeToken,
        userAddedTokens,
        chainId
    ]);
    const tokenList = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        return chainId && userAddedTokens.map((token)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(components_Layout_Row__WEBPACK_IMPORTED_MODULE_4__/* .RowBetween */ .m0, {
                width: "100%",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(components_Layout_Row__WEBPACK_IMPORTED_MODULE_4__/* .RowFixed */ .DA, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Logo__WEBPACK_IMPORTED_MODULE_8__/* .CurrencyLogo */ .Xw, {
                                currency: token,
                                size: "20px"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Link, {
                                external: true,
                                href: (0,utils__WEBPACK_IMPORTED_MODULE_9__/* .getBscScanLink */ .s6)(token.address, 'address', chainId),
                                color: "textSubtle",
                                ml: "10px",
                                children: token.symbol
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(components_Layout_Row__WEBPACK_IMPORTED_MODULE_4__/* .RowFixed */ .DA, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.IconButton, {
                                variant: "text",
                                onClick: ()=>removeToken(chainId, token.address)
                                ,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.CloseIcon, {})
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.LinkExternal, {
                                href: (0,utils__WEBPACK_IMPORTED_MODULE_9__/* .getBscScanLink */ .s6)(token.address, 'address', chainId)
                            })
                        ]
                    })
                ]
            }, token.address)
        );
    }, [
        userAddedTokens,
        chainId,
        removeToken
    ]);
    const isAddressValid = searchQuery === '' || (0,utils__WEBPACK_IMPORTED_MODULE_9__/* .isAddress */ .UJ)(searchQuery);
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Wrapper, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Layout_Column__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .ZP, {
            style: {
                width: '100%',
                flex: '1 1'
            },
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Layout_Column__WEBPACK_IMPORTED_MODULE_12__/* .AutoColumn */ .Tz, {
                    gap: "14px",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Layout_Row__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Input, {
                                id: "token-search-input",
                                scale: "lg",
                                placeholder: "0x0000",
                                value: searchQuery,
                                autoComplete: "off",
                                ref: inputRef,
                                onChange: handleInput,
                                isWarning: !isAddressValid
                            })
                        }),
                        !isAddressValid && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                            color: "failure",
                            children: t('Enter valid token address')
                        }),
                        searchToken && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ImportRow__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                            token: searchToken,
                            showImportView: ()=>setModalView(_types__WEBPACK_IMPORTED_MODULE_14__/* .CurrencyModalView.importToken */ .H.importToken)
                            ,
                            setImportToken: setImportToken,
                            style: {
                                height: 'fit-content'
                            }
                        })
                    ]
                }),
                tokenList,
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Footer, {
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                            bold: true,
                            color: "textSubtle",
                            children: [
                                userAddedTokens?.length,
                                " ",
                                userAddedTokens.length === 1 ? t('Custom Token') : t('Custom Tokens')
                            ]
                        }),
                        userAddedTokens.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                            variant: "tertiary",
                            onClick: handleRemoveAll,
                            children: t('Clear all')
                        })
                    ]
                })
            ]
        })
    }));
};

});

/***/ }),

/***/ 24963:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _state_wallet_hooks__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(71900);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_state_wallet_hooks__WEBPACK_IMPORTED_MODULE_1__]);
_state_wallet_hooks__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];


// compare two token amounts with highest one coming first
function balanceComparator(balanceA, balanceB) {
    if (balanceA && balanceB) {
        return balanceA.greaterThan(balanceB) ? -1 : balanceA.equalTo(balanceB) ? 0 : 1;
    }
    if (balanceA && balanceA.greaterThan('0')) {
        return -1;
    }
    if (balanceB && balanceB.greaterThan('0')) {
        return 1;
    }
    return 0;
}
function getTokenComparator(balances) {
    return function sortTokens(tokenA, tokenB) {
        // -1 = a is first
        // 1 = b is first
        // sort by balances
        const balanceA = balances[tokenA.address];
        const balanceB = balances[tokenB.address];
        const balanceComp = balanceComparator(balanceA, balanceB);
        if (balanceComp !== 0) return balanceComp;
        if (tokenA.symbol && tokenB.symbol) {
            // sort by symbol
            return tokenA.symbol.toLowerCase() < tokenB.symbol.toLowerCase() ? -1 : 1;
        }
        return tokenA.symbol ? -1 : tokenB.symbol ? -1 : 0;
    };
}
function useTokenComparator(inverted) {
    const balances = (0,_state_wallet_hooks__WEBPACK_IMPORTED_MODULE_1__/* .useAllTokenBalances */ .uD)();
    const comparator = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>getTokenComparator(balances ?? {})
    , [
        balances
    ]);
    return (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        if (inverted) {
            return (tokenA, tokenB)=>comparator(tokenA, tokenB) * -1
            ;
        }
        return comparator;
    }, [
        inverted,
        comparator
    ]);
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useTokenComparator);

});

/***/ }),

/***/ 18357:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C": () => (/* binding */ getSwapSound)
/* harmony export */ });
let swapSound;
const getSwapSound = ()=>{
    if (!swapSound) {
        swapSound = new Audio('swap.mp3');
    }
    return swapSound;
};


/***/ }),

/***/ 40330:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "H": () => (/* binding */ CurrencyModalView)
/* harmony export */ });
var CurrencyModalView;
(function(CurrencyModalView) {
    CurrencyModalView[CurrencyModalView["search"] = 0] = "search";
    CurrencyModalView[CurrencyModalView["manage"] = 1] = "manage";
    CurrencyModalView[CurrencyModalView["importToken"] = 2] = "importToken";
    CurrencyModalView[CurrencyModalView["importList"] = 3] = "importList";
})(CurrencyModalView || (CurrencyModalView = {}));
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (CurrencyModalView)));


/***/ }),

/***/ 6199:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

/**
 * Returns the previous value of the given value
 *
 * @see https://reactjs.org/docs/hooks-faq.html#how-to-get-the-previous-props-or-state
 */ const usePreviousValue = (value)=>{
    const ref = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        ref.current = value;
    }, [
        value
    ]);
    return ref.current;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (usePreviousValue);


/***/ })

};
;
//# sourceMappingURL=1721.js.map