"use strict";
exports.id = 1982;
exports.ids = [1982];
exports.modules = {

/***/ 8080:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const Loading = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
    componentId: "sc-57089fde-0"
})`
  border: 8px solid #f3f3f3;
  border-radius: 50%;
  border-top: 8px solid #ddd;
  border-bottom: 8px solid #ddd;
  width: 20px;
  height: 20px;
  -webkit-animation: spin 2s linear infinite;
  animation: spin 2s linear infinite;
  @-webkit-keyframes spin {
    0% {
      -webkit-transform: rotate(0deg);
    }
    100% {
      -webkit-transform: rotate(360deg);
    }
  }

  @keyframes spin {
    0% {
      transform: rotate(0deg);
    }
    100% {
      transform: rotate(360deg);
    }
  }
`;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Loading);


/***/ }),

/***/ 14450:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* reexport */ SearchInput_SearchInput)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
// EXTERNAL MODULE: external "@pancakeswap/uikit"
var uikit_ = __webpack_require__(2829);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(57518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: external "lodash/debounce"
var debounce_ = __webpack_require__(93908);
var debounce_default = /*#__PURE__*/__webpack_require__.n(debounce_);
// EXTERNAL MODULE: ./src/contexts/Localization/index.tsx + 3 modules
var Localization = __webpack_require__(99150);
;// CONCATENATED MODULE: ./src/components/SearchInput/SearchInput.tsx






const StyledInput = external_styled_components_default()(uikit_.Input).withConfig({
    componentId: "sc-1edb0dfa-0"
})`
  border-radius: 16px;
  margin-left: auto;
`;
const InputWrapper = external_styled_components_default().div.withConfig({
    componentId: "sc-1edb0dfa-1"
})`
  position: relative;
  ${({ theme  })=>theme.mediaQueries.sm
} {
    display: block;
  }
`;
const SearchInput = ({ onChange: onChangeCallback , placeholder ='Search'  })=>{
    const { 0: searchText , 1: setSearchText  } = (0,external_react_.useState)('');
    const { t  } = (0,Localization/* useTranslation */.$G)();
    const debouncedOnChange = (0,external_react_.useMemo)(()=>debounce_default()((e)=>onChangeCallback(e)
        , 500)
    , [
        onChangeCallback
    ]);
    const onChange = (e)=>{
        setSearchText(e.target.value);
        debouncedOnChange(e);
    };
    return(/*#__PURE__*/ jsx_runtime_.jsx(InputWrapper, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(StyledInput, {
            value: searchText,
            onChange: onChange,
            placeholder: t(placeholder)
        })
    }));
};
/* harmony default export */ const SearchInput_SearchInput = (SearchInput);

;// CONCATENATED MODULE: ./src/components/SearchInput/index.ts



/***/ }),

/***/ 30798:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

/**
 * Use this hook when you want to animate something when it appears on the screen (e.g. when some prop set to true)
 * but when its not on the screen you want it to be fully unmounted and not just hidden or height 0.
 * This is especially useful when you have a table of 100s rows and each row has expandable element that appears on click.
 * If you just set the expanding animation while keeping inactive elements mounted all those 100 elements will load the DOM,
 * and if they all receive updates via props you're looking at 100 DOM updates for hidden elements.
 * This hook "shows" element immediately when the isMounted is true
 * but keeps element mounted for delayTime to let unmounting animation happen, after which you unmount element completely.
 * delayTime should be the same as animation time in most cases.
 */ const useDelayedUnmount = (isMounted, delayTime)=>{
    const { 0: shouldRender , 1: setShouldRender  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        let timeoutId;
        if (isMounted && !shouldRender) {
            setShouldRender(true);
        } else if (!isMounted && shouldRender) {
            timeoutId = setTimeout(()=>setShouldRender(false)
            , delayTime);
        }
        return ()=>clearTimeout(timeoutId)
        ;
    }, [
        isMounted,
        delayTime,
        shouldRender
    ]);
    return shouldRender;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useDelayedUnmount);


/***/ }),

/***/ 11438:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "b": () => (/* binding */ latinise)
/* harmony export */ });
/* unused harmony export Latinise */
const Latinise = {
    latin_map: {
        τ: 't',
        Τ: 'T'
    }
};
const latinise = (input)=>{
    return input.replace(/[^A-Za-z0-9[\] ]/g, (x)=>Latinise.latin_map[x] || x
    );
};


/***/ })

};
;
//# sourceMappingURL=1982.js.map