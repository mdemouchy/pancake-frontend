"use strict";
exports.id = 941;
exports.ids = [941];
exports.modules = {

/***/ 1529:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var components_Layout_Container__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(55027);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(99150);






const StyledHero = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Box).withConfig({
    componentId: "sc-b5e63b48-0"
})`
  background-image: url('/images/ifos/assets/ifo-banner-${({ theme  })=>theme.isDark ? 'dark' : 'light'
}.png');
  background-position: top, center;
  background-repeat: no-repeat;
  background-size: auto 100%;
`;
const StyledHeading = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Heading).withConfig({
    componentId: "sc-b5e63b48-1"
})`
  font-size: 40px;

  ${({ theme  })=>theme.mediaQueries.md
} {
    font-size: 64px;
  }
`;
const StyledButton = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Button).withConfig({
    componentId: "sc-b5e63b48-2"
})`
  background-color: ${({ theme  })=>theme.colors.tertiary
};
  color: ${({ theme  })=>theme.colors.primary
};
  padding: 4px 13px;
  height: auto;
  text-transform: uppercase;
  align-self: flex-start;
  font-size: 12px;
  box-shadow: ${({ theme  })=>theme.shadows.inset
};
  border-radius: 8px;
  margin-left: 8px;
`;
const DesktopButton = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Button).withConfig({
    componentId: "sc-b5e63b48-3"
})`
  align-self: flex-end;
`;
const StyledSubTitle = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text).withConfig({
    componentId: "sc-b5e63b48-4"
})`
  font-size: 16px;

  ${({ theme  })=>theme.mediaQueries.md
} {
    font-size: 20px;
  }
`;
const Hero = ()=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_5__/* .useTranslation */ .$G)();
    const { isMobile  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.useMatchBreakpoints)();
    const handleClick = ()=>{
        document.getElementById('ifo-how-to')?.scrollIntoView();
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Box, {
        mb: "8px",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledHero, {
            py: [
                '16px',
                '16px',
                '32px'
            ],
            minHeight: [
                '212px',
                '212px',
                '197px'
            ],
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Layout_Container__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                    justifyContent: "space-between",
                    flexDirection: [
                        'column',
                        'column',
                        'column',
                        'row'
                    ],
                    style: {
                        gap: '4px'
                    },
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Box, {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledHeading, {
                                    as: "h1",
                                    mb: [
                                        '12px',
                                        '12px',
                                        '16px'
                                    ],
                                    children: t('IFO: Initial Farm Offerings')
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(StyledSubTitle, {
                                    bold: true,
                                    children: [
                                        t('Buy new tokens launching on Binance Smart Chain'),
                                        isMobile && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledButton, {
                                            onClick: handleClick,
                                            children: t('How does it work?')
                                        })
                                    ]
                                })
                            ]
                        }),
                        !isMobile && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(DesktopButton, {
                            onClick: handleClick,
                            variant: "subtle",
                            children: t('How does it work?')
                        })
                    ]
                })
            })
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Hero);


/***/ }),

/***/ 63771:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var config_constants_tokens__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(29748);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(99150);
/* harmony import */ var utils_bigNumber__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(35128);
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(38328);
/* harmony import */ var utils_formatBalance__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(65044);
/* harmony import */ var components_Layout_Flex__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(40508);










const SmartContractIcon = (props)=>{
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Svg, {
        viewBox: "0 0 25 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        ...props,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M10.037 6a.75.75 0 000 1.5h7.5a.75.75 0 000-1.5h-7.5zM9.287 9.75a.75.75 0 01.75-.75h7.5a.75.75 0 010 1.5h-7.5a.75.75 0 01-.75-.75zM10.037 12a.75.75 0 000 1.5h7.5a.75.75 0 000-1.5h-7.5z"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M5.287 4a2 2 0 012-2h13a2 2 0 012 2v15c0 1.66-1.34 3-3 3h-14c-1.66 0-3-1.34-3-3v-2c0-.55.45-1 1-1h2V4zm0 16h11v-2h-12v1c0 .55.45 1 1 1zm14 0c.55 0 1-.45 1-1V4h-13v12h10c.55 0 1 .45 1 1v2c0 .55.45 1 1 1z"
            })
        ]
    }));
};
const FIXED_MIN_DOLLAR_FOR_ACHIEVEMENT = utils_bigNumber__WEBPACK_IMPORTED_MODULE_6__/* .BIG_TEN */ .xp;
const Container = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex).withConfig({
    componentId: "sc-aadcf501-0"
})`
  justify-content: space-between;
  flex-direction: column;
  align-items: center;
  text-align: left;
  gap: 16px;

  ${({ theme  })=>theme.mediaQueries.md
} {
    flex-direction: row;
    align-items: initial;
  }
`;
const AchievementFlex = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex).withConfig({
    componentId: "sc-aadcf501-1"
})`
  ${({ isFinished  })=>isFinished ? 'filter: grayscale(100%)' : ''
};
  text-align: left;
`;
const InlinePrize = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex).withConfig({
    componentId: "sc-aadcf501-2"
})`
  display: inline-flex;
  vertical-align: top;
`;
const IfoAchievement = ({ ifo , publicIfoData  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_5__/* .useTranslation */ .$G)();
    const tokenName = ifo.token.symbol?.toLowerCase();
    const campaignTitle = ifo.name;
    const minLpForAchievement = publicIfoData.thresholdPoints ? (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_8__/* .formatBigNumber */ .dp)(publicIfoData.thresholdPoints, 3) : FIXED_MIN_DOLLAR_FOR_ACHIEVEMENT.div(publicIfoData.currencyPriceInUSD).toNumber().toFixed(3);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Container, {
        p: "16px",
        pb: "32px",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(AchievementFlex, {
                isFinished: publicIfoData.status === 'finished',
                alignItems: "flex-start",
                flex: 1,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Image, {
                        src: `/images/achievements/ifo-${tokenName}.svg`,
                        width: 56,
                        height: 56,
                        mr: "8px"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                        flexDirection: "column",
                        ml: "8px",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                color: "secondary",
                                fontSize: "12px",
                                children: `${t('Achievement')}:`
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                    bold: true,
                                    mr: "8px",
                                    lineHeight: 1.2,
                                    children: [
                                        t('IFO Shopper: %title%', {
                                            title: campaignTitle
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(InlinePrize, {
                                            alignItems: "center",
                                            ml: "8px",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.PrizeIcon, {
                                                    color: "textSubtle",
                                                    width: "16px",
                                                    mr: "4px"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                                    lineHeight: 1.2,
                                                    color: "textSubtle",
                                                    children: publicIfoData.numberPoints
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            publicIfoData.currencyPriceInUSD.gt(0) ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                color: "textSubtle",
                                fontSize: "12px",
                                children: t('Commit ~%amount% %symbol% in total to earn!', {
                                    amount: minLpForAchievement,
                                    symbol: ifo.currency === config_constants_tokens__WEBPACK_IMPORTED_MODULE_4__/* ["default"].cake */ .ZP.cake ? 'CAKE' : 'LP'
                                })
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Skeleton, {
                                minHeight: 18,
                                width: 80
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(components_Layout_Flex__WEBPACK_IMPORTED_MODULE_9__/* .FlexGap */ .O, {
                                gap: "16px",
                                pt: "24px",
                                pl: "4px",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Link, {
                                        external: true,
                                        href: ifo.articleUrl,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.LanguageIcon, {
                                            color: "textSubtle"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Link, {
                                        external: true,
                                        href: (0,utils__WEBPACK_IMPORTED_MODULE_7__/* .getBscScanLink */ .s6)(ifo.address, 'address'),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SmartContractIcon, {
                                            color: "textSubtle"
                                        })
                                    }),
                                    ifo.twitterUrl && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Link, {
                                        external: true,
                                        href: ifo.twitterUrl,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.TwitterIcon, {
                                            color: "textSubtle"
                                        })
                                    }),
                                    ifo.telegramUrl && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Link, {
                                        external: true,
                                        href: ifo.telegramUrl,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.TelegramIcon, {
                                            color: "textSubtle"
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            ifo.description && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                alignItems: "flex-end",
                flexDirection: "column",
                flex: 1,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                    fontSize: "14px",
                    lineHeight: 1.2,
                    style: {
                        whiteSpace: 'pre-line'
                    },
                    children: ifo.description
                })
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (IfoAchievement);


/***/ }),

/***/ 4648:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var config_constants_types__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(97971);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99150);
/* harmony import */ var hooks_useToast__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(789);
/* harmony import */ var components_Toast__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(63937);
/* harmony import */ var utils_sentry__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(17226);








const ClaimButton = ({ poolId , ifoVersion , walletIfoData  })=>{
    const userPoolCharacteristics = walletIfoData[poolId];
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    const { toastError , toastSuccess  } = (0,hooks_useToast__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)();
    const setPendingTx = (isPending)=>walletIfoData.setPendingTx(isPending, poolId)
    ;
    const handleClaim = async ()=>{
        try {
            setPendingTx(true);
            const tx = ifoVersion === 1 ? await walletIfoData.contract.harvest() : await walletIfoData.contract.harvestPool(poolId === config_constants_types__WEBPACK_IMPORTED_MODULE_3__/* .PoolIds.poolBasic */ .vr.poolBasic ? 0 : 1);
            toastSuccess(`${t('Transaction Submitted')}!`, /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_6__/* .ToastDescriptionWithTx */ .YO, {
                txHash: tx.hash
            }));
            const receipt = await tx.wait();
            const txHash = receipt.transactionHash;
            walletIfoData.setIsClaimed(poolId);
            toastSuccess(t('Success!'), /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_6__/* .ToastDescriptionWithTx */ .YO, {
                txHash: txHash,
                children: t('You have successfully claimed your rewards.')
            }));
        } catch (error) {
            toastError(t('Error'), t('Please try again. Confirm the transaction and make sure you are paying enough gas!'));
            (0,utils_sentry__WEBPACK_IMPORTED_MODULE_7__/* .logError */ .H)(error);
        } finally{
            setPendingTx(false);
        }
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
        onClick: handleClaim,
        disabled: userPoolCharacteristics.isPendingTx,
        width: "100%",
        isLoading: userPoolCharacteristics.isPendingTx,
        endIcon: userPoolCharacteristics.isPendingTx ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.AutoRenewIcon, {
            spin: true,
            color: "currentColor"
        }) : null,
        children: t('Claim')
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ClaimButton);


/***/ }),

/***/ 54894:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var state_block_hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(37063);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var utils_formatBalance__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(65044);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(99150);
/* harmony import */ var hooks_useTokenBalance__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(24319);
/* harmony import */ var hooks_useToast__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(789);
/* harmony import */ var components_Toast__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(63937);
/* harmony import */ var _GetTokenModal__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(24596);
/* harmony import */ var _ContributeModal__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(42002);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_ContributeModal__WEBPACK_IMPORTED_MODULE_10__, hooks_useTokenBalance__WEBPACK_IMPORTED_MODULE_6__, state_block_hooks__WEBPACK_IMPORTED_MODULE_2__]);
([_ContributeModal__WEBPACK_IMPORTED_MODULE_10__, hooks_useTokenBalance__WEBPACK_IMPORTED_MODULE_6__, state_block_hooks__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);











const ContributeButton = ({ poolId , ifo , publicIfoData , walletIfoData  })=>{
    const publicPoolCharacteristics = publicIfoData[poolId];
    const userPoolCharacteristics = walletIfoData[poolId];
    const { isPendingTx , amountTokenCommittedInLP  } = userPoolCharacteristics;
    const { limitPerUserInLP  } = publicPoolCharacteristics;
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_5__/* .useTranslation */ .$G)();
    const { toastSuccess  } = (0,hooks_useToast__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
    const currentBlock = (0,state_block_hooks__WEBPACK_IMPORTED_MODULE_2__/* .useCurrentBlock */ .je)();
    const { balance: userCurrencyBalance  } = (0,hooks_useTokenBalance__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .ZP)(ifo.currency.address);
    // Refetch all the data, and display a message when fetching is done
    const handleContributeSuccess = async (amount, txHash)=>{
        await Promise.all([
            publicIfoData.fetchIfoData(currentBlock),
            walletIfoData.fetchIfoData()
        ]);
        toastSuccess(t('Success!'), /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_8__/* .ToastDescriptionWithTx */ .YO, {
            txHash: txHash,
            children: t('You have contributed %amount% CAKE to this IFO!', {
                amount: (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_4__/* .getBalanceNumber */ .mW)(amount)
            })
        }));
    };
    const [onPresentContributeModal] = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.useModal)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ContributeModal__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
        poolId: poolId,
        creditLeft: walletIfoData.ifoCredit?.creditLeft,
        ifo: ifo,
        publicIfoData: publicIfoData,
        walletIfoData: walletIfoData,
        onSuccess: handleContributeSuccess,
        userCurrencyBalance: userCurrencyBalance
    }), false);
    const [onPresentGetTokenModal] = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.useModal)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_GetTokenModal__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
        currency: ifo.currency
    }), false);
    const isMaxCommitted = walletIfoData.ifoCredit?.creditLeft && walletIfoData.ifoCredit?.creditLeft.isLessThanOrEqualTo(0) || limitPerUserInLP.isGreaterThan(0) && amountTokenCommittedInLP.isGreaterThanOrEqualTo(limitPerUserInLP);
    const isDisabled = isPendingTx || isMaxCommitted || publicIfoData.status !== 'live';
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Button, {
        onClick: userCurrencyBalance.isEqualTo(0) ? onPresentGetTokenModal : onPresentContributeModal,
        width: "100%",
        disabled: isDisabled,
        children: isMaxCommitted && publicIfoData.status === 'live' ? t('Max. Committed') : t('Commit CAKE')
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ContributeButton);

});

/***/ }),

/***/ 42002:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(18054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(34215);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(bignumber_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _ethersproject_constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(26644);
/* harmony import */ var _ethersproject_constants__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_constants__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _ethersproject_units__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(93138);
/* harmony import */ var _ethersproject_units__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_units__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var config_constants_types__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(97971);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(99150);
/* harmony import */ var utils_formatBalance__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(65044);
/* harmony import */ var components_ApproveConfirmButtons__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(75673);
/* harmony import */ var components_Toast__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(63937);
/* harmony import */ var hooks_useApproveConfirmTransaction__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(67218);
/* harmony import */ var hooks_useCallWithGasPrice__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(71228);
/* harmony import */ var hooks_useToast__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(789);
/* harmony import */ var config__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(33206);
/* harmony import */ var hooks_useContract__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(46063);
/* harmony import */ var config_constants_tokens__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(29748);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks_useCallWithGasPrice__WEBPACK_IMPORTED_MODULE_13__]);
hooks_useCallWithGasPrice__WEBPACK_IMPORTED_MODULE_13__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];


















const multiplierValues = [
    0.1,
    0.25,
    0.5,
    0.75,
    1
];
// Default value for transaction setting, tweak based on BSC network congestion.
const gasPrice = (0,_ethersproject_units__WEBPACK_IMPORTED_MODULE_5__.parseUnits)('10', 'gwei').toString();
const SmallAmountNotice = ()=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_8__/* .useTranslation */ .$G)();
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Box, {
        maxWidth: "350px",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Message, {
            variant: "warning",
            mb: "16px",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.MessageText, {
                children: t('If the amount you commit is too small, you may not receive a meaningful amount of IFO tokens.')
            })
        })
    }));
};
const ContributeModal = ({ poolId , ifo , publicIfoData , walletIfoData , userCurrencyBalance , creditLeft , onDismiss , onSuccess ,  })=>{
    const publicPoolCharacteristics = publicIfoData[poolId];
    const userPoolCharacteristics = walletIfoData[poolId];
    const { currency  } = ifo;
    const { toastSuccess  } = (0,hooks_useToast__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z)();
    const { limitPerUserInLP  } = publicPoolCharacteristics;
    const { amountTokenCommittedInLP  } = userPoolCharacteristics;
    const { contract  } = walletIfoData;
    const { 0: value , 1: setValue  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_2__.useWeb3React)();
    const { callWithGasPrice  } = (0,hooks_useCallWithGasPrice__WEBPACK_IMPORTED_MODULE_13__/* .useCallWithGasPrice */ .d)();
    const raisingTokenContractReader = (0,hooks_useContract__WEBPACK_IMPORTED_MODULE_16__/* .useERC20 */ .X_)(currency.address, false);
    const raisingTokenContractApprover = (0,hooks_useContract__WEBPACK_IMPORTED_MODULE_16__/* .useERC20 */ .X_)(currency.address);
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_8__/* .useTranslation */ .$G)();
    const valueWithTokenDecimals = new (bignumber_js__WEBPACK_IMPORTED_MODULE_3___default())(value).times(config__WEBPACK_IMPORTED_MODULE_15__/* .DEFAULT_TOKEN_DECIMAL */ .o3);
    const label = currency === config_constants_tokens__WEBPACK_IMPORTED_MODULE_17__/* ["default"].cake */ .ZP.cake ? t('Max. CAKE entry') : t('Max. token entry');
    const { isApproving , isApproved , isConfirmed , isConfirming , handleApprove , handleConfirm  } = (0,hooks_useApproveConfirmTransaction__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z)({
        onRequiresApproval: async ()=>{
            try {
                const response = await raisingTokenContractReader.allowance(account, contract.address);
                const currentAllowance = new (bignumber_js__WEBPACK_IMPORTED_MODULE_3___default())(response.toString());
                return currentAllowance.gt(0);
            } catch (error) {
                return false;
            }
        },
        onApprove: ()=>{
            return callWithGasPrice(raisingTokenContractApprover, 'approve', [
                contract.address,
                _ethersproject_constants__WEBPACK_IMPORTED_MODULE_4__.MaxUint256
            ], {
                gasPrice
            });
        },
        onApproveSuccess: ({ receipt  })=>{
            toastSuccess(t('Successfully Enabled!'), /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_11__/* .ToastDescriptionWithTx */ .YO, {
                txHash: receipt.transactionHash,
                children: t('You can now participate in the %symbol% IFO.', {
                    symbol: ifo.token.symbol
                })
            }));
        },
        onConfirm: ()=>{
            return callWithGasPrice(contract, 'depositPool', [
                valueWithTokenDecimals.toString(),
                poolId === config_constants_types__WEBPACK_IMPORTED_MODULE_7__/* .PoolIds.poolBasic */ .vr.poolBasic ? 0 : 1
            ], {
                gasPrice
            });
        },
        onSuccess: async ({ receipt  })=>{
            await onSuccess(valueWithTokenDecimals, receipt.transactionHash);
            onDismiss();
        }
    });
    // in v3 max token entry is based on ifo credit and hard cap limit per user minus amount already committed
    const maximumTokenEntry = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        if (!creditLeft) {
            return limitPerUserInLP.minus(amountTokenCommittedInLP);
        }
        if (limitPerUserInLP.isGreaterThan(0)) {
            if (limitPerUserInLP.isGreaterThan(0)) {
                return limitPerUserInLP.minus(amountTokenCommittedInLP).isLessThanOrEqualTo(creditLeft) ? limitPerUserInLP.minus(amountTokenCommittedInLP) : creditLeft;
            }
        }
        return creditLeft;
    }, [
        creditLeft,
        limitPerUserInLP,
        amountTokenCommittedInLP
    ]);
    // include user balance for input
    const maximumTokenCommittable = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        return maximumTokenEntry.isLessThanOrEqualTo(userCurrencyBalance) ? maximumTokenEntry : userCurrencyBalance;
    }, [
        maximumTokenEntry,
        userCurrencyBalance
    ]);
    const { targetRef , tooltip , tooltipVisible  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.useTooltip)(poolId === config_constants_types__WEBPACK_IMPORTED_MODULE_7__/* .PoolIds.poolBasic */ .vr.poolBasic ? t('For the basic sale, Max CAKE entry is capped by minimum between your average CAKE balance in the IFO CAKE pool, or the pool’s hard cap. To increase the max entry, Stake more CAKE into the IFO CAKE pool') : t('For the unlimited sale, Max CAKE entry is capped by your average CAKE balance in the IFO CAKE pool. To increase the max entry, Stake more CAKE into the IFO CAKE pool'), {});
    const isWarning = valueWithTokenDecimals.isGreaterThan(userCurrencyBalance) || valueWithTokenDecimals.isGreaterThan(maximumTokenEntry);
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Modal, {
        title: t('Contribute %symbol%', {
            symbol: currency.symbol
        }),
        onDismiss: onDismiss,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.ModalBody, {
            maxWidth: "360px",
            children: [
                poolId === config_constants_types__WEBPACK_IMPORTED_MODULE_7__/* .PoolIds.poolUnlimited */ .vr.poolUnlimited && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SmallAmountNotice, {}),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Box, {
                    p: "2px",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Flex, {
                            justifyContent: "space-between",
                            mb: "16px",
                            children: [
                                tooltipVisible && tooltip,
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.TooltipText, {
                                    ref: targetRef,
                                    children: [
                                        label,
                                        ":"
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Text, {
                                    children: `${(0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_9__/* .formatNumber */ .uf)((0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_9__/* .getBalanceAmount */ .U4)(maximumTokenEntry, currency.decimals).toNumber(), 3, 3)} ${ifo.currency.symbol}`
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Flex, {
                            justifyContent: "space-between",
                            mb: "8px",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Text, {
                                    children: [
                                        t('Commit'),
                                        ":"
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Flex, {
                                    flexGrow: 1,
                                    justifyContent: "flex-end",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Image, {
                                            src: ifo.currency.symbol === 'CAKE' ? '/images/cake.svg' : `/images/farms/${currency.symbol.split(' ')[0].toLocaleLowerCase()}.svg`,
                                            width: 24,
                                            height: 24
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Text, {
                                            ml: "4px",
                                            children: currency.symbol
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.BalanceInput, {
                            value: value,
                            currencyValue: `${publicIfoData.currencyPriceInUSD.times(value || 0).toFixed(2)} USD`,
                            onUserInput: setValue,
                            isWarning: isWarning,
                            decimals: currency.decimals,
                            onBlur: ()=>{
                                if (isWarning) {
                                    // auto adjust to max value
                                    setValue((0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_9__/* .getBalanceAmount */ .U4)(maximumTokenCommittable).toString());
                                }
                            },
                            mb: "8px"
                        }),
                        isWarning && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Text, {
                            color: valueWithTokenDecimals.isGreaterThan(userCurrencyBalance) ? 'failure' : 'warning',
                            textAlign: "right",
                            fontSize: "12px",
                            mb: "8px",
                            children: valueWithTokenDecimals.isGreaterThan(userCurrencyBalance) ? t('Insufficient Balance') : t('Exceeded max CAKE entry')
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Text, {
                            color: "textSubtle",
                            textAlign: "right",
                            fontSize: "12px",
                            mb: "16px",
                            children: t('Balance: %balance%', {
                                balance: (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_9__/* .getBalanceAmount */ .U4)(userCurrencyBalance, currency.decimals).toString()
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Flex, {
                            justifyContent: "space-between",
                            mb: "16px",
                            children: multiplierValues.map((multiplierValue, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Button, {
                                    scale: "xs",
                                    variant: "tertiary",
                                    onClick: ()=>setValue((0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_9__/* .getBalanceAmount */ .U4)(maximumTokenCommittable.times(multiplierValue)).toString())
                                    ,
                                    mr: index < multiplierValues.length - 1 ? '8px' : 0,
                                    children: [
                                        multiplierValue * 100,
                                        "%"
                                    ]
                                }, multiplierValue)
                            )
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Text, {
                            color: "textSubtle",
                            fontSize: "12px",
                            mb: "24px",
                            children: [
                                t('If you don’t commit enough CAKE, you may not receive any IFO tokens at all and will only receive a full refund of your CAKE.'),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_6__.Link, {
                                    fontSize: "12px",
                                    display: "inline",
                                    href: "https://docs.pancakeswap.finance/products/ifo-initial-farm-offering",
                                    external: true,
                                    children: t('Read more')
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_ApproveConfirmButtons__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                            isApproveDisabled: isConfirmed || isConfirming || isApproved,
                            isApproving: isApproving,
                            isConfirmDisabled: !isApproved || isConfirmed || valueWithTokenDecimals.isNaN() || valueWithTokenDecimals.eq(0) || isWarning,
                            isConfirming: isConfirming,
                            onApprove: handleApprove,
                            onConfirm: handleConfirm
                        })
                    ]
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ContributeModal);

});

/***/ }),

/***/ 24596:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(99150);




const GetTokenModal = ({ currency , onDismiss  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_3__/* .useTranslation */ .$G)();
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Modal, {
        title: t('%symbol% required', {
            symbol: currency.symbol
        }),
        onDismiss: onDismiss,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.ModalBody, {
            maxWidth: "288px",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Image, {
                    src: `/images/tokens/${currency.address}.svg`,
                    width: 72,
                    height: 72,
                    margin: "auto",
                    mb: "24px"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                    mb: "16px",
                    children: t('You’ll need %symbol% tokens to participate in the IFO!', {
                        symbol: currency.symbol
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                    mb: "24px",
                    children: t('Get %symbol%, or make sure your tokens aren’t staked somewhere else.', {
                        symbol: currency.symbol
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                    as: _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Link,
                    external: true,
                    href: `/swap?outputCurrency=${currency.address}`,
                    endIcon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.OpenNewIcon, {
                        color: "white"
                    }),
                    minWidth: "100%" // Bypass the width="fit-content" on Links
                    ,
                    children: t('Get %symbol%', {
                        symbol: currency.symbol
                    })
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (GetTokenModal);


/***/ }),

/***/ 88342:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(99150);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(18054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var components_NextLink__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(53629);
/* harmony import */ var components_ConnectWalletButton__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(30621);
/* harmony import */ var _ContributeButton__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(54894);
/* harmony import */ var _ClaimButton__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4648);
/* harmony import */ var _Skeletons__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(17236);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_ContributeButton__WEBPACK_IMPORTED_MODULE_7__]);
_ContributeButton__WEBPACK_IMPORTED_MODULE_7__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];










const IfoCardActions = ({ poolId , ifo , publicIfoData , walletIfoData , hasProfile , isLoading  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_2__/* .useTranslation */ .$G)();
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_4__.useWeb3React)();
    const userPoolCharacteristics = walletIfoData[poolId];
    if (isLoading) {
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Skeletons__WEBPACK_IMPORTED_MODULE_9__/* .SkeletonCardActions */ .r0, {}));
    }
    if (!account) {
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_ConnectWalletButton__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
            width: "100%"
        }));
    }
    if (!hasProfile) {
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Button, {
            as: components_NextLink__WEBPACK_IMPORTED_MODULE_5__/* .NextLinkFromReactRouter */ .a,
            to: `/profile/${account.toLowerCase()}`,
            width: "100%",
            children: t('Activate your Profile')
        }));
    }
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            (publicIfoData.status === 'live' || publicIfoData.status === 'coming_soon') && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ContributeButton__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                poolId: poolId,
                ifo: ifo,
                publicIfoData: publicIfoData,
                walletIfoData: walletIfoData
            }),
            publicIfoData.status === 'finished' && !userPoolCharacteristics.hasClaimed && (userPoolCharacteristics.offeringAmountInToken.isGreaterThan(0) || userPoolCharacteristics.refundingAmountInLP.isGreaterThan(0)) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ClaimButton__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                poolId: poolId,
                ifoVersion: ifo.version,
                walletIfoData: walletIfoData
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (IfoCardActions);

});

/***/ }),

/***/ 18570:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var config_constants_tokens__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(29748);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99150);
/* harmony import */ var config_constants_types__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(97971);
/* harmony import */ var utils_formatBalance__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(65044);
/* harmony import */ var hooks_useBUSDPrice__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(90834);
/* harmony import */ var utils_prices__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7879);
/* harmony import */ var _Skeletons__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(17236);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks_useBUSDPrice__WEBPACK_IMPORTED_MODULE_7__]);
hooks_useBUSDPrice__WEBPACK_IMPORTED_MODULE_7__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];










const FooterEntry = ({ label , value  })=>{
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
        justifyContent: "space-between",
        alignItems: "center",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                small: true,
                color: "textSubtle",
                children: label
            }),
            value ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                small: true,
                textAlign: "right",
                children: value
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Skeleton, {
                height: 21,
                width: 80
            })
        ]
    }));
};
const MaxTokenEntry = ({ maxToken , ifo , poolId  })=>{
    const isCurrencyCake = ifo.currency === config_constants_tokens__WEBPACK_IMPORTED_MODULE_2__/* ["default"].cake */ .ZP.cake;
    const isV3 = ifo.version === 3;
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    const tooltipContent = poolId === config_constants_types__WEBPACK_IMPORTED_MODULE_5__/* .PoolIds.poolBasic */ .vr.poolBasic ? t('For the basic sale, Max CAKE entry is capped by minimum between your average CAKE balance in the IFO CAKE pool, or the pool’s hard cap. To increase the max entry, Stake more CAKE into the IFO CAKE pool') : t('For the unlimited sale, Max CAKE entry is capped by your average CAKE balance in the IFO CAKE pool. To increase the max entry, Stake more CAKE into the IFO CAKE pool');
    const { targetRef , tooltip , tooltipVisible  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.useTooltip)(tooltipContent, {
        placement: 'bottom-start'
    });
    const label = isCurrencyCake ? t('Max. CAKE entry') : t('Max. token entry');
    const price = (0,hooks_useBUSDPrice__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP)(ifo.currency);
    const dollarValueOfToken = (0,utils_prices__WEBPACK_IMPORTED_MODULE_8__/* .multiplyPriceByAmount */ .as)(price, maxToken, ifo.currency.decimals);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            isV3 && tooltipVisible && tooltip,
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FooterEntry, {
                label: isV3 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.TooltipText, {
                    small: true,
                    color: "textSubtle",
                    ref: targetRef,
                    children: label
                }) : label,
                value: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                    small: true,
                    textAlign: "right",
                    color: maxToken > 0 ? 'text' : 'failure',
                    children: `${(0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_6__/* .formatNumber */ .uf)(maxToken, 3, 3)} ${!isCurrencyCake ? ifo.currency.symbol : ''} ${` ~($${dollarValueOfToken.toFixed(0)})`}`
                })
            })
        ]
    }));
};
const IfoCardDetails = ({ poolId , ifo , publicIfoData , walletIfoData  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    const { status , currencyPriceInUSD  } = publicIfoData;
    const poolCharacteristic = publicIfoData[poolId];
    const walletCharacteristic = walletIfoData[poolId];
    let version3MaxTokens = walletIfoData.ifoCredit?.creditLeft ? walletIfoData.ifoCredit.creditLeft.gt(poolCharacteristic.limitPerUserInLP.minus(walletCharacteristic.amountTokenCommittedInLP)) ? poolCharacteristic.limitPerUserInLP.minus(walletCharacteristic.amountTokenCommittedInLP) : walletIfoData.ifoCredit.creditLeft : null;
    // unlimited pool just show the credit left
    version3MaxTokens = poolId === config_constants_types__WEBPACK_IMPORTED_MODULE_5__/* .PoolIds.poolUnlimited */ .vr.poolUnlimited ? walletIfoData.ifoCredit?.creditLeft : version3MaxTokens;
    /* Format start */ const maxLpTokens = ifo.version === 3 && ifo.isActive ? version3MaxTokens ? (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_6__/* .getBalanceNumber */ .mW)(version3MaxTokens, ifo.currency.decimals) : 0 : (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_6__/* .getBalanceNumber */ .mW)(poolCharacteristic.limitPerUserInLP, ifo.currency.decimals);
    const taxRate = `${poolCharacteristic.taxRate}%`;
    const totalCommittedPercent = poolCharacteristic.totalAmountPool.div(poolCharacteristic.raisingAmountPool).times(100).toFixed(2);
    const totalLPCommitted = (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_6__/* .getBalanceNumber */ .mW)(poolCharacteristic.totalAmountPool, ifo.currency.decimals);
    const totalLPCommittedInUSD = currencyPriceInUSD.times(totalLPCommitted);
    const totalCommitted = `~$${(0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_6__/* .formatNumber */ .uf)(totalLPCommittedInUSD.toNumber(), 0, 0)} (${totalCommittedPercent}%)`;
    const sumTaxesOverflow = poolCharacteristic.totalAmountPool.times(poolCharacteristic.taxRate).times(0.01);
    const pricePerTokenWithFeeToOriginalRatio = sumTaxesOverflow.plus(poolCharacteristic.raisingAmountPool).div(poolCharacteristic.offeringAmountPool).div(poolCharacteristic.raisingAmountPool.div(poolCharacteristic.offeringAmountPool));
    const pricePerTokenWithFee = `~$${(0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_6__/* .formatNumber */ .uf)(pricePerTokenWithFeeToOriginalRatio.times(ifo.tokenOfferingPrice).toNumber(), 0, 2)}`;
    const tokenEntry = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(MaxTokenEntry, {
        poolId: poolId,
        ifo: ifo,
        maxToken: maxLpTokens
    });
    /* Format end */ const renderBasedOnIfoStatus = ()=>{
        if (status === 'coming_soon') {
            return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    tokenEntry,
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FooterEntry, {
                        label: t('Funds to raise:'),
                        value: ifo[poolId].raiseAmount
                    }),
                    ifo[poolId].cakeToBurn !== '$0' && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FooterEntry, {
                        label: t('CAKE to burn:'),
                        value: ifo[poolId].cakeToBurn
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FooterEntry, {
                        label: t('Price per %symbol%:', {
                            symbol: ifo.token.symbol
                        }),
                        value: `$${ifo.tokenOfferingPrice}`
                    })
                ]
            }));
        }
        if (status === 'live') {
            return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    tokenEntry,
                    poolId === config_constants_types__WEBPACK_IMPORTED_MODULE_5__/* .PoolIds.poolBasic */ .vr.poolBasic && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FooterEntry, {
                        label: t('Price per %symbol%:', {
                            symbol: ifo.token.symbol
                        }),
                        value: `$${ifo.tokenOfferingPrice}`
                    }),
                    poolId === config_constants_types__WEBPACK_IMPORTED_MODULE_5__/* .PoolIds.poolUnlimited */ .vr.poolUnlimited && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FooterEntry, {
                        label: t('Additional fee:'),
                        value: taxRate
                    }),
                    poolId === config_constants_types__WEBPACK_IMPORTED_MODULE_5__/* .PoolIds.poolUnlimited */ .vr.poolUnlimited && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FooterEntry, {
                        label: t('Price per %symbol% with fee:', {
                            symbol: ifo.token.symbol
                        }),
                        value: pricePerTokenWithFee
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FooterEntry, {
                        label: t('Total committed:'),
                        value: currencyPriceInUSD.gt(0) ? totalCommitted : null
                    })
                ]
            }));
        }
        if (status === 'finished') {
            return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    (poolId === config_constants_types__WEBPACK_IMPORTED_MODULE_5__/* .PoolIds.poolBasic */ .vr.poolBasic || ifo.isActive) && tokenEntry,
                    poolId === config_constants_types__WEBPACK_IMPORTED_MODULE_5__/* .PoolIds.poolUnlimited */ .vr.poolUnlimited && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FooterEntry, {
                        label: t('Additional fee:'),
                        value: taxRate
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FooterEntry, {
                        label: t('Total committed:'),
                        value: currencyPriceInUSD.gt(0) ? totalCommitted : null
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FooterEntry, {
                        label: t('Funds to raise:'),
                        value: ifo[poolId].raiseAmount
                    }),
                    ifo[poolId].cakeToBurn !== '$0' && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FooterEntry, {
                        label: t('CAKE to burn:'),
                        value: ifo[poolId].cakeToBurn
                    }),
                    ifo.version > 1 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FooterEntry, {
                        label: t('Price per %symbol%:', {
                            symbol: ifo.token.symbol
                        }),
                        value: `$${ifo.tokenOfferingPrice ? ifo.tokenOfferingPrice : '?'}`
                    }),
                    ifo.version > 1 && poolId === config_constants_types__WEBPACK_IMPORTED_MODULE_5__/* .PoolIds.poolUnlimited */ .vr.poolUnlimited && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FooterEntry, {
                        label: t('Price per %symbol% with fee:', {
                            symbol: ifo.token.symbol
                        }),
                        value: pricePerTokenWithFee
                    })
                ]
            }));
        }
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Skeletons__WEBPACK_IMPORTED_MODULE_9__/* .SkeletonCardDetails */ .X2, {}));
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Box, {
        paddingTop: "24px",
        children: renderBasedOnIfoStatus()
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (IfoCardDetails);

});

/***/ }),

/***/ 58068:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(34215);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(bignumber_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(18054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var config_constants_tokens__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(29748);
/* harmony import */ var config_constants_ifo__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(47829);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(99150);
/* harmony import */ var utils_formatBalance__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(65044);
/* harmony import */ var components_TokenImage__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(95239);
/* harmony import */ var views_Pools_components_CakeVaultCard_VaultStakeModal__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1799);
/* harmony import */ var state_pools_hooks__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1624);
/* harmony import */ var utils_bigNumber__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(35128);
/* harmony import */ var _types__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(81796);
/* harmony import */ var _PercentageOfTotal__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(71472);
/* harmony import */ var _Skeletons__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(17236);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([views_Pools_components_CakeVaultCard_VaultStakeModal__WEBPACK_IMPORTED_MODULE_11__, state_pools_hooks__WEBPACK_IMPORTED_MODULE_12__]);
([views_Pools_components_CakeVaultCard_VaultStakeModal__WEBPACK_IMPORTED_MODULE_11__, state_pools_hooks__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);

















const TokenSection = ({ primaryToken , secondaryToken , children , ...props })=>{
    const renderTokenComponent = ()=>{
        if (!primaryToken) {
            return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.BunnyPlaceholderIcon, {
                width: 32,
                mr: "16px"
            }));
        }
        if (primaryToken && secondaryToken) {
            return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_TokenImage__WEBPACK_IMPORTED_MODULE_10__/* .TokenPairImage */ .q, {
                variant: "inverted",
                primaryToken: primaryToken,
                height: 32,
                width: 32,
                secondaryToken: secondaryToken,
                mr: "16px"
            }));
        }
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_TokenImage__WEBPACK_IMPORTED_MODULE_10__/* .TokenImage */ .O, {
            token: primaryToken,
            height: 32,
            width: 32,
            mr: "16px"
        }));
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
        ...props,
        children: [
            renderTokenComponent(),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: children
            })
        ]
    }));
};
const CommitTokenSection = ({ commitToken , ...props })=>{
    if (commitToken.equals(config_constants_ifo__WEBPACK_IMPORTED_MODULE_7__/* .cakeBnbLpToken */ .b)) {
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TokenSection, {
            primaryToken: config_constants_tokens__WEBPACK_IMPORTED_MODULE_6__/* ["default"].cake */ .ZP.cake,
            secondaryToken: config_constants_tokens__WEBPACK_IMPORTED_MODULE_6__/* ["default"].wbnb */ .ZP.wbnb,
            ...props
        }));
    }
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TokenSection, {
        primaryToken: commitToken,
        ...props
    }));
};
const Label = (props)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
        bold: true,
        fontSize: "12px",
        color: "secondary",
        textTransform: "uppercase",
        ...props
    })
;
const Value = (props)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
        bold: true,
        fontSize: "20px",
        style: {
            wordBreak: 'break-all'
        },
        ...props
    })
;
const OnSaleInfo = ({ token , saleAmount , distributionRatio  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_8__/* .useTranslation */ .$G)();
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TokenSection, {
        primaryToken: token,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
            flexDirection: "column",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Label, {
                    children: t('On sale').toUpperCase()
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Value, {
                    children: saleAmount
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                    fontSize: "14px",
                    color: "textSubtle",
                    children: t('%ratio%% of total sale', {
                        ratio: distributionRatio
                    })
                })
            ]
        })
    }));
};
const MessageTextLink = styled_components__WEBPACK_IMPORTED_MODULE_4___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Link).withConfig({
    componentId: "sc-cd901642-0"
})`
  display: inline;
  text-decoration: underline;
  font-weight: bold;
  font-size: 14px;
  white-space: nowrap;
`;
const IfoCardTokens = ({ poolId , ifo , publicIfoData , walletIfoData , hasProfile , isLoading , onApprove , enableStatus ,  })=>{
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_5__.useWeb3React)();
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_8__/* .useTranslation */ .$G)();
    const { targetRef , tooltip , tooltipVisible  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.useTooltip)(t('Sorry, you didn’t contribute enough CAKE to meet the minimum threshold. You didn’t buy anything in this sale, but you can still reclaim your CAKE.'), {
        placement: 'bottom'
    });
    const publicPoolCharacteristics = publicIfoData[poolId];
    const userPoolCharacteristics = walletIfoData[poolId];
    const { currency , token  } = ifo;
    const { hasClaimed  } = userPoolCharacteristics;
    const distributionRatio = ifo[poolId].distributionRatio * 100;
    const ifoPoolVault = (0,state_pools_hooks__WEBPACK_IMPORTED_MODULE_12__/* .useIfoPoolVault */ .IK)();
    const { pool  } = (0,state_pools_hooks__WEBPACK_IMPORTED_MODULE_12__/* .useIfoWithApr */ .ix)();
    const credit = (0,state_pools_hooks__WEBPACK_IMPORTED_MODULE_12__/* .useIfoPoolCredit */ .Eo)();
    const stakingTokenBalance = pool?.userData?.stakingTokenBalance ? new (bignumber_js__WEBPACK_IMPORTED_MODULE_2___default())(pool.userData.stakingTokenBalance) : utils_bigNumber__WEBPACK_IMPORTED_MODULE_13__/* .BIG_ZERO */ .HW;
    const [onPresentStake] = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.useModal)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(views_Pools_components_CakeVaultCard_VaultStakeModal__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
        stakingMax: stakingTokenBalance,
        performanceFee: ifoPoolVault.fees.performanceFeeAsDecimal,
        pool: pool
    }));
    const renderTokenSection = ()=>{
        if (isLoading) {
            return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Skeletons__WEBPACK_IMPORTED_MODULE_16__/* .SkeletonCardTokens */ .cL, {}));
        }
        if (!account) {
            return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(OnSaleInfo, {
                token: token,
                distributionRatio: distributionRatio,
                saleAmount: ifo[poolId].saleAmount
            }));
        }
        let message;
        if (account && !hasProfile) {
            message = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Message, {
                my: "24px",
                p: "8px",
                variant: "warning",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Box, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.MessageText, {
                            display: "inline",
                            children: publicIfoData.status === 'finished' ? t('Activate PancakeSwap Profile to take part in next IFO‘s!') : t('You need an active PancakeSwap Profile to take part in an IFO!')
                        }),
                        ' ',
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(MessageTextLink, {
                            href: "#ifo-how-to",
                            color: "#D67E0A",
                            display: "inline",
                            children: [
                                t('How does it work?'),
                                " \xbb"
                            ]
                        })
                    ]
                })
            });
        }
        if (ifo.version === 3 && (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_9__/* .getBalanceNumber */ .mW)(credit) === 0) {
            message = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Message, {
                my: "24px",
                p: "8px",
                variant: "danger",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Box, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.MessageText, {
                            display: "inline",
                            children: t('You don’t have any average CAKE balance available to commit in the IFO CAKE pool.')
                        }),
                        ' ',
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(MessageTextLink, {
                            display: "inline",
                            fontWeight: 700,
                            href: "#ifo-how-to",
                            color: "failure",
                            children: [
                                t('How does it work?'),
                                " \xbb"
                            ]
                        })
                    ]
                })
            });
        }
        if (account && !hasProfile) {
            return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(OnSaleInfo, {
                        token: token,
                        distributionRatio: distributionRatio,
                        saleAmount: ifo[poolId].saleAmount
                    }),
                    message
                ]
            }));
        }
        if (publicIfoData.status === 'coming_soon') {
            return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(TokenSection, {
                        primaryToken: ifo.token,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Label, {
                                children: t('On sale')
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Value, {
                                children: ifo[poolId].saleAmount
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                        fontSize: "14px",
                        color: "textSubtle",
                        pl: "48px",
                        children: t('%ratio%% of total sale', {
                            ratio: distributionRatio
                        })
                    }),
                    message,
                    enableStatus !== _types__WEBPACK_IMPORTED_MODULE_14__/* .EnableStatus.ENABLED */ .W.ENABLED && account && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Button, {
                        width: "100%",
                        mt: "16px",
                        onClick: onApprove,
                        isLoading: enableStatus === _types__WEBPACK_IMPORTED_MODULE_14__/* .EnableStatus.IS_ENABLING */ .W.IS_ENABLING,
                        endIcon: enableStatus === _types__WEBPACK_IMPORTED_MODULE_14__/* .EnableStatus.IS_ENABLING */ .W.IS_ENABLING ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.AutoRenewIcon, {
                            spin: true,
                            color: "currentColor"
                        }) : null,
                        children: t('Enable')
                    })
                ]
            }));
        }
        if (publicIfoData.status === 'live') {
            return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(CommitTokenSection, {
                        commitToken: ifo.currency,
                        mb: "24px",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Label, {
                                children: t('Your %symbol% committed', {
                                    symbol: currency.symbol
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Value, {
                                children: (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_9__/* .getBalanceNumber */ .mW)(userPoolCharacteristics.amountTokenCommittedInLP, currency.decimals)
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PercentageOfTotal__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                                userAmount: userPoolCharacteristics.amountTokenCommittedInLP,
                                totalAmount: publicPoolCharacteristics.totalAmountPool
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(TokenSection, {
                        primaryToken: ifo.token,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Label, {
                                children: t('%symbol% to receive', {
                                    symbol: token.symbol
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Value, {
                                children: (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_9__/* .getBalanceNumber */ .mW)(userPoolCharacteristics.offeringAmountInToken, token.decimals)
                            })
                        ]
                    })
                ]
            }));
        }
        if (publicIfoData.status === 'finished') {
            return userPoolCharacteristics.amountTokenCommittedInLP.isEqualTo(0) ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                flexDirection: "column",
                alignItems: "center",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.BunnyPlaceholderIcon, {
                        width: 80,
                        mb: "16px"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                        fontWeight: 600,
                        children: t('You didn’t participate in this sale!')
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                        textAlign: "center",
                        fontSize: "14px",
                        children: t('To participate in the next IFO, stake some CAKE in the IFO CAKE pool!')
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(MessageTextLink, {
                        href: "#ifo-how-to",
                        textAlign: "center",
                        children: [
                            t('How does it work?'),
                            " \xbb"
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Button, {
                        mt: "24px",
                        onClick: onPresentStake,
                        children: t('Stake CAKE in IFO pool')
                    })
                ]
            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(CommitTokenSection, {
                        commitToken: ifo.currency,
                        mb: "24px",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Label, {
                                children: t(hasClaimed ? 'Your %symbol% RECLAIMED' : 'Your %symbol% TO RECLAIM', {
                                    symbol: currency.symbol
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                                alignItems: "center",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Value, {
                                        children: (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_9__/* .getBalanceNumber */ .mW)(userPoolCharacteristics.refundingAmountInLP, currency.decimals)
                                    }),
                                    hasClaimed && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.CheckmarkCircleIcon, {
                                        color: "success",
                                        ml: "8px"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PercentageOfTotal__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                                userAmount: userPoolCharacteristics.amountTokenCommittedInLP,
                                totalAmount: publicPoolCharacteristics.totalAmountPool
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(TokenSection, {
                        primaryToken: ifo.token,
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Label, {
                                children: [
                                    " ",
                                    t(hasClaimed ? '%symbol% received' : '%symbol% to receive', {
                                        symbol: token.symbol
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                                alignItems: "center",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Value, {
                                        children: (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_9__/* .getBalanceNumber */ .mW)(userPoolCharacteristics.offeringAmountInToken, token.decimals)
                                    }),
                                    !hasClaimed && userPoolCharacteristics.offeringAmountInToken.isEqualTo(0) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        ref: targetRef,
                                        style: {
                                            display: 'flex',
                                            marginLeft: '8px'
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.HelpIcon, {})
                                    }),
                                    hasClaimed && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.CheckmarkCircleIcon, {
                                        color: "success",
                                        ml: "8px"
                                    })
                                ]
                            })
                        ]
                    }),
                    hasClaimed && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Message, {
                        my: "24px",
                        p: "8px",
                        variant: "success",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.MessageText, {
                            children: t('You’ve successfully claimed tokens back.')
                        })
                    })
                ]
            });
        }
        return null;
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Box, {
        children: [
            tooltipVisible && tooltip,
            renderTokenSection()
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (IfoCardTokens);

});

/***/ }),

/***/ 71472:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(99150);




const PercentageOfTotal = ({ userAmount , totalAmount , ...props })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_3__/* .useTranslation */ .$G)();
    const percentOfUserContribution = totalAmount.isGreaterThan(0) ? userAmount.div(totalAmount).times(100).toNumber() : 0;
    const percentOfUserDisplay = percentOfUserContribution.toLocaleString(undefined, {
        maximumFractionDigits: 5
    });
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
        fontSize: "14px",
        color: "textSubtle",
        ...props,
        children: t('%num% of total', {
            num: `${percentOfUserDisplay}%`
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PercentageOfTotal);


/***/ }),

/***/ 17236:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "r0": () => (/* binding */ SkeletonCardActions),
/* harmony export */   "cL": () => (/* binding */ SkeletonCardTokens),
/* harmony export */   "X2": () => (/* binding */ SkeletonCardDetails)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);



const SkeletonCardActions = ()=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Skeleton, {
        height: "48px"
    }));
};
const SkeletonCardTokens = ()=>{
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                justifyContent: "space-between",
                alignItems: "center",
                mb: "24px",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Skeleton, {
                        variant: "circle",
                        width: "32px",
                        height: "32px",
                        mr: "16px"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Skeleton, {
                        width: "90%"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                justifyContent: "space-between",
                alignItems: "center",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Skeleton, {
                        variant: "circle",
                        width: "32px",
                        height: "32px",
                        mr: "16px"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Skeleton, {
                        width: "90%"
                    })
                ]
            })
        ]
    }));
};
const SkeletonCardDetails = ()=>{
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Skeleton, {
                mb: "8px"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Skeleton, {})
        ]
    }));
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = (null);


/***/ }),

/***/ 55217:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(99150);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var config_constants_types__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(97971);
/* harmony import */ var state_profile_hooks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(89424);
/* harmony import */ var _IfoCardTokens__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(58068);
/* harmony import */ var _IfoCardActions__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(88342);
/* harmony import */ var _IfoCardDetails__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(18570);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_IfoCardDetails__WEBPACK_IMPORTED_MODULE_9__, _IfoCardActions__WEBPACK_IMPORTED_MODULE_8__, _IfoCardTokens__WEBPACK_IMPORTED_MODULE_7__, state_profile_hooks__WEBPACK_IMPORTED_MODULE_6__]);
([_IfoCardDetails__WEBPACK_IMPORTED_MODULE_9__, _IfoCardActions__WEBPACK_IMPORTED_MODULE_8__, _IfoCardTokens__WEBPACK_IMPORTED_MODULE_7__, state_profile_hooks__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);










const StyledCard = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Card).withConfig({
    componentId: "sc-a53bc973-0"
})`
  background: none;
  max-width: 368px;
  width: 100%;
  margin: 0 auto;
  height: fit-content;
`;
const cardConfig = (t, poolId)=>{
    switch(poolId){
        case config_constants_types__WEBPACK_IMPORTED_MODULE_5__/* .PoolIds.poolBasic */ .vr.poolBasic:
            return {
                title: t('Basic Sale'),
                variant: 'blue',
                tooltip: t('Every person can only commit a limited amount, but may expect a higher return per token committed.')
            };
        case config_constants_types__WEBPACK_IMPORTED_MODULE_5__/* .PoolIds.poolUnlimited */ .vr.poolUnlimited:
            return {
                title: t('Unlimited Sale'),
                variant: 'violet',
                tooltip: t('No limits on the amount you can commit. Additional fee applies when claiming.')
            };
        default:
            return {
                title: '',
                variant: 'blue',
                tooltip: ''
            };
    }
};
const SmallCard = ({ poolId , ifo , publicIfoData , walletIfoData , onApprove , enableStatus  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_3__/* .useTranslation */ .$G)();
    const config = cardConfig(t, poolId);
    const { hasProfile , isLoading: isProfileLoading  } = (0,state_profile_hooks__WEBPACK_IMPORTED_MODULE_6__/* .useProfile */ .Un)();
    const { targetRef , tooltip , tooltipVisible  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.useTooltip)(config.tooltip, {
        placement: 'bottom'
    });
    const isLoading = isProfileLoading || publicIfoData.status === 'idle';
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            tooltipVisible && tooltip,
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(StyledCard, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.CardHeader, {
                        p: "16px 24px",
                        variant: config.variant,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Flex, {
                            justifyContent: "space-between",
                            alignItems: "center",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                                    bold: true,
                                    fontSize: "20px",
                                    lineHeight: 1,
                                    children: config.title
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    ref: targetRef,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.HelpIcon, {})
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.CardBody, {
                        p: "12px",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IfoCardTokens__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                poolId: poolId,
                                ifo: ifo,
                                publicIfoData: publicIfoData,
                                walletIfoData: walletIfoData,
                                hasProfile: hasProfile,
                                isLoading: isLoading,
                                onApprove: onApprove,
                                enableStatus: enableStatus
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Box, {
                                mt: "24px",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IfoCardActions__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                    poolId: poolId,
                                    ifo: ifo,
                                    publicIfoData: publicIfoData,
                                    walletIfoData: walletIfoData,
                                    hasProfile: hasProfile,
                                    isLoading: isLoading
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IfoCardDetails__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                poolId: poolId,
                                ifo: ifo,
                                publicIfoData: publicIfoData,
                                walletIfoData: walletIfoData
                            })
                        ]
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SmallCard);

});

/***/ }),

/***/ 18981:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Q": () => (/* binding */ IfoRibbon)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
// EXTERNAL MODULE: external "@pancakeswap/uikit"
var uikit_ = __webpack_require__(2829);
// EXTERNAL MODULE: ./src/contexts/Localization/index.tsx + 3 modules
var Localization = __webpack_require__(99150);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(57518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: ./src/utils/getTimePeriods.ts
var getTimePeriods = __webpack_require__(87218);
;// CONCATENATED MODULE: ./src/views/Ifos/components/IfoFoldableCard/Timer.tsx






const GradientText = external_styled_components_default()(uikit_.Heading).withConfig({
    componentId: "sc-f5cb1662-0"
})`
  background: -webkit-linear-gradient(#ffd800, #eb8c00);
  background-clip: text;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  -webkit-text-stroke: 1px rgba(0, 0, 0, 0.5);
`;
const FlexGap = external_styled_components_default()(uikit_.Flex).withConfig({
    componentId: "sc-f5cb1662-1"
})`
  gap: ${({ gap  })=>gap
};
`;
const SoonTimer = ({ publicIfoData  })=>{
    const { t  } = (0,Localization/* useTranslation */.$G)();
    const { status , secondsUntilStart  } = publicIfoData;
    const timeUntil = (0,getTimePeriods/* default */.Z)(secondsUntilStart);
    return(/*#__PURE__*/ jsx_runtime_.jsx(uikit_.Flex, {
        justifyContent: "center",
        position: "relative",
        children: status === 'idle' ? /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Skeleton, {
            animation: "pulse",
            variant: "rect",
            width: "100%",
            height: "48px"
        }) : /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(FlexGap, {
                gap: "8px",
                alignItems: "center",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Heading, {
                        as: "h3",
                        scale: "lg",
                        color: "secondary",
                        children: t('Start in')
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(FlexGap, {
                        gap: "4px",
                        alignItems: "baseline",
                        children: [
                            timeUntil.days ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Heading, {
                                        scale: "lg",
                                        color: "secondary",
                                        children: timeUntil.days
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Text, {
                                        color: "secondary",
                                        children: t('d')
                                    })
                                ]
                            }) : null,
                            timeUntil.days || timeUntil.hours ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Heading, {
                                        color: "secondary",
                                        scale: "lg",
                                        children: timeUntil.hours
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Text, {
                                        color: "secondary",
                                        children: t('h')
                                    })
                                ]
                            }) : null,
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Heading, {
                                        color: "secondary",
                                        scale: "lg",
                                        children: timeUntil.minutes
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Text, {
                                        color: "secondary",
                                        children: t('m')
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        })
    }));
};
const EndInHeading = external_styled_components_default()(uikit_.Heading).withConfig({
    componentId: "sc-f5cb1662-2"
})`
  color: white;
  font-size: 20px;
  font-weight: 600;
  line-height: 1.1;

  ${({ theme  })=>theme.mediaQueries.md
} {
    font-size: 24px;
  }
`;
const LiveNowHeading = external_styled_components_default()(EndInHeading).withConfig({
    componentId: "sc-f5cb1662-3"
})`
  color: white;
  ${({ theme  })=>theme.mediaQueries.md
} {
    background: -webkit-linear-gradient(#ffd800, #eb8c00);
    background-clip: text;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    -webkit-text-stroke: 1px rgba(0, 0, 0, 0.5);
  }
`;
const LiveTimer = ({ publicIfoData  })=>{
    const { t  } = (0,Localization/* useTranslation */.$G)();
    const { status , secondsUntilEnd  } = publicIfoData;
    const timeUntil = (0,getTimePeriods/* default */.Z)(secondsUntilEnd);
    return(/*#__PURE__*/ jsx_runtime_.jsx(uikit_.Flex, {
        justifyContent: "center",
        position: "relative",
        children: status === 'idle' ? /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Skeleton, {
            animation: "pulse",
            variant: "rect",
            width: "100%",
            height: "48px"
        }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(uikit_.PocketWatchIcon, {
                    width: "42px",
                    mr: "8px"
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(FlexGap, {
                    gap: "8px",
                    alignItems: "center",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(LiveNowHeading, {
                            as: "h3",
                            children: `${t('Live Now').toUpperCase()}!`
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(EndInHeading, {
                            as: "h3",
                            scale: "lg",
                            color: "white",
                            children: t('Ends in')
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(FlexGap, {
                            gap: "4px",
                            alignItems: "baseline",
                            children: [
                                timeUntil.days ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(GradientText, {
                                            scale: "lg",
                                            children: timeUntil.days
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Text, {
                                            color: "white",
                                            children: t('d')
                                        })
                                    ]
                                }) : null,
                                timeUntil.days || timeUntil.hours ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(GradientText, {
                                            scale: "lg",
                                            children: timeUntil.hours
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Text, {
                                            color: "white",
                                            children: t('h')
                                        })
                                    ]
                                }) : null,
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(GradientText, {
                                            scale: "lg",
                                            children: timeUntil.minutes
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Text, {
                                            color: "white",
                                            children: t('m')
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    }));
};
/* harmony default export */ const Timer = (LiveTimer);

;// CONCATENATED MODULE: ./src/views/Ifos/components/IfoFoldableCard/IfoRibbon.tsx






const BigCurve = external_styled_components_default()(uikit_.Box).withConfig({
    componentId: "sc-cf22552d-0"
})`
  width: 150%;
  position: absolute;
  top: -150%;
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);

  ${({ theme  })=>theme.mediaQueries.md
} {
    border-radius: 50%;
  }

  ${({ $status , theme  })=>{
    switch($status){
        case 'coming_soon':
            return `
          background: ${theme.colors.tertiary};
        `;
        case 'live':
            return `
          background: linear-gradient(#8051D6 100%, #492286 100%);
        `;
        case 'finished':
            return `
          background: ${theme.colors.input};
        `;
        default:
            return '';
    }
}}
`;
const IfoRibbon = ({ publicIfoData  })=>{
    const { status  } = publicIfoData;
    let Component;
    if (status === 'finished') {
        Component = /*#__PURE__*/ jsx_runtime_.jsx(IfoRibbonEnd, {});
    } else if (status === 'live') {
        Component = /*#__PURE__*/ jsx_runtime_.jsx(IfoRibbonLive, {
            publicIfoData: publicIfoData
        });
    } else if (status === 'coming_soon') {
        Component = /*#__PURE__*/ jsx_runtime_.jsx(IfoRibbonSoon, {
            publicIfoData: publicIfoData
        });
    }
    if (status === 'idle') {
        return null;
    }
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            status === 'live' && /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Progress, {
                variant: "flat",
                children: /*#__PURE__*/ jsx_runtime_.jsx(uikit_.ProgressBar, {
                    $useDark: true,
                    $background: "linear-gradient(273deg, #ffd800 -2.87%, #eb8c00 113.73%)",
                    style: {
                        width: `${Math.min(Math.max(publicIfoData.progress, 0), 100)}%`
                    }
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Flex, {
                justifyContent: "center",
                alignItems: "center",
                flexDirection: "column",
                minHeight: [
                    '48px',
                    '48px',
                    '48px',
                    '75px'
                ],
                position: "relative",
                overflow: "hidden",
                children: Component
            })
        ]
    }));
};
const IfoRibbonEnd = ()=>{
    const { t  } = (0,Localization/* useTranslation */.$G)();
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(BigCurve, {
                $status: "finished"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Box, {
                position: "relative",
                children: /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Heading, {
                    as: "h3",
                    scale: "lg",
                    color: "textSubtle",
                    children: t('Sale Finished!')
                })
            })
        ]
    }));
};
const IfoRibbonSoon = ({ publicIfoData  })=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(BigCurve, {
                $status: "coming_soon"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Box, {
                position: "relative",
                children: /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Heading, {
                    as: "h3",
                    scale: "lg",
                    color: "secondary",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(SoonTimer, {
                        publicIfoData: publicIfoData
                    })
                })
            })
        ]
    }));
};
const IfoRibbonLive = ({ publicIfoData  })=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(BigCurve, {
                $status: "live"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Box, {
                position: "relative",
                children: /*#__PURE__*/ jsx_runtime_.jsx(Timer, {
                    publicIfoData: publicIfoData
                })
            })
        ]
    }));
};


/***/ }),

/***/ 83375:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "K": () => (/* binding */ IfoCurrentCard),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(18054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(34215);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(bignumber_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var components_Toast__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(63937);
/* harmony import */ var config_constants_types__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(97971);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(99150);
/* harmony import */ var hooks_useContract__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(46063);
/* harmony import */ var hooks_useToast__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(789);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var state_block_hooks__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(37063);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var hooks_useRefreshEffect__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(27892);
/* harmony import */ var _hooks_useIsWindowVisible__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(94587);
/* harmony import */ var _hooks_useIfoApprove__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(13161);
/* harmony import */ var _Achievement__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(63771);
/* harmony import */ var _IfoPoolCard__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(55217);
/* harmony import */ var _types__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(81796);
/* harmony import */ var _IfoRibbon__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(18981);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_IfoPoolCard__WEBPACK_IMPORTED_MODULE_16__, hooks_useRefreshEffect__WEBPACK_IMPORTED_MODULE_12__, _hooks_useIfoApprove__WEBPACK_IMPORTED_MODULE_14__, state_block_hooks__WEBPACK_IMPORTED_MODULE_10__]);
([_IfoPoolCard__WEBPACK_IMPORTED_MODULE_16__, hooks_useRefreshEffect__WEBPACK_IMPORTED_MODULE_12__, _hooks_useIfoApprove__WEBPACK_IMPORTED_MODULE_14__, state_block_hooks__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);



















const StyledCard = styled_components__WEBPACK_IMPORTED_MODULE_11___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Card).withConfig({
    componentId: "sc-b63d2f4-0"
})`
  width: 100%;
  margin: auto;
  border-top-left-radius: 32px;
  border-top-right-radius: 32px;

  ${({ $isCurrent  })=>$isCurrent && `
  border-top-left-radius: 0;
  border-top-right-radius: 0;
  > div {
    border-top-left-radius: 0;
    border-top-right-radius: 0;
  }
  `
}

  > div {
    background: ${({ theme , $isCurrent  })=>$isCurrent ? theme.colors.gradients.bubblegum : theme.colors.dropdown
};
  }

  ${({ theme  })=>theme.mediaQueries.sm
} {
    border-top-left-radius: 32px;
    border-top-right-radius: 32px;

    > div {
      border-top-left-radius: 32px;
      border-top-right-radius: 32px;
    }
  }
`;
const Header = styled_components__WEBPACK_IMPORTED_MODULE_11___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.CardHeader).withConfig({
    componentId: "sc-b63d2f4-1"
})`
  display: flex;
  justify-content: flex-end;
  align-items: center;
  height: ${({ $isCurrent  })=>$isCurrent ? '64px' : '112px'
};
  background-repeat: no-repeat;
  background-size: cover;
  background-position: center;
  border-top-left-radius: 32px;
  border-top-right-radius: 32px;
  background-color: ${({ theme  })=>theme.colors.dropdown
};
  background-image: ${({ ifoId  })=>`url('/images/ifos/${ifoId}-bg.svg'), url('/images/ifos/${ifoId}-bg.png')`
};
  ${({ theme  })=>theme.mediaQueries.md
} {
    height: 112px;
  }
`;
const CardsWrapper = styled_components__WEBPACK_IMPORTED_MODULE_11___default().div.withConfig({
    componentId: "sc-b63d2f4-2"
})`
  display: grid;
  grid-gap: 32px;
  grid-template-columns: 1fr;
  ${({ theme  })=>theme.mediaQueries.xxl
} {
    grid-template-columns: ${({ singleCard  })=>singleCard ? '1fr' : '1fr 1fr'
};
    justify-items: ${({ singleCard  })=>singleCard ? 'center' : 'unset'
};
  }
`;
const StyledCardBody = styled_components__WEBPACK_IMPORTED_MODULE_11___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.CardBody).withConfig({
    componentId: "sc-b63d2f4-3"
})`
  padding: 24px 16px;
  ${({ theme  })=>theme.mediaQueries.md
} {
    padding: 24px;
  }
`;
const StyledCardFooter = styled_components__WEBPACK_IMPORTED_MODULE_11___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.CardFooter).withConfig({
    componentId: "sc-b63d2f4-4"
})`
  padding: 0;
  background: ${({ theme  })=>theme.colors.backgroundAlt
};
  text-align: center;
`;
const StyledNoHatBunny = styled_components__WEBPACK_IMPORTED_MODULE_11___default().div.withConfig({
    componentId: "sc-b63d2f4-5"
})`
  position: absolute;
  left: -24px;
  z-index: 1;
  top: 33px;

  > img {
    width: 78px;
  }

  ${({ theme  })=>theme.mediaQueries.sm
} {
    top: ${({ $isLive  })=>$isLive ? '46px' : '33px'
};
  }
  ${({ theme  })=>theme.mediaQueries.md
} {
    left: auto;
    top: ${({ $isLive  })=>$isLive ? '61px' : '48px'
};
    right: ${({ $isCurrent  })=>$isCurrent ? '17px' : '90px'
};

    > img {
      width: 123px;
    }
  }
  ${({ theme  })=>theme.mediaQueries.lg
} {
    right: ${({ $isCurrent  })=>$isCurrent ? '67px' : '90px'
};
  }
  ${({ theme  })=>theme.mediaQueries.xxl
} {
    right: 90px;
  }
`;
const NoHatBunny = ({ isLive , isCurrent  })=>{
    const { isXs , isSm , isMd  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.useMatchBreakpoints)();
    const isSmallerThanTablet = isXs || isSm || isMd;
    if (isSmallerThanTablet && isLive) return null;
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledNoHatBunny, {
        $isLive: isLive,
        $isCurrent: isCurrent,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
            src: `/images/ifos/assets/bunnypop-${!isSmallerThanTablet ? 'right' : 'left'}.png`,
            width: 123,
            height: 162,
            alt: "bunny"
        })
    }));
};
// Active Ifo
const IfoCurrentCard = ({ ifo , publicIfoData , walletIfoData  })=>{
    const { 0: isExpanded , 1: setIsExpanded  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(false);
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_6__/* .useTranslation */ .$G)();
    const { isMobile  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.useMatchBreakpoints)();
    const shouldShowBunny = publicIfoData.status === 'live' || publicIfoData.status === 'coming_soon';
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            isMobile && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Box, {
                className: "sticky-header",
                position: "sticky",
                bottom: "48px",
                width: "100%",
                zIndex: 6,
                maxWidth: [
                    '400px',
                    '400px',
                    '400px',
                    '100%'
                ],
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Header, {
                        $isCurrent: true,
                        ifoId: ifo.id
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IfoRibbon__WEBPACK_IMPORTED_MODULE_18__/* .IfoRibbon */ .Q, {
                        publicIfoData: publicIfoData
                    }),
                    shouldShowBunny && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(NoHatBunny, {
                        isLive: publicIfoData.status === 'live'
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Box, {
                position: "relative",
                width: "100%",
                maxWidth: [
                    '400px',
                    '400px',
                    '400px',
                    '100%'
                ],
                children: [
                    !isMobile && shouldShowBunny && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(NoHatBunny, {
                        isCurrent: true,
                        isLive: publicIfoData.status === 'live'
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(StyledCard, {
                        $isCurrent: true,
                        children: [
                            !isMobile && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Header, {
                                        $isCurrent: true,
                                        ifoId: ifo.id
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IfoRibbon__WEBPACK_IMPORTED_MODULE_18__/* .IfoRibbon */ .Q, {
                                        publicIfoData: publicIfoData
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(IfoCard, {
                                ifo: ifo,
                                publicIfoData: publicIfoData,
                                walletIfoData: walletIfoData
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(StyledCardFooter, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.ExpandableLabel, {
                                        expanded: isExpanded,
                                        onClick: ()=>setIsExpanded(!isExpanded)
                                        ,
                                        children: isExpanded ? t('Hide') : t('Details')
                                    }),
                                    isExpanded && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Achievement__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                                        ifo: ifo,
                                        publicIfoData: publicIfoData
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    }));
};
const FoldableContent = styled_components__WEBPACK_IMPORTED_MODULE_11___default().div.withConfig({
    componentId: "sc-b63d2f4-6"
})`
  display: ${({ isVisible  })=>isVisible ? 'block' : 'none'
};
`;
// Past Ifo
const IfoFoldableCard = ({ ifo , publicIfoData , walletIfoData  })=>{
    const { 0: isExpanded , 1: setIsExpanded  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(false);
    const { isDesktop  } = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.useMatchBreakpoints)();
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Box, {
        position: "relative",
        children: [
            isExpanded && isDesktop && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(NoHatBunny, {
                isLive: false
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Box, {
                as: StyledCard,
                borderRadius: "32px",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Box, {
                        position: "relative",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Header, {
                                ifoId: ifo.id,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.ExpandableButton, {
                                    expanded: isExpanded,
                                    onClick: ()=>setIsExpanded((prev)=>!prev
                                        )
                                })
                            }),
                            isExpanded && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IfoRibbon__WEBPACK_IMPORTED_MODULE_18__/* .IfoRibbon */ .Q, {
                                    publicIfoData: publicIfoData
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(FoldableContent, {
                        isVisible: isExpanded,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(IfoCard, {
                                ifo: ifo,
                                publicIfoData: publicIfoData,
                                walletIfoData: walletIfoData
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Achievement__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                                ifo: ifo,
                                publicIfoData: publicIfoData
                            })
                        ]
                    })
                ]
            })
        ]
    }));
};
const IfoCard = ({ ifo , publicIfoData , walletIfoData  })=>{
    const currentBlock = (0,state_block_hooks__WEBPACK_IMPORTED_MODULE_10__/* .useCurrentBlock */ .je)();
    const { fetchIfoData: fetchPublicIfoData , isInitialized: isPublicIfoDataInitialized , secondsUntilEnd  } = publicIfoData;
    const { contract , fetchIfoData: fetchWalletIfoData , resetIfoData: resetWalletIfoData , isInitialized: isWalletDataInitialized ,  } = walletIfoData;
    const { 0: enableStatus , 1: setEnableStatus  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(_types__WEBPACK_IMPORTED_MODULE_17__/* .EnableStatus.DISABLED */ .W.DISABLED);
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_6__/* .useTranslation */ .$G)();
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_2__.useWeb3React)();
    const raisingTokenContract = (0,hooks_useContract__WEBPACK_IMPORTED_MODULE_7__/* .useERC20 */ .X_)(ifo.currency.address, false);
    // Continue to fetch 2 more minutes to get latest data
    const isRecentlyActive = (publicIfoData.status !== 'finished' || publicIfoData.status === 'finished' && secondsUntilEnd >= -120) && ifo.isActive;
    const onApprove = (0,_hooks_useIfoApprove__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z)(ifo, contract.address);
    const { toastSuccess , toastError  } = (0,hooks_useToast__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
    const isWindowVisible = (0,_hooks_useIsWindowVisible__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z)();
    (0,react__WEBPACK_IMPORTED_MODULE_9__.useEffect)(()=>{
        if (isRecentlyActive || !isPublicIfoDataInitialized) {
            fetchPublicIfoData(currentBlock);
        }
    }, [
        isRecentlyActive,
        isPublicIfoDataInitialized,
        fetchPublicIfoData,
        currentBlock
    ]);
    (0,hooks_useRefreshEffect__WEBPACK_IMPORTED_MODULE_12__/* .useFastRefreshEffect */ .a)(()=>{
        if (isWindowVisible && (isRecentlyActive || !isWalletDataInitialized)) {
            if (account) {
                fetchWalletIfoData();
            }
        }
        if (!account && isWalletDataInitialized) {
            resetWalletIfoData();
        }
    }, [
        isWindowVisible,
        account,
        isRecentlyActive,
        isWalletDataInitialized,
        fetchWalletIfoData,
        resetWalletIfoData
    ]);
    const handleApprove = async ()=>{
        try {
            setEnableStatus(_types__WEBPACK_IMPORTED_MODULE_17__/* .EnableStatus.IS_ENABLING */ .W.IS_ENABLING);
            await onApprove((tx)=>{
                toastSuccess(`${t('Transaction Submitted')}!`, /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_4__/* .ToastDescriptionWithTx */ .YO, {
                    txHash: tx.hash
                }));
            }, (receipt)=>{
                toastSuccess(t('Successfully Enabled!'), /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_4__/* .ToastDescriptionWithTx */ .YO, {
                    txHash: receipt.transactionHash,
                    children: t('You can now participate in the %symbol% IFO.', {
                        symbol: ifo.token.symbol
                    })
                }));
            }, (receipt)=>{
                toastError(t('Error'), /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Toast__WEBPACK_IMPORTED_MODULE_4__/* .ToastDescriptionWithTx */ .YO, {
                    txHash: receipt.transactionHash,
                    children: t('Please try again. Confirm the transaction and make sure you are paying enough gas!')
                }));
            });
            setEnableStatus(_types__WEBPACK_IMPORTED_MODULE_17__/* .EnableStatus.ENABLED */ .W.ENABLED);
        } catch (error) {
            setEnableStatus(_types__WEBPACK_IMPORTED_MODULE_17__/* .EnableStatus.DISABLED */ .W.DISABLED);
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_9__.useEffect)(()=>{
        const checkAllowance = async ()=>{
            try {
                const response = await raisingTokenContract.allowance(account, contract.address);
                const currentAllowance = new (bignumber_js__WEBPACK_IMPORTED_MODULE_3___default())(response.toString());
                setEnableStatus(currentAllowance.lte(0) ? _types__WEBPACK_IMPORTED_MODULE_17__/* .EnableStatus.DISABLED */ .W.DISABLED : _types__WEBPACK_IMPORTED_MODULE_17__/* .EnableStatus.ENABLED */ .W.ENABLED);
            } catch (error) {
                setEnableStatus(_types__WEBPACK_IMPORTED_MODULE_17__/* .EnableStatus.DISABLED */ .W.DISABLED);
            }
        };
        if (account) {
            checkAllowance();
        }
    }, [
        account,
        raisingTokenContract,
        contract,
        setEnableStatus
    ]);
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledCardBody, {
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(CardsWrapper, {
                singleCard: !publicIfoData.poolBasic || !walletIfoData.poolBasic,
                children: [
                    publicIfoData.poolBasic && walletIfoData.poolBasic && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IfoPoolCard__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                        poolId: config_constants_types__WEBPACK_IMPORTED_MODULE_5__/* .PoolIds.poolBasic */ .vr.poolBasic,
                        ifo: ifo,
                        publicIfoData: publicIfoData,
                        walletIfoData: walletIfoData,
                        onApprove: handleApprove,
                        enableStatus: enableStatus
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IfoPoolCard__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                        poolId: config_constants_types__WEBPACK_IMPORTED_MODULE_5__/* .PoolIds.poolUnlimited */ .vr.poolUnlimited,
                        ifo: ifo,
                        publicIfoData: publicIfoData,
                        walletIfoData: walletIfoData,
                        onApprove: handleApprove,
                        enableStatus: enableStatus
                    })
                ]
            })
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (IfoFoldableCard);

});

/***/ }),

/***/ 81796:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "W": () => (/* binding */ EnableStatus)
/* harmony export */ });
var EnableStatus;
(function(EnableStatus) {
    EnableStatus["ENABLED"] = 'enabled';
    EnableStatus["DISABLED"] = 'disabled';
    EnableStatus["IS_ENABLING"] = 'is_enabling';
})(EnableStatus || (EnableStatus = {}));
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (EnableStatus)));


/***/ }),

/***/ 61917:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "d": () => (/* binding */ IfoLayoutWrapper),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);


const IfoLayout = styled_components__WEBPACK_IMPORTED_MODULE_1___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_0__.Box).withConfig({
    componentId: "sc-e60704a0-0"
})`
  > div:not(.sticky-header) {
    margin-bottom: 32px;
  }
`;
const IfoLayoutWrapper = styled_components__WEBPACK_IMPORTED_MODULE_1___default()(IfoLayout).withConfig({
    componentId: "sc-e60704a0-1"
})`
  column-gap: 32px;
  display: grid;
  grid-template-columns: 1fr;

  ${({ theme  })=>theme.mediaQueries.md
} {
    grid-template-columns: minmax(300px, 1fr) minmax(462px, 2fr);
  }

  > div {
    margin: 0 auto;
    align-items: flex-start;
  }
`;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (IfoLayout);


/***/ }),

/***/ 43933:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "l": () => (/* binding */ getStatus)
/* harmony export */ });
const getStatus = (currentBlock, startBlock, endBlock)=>{
    // Add an extra check to currentBlock because it takes awhile to fetch so the initial value is 0
    // making the UI change to an inaccurate status
    if (currentBlock === 0) {
        return 'idle';
    }
    if (currentBlock < startBlock) {
        return 'coming_soon';
    }
    if (currentBlock >= startBlock && currentBlock <= endBlock) {
        return 'live';
    }
    if (currentBlock > endBlock) {
        return 'finished';
    }
    return 'idle';
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = (null);


/***/ }),

/***/ 80907:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(34215);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(bignumber_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(18054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var utils_bigNumber__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(35128);




// Retrieve IFO allowance
const useIfoAllowance = (tokenContract, spenderAddress, dependency)=>{
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_2__.useWeb3React)();
    const { 0: allowance , 1: setAllowance  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(utils_bigNumber__WEBPACK_IMPORTED_MODULE_3__/* .BIG_ZERO */ .HW);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        const fetch = async ()=>{
            try {
                const res = await tokenContract.allowance(account, spenderAddress);
                setAllowance(new (bignumber_js__WEBPACK_IMPORTED_MODULE_1___default())(res.toString()));
            } catch (e) {
                console.error(e);
            }
        };
        if (account) {
            fetch();
        }
    }, [
        account,
        spenderAddress,
        tokenContract,
        dependency
    ]);
    return allowance;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useIfoAllowance);


/***/ }),

/***/ 13161:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ethersproject_constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(26644);
/* harmony import */ var _ethersproject_constants__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_constants__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var hooks_useCallWithGasPrice__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(71228);
/* harmony import */ var hooks_useContract__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(46063);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks_useCallWithGasPrice__WEBPACK_IMPORTED_MODULE_2__]);
hooks_useCallWithGasPrice__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];




const useIfoApprove = (ifo, spenderAddress)=>{
    const raisingTokenContract = (0,hooks_useContract__WEBPACK_IMPORTED_MODULE_3__/* .useERC20 */ .X_)(ifo.currency.address);
    const { callWithGasPrice  } = (0,hooks_useCallWithGasPrice__WEBPACK_IMPORTED_MODULE_2__/* .useCallWithGasPrice */ .d)();
    const onApprove = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async (onTransactionSubmitted, onSuccess, onError)=>{
        const tx = await callWithGasPrice(raisingTokenContract, 'approve', [
            spenderAddress,
            _ethersproject_constants__WEBPACK_IMPORTED_MODULE_1__.MaxUint256
        ]);
        onTransactionSubmitted(tx);
        const receipt = await tx.wait();
        if (receipt.status) {
            onSuccess(receipt);
        } else {
            onError(receipt);
        }
    }, [
        spenderAddress,
        raisingTokenContract,
        callWithGasPrice
    ]);
    return onApprove;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useIfoApprove);

});

/***/ }),

/***/ 56001:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(34215);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(bignumber_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var config__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(33206);
/* harmony import */ var config_abi_ifoV2_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4554);
/* harmony import */ var config_constants_tokens__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(29748);
/* harmony import */ var _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(65757);
/* harmony import */ var _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var state_farms_hooks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8733);
/* harmony import */ var utils_bigNumber__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(35128);
/* harmony import */ var utils_multicall__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(41144);
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(43933);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([state_farms_hooks__WEBPACK_IMPORTED_MODULE_6__]);
state_farms_hooks__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];










// https://github.com/pancakeswap/pancake-contracts/blob/master/projects/ifo/contracts/IFOV2.sol#L431
// 1,000,000,000 / 100
const TAX_PRECISION = _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_5__.FixedNumber.from(10000000000);
const formatPool = (pool)=>({
        raisingAmountPool: pool ? new (bignumber_js__WEBPACK_IMPORTED_MODULE_0___default())(pool[0].toString()) : utils_bigNumber__WEBPACK_IMPORTED_MODULE_7__/* .BIG_ZERO */ .HW,
        offeringAmountPool: pool ? new (bignumber_js__WEBPACK_IMPORTED_MODULE_0___default())(pool[1].toString()) : utils_bigNumber__WEBPACK_IMPORTED_MODULE_7__/* .BIG_ZERO */ .HW,
        limitPerUserInLP: pool ? new (bignumber_js__WEBPACK_IMPORTED_MODULE_0___default())(pool[2].toString()) : utils_bigNumber__WEBPACK_IMPORTED_MODULE_7__/* .BIG_ZERO */ .HW,
        hasTax: pool ? pool[3] : false,
        totalAmountPool: pool ? new (bignumber_js__WEBPACK_IMPORTED_MODULE_0___default())(pool[4].toString()) : utils_bigNumber__WEBPACK_IMPORTED_MODULE_7__/* .BIG_ZERO */ .HW,
        sumTaxesOverflow: pool ? new (bignumber_js__WEBPACK_IMPORTED_MODULE_0___default())(pool[5].toString()) : utils_bigNumber__WEBPACK_IMPORTED_MODULE_7__/* .BIG_ZERO */ .HW
    })
;
/**
 * Gets all public data of an IFO
 */ const useGetPublicIfoData = (ifo)=>{
    const { address , releaseBlockNumber  } = ifo;
    const cakePriceUsd = (0,state_farms_hooks__WEBPACK_IMPORTED_MODULE_6__/* .usePriceCakeBusd */ .Iu)();
    const lpTokenPriceInUsd = (0,state_farms_hooks__WEBPACK_IMPORTED_MODULE_6__/* .useLpTokenPrice */ .w5)(ifo.currency.symbol);
    const currencyPriceInUSD = ifo.currency === config_constants_tokens__WEBPACK_IMPORTED_MODULE_4__/* ["default"].cake */ .ZP.cake ? cakePriceUsd : lpTokenPriceInUsd;
    const { 0: state , 1: setState  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        isInitialized: false,
        status: 'idle',
        blocksRemaining: 0,
        secondsUntilStart: 0,
        progress: 5,
        secondsUntilEnd: 0,
        poolBasic: {
            raisingAmountPool: utils_bigNumber__WEBPACK_IMPORTED_MODULE_7__/* .BIG_ZERO */ .HW,
            offeringAmountPool: utils_bigNumber__WEBPACK_IMPORTED_MODULE_7__/* .BIG_ZERO */ .HW,
            limitPerUserInLP: utils_bigNumber__WEBPACK_IMPORTED_MODULE_7__/* .BIG_ZERO */ .HW,
            taxRate: 0,
            totalAmountPool: utils_bigNumber__WEBPACK_IMPORTED_MODULE_7__/* .BIG_ZERO */ .HW,
            sumTaxesOverflow: utils_bigNumber__WEBPACK_IMPORTED_MODULE_7__/* .BIG_ZERO */ .HW
        },
        poolUnlimited: {
            raisingAmountPool: utils_bigNumber__WEBPACK_IMPORTED_MODULE_7__/* .BIG_ZERO */ .HW,
            offeringAmountPool: utils_bigNumber__WEBPACK_IMPORTED_MODULE_7__/* .BIG_ZERO */ .HW,
            limitPerUserInLP: utils_bigNumber__WEBPACK_IMPORTED_MODULE_7__/* .BIG_ZERO */ .HW,
            taxRate: 0,
            totalAmountPool: utils_bigNumber__WEBPACK_IMPORTED_MODULE_7__/* .BIG_ZERO */ .HW,
            sumTaxesOverflow: utils_bigNumber__WEBPACK_IMPORTED_MODULE_7__/* .BIG_ZERO */ .HW
        },
        thresholdPoints: undefined,
        startBlockNum: 0,
        endBlockNum: 0,
        numberPoints: 0
    });
    const fetchIfoData = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(async (currentBlock)=>{
        const [startBlock, endBlock, poolBasic, poolUnlimited, taxRate, numberPoints, thresholdPoints] = await (0,utils_multicall__WEBPACK_IMPORTED_MODULE_8__/* .multicallv2 */ .v)(config_abi_ifoV2_json__WEBPACK_IMPORTED_MODULE_3__, [
            {
                address,
                name: 'startBlock'
            },
            {
                address,
                name: 'endBlock'
            },
            {
                address,
                name: 'viewPoolInformation',
                params: [
                    0
                ]
            },
            {
                address,
                name: 'viewPoolInformation',
                params: [
                    1
                ]
            },
            {
                address,
                name: 'viewPoolTaxRateOverflow',
                params: [
                    1
                ]
            },
            {
                address,
                name: 'numberPoints'
            },
            {
                address,
                name: 'thresholdPoints'
            }, 
        ]);
        const poolBasicFormatted = formatPool(poolBasic);
        const poolUnlimitedFormatted = formatPool(poolUnlimited);
        const startBlockNum = startBlock ? startBlock[0].toNumber() : 0;
        const endBlockNum = endBlock ? endBlock[0].toNumber() : 0;
        const taxRateNum = taxRate ? _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_5__.FixedNumber.from(taxRate[0]).divUnsafe(TAX_PRECISION).toUnsafeFloat() : 0;
        const status = (0,_helpers__WEBPACK_IMPORTED_MODULE_9__/* .getStatus */ .l)(currentBlock, startBlockNum, endBlockNum);
        const totalBlocks = endBlockNum - startBlockNum;
        const blocksRemaining = endBlockNum - currentBlock;
        // Calculate the total progress until finished or until start
        const progress = currentBlock > startBlockNum ? (currentBlock - startBlockNum) / totalBlocks * 100 : (currentBlock - releaseBlockNumber) / (startBlockNum - releaseBlockNumber) * 100;
        setState((prev)=>({
                ...prev,
                isInitialized: true,
                secondsUntilEnd: blocksRemaining * config__WEBPACK_IMPORTED_MODULE_2__/* .BSC_BLOCK_TIME */ .hJ,
                secondsUntilStart: (startBlockNum - currentBlock) * config__WEBPACK_IMPORTED_MODULE_2__/* .BSC_BLOCK_TIME */ .hJ,
                poolBasic: {
                    ...poolBasicFormatted,
                    taxRate: 0
                },
                poolUnlimited: {
                    ...poolUnlimitedFormatted,
                    taxRate: taxRateNum
                },
                status,
                progress,
                blocksRemaining,
                startBlockNum,
                endBlockNum,
                thresholdPoints: thresholdPoints && thresholdPoints[0],
                numberPoints: numberPoints ? numberPoints[0].toNumber() : 0
            })
        );
    }, [
        releaseBlockNumber,
        address
    ]);
    return {
        ...state,
        currencyPriceInUSD,
        fetchIfoData
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useGetPublicIfoData);

});

/***/ }),

/***/ 30002:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(34215);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(bignumber_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var hooks_useContract__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(46063);
/* harmony import */ var utils_multicall__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(41144);
/* harmony import */ var config_abi_ifoV2_json__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4554);
/* harmony import */ var state_pools_hooks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1624);
/* harmony import */ var state_pools__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(13591);
/* harmony import */ var state__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(82727);
/* harmony import */ var utils_bigNumber__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(35128);
/* harmony import */ var _useIfoAllowance__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(80907);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([state_pools_hooks__WEBPACK_IMPORTED_MODULE_6__]);
state_pools_hooks__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];











const initialState = {
    isInitialized: false,
    poolBasic: {
        amountTokenCommittedInLP: utils_bigNumber__WEBPACK_IMPORTED_MODULE_9__/* .BIG_ZERO */ .HW,
        offeringAmountInToken: utils_bigNumber__WEBPACK_IMPORTED_MODULE_9__/* .BIG_ZERO */ .HW,
        refundingAmountInLP: utils_bigNumber__WEBPACK_IMPORTED_MODULE_9__/* .BIG_ZERO */ .HW,
        taxAmountInLP: utils_bigNumber__WEBPACK_IMPORTED_MODULE_9__/* .BIG_ZERO */ .HW,
        hasClaimed: false,
        isPendingTx: false
    },
    poolUnlimited: {
        amountTokenCommittedInLP: utils_bigNumber__WEBPACK_IMPORTED_MODULE_9__/* .BIG_ZERO */ .HW,
        offeringAmountInToken: utils_bigNumber__WEBPACK_IMPORTED_MODULE_9__/* .BIG_ZERO */ .HW,
        refundingAmountInLP: utils_bigNumber__WEBPACK_IMPORTED_MODULE_9__/* .BIG_ZERO */ .HW,
        taxAmountInLP: utils_bigNumber__WEBPACK_IMPORTED_MODULE_9__/* .BIG_ZERO */ .HW,
        hasClaimed: false,
        isPendingTx: false
    }
};
/**
 * Gets all data from an IFO related to a wallet
 */ const useGetWalletIfoData = (ifo)=>{
    const { 0: state , 1: setState  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(initialState);
    const dispatch = (0,state__WEBPACK_IMPORTED_MODULE_8__/* .useAppDispatch */ .TL)();
    const credit = (0,state_pools_hooks__WEBPACK_IMPORTED_MODULE_6__/* .useIfoPoolCredit */ .Eo)();
    const { address , currency  } = ifo;
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_1__.useWeb3React)();
    const contract = (0,hooks_useContract__WEBPACK_IMPORTED_MODULE_3__/* .useIfoV2Contract */ .gx)(address);
    const currencyContract = (0,hooks_useContract__WEBPACK_IMPORTED_MODULE_3__/* .useERC20 */ .X_)(currency.address, false);
    const allowance = (0,_useIfoAllowance__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)(currencyContract, address);
    const setPendingTx = (status, poolId)=>setState((prevState)=>({
                ...prevState,
                [poolId]: {
                    ...prevState[poolId],
                    isPendingTx: status
                }
            })
        )
    ;
    const setIsClaimed = (poolId)=>{
        setState((prevState)=>({
                ...prevState,
                [poolId]: {
                    ...prevState[poolId],
                    hasClaimed: true
                }
            })
        );
    };
    const fetchIfoData = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async ()=>{
        const ifoCalls = [
            'viewUserInfo',
            'viewUserOfferingAndRefundingAmountsForPools'
        ].map((method)=>({
                address,
                name: method,
                params: [
                    account,
                    [
                        0,
                        1
                    ]
                ]
            })
        );
        dispatch((0,state_pools__WEBPACK_IMPORTED_MODULE_7__/* .fetchIfoPoolUserAndCredit */ .W3)({
            account
        }));
        const [userInfo, amounts] = await (0,utils_multicall__WEBPACK_IMPORTED_MODULE_4__/* .multicallv2 */ .v)(config_abi_ifoV2_json__WEBPACK_IMPORTED_MODULE_5__, ifoCalls);
        setState((prevState)=>({
                ...prevState,
                isInitialized: true,
                poolBasic: {
                    ...prevState.poolBasic,
                    amountTokenCommittedInLP: new (bignumber_js__WEBPACK_IMPORTED_MODULE_2___default())(userInfo[0][0].toString()),
                    offeringAmountInToken: new (bignumber_js__WEBPACK_IMPORTED_MODULE_2___default())(amounts[0][0][0].toString()),
                    refundingAmountInLP: new (bignumber_js__WEBPACK_IMPORTED_MODULE_2___default())(amounts[0][0][1].toString()),
                    taxAmountInLP: new (bignumber_js__WEBPACK_IMPORTED_MODULE_2___default())(amounts[0][0][2].toString()),
                    hasClaimed: userInfo[1][0]
                },
                poolUnlimited: {
                    ...prevState.poolUnlimited,
                    amountTokenCommittedInLP: new (bignumber_js__WEBPACK_IMPORTED_MODULE_2___default())(userInfo[0][1].toString()),
                    offeringAmountInToken: new (bignumber_js__WEBPACK_IMPORTED_MODULE_2___default())(amounts[0][1][0].toString()),
                    refundingAmountInLP: new (bignumber_js__WEBPACK_IMPORTED_MODULE_2___default())(amounts[0][1][1].toString()),
                    taxAmountInLP: new (bignumber_js__WEBPACK_IMPORTED_MODULE_2___default())(amounts[0][1][2].toString()),
                    hasClaimed: userInfo[1][1]
                }
            })
        );
    }, [
        account,
        address,
        dispatch
    ]);
    const resetIfoData = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(()=>{
        setState({
            ...initialState
        });
    }, []);
    const creditLeftWithNegative = credit.minus(state.poolBasic.amountTokenCommittedInLP).minus(state.poolUnlimited.amountTokenCommittedInLP);
    const ifoCredit = {
        credit,
        creditLeft: bignumber_js__WEBPACK_IMPORTED_MODULE_2___default().maximum(utils_bigNumber__WEBPACK_IMPORTED_MODULE_9__/* .BIG_ZERO */ .HW, creditLeftWithNegative)
    };
    return {
        ...state,
        allowance,
        contract,
        setPendingTx,
        setIsClaimed,
        fetchIfoData,
        resetIfoData,
        ifoCredit
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useGetWalletIfoData);

});

/***/ }),

/***/ 60911:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "t": () => (/* binding */ IfoPageLayout)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(99150);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var state_pools_hooks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1624);
/* harmony import */ var _components_Hero__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1529);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([state_pools_hooks__WEBPACK_IMPORTED_MODULE_5__]);
state_pools_hooks__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];







const IfoPageLayout = ({ children  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_2__/* .useTranslation */ .$G)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const isExact = router.route === '/ifo';
    (0,state_pools_hooks__WEBPACK_IMPORTED_MODULE_5__/* .useFetchIfoPool */ .HV)();
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.SubMenuItems, {
                items: [
                    {
                        label: t('Latest'),
                        href: '/ifo'
                    },
                    {
                        label: t('Finished'),
                        href: '/ifo/history'
                    }, 
                ],
                activeItem: isExact ? '/ifo' : '/ifo/history'
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Hero__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}),
            children
        ]
    }));
};

});

/***/ })

};
;
//# sourceMappingURL=941.js.map