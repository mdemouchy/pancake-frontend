"use strict";
exports.id = 1527;
exports.ids = [1527];
exports.modules = {

/***/ 11527:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "f": () => (/* binding */ sortActivity)
/* harmony export */ });
/* harmony import */ var _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(65757);
/* harmony import */ var _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var state_nftMarket_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(75186);


const sortActivity = ({ askOrders =[] , transactions =[]  })=>{
    const getAskOrderEvent = (orderType)=>{
        switch(orderType){
            case state_nftMarket_types__WEBPACK_IMPORTED_MODULE_1__/* .AskOrderType.CANCEL */ .cP.CANCEL:
                return state_nftMarket_types__WEBPACK_IMPORTED_MODULE_1__/* .MarketEvent.CANCEL */ .YG.CANCEL;
            case state_nftMarket_types__WEBPACK_IMPORTED_MODULE_1__/* .AskOrderType.MODIFY */ .cP.MODIFY:
                return state_nftMarket_types__WEBPACK_IMPORTED_MODULE_1__/* .MarketEvent.MODIFY */ .YG.MODIFY;
            case state_nftMarket_types__WEBPACK_IMPORTED_MODULE_1__/* .AskOrderType.NEW */ .cP.NEW:
                return state_nftMarket_types__WEBPACK_IMPORTED_MODULE_1__/* .MarketEvent.NEW */ .YG.NEW;
            default:
                return state_nftMarket_types__WEBPACK_IMPORTED_MODULE_1__/* .MarketEvent.MODIFY */ .YG.MODIFY;
        }
    };
    const transformTransactions = (transactionsHistory)=>{
        const transformedTransactions = transactionsHistory.map((transactionHistory)=>{
            const marketEvent = state_nftMarket_types__WEBPACK_IMPORTED_MODULE_1__/* .MarketEvent.SELL */ .YG.SELL;
            const { timestamp , nft  } = transactionHistory;
            const price = transactionHistory.askPrice;
            const tx = transactionHistory.id;
            const buyer = transactionHistory.buyer.id;
            const seller = transactionHistory.seller.id;
            return {
                marketEvent,
                price,
                timestamp,
                nft,
                tx,
                buyer,
                seller
            };
        });
        return transformedTransactions;
    };
    const transformAskOrders = (askOrdersHistory)=>{
        const transformedAskOrders = askOrdersHistory.map((askOrderHistory)=>{
            const marketEvent = getAskOrderEvent(askOrderHistory.orderType);
            const price = askOrderHistory.askPrice;
            const { timestamp , nft  } = askOrderHistory;
            const tx = askOrderHistory.id;
            const seller = askOrderHistory?.seller.id;
            return {
                marketEvent,
                price,
                timestamp,
                nft,
                tx,
                seller
            };
        });
        return transformedAskOrders;
    };
    const allActivity = [
        ...transformAskOrders(askOrders),
        ...transformTransactions(transactions)
    ];
    if (allActivity.length > 0) {
        const sortedByMostRecent = allActivity.sort((activityItem1, activityItem2)=>{
            const timestamp1 = _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__.BigNumber.from(activityItem1.timestamp);
            const timestamp2 = _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__.BigNumber.from(activityItem2.timestamp);
            return timestamp2.sub(timestamp1).toNumber();
        });
        return sortedByMostRecent;
    }
    return [];
};


/***/ })

};
;
//# sourceMappingURL=1527.js.map