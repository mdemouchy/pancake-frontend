"use strict";
exports.id = 2920;
exports.ids = [2920];
exports.modules = {

/***/ 49704:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ UnsupportedCurrencyFooter)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var components_Layout_Row__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(39475);
/* harmony import */ var components_Layout_Column__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(41914);
/* harmony import */ var components_Logo__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(83356);
/* harmony import */ var hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(64011);
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(38328);
/* harmony import */ var utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(53854);
/* harmony import */ var _hooks_Tokens__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(86435);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([components_Logo__WEBPACK_IMPORTED_MODULE_6__, _hooks_Tokens__WEBPACK_IMPORTED_MODULE_10__]);
([components_Logo__WEBPACK_IMPORTED_MODULE_6__, _hooks_Tokens__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);











const DetailsFooter = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
    componentId: "sc-ece6f1f6-0"
})`
  padding: 8px 0;
  width: 100%;
  max-width: 400px;
  border-bottom-left-radius: 20px;
  border-bottom-right-radius: 20px;
  color: ${({ theme  })=>theme.colors.text
};
  background-color: ${({ theme  })=>theme.colors.invertedContrast
};
  text-align: center;
`;
const UnsupportedModal = ({ currencies , onDismiss  })=>{
    const { chainId  } = (0,hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
    const tokens = chainId && currencies ? currencies.map((currency)=>{
        return (0,utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_9__/* .wrappedCurrency */ .pu)(currency, chainId);
    }) : [];
    const unsupportedTokens = (0,_hooks_Tokens__WEBPACK_IMPORTED_MODULE_10__/* .useUnsupportedTokens */ .l6)();
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Modal, {
        title: "Unsupported Assets",
        maxWidth: "420px",
        onDismiss: onDismiss,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(components_Layout_Column__WEBPACK_IMPORTED_MODULE_5__/* .AutoColumn */ .Tz, {
            gap: "lg",
            children: [
                tokens.map((token)=>{
                    return token && unsupportedTokens && Object.keys(unsupportedTokens).includes(token.address) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(components_Layout_Column__WEBPACK_IMPORTED_MODULE_5__/* .AutoColumn */ .Tz, {
                        gap: "10px",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(components_Layout_Row__WEBPACK_IMPORTED_MODULE_4__/* .AutoRow */ .BA, {
                                gap: "5px",
                                align: "center",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Logo__WEBPACK_IMPORTED_MODULE_6__/* .CurrencyLogo */ .Xw, {
                                        currency: token,
                                        size: "24px"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                        children: token.symbol
                                    })
                                ]
                            }),
                            chainId && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Link, {
                                external: true,
                                small: true,
                                color: "primaryDark",
                                href: (0,utils__WEBPACK_IMPORTED_MODULE_8__/* .getBscScanLink */ .s6)(token.address, 'address', chainId),
                                children: token.address
                            })
                        ]
                    }, token.address?.concat('not-supported'));
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Layout_Column__WEBPACK_IMPORTED_MODULE_5__/* .AutoColumn */ .Tz, {
                    gap: "lg",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        children: "Some assets are not available through this interface because they may not work well with our smart contract or we are unable to allow trading for legal reasons."
                    })
                })
            ]
        })
    }));
};
function UnsupportedCurrencyFooter({ currencies  }) {
    const [onPresentModal] = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.useModal)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(UnsupportedModal, {
        currencies: currencies
    }));
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(DetailsFooter, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
            variant: "text",
            onClick: onPresentModal,
            children: "Read more about unsupported assets"
        })
    }));
};

});

/***/ }),

/***/ 45131:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "i": () => (/* binding */ maxAmountSpend)
/* harmony export */ });
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(42877);
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _config_constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3862);


/**
 * Given some token amount, return the max that can be spent of it
 * @param currencyAmount to return max of
 */ function maxAmountSpend(currencyAmount) {
    if (!currencyAmount) return undefined;
    if (currencyAmount.currency === _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.ETHER) {
        if (_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.greaterThan(currencyAmount.raw, _config_constants__WEBPACK_IMPORTED_MODULE_1__/* .MIN_BNB */ .Uz)) {
            return _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.CurrencyAmount.ether(_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.subtract(currencyAmount.raw, _config_constants__WEBPACK_IMPORTED_MODULE_1__/* .MIN_BNB */ .Uz));
        }
        return _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.CurrencyAmount.ether(_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(0));
    }
    return currencyAmount;
}
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (maxAmountSpend)));


/***/ })

};
;
//# sourceMappingURL=2920.js.map