"use strict";
exports.id = 6261;
exports.ids = [6261];
exports.modules = {

/***/ 36261:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "hl": () => (/* binding */ LightCard),
/* harmony export */   "m5": () => (/* binding */ LightGreyCard),
/* harmony export */   "h2": () => (/* binding */ GreyCard)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__);


const Card = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_1__.Box).withConfig({
    componentId: "sc-2d513063-0"
})`
  width: ${({ width  })=>width ?? '100%'
};
  padding: ${({ padding  })=>padding ?? '1.25rem'
};
  border: ${({ border  })=>border
};
  border-radius: ${({ borderRadius  })=>borderRadius ?? '16px'
};
  background-color: ${({ theme  })=>theme.colors.background
};
`;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Card);
const LightCard = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(Card).withConfig({
    componentId: "sc-2d513063-1"
})`
  border: 1px solid ${({ theme  })=>theme.colors.background
};
  background-color: ${({ theme  })=>theme.colors.backgroundAlt
};
`;
const LightGreyCard = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(Card).withConfig({
    componentId: "sc-2d513063-2"
})`
  border: 1px solid ${({ theme  })=>theme.colors.cardBorder
};
  background-color: ${({ theme  })=>theme.colors.background
};
`;
const GreyCard = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(Card).withConfig({
    componentId: "sc-2d513063-3"
})`
  background-color: ${({ theme  })=>theme.colors.dropdown
};
`;


/***/ })

};
;
//# sourceMappingURL=6261.js.map