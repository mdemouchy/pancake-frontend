"use strict";
exports.id = 8753;
exports.ids = [8753];
exports.modules = {

/***/ 10056:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(89699);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(13968);
/* harmony import */ var state_nftMarket_types__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(75186);
/* harmony import */ var state_nftMarket_helpers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(86849);
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(38328);
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(15941);
/* harmony import */ var config_constants_types__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(97971);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swr__WEBPACK_IMPORTED_MODULE_6__, state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_2__]);
([swr__WEBPACK_IMPORTED_MODULE_6__, state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);








const useNftsForAddress = (account, profile, isProfileFetching)=>{
    const collections = (0,state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_2__/* .useGetCollections */ .t8)();
    const hasProfileNft = profile?.tokenId;
    const profileNftTokenId = profile?.tokenId?.toString();
    const profileNftCollectionAddress = profile?.collectionAddress;
    const profileNftWithCollectionAddress = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        if (hasProfileNft) {
            return {
                tokenId: profileNftTokenId,
                collectionAddress: profileNftCollectionAddress,
                nftLocation: state_nftMarket_types__WEBPACK_IMPORTED_MODULE_3__/* .NftLocation.PROFILE */ .Fb.PROFILE
            };
        }
        return null;
    }, [
        profileNftTokenId,
        profileNftCollectionAddress,
        hasProfileNft
    ]);
    const { status , data , mutate  } = (0,swr__WEBPACK_IMPORTED_MODULE_6__["default"])([
        account,
        collections,
        isProfileFetching,
        'userNfts'
    ], async ()=>{
        if (!isProfileFetching && !lodash_isEmpty__WEBPACK_IMPORTED_MODULE_1___default()(collections) && (0,utils__WEBPACK_IMPORTED_MODULE_5__/* .isAddress */ .UJ)(account)) {
            return (0,state_nftMarket_helpers__WEBPACK_IMPORTED_MODULE_4__/* .getCompleteAccountNftData */ .A8)(account, collections, profileNftWithCollectionAddress);
        }
        return [];
    });
    return {
        nfts: data ?? [],
        isLoading: status !== config_constants_types__WEBPACK_IMPORTED_MODULE_7__/* .FetchStatus.Fetched */ .iF.Fetched,
        refresh: mutate
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useNftsForAddress);

});

/***/ }),

/***/ 74136:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);




const Label = styled_components__WEBPACK_IMPORTED_MODULE_2___default().label.withConfig({
    componentId: "sc-df5673e8-0"
})`
  cursor: ${({ isDisabled  })=>isDisabled ? 'not-allowed' : 'pointer'
};
  display: flex;
  justify-content: space-between;
  align-items: center;
  opacity: ${({ isDisabled  })=>isDisabled ? '0.6' : '1'
};
`;
const Body = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-df5673e8-1"
})`
  align-items: center;
  display: flex;
  flex-grow: 1;
  height: 80px;
  padding: 8px 16px;
`;
const Children = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-df5673e8-2"
})`
  margin-left: 16px;
`;
const StyledBackgroundImage = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-df5673e8-3"
})`
  align-self: stretch;
  background-image: url('${({ src  })=>src
}');
  background-size: contain;
  background-position: center;
  background-repeat: no-repeat;
  flex: none;
  width: 80px;
`;
const SelectionCard = ({ name , value , isChecked =false , image , onChange , disabled , children , ...props })=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Card, {
        isSuccess: isChecked,
        isDisabled: disabled,
        mb: "16px",
        ...props,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Label, {
            isDisabled: disabled,
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Body, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Radio, {
                            name: name,
                            checked: isChecked,
                            value: value,
                            onChange: (e)=>onChange(e.target.value)
                            ,
                            disabled: disabled,
                            style: {
                                flex: 'none'
                            }
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Children, {
                            children: children
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledBackgroundImage, {
                    src: image
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SelectionCard);


/***/ })

};
;
//# sourceMappingURL=8753.js.map