"use strict";
exports.id = 8431;
exports.ids = [8431];
exports.modules = {

/***/ 44482:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* reexport */ PageHeader_PageHeader)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(57518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: external "@pancakeswap/uikit"
var uikit_ = __webpack_require__(2829);
// EXTERNAL MODULE: ./src/components/Layout/Container.tsx
var Container = __webpack_require__(55027);
;// CONCATENATED MODULE: ./src/components/PageHeader/PageHeader.tsx





const Outer = external_styled_components_default()(uikit_.Box).withConfig({
    componentId: "sc-4729964c-0"
})`
  background: ${({ theme , background  })=>background || theme.colors.gradients.bubblegum
};
`;
const Inner = external_styled_components_default()(Container/* default */.Z).withConfig({
    componentId: "sc-4729964c-1"
})`
  padding-top: 32px;
  padding-bottom: 32px;
`;
const PageHeader = ({ background , children , ...props })=>/*#__PURE__*/ jsx_runtime_.jsx(Outer, {
        background: background,
        ...props,
        children: /*#__PURE__*/ jsx_runtime_.jsx(Inner, {
            children: children
        })
    })
;
/* harmony default export */ const PageHeader_PageHeader = (PageHeader);

;// CONCATENATED MODULE: ./src/components/PageHeader/index.ts




/***/ }),

/***/ 70217:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const AvatarImage = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.attrs(({ alt  })=>({
        alt
    })
).withConfig({
    componentId: "sc-20e79e7-0"
})`
  background: url('${({ src  })=>src
}');
  background-repeat: no-repeat;
  background-size: cover;
  border-radius: 50%;
  position: relative;
  width: 96px;
  height: 96px;
  border: 4px ${({ borderColor  })=>borderColor || '#f2ecf2'
} solid;

  & > img {
    border-radius: 50%;
  }
`;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AvatarImage);


/***/ }),

/***/ 12399:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_BannerHeader)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
// EXTERNAL MODULE: external "@pancakeswap/uikit"
var uikit_ = __webpack_require__(2829);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(57518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
;// CONCATENATED MODULE: ./src/views/Nft/market/components/BannerHeader/BannerImage.tsx

const StyledBannerImage = external_styled_components_default().div.attrs(({ alt  })=>({
        alt
    })
).withConfig({
    componentId: "sc-b1ab0d1f-0"
})`
  ${({ src , theme  })=>src ? `background-image: url('${src}')` : `background-color: ${theme.colors.cardBorder}`
};
  background-image: url('${({ src  })=>src
}');
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
  flex: none;
  width: 100%;
  border-radius: 32px;
  height: 123px;

  ${({ theme  })=>theme.mediaQueries.sm
} {
    height: 192px;
  }

  ${({ theme  })=>theme.mediaQueries.md
} {
    height: 256px;
  }
`;
/* harmony default export */ const BannerImage = (StyledBannerImage);

;// CONCATENATED MODULE: ./src/views/Nft/market/components/BannerHeader/index.tsx




const BannerHeader = ({ bannerImage , bannerAlt , avatar , children , ...props })=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx(uikit_.Flex, {
        flexDirection: "column",
        mb: "24px",
        ...props,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(uikit_.Box, {
            position: "relative",
            pb: "56px",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(BannerImage, {
                    src: bannerImage,
                    alt: bannerAlt
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Box, {
                    position: "absolute",
                    bottom: 0,
                    left: -4,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(uikit_.Flex, {
                        alignItems: "flex-end",
                        children: [
                            avatar,
                            children
                        ]
                    })
                })
            ]
        })
    }));
};
/* harmony default export */ const components_BannerHeader = (BannerHeader);


/***/ }),

/***/ 38282:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_PageHeader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(44482);
/* harmony import */ var hooks_useTheme__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(23917);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks_useTheme__WEBPACK_IMPORTED_MODULE_3__]);
hooks_useTheme__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];




const MarketPageHeader = (props)=>{
    const { theme  } = (0,hooks_useTheme__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)();
    const background = theme.isDark ? 'linear-gradient(166.77deg, #3B4155 0%, #3A3045 100%)' : 'linear-gradient(111.68deg, #f2ecf2 0%, #e8f2f6 100%)';
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_PageHeader__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        background: background,
        ...props
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MarketPageHeader);

});

/***/ }),

/***/ 75199:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);



const MarketPageTitle = ({ title , description , children , ...props })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Grid, {
        gridGap: "16px",
        alignItems: "center",
        gridTemplateColumns: [
            '1fr',
            null,
            null,
            null,
            'repeat(2, 1fr)'
        ],
        ...props,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Box, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Heading, {
                        as: "h1",
                        scale: "xl",
                        color: "secondary",
                        mb: "16px",
                        children: title
                    }),
                    description
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Box, {
                children: children
            })
        ]
    })
;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MarketPageTitle);


/***/ }),

/***/ 74298:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "B": () => (/* binding */ StatBoxItem),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);




const StatBoxItem = ({ title , stat , ...props })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Box, {
        ...props,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                fontSize: "12px",
                color: "textSubtle",
                textAlign: "center",
                children: title
            }),
            stat === null ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Skeleton, {
                height: "24px",
                width: "50%",
                mx: "auto"
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                fontWeight: "600",
                textAlign: "center",
                children: stat
            })
        ]
    })
;
const StatBox = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex).withConfig({
    componentId: "sc-c4bd049b-0"
})`
  align-items: center;
  background: ${({ theme  })=>theme.colors.invertedContrast
};
  border: 1px solid ${({ theme  })=>theme.colors.cardBorder
};
  border-radius: ${({ theme  })=>theme.radii.card
};
  justify-content: space-around;
  padding: 8px;
  width: 100%;
`;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (StatBox);


/***/ })

};
;
//# sourceMappingURL=8431.js.map