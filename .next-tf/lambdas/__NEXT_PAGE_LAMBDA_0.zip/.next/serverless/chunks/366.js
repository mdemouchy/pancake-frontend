"use strict";
exports.id = 366;
exports.ids = [366];
exports.modules = {

/***/ 90366:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "M": () => (/* binding */ fetchActivityNftMetadata)
/* harmony export */ });
/* harmony import */ var state_nftMarket_helpers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(86849);
/* harmony import */ var lodash_uniqBy__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(69309);
/* harmony import */ var lodash_uniqBy__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash_uniqBy__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1940);



const fetchActivityNftMetadata = async (activities)=>{
    const hasPBCollections = activities.some((activity)=>activity.nft.collection.id.toLowerCase() === _constants__WEBPACK_IMPORTED_MODULE_2__/* .pancakeBunniesAddress.toLowerCase */ .Jr.toLowerCase()
    );
    let bunniesMetadata;
    if (hasPBCollections) {
        bunniesMetadata = await (0,state_nftMarket_helpers__WEBPACK_IMPORTED_MODULE_0__/* .getNftsFromCollectionApi */ .Rq)(_constants__WEBPACK_IMPORTED_MODULE_2__/* .pancakeBunniesAddress */ .Jr);
    }
    const pbNfts = bunniesMetadata ? activities.filter((activity)=>activity.nft.collection.id.toLowerCase() === _constants__WEBPACK_IMPORTED_MODULE_2__/* .pancakeBunniesAddress.toLowerCase */ .Jr.toLowerCase()
    ).map((activity)=>{
        const { name: collectionName  } = bunniesMetadata.data[activity.nft.otherId].collection;
        return {
            ...bunniesMetadata.data[activity.nft.otherId],
            tokenId: activity.nft.tokenId,
            attributes: [
                {
                    traitType: 'bunnyId',
                    value: activity.nft.otherId
                }
            ],
            collectionAddress: activity.nft.collection.id,
            collectionName
        };
    }) : [];
    const activityNftTokenIds = lodash_uniqBy__WEBPACK_IMPORTED_MODULE_1___default()(activities.filter((activity)=>activity.nft.collection.id.toLowerCase() !== _constants__WEBPACK_IMPORTED_MODULE_2__/* .pancakeBunniesAddress.toLowerCase */ .Jr.toLowerCase()
    ).map((activity)=>{
        return {
            tokenId: activity.nft.tokenId,
            collectionAddress: activity.nft.collection.id
        };
    }), 'tokenId');
    const nfts = await (0,state_nftMarket_helpers__WEBPACK_IMPORTED_MODULE_0__/* .getNftsFromDifferentCollectionsApi */ ._C)(activityNftTokenIds);
    return nfts.concat(pbNfts);
};


/***/ })

};
;
//# sourceMappingURL=366.js.map