"use strict";
exports.id = 6149;
exports.ids = [6149];
exports.modules = {

/***/ 56149:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(13968);
/* harmony import */ var _ActivityHistory_ActivityHistory__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(58686);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_ActivityHistory_ActivityHistory__WEBPACK_IMPORTED_MODULE_4__, state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_3__]);
([_ActivityHistory_ActivityHistory__WEBPACK_IMPORTED_MODULE_4__, state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);





const Activity = ()=>{
    const collectionAddress = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)().query.collectionAddress;
    const collection = (0,state_nftMarket_hooks__WEBPACK_IMPORTED_MODULE_3__/* .useGetCollection */ .YD)(collectionAddress);
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ActivityHistory_ActivityHistory__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
            collection: collection
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Activity);

});

/***/ })

};
;
//# sourceMappingURL=6149.js.map