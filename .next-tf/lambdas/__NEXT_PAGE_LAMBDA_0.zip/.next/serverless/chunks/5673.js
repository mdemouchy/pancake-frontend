"use strict";
exports.id = 5673;
exports.ids = [5673];
exports.modules = {

/***/ 75673:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "N": () => (/* binding */ ButtonArrangement),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99150);





var ButtonArrangement;
(function(ButtonArrangement) {
    ButtonArrangement["ROW"] = 'row';
    ButtonArrangement["SEQUENTIAL"] = 'sequential';
})(ButtonArrangement || (ButtonArrangement = {}));
const StyledApproveConfirmButtonRow = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-525eb1f4-0"
})`
  align-items: center;
  display: grid;
  grid-template-columns: 1fr;
  justify-content: center;

  ${({ theme  })=>theme.mediaQueries.md
} {
    grid-template-columns: 1fr 24px 1fr;
  }
`;
const Button = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Button).withConfig({
    componentId: "sc-525eb1f4-1"
})`
  width: 100%;

  ${({ theme  })=>theme.mediaQueries.md
} {
    min-width: 160px;
  }
`;
const iconAttrs = {
    width: '24px',
    color: 'textDisabled'
};
const ChevronRight = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.ChevronRightIcon).attrs(iconAttrs).withConfig({
    componentId: "sc-525eb1f4-2"
})`
  display: none;

  ${({ theme  })=>theme.mediaQueries.md
} {
    display: block;
  }
`;
const ChevronBottom = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.ChevronDownIcon).attrs(iconAttrs).withConfig({
    componentId: "sc-525eb1f4-3"
})`
  display: block;

  ${({ theme  })=>theme.mediaQueries.md
} {
    display: none;
  }
`;
const spinnerIcon = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.AutoRenewIcon, {
    spin: true,
    color: "currentColor"
});
const ApproveConfirmButtons = ({ isApproveDisabled , isApproving , isConfirming , isConfirmDisabled , onApprove , onConfirm , buttonArrangement =ButtonArrangement.ROW , confirmLabel , confirmId ,  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    const confirmButtonText = confirmLabel ?? t('Confirm');
    const ApproveConfirmRow = ()=>{
        return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(StyledApproveConfirmButtonRow, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Box, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Button, {
                        disabled: isApproveDisabled,
                        onClick: onApprove,
                        endIcon: isApproving ? spinnerIcon : undefined,
                        isLoading: isApproving,
                        children: isApproving ? t('Enabling') : t('Enable')
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                    justifyContent: "center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ChevronRight, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ChevronBottom, {})
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Box, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Button, {
                        id: confirmId,
                        onClick: onConfirm,
                        disabled: isConfirmDisabled,
                        isLoading: isConfirming,
                        endIcon: isConfirming ? spinnerIcon : undefined,
                        children: isConfirming ? t('Confirming') : confirmButtonText
                    })
                })
            ]
        }));
    };
    const ApproveConfirmSequential = ()=>{
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: isApproveDisabled ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Box, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Button, {
                    id: confirmId,
                    onClick: onConfirm,
                    disabled: isConfirmDisabled,
                    isLoading: isConfirming,
                    endIcon: isConfirming ? spinnerIcon : undefined,
                    children: isConfirming ? t('Confirming') : confirmButtonText
                })
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Box, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Button, {
                    onClick: onApprove,
                    endIcon: isApproving ? spinnerIcon : undefined,
                    isLoading: isApproving,
                    children: isApproving ? t('Enabling') : t('Enable')
                })
            })
        }));
    };
    return buttonArrangement === ButtonArrangement.ROW ? ApproveConfirmRow() : ApproveConfirmSequential();
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ApproveConfirmButtons);


/***/ })

};
;
//# sourceMappingURL=5673.js.map