"use strict";
exports.id = 1228;
exports.ids = [1228];
exports.modules = {

/***/ 71228:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "d": () => (/* binding */ useCallWithGasPrice)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var state_user_hooks__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(68605);
/* harmony import */ var lodash_get__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1712);
/* harmony import */ var lodash_get__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lodash_get__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _sentry_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(15427);
/* harmony import */ var _sentry_react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_sentry_react__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([state_user_hooks__WEBPACK_IMPORTED_MODULE_1__]);
state_user_hooks__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];




function useCallWithGasPrice() {
    const gasPrice = (0,state_user_hooks__WEBPACK_IMPORTED_MODULE_1__/* .useGasPrice */ .Fh)();
    /**
   * Perform a contract call with a gas price returned from useGasPrice
   * @param contract Used to perform the call
   * @param methodName The name of the method called
   * @param methodArgs An array of arguments to pass to the method
   * @param overrides An overrides object to pass to the method. gasPrice passed in here will take priority over the price returned by useGasPrice
   * @returns https://docs.ethers.io/v5/api/providers/types/#providers-TransactionReceipt
   */ const callWithGasPrice = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async (contract, methodName, methodArgs = [], overrides = null)=>{
        _sentry_react__WEBPACK_IMPORTED_MODULE_3__.addBreadcrumb({
            type: 'Transaction',
            message: `Call with gas price: ${gasPrice}`,
            data: {
                contractAddress: contract.address,
                methodName,
                methodArgs,
                overrides
            }
        });
        const contractMethod = lodash_get__WEBPACK_IMPORTED_MODULE_2___default()(contract, methodName);
        const hasManualGasPriceOverride = overrides?.gasPrice;
        const tx = await contractMethod(...methodArgs, hasManualGasPriceOverride ? {
            ...overrides
        } : {
            ...overrides,
            gasPrice
        });
        if (tx) {
            _sentry_react__WEBPACK_IMPORTED_MODULE_3__.addBreadcrumb({
                type: 'Transaction',
                message: `Transaction sent: ${tx.hash}`,
                data: {
                    hash: tx.hash,
                    from: tx.from,
                    gasLimit: tx.gasLimit?.toString(),
                    nonce: tx.nonce
                }
            });
        }
        return tx;
    }, [
        gasPrice
    ]);
    return {
        callWithGasPrice
    };
}

});

/***/ })

};
;
//# sourceMappingURL=1228.js.map