"use strict";
exports.id = 7858;
exports.ids = [7858];
exports.modules = {

/***/ 71249:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_ReactMarkdown)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
// EXTERNAL MODULE: external "react-markdown"
var external_react_markdown_ = __webpack_require__(13702);
var external_react_markdown_default = /*#__PURE__*/__webpack_require__.n(external_react_markdown_);
// EXTERNAL MODULE: external "remark-gfm"
var external_remark_gfm_ = __webpack_require__(78344);
var external_remark_gfm_default = /*#__PURE__*/__webpack_require__.n(external_remark_gfm_);
// EXTERNAL MODULE: external "@pancakeswap/uikit"
var uikit_ = __webpack_require__(2829);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(57518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
;// CONCATENATED MODULE: ./src/components/ReactMarkdown/styles.tsx




const Table = external_styled_components_default().table.withConfig({
    componentId: "sc-65982d11-0"
})`
  margin-bottom: 32px;
  margin-top: 32px;
  width: 100%;

  td,
  th {
    color: ${({ theme  })=>theme.colors.text
};
    padding: 8px;
  }
`;
const TableBox = external_styled_components_default().div.withConfig({
    componentId: "sc-65982d11-1"
})`
  width: 100%;
  overflow: auto;
  -webkit-overflow-scrolling: touch;
`;
const ThemedComponent = external_styled_components_default().div.withConfig({
    componentId: "sc-65982d11-2"
})`
  color: ${({ theme  })=>theme.colors.text
};
  margin-bottom: 16px;
  margin-top: 16px;

  li {
    margin-bottom: 8px;
  }
`;
const Pre = external_styled_components_default().pre.withConfig({
    componentId: "sc-65982d11-3"
})`
  color: ${({ theme  })=>theme.colors.text
};
  margin-bottom: 16px;
  margin-top: 16px;
  max-width: 100%;
  overflow-x: auto;
`;
const AStyle = external_styled_components_default().a.withConfig({
    componentId: "sc-65982d11-4"
})`
  word-break: break-all;
`;
const Title = (props)=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx(uikit_.Heading, {
        as: "h4",
        scale: "lg",
        my: "16px",
        ...props
    }));
};
const markdownComponents = {
    h1: Title,
    h2: Title,
    h3: Title,
    h4: Title,
    h5: Title,
    h6: Title,
    p: (props)=>{
        // @ts-ignore
        return(/*#__PURE__*/ jsx_runtime_.jsx(uikit_.Text, {
            as: "p",
            my: "16px",
            ...props
        }));
    },
    table: ({ ...props })=>{
        return(/*#__PURE__*/ jsx_runtime_.jsx(TableBox, {
            children: /*#__PURE__*/ jsx_runtime_.jsx(Table, {
                children: props.children
            })
        }));
    },
    ol: (props)=>{
        return(/*#__PURE__*/ jsx_runtime_.jsx(ThemedComponent, {
            as: "ol",
            ...props
        }));
    },
    ul: (props)=>{
        return(/*#__PURE__*/ jsx_runtime_.jsx(ThemedComponent, {
            as: "ul",
            ...props
        }));
    },
    pre: Pre,
    a: AStyle
};
/* harmony default export */ const styles = (markdownComponents);

;// CONCATENATED MODULE: ./src/components/ReactMarkdown/index.tsx





const ReactMarkdown = (props)=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx((external_react_markdown_default()), {
        remarkPlugins: [
            (external_remark_gfm_default())
        ],
        components: styles,
        ...props
    }));
};
/* harmony default export */ const components_ReactMarkdown = (ReactMarkdown);


/***/ }),

/***/ 6365:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(99150);
/* harmony import */ var utils_formatBalance__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(65044);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(90767);






const DetailsView = ({ total , cakeBalance , cakeVaultBalance , cakePoolBalance , poolsBalance , cakeBnbLpBalance , ifoPoolBalance ,  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_3__/* .useTranslation */ .$G)();
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styles__WEBPACK_IMPORTED_MODULE_5__/* .ModalInner */ .I, {
        mb: "0",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                as: "p",
                mb: "24px",
                fontSize: "14px",
                color: "textSubtle",
                children: t('Your voting power is determined by the amount of CAKE you held at the block detailed below. CAKE held in other places does not contribute to your voting power.')
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                color: "secondary",
                textTransform: "uppercase",
                mb: "4px",
                bold: true,
                fontSize: "14px",
                children: t('Overview')
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styles__WEBPACK_IMPORTED_MODULE_5__/* .VotingBox */ .k, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        color: "secondary",
                        children: t('Your Voting Power')
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        bold: true,
                        fontSize: "20px",
                        children: (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_4__/* .formatNumber */ .uf)(total, 0, 3)
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                color: "secondary",
                textTransform: "uppercase",
                mb: "4px",
                bold: true,
                fontSize: "14px",
                children: t('Your Cake Held Now')
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                alignItems: "center",
                justifyContent: "space-between",
                mb: "4px",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        color: "textSubtle",
                        fontSize: "16px",
                        children: t('Wallet')
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        textAlign: "right",
                        children: (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_4__/* .formatNumber */ .uf)(cakeBalance, 0, 3)
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                alignItems: "center",
                justifyContent: "space-between",
                mb: "4px",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        color: "textSubtle",
                        fontSize: "16px",
                        children: t('Manual CAKE Pool')
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        textAlign: "right",
                        children: (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_4__/* .formatNumber */ .uf)(cakePoolBalance, 0, 3)
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                alignItems: "center",
                justifyContent: "space-between",
                mb: "4px",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        color: "textSubtle",
                        fontSize: "16px",
                        children: t('Auto CAKE Pool')
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        textAlign: "right",
                        children: (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_4__/* .formatNumber */ .uf)(cakeVaultBalance, 0, 3)
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                alignItems: "center",
                justifyContent: "space-between",
                mb: "4px",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        color: "textSubtle",
                        fontSize: "16px",
                        children: t('IFO Pool')
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        textAlign: "right",
                        children: (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_4__/* .formatNumber */ .uf)(ifoPoolBalance, 0, 3)
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                alignItems: "center",
                justifyContent: "space-between",
                mb: "4px",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        color: "textSubtle",
                        fontSize: "16px",
                        children: t('Other Syrup Pools')
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        textAlign: "right",
                        children: (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_4__/* .formatNumber */ .uf)(poolsBalance, 0, 3)
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                alignItems: "center",
                justifyContent: "space-between",
                mb: "4px",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        color: "textSubtle",
                        fontSize: "16px",
                        children: t('CAKE BNB LP')
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        textAlign: "right",
                        children: (0,utils_formatBalance__WEBPACK_IMPORTED_MODULE_4__/* .formatNumber */ .uf)(cakeBnbLpBalance, 0, 3)
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DetailsView);


/***/ }),

/***/ 90767:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "k": () => (/* binding */ VotingBox),
/* harmony export */   "I": () => (/* binding */ ModalInner)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);




const VotingBox = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
    componentId: "sc-c17ae568-0"
})`
  align-items: center;
  border: 1px solid ${({ theme  })=>theme.colors.cardBorder
};
  border-radius: 12px;
  display: flex;
  height: 64px;
  justify-content: space-between;
  margin-bottom: 24px;
  padding: 0 16px;
`;
const ModalInner = (props)=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Box, {
        mb: "24px",
        maxWidth: "320px",
        ...props
    }));
};


/***/ }),

/***/ 73408:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const Layout = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
    componentId: "sc-930753e4-0"
})`
  align-items: start;
  display: grid;
  grid-gap: 32px;
  grid-template-columns: minmax(0, 1fr);

  ${({ theme  })=>theme.mediaQueries.lg
} {
    grid-template-columns: 1fr 332px;
  }
`;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Layout);


/***/ }),

/***/ 4411:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var utils_calls__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(50059);
/* harmony import */ var utils_addressHelpers__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(55878);
/* harmony import */ var utils_providers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(35922);
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(20388);






const initialState = {
    cakeBalance: 0,
    cakeVaultBalance: 0,
    cakePoolBalance: 0,
    poolsBalance: 0,
    cakeBnbLpBalance: 0,
    ifoPoolBalance: 0,
    total: 0
};
const useGetVotingPower = (block, isActive = true)=>{
    const { account  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_1__.useWeb3React)();
    const { 0: votingPower , 1: setVotingPower  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(initialState);
    const { 0: isLoading , 1: setIsLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(!!account);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        const fetchVotingPower = async ()=>{
            setIsLoading(true);
            try {
                const blockNumber = block || await utils_providers__WEBPACK_IMPORTED_MODULE_4__/* .simpleRpcProvider.getBlockNumber */ .J.getBlockNumber();
                const eligiblePools = await (0,utils_calls__WEBPACK_IMPORTED_MODULE_2__/* .getActivePools */ .yp)(blockNumber);
                const poolAddresses = eligiblePools.map(({ contractAddress  })=>(0,utils_addressHelpers__WEBPACK_IMPORTED_MODULE_3__/* .getAddress */ .Kn)(contractAddress)
                );
                const { cakeBalance , cakeBnbLpBalance , cakePoolBalance , total , poolsBalance , cakeVaultBalance , IFOPoolBalance ,  } = await (0,_helpers__WEBPACK_IMPORTED_MODULE_5__/* .getVotingPower */ .u$)(account, poolAddresses, blockNumber);
                if (isActive) {
                    setVotingPower((prevVotingPower)=>({
                            ...prevVotingPower,
                            cakeBalance: parseFloat(cakeBalance),
                            cakeBnbLpBalance: parseFloat(cakeBnbLpBalance),
                            cakePoolBalance: parseFloat(cakePoolBalance),
                            poolsBalance: parseFloat(poolsBalance),
                            cakeVaultBalance: parseFloat(cakeVaultBalance),
                            ifoPoolBalance: IFOPoolBalance ? parseFloat(IFOPoolBalance) : 0,
                            total: parseFloat(total)
                        })
                    );
                }
            } finally{
                setIsLoading(false);
            }
        };
        if (account && isActive) {
            fetchVotingPower();
        }
    }, [
        account,
        block,
        setVotingPower,
        isActive,
        setIsLoading
    ]);
    return {
        ...votingPower,
        isLoading
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useGetVotingPower);


/***/ })

};
;
//# sourceMappingURL=7858.js.map