"use strict";
exports.id = 1685;
exports.ids = [1685];
exports.modules = {

/***/ 71685:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _usePreviousValue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6199);


/**
 * A helper hook to keep track of the time between events
 * Can also be used to force an effect to re-run
 */ const useLastUpdated = ()=>{
    const { 0: lastUpdated , 1: setStateLastUpdated  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(Date.now());
    const previousLastUpdated = (0,_usePreviousValue__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)(lastUpdated);
    const setLastUpdated = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(()=>{
        setStateLastUpdated(Date.now());
    }, [
        setStateLastUpdated
    ]);
    return {
        lastUpdated,
        previousLastUpdated,
        setLastUpdated
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useLastUpdated);


/***/ }),

/***/ 6199:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

/**
 * Returns the previous value of the given value
 *
 * @see https://reactjs.org/docs/hooks-faq.html#how-to-get-the-previous-props-or-state
 */ const usePreviousValue = (value)=>{
    const ref = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        ref.current = value;
    }, [
        value
    ]);
    return ref.current;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (usePreviousValue);


/***/ })

};
;
//# sourceMappingURL=1685.js.map