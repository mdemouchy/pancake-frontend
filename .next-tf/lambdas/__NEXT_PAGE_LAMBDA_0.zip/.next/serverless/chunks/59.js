"use strict";
exports.id = 59;
exports.ids = [59];
exports.modules = {

/***/ 50059:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Zj": () => (/* reexport */ callWithEstimateGas),
  "yp": () => (/* reexport */ pools/* getActivePools */.y),
  "sA": () => (/* reexport */ harvestFarm),
  "AQ": () => (/* reexport */ stakeFarm),
  "dU": () => (/* reexport */ unstakeFarm)
});

// UNUSED EXPORTS: estimateGas

// EXTERNAL MODULE: external "@ethersproject/bignumber"
var bignumber_ = __webpack_require__(65757);
;// CONCATENATED MODULE: ./src/utils/calls/estimateGas.ts

/**
 * Estimate the gas needed to call a function, and add a 10% margin
 * @param contract Used to perform the call
 * @param methodName The name of the methode called
 * @param gasMarginPer10000 The gasMargin per 10000 (i.e. 10% -> 1000)
 * @param args An array of arguments to pass to the method
 * @returns https://docs.ethers.io/v5/api/providers/types/#providers-TransactionReceipt
 */ const estimateGas = async (contract, methodName, methodArgs, gasMarginPer10000)=>{
    if (!contract[methodName]) {
        throw new Error(`Method ${methodName} doesn't exist on ${contract.address}`);
    }
    const rawGasEstimation = await contract.estimateGas[methodName](...methodArgs);
    // By convention, BigNumber values are multiplied by 1000 to avoid dealing with real numbers
    const gasEstimation = rawGasEstimation.mul(bignumber_.BigNumber.from(10000).add(bignumber_.BigNumber.from(gasMarginPer10000))).div(bignumber_.BigNumber.from(10000));
    return gasEstimation;
};
/**
 * Perform a contract call with a gas value returned from estimateGas
 * @param contract Used to perform the call
 * @param methodName The name of the method called
 * @param methodArgs An array of arguments to pass to the method
 * @param overrides An overrides object to pass to the method
 * @returns https://docs.ethers.io/v5/api/providers/types/#providers-TransactionReceipt
 */ const callWithEstimateGas = async (contract, methodName, methodArgs = [], overrides = {}, gasMarginPer10000 = 1000)=>{
    const gasEstimation = estimateGas(contract, methodName, methodArgs, gasMarginPer10000);
    const tx = await contract[methodName](...methodArgs, {
        gasLimit: gasEstimation,
        ...overrides
    });
    return tx;
};

// EXTERNAL MODULE: external "bignumber.js"
var external_bignumber_js_ = __webpack_require__(34215);
var external_bignumber_js_default = /*#__PURE__*/__webpack_require__.n(external_bignumber_js_);
// EXTERNAL MODULE: ./src/config/index.ts
var config = __webpack_require__(33206);
// EXTERNAL MODULE: ./src/utils/getGasPrice.ts
var getGasPrice = __webpack_require__(76582);
;// CONCATENATED MODULE: ./src/utils/calls/farms.ts



const options = {
    gasLimit: config/* DEFAULT_GAS_LIMIT */.QL
};
const stakeFarm = async (masterChefContract, pid, amount)=>{
    const gasPrice = (0,getGasPrice/* default */.Z)();
    const value = new (external_bignumber_js_default())(amount).times(config/* DEFAULT_TOKEN_DECIMAL */.o3).toString();
    if (pid === 0) {
        return masterChefContract.enterStaking(value, {
            ...options,
            gasPrice
        });
    }
    return masterChefContract.deposit(pid, value, {
        ...options,
        gasPrice
    });
};
const unstakeFarm = async (masterChefContract, pid, amount)=>{
    const gasPrice = (0,getGasPrice/* default */.Z)();
    const value = new (external_bignumber_js_default())(amount).times(config/* DEFAULT_TOKEN_DECIMAL */.o3).toString();
    if (pid === 0) {
        return masterChefContract.leaveStaking(value, {
            ...options,
            gasPrice
        });
    }
    return masterChefContract.withdraw(pid, value, {
        ...options,
        gasPrice
    });
};
const harvestFarm = async (masterChefContract, pid)=>{
    const gasPrice = (0,getGasPrice/* default */.Z)();
    if (pid === 0) {
        return masterChefContract.leaveStaking('0', {
            ...options,
            gasPrice
        });
    }
    return masterChefContract.deposit(pid, '0', {
        ...options,
        gasPrice
    });
};

// EXTERNAL MODULE: ./src/utils/calls/pools.ts + 1 modules
var pools = __webpack_require__(65440);
;// CONCATENATED MODULE: ./src/utils/calls/index.ts





/***/ }),

/***/ 76582:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(42877);
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var state__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(82727);
/* harmony import */ var state_user_hooks_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(50787);



/**
 * Function to return gasPrice outwith a react component
 */ const getGasPrice = ()=>{
    const chainId = "1666700000";
    const state = state__WEBPACK_IMPORTED_MODULE_1__/* ["default"].getState */ .ZP.getState();
    const userGas = state.user.gasPrice || state_user_hooks_helpers__WEBPACK_IMPORTED_MODULE_2__/* .GAS_PRICE_GWEI["default"] */ .j4["default"];
    return chainId === _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET.toString() ? userGas : state_user_hooks_helpers__WEBPACK_IMPORTED_MODULE_2__/* .GAS_PRICE_GWEI.testnet */ .j4.testnet;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (getGasPrice);


/***/ })

};
;
//# sourceMappingURL=59.js.map