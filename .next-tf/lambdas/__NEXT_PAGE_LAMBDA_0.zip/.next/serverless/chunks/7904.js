"use strict";
exports.id = 7904;
exports.ids = [7904];
exports.modules = {

/***/ 77214:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "I": () => (/* binding */ Input)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(99150);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(38328);





const StyledInput = styled_components__WEBPACK_IMPORTED_MODULE_2___default().input.withConfig({
    componentId: "sc-3210bbaf-0"
})`
  color: ${({ error , theme  })=>error ? theme.colors.failure : theme.colors.text
};
  width: 0;
  position: relative;
  font-weight: 500;
  outline: none;
  border: none;
  flex: 1 1 auto;
  background-color: transparent;
  font-size: 16px;
  text-align: ${({ align  })=>align ?? 'right'
};
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  padding: 0px;
  -webkit-appearance: textfield;

  ::-webkit-search-decoration {
    -webkit-appearance: none;
  }

  [type='number'] {
    -moz-appearance: textfield;
  }

  ::-webkit-outer-spin-button,
  ::-webkit-inner-spin-button {
    -webkit-appearance: none;
  }

  ::placeholder {
    color: ${({ theme  })=>theme.colors.textSubtle
};
  }
`;
const inputRegex = RegExp(`^\\d*(?:\\\\[.])?\\d*$`) // match escaped "." characters via in a non-capturing group
;
const Input = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().memo(function InnerInput({ value , onUserInput , placeholder , ...rest }) {
    const enforcer = (nextUserInput)=>{
        if (nextUserInput === '' || inputRegex.test((0,_utils__WEBPACK_IMPORTED_MODULE_4__/* .escapeRegExp */ .hr)(nextUserInput))) {
            onUserInput(nextUserInput);
        }
    };
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_3__/* .useTranslation */ .$G)();
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledInput, {
        ...rest,
        value: value,
        onChange: (event)=>{
            // replace commas with periods, because we exclusively uses period as the decimal separator
            enforcer(event.target.value.replace(/,/g, '.'));
        },
        // universal input options
        inputMode: "decimal",
        title: t('Token Amount'),
        autoComplete: "off",
        autoCorrect: "off",
        // text-specific options
        type: "text",
        pattern: "^[0-9]*[.,]?[0-9]*$",
        placeholder: placeholder || '0.0',
        minLength: 1,
        maxLength: 79,
        spellCheck: "false"
    }));
});
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (Input)));


/***/ }),

/***/ 71372:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ CurrencyInputPanel)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99150);
/* harmony import */ var hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(64011);
/* harmony import */ var _state_wallet_hooks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(71900);
/* harmony import */ var _SearchModal_CurrencySearchModal__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(31721);
/* harmony import */ var _Logo__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(83356);
/* harmony import */ var _Layout_Row__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(39475);
/* harmony import */ var _NumericalInput__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(77214);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Logo__WEBPACK_IMPORTED_MODULE_8__, _SearchModal_CurrencySearchModal__WEBPACK_IMPORTED_MODULE_7__, _state_wallet_hooks__WEBPACK_IMPORTED_MODULE_6__]);
([_Logo__WEBPACK_IMPORTED_MODULE_8__, _SearchModal_CurrencySearchModal__WEBPACK_IMPORTED_MODULE_7__, _state_wallet_hooks__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);











const InputRow = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
    componentId: "sc-85bfa705-0"
})`
  display: flex;
  flex-flow: row nowrap;
  align-items: center;
  justify-content: flex-end;
  padding: ${({ selected  })=>selected ? '0.75rem 0.5rem 0.75rem 1rem' : '0.75rem 0.75rem 0.75rem 1rem'
};
`;
const CurrencySelectButton = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button).attrs({
    variant: 'text',
    scale: 'sm'
}).withConfig({
    componentId: "sc-85bfa705-1"
})`
  padding: 0 0.5rem;
`;
const LabelRow = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
    componentId: "sc-85bfa705-2"
})`
  display: flex;
  flex-flow: row nowrap;
  align-items: center;
  color: ${({ theme  })=>theme.colors.text
};
  font-size: 0.75rem;
  line-height: 1rem;
  padding: 0.75rem 1rem 0 1rem;
`;
const InputPanel = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
    componentId: "sc-85bfa705-3"
})`
  display: flex;
  flex-flow: column nowrap;
  position: relative;
  border-radius: '20px';
  background-color: ${({ theme  })=>theme.colors.backgroundAlt
};
  z-index: 1;
`;
const Container = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
    componentId: "sc-85bfa705-4"
})`
  border-radius: 16px;
  background-color: ${({ theme  })=>theme.colors.input
};
  box-shadow: ${({ theme  })=>theme.shadows.inset
};
`;
function CurrencyInputPanel({ value , onUserInput , onMax , showMaxButton , label , onCurrencySelect , currency , disableCurrencySelect =false , hideBalance =false , pair =null , otherCurrency , id , showCommonBases  }) {
    const { account  } = (0,hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)();
    const selectedCurrencyBalance = (0,_state_wallet_hooks__WEBPACK_IMPORTED_MODULE_6__/* .useCurrencyBalance */ ._h)(account ?? undefined, currency ?? undefined);
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_4__/* .useTranslation */ .$G)();
    const [onPresentCurrencyModal] = (0,_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.useModal)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SearchModal_CurrencySearchModal__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
        onCurrencySelect: onCurrencySelect,
        selectedCurrency: currency,
        otherSelectedCurrency: otherCurrency,
        showCommonBases: showCommonBases
    }));
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Box, {
        id: id,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                mb: "6px",
                alignItems: "center",
                justifyContent: "space-between",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CurrencySelectButton, {
                        className: "open-currency-select-button",
                        selected: !!currency,
                        onClick: ()=>{
                            if (!disableCurrencySelect) {
                                onPresentCurrencyModal();
                            }
                        },
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                            alignItems: "center",
                            justifyContent: "space-between",
                            children: [
                                pair ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Logo__WEBPACK_IMPORTED_MODULE_8__/* .DoubleCurrencyLogo */ .ge, {
                                    currency0: pair.token0,
                                    currency1: pair.token1,
                                    size: 16,
                                    margin: true
                                }) : currency ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Logo__WEBPACK_IMPORTED_MODULE_8__/* .CurrencyLogo */ .Xw, {
                                    currency: currency,
                                    size: "24px",
                                    style: {
                                        marginRight: '8px'
                                    }
                                }) : null,
                                pair ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                    id: "pair",
                                    bold: true,
                                    children: [
                                        pair?.token0.symbol,
                                        ":",
                                        pair?.token1.symbol
                                    ]
                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                    id: "pair",
                                    bold: true,
                                    children: (currency && currency.symbol && currency.symbol.length > 20 ? `${currency.symbol.slice(0, 4)}...${currency.symbol.slice(currency.symbol.length - 5, currency.symbol.length)}` : currency?.symbol) || t('Select a currency')
                                }),
                                !disableCurrencySelect && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.ChevronDownIcon, {})
                            ]
                        })
                    }),
                    account && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        onClick: onMax,
                        color: "textSubtle",
                        fontSize: "14px",
                        style: {
                            display: 'inline',
                            cursor: 'pointer'
                        },
                        children: !hideBalance && !!currency ? t('Balance: %balance%', {
                            balance: selectedCurrencyBalance?.toSignificant(6) ?? t('Loading')
                        }) : ' -'
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(InputPanel, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Container, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(LabelRow, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Layout_Row__WEBPACK_IMPORTED_MODULE_9__/* .RowBetween */ .m0, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_NumericalInput__WEBPACK_IMPORTED_MODULE_10__/* .Input */ .I, {
                                    className: "token-amount-input",
                                    value: value,
                                    onUserInput: (val)=>{
                                        onUserInput(val);
                                    }
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(InputRow, {
                            selected: disableCurrencySelect,
                            children: account && currency && showMaxButton && label !== 'To' && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                                onClick: onMax,
                                scale: "xs",
                                variant: "secondary",
                                children: "MAX"
                            })
                        })
                    ]
                })
            })
        ]
    }));
};

});

/***/ }),

/***/ 41228:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "pM": () => (/* binding */ ConfirmationModalContent),
/* harmony export */   "ht": () => (/* binding */ TransactionErrorContent),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var utils_wallet__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(49058);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(99150);
/* harmony import */ var hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(64011);
/* harmony import */ var utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(53854);
/* harmony import */ var _Layout_Row__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(39475);
/* harmony import */ var _Layout_Column__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(41914);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(38328);











const Wrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-168b6011-0"
})`
  width: 100%;
`;
const Section = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_Layout_Column__WEBPACK_IMPORTED_MODULE_9__/* .AutoColumn */ .Tz).withConfig({
    componentId: "sc-168b6011-1"
})`
  padding: 24px;
`;
const ConfirmedIcon = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_Layout_Column__WEBPACK_IMPORTED_MODULE_9__/* .ColumnCenter */ .lg).withConfig({
    componentId: "sc-168b6011-2"
})`
  padding: 24px 0;
`;
function ConfirmationPendingContent({ pendingText  }) {
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_5__/* .useTranslation */ .$G)();
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Wrapper, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ConfirmedIcon, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Spinner, {})
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Layout_Column__WEBPACK_IMPORTED_MODULE_9__/* .AutoColumn */ .Tz, {
                gap: "12px",
                justify: "center",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                        fontSize: "20px",
                        children: t('Waiting For Confirmation')
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Layout_Column__WEBPACK_IMPORTED_MODULE_9__/* .AutoColumn */ .Tz, {
                        gap: "12px",
                        justify: "center",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                            bold: true,
                            small: true,
                            textAlign: "center",
                            children: pendingText
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                        small: true,
                        color: "textSubtle",
                        textAlign: "center",
                        children: t('Confirm this transaction in your wallet')
                    })
                ]
            })
        ]
    }));
}
function TransactionSubmittedContent({ onDismiss , chainId , hash , currencyToAdd  }) {
    const { library  } = (0,hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)();
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_5__/* .useTranslation */ .$G)();
    const token = (0,utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_7__/* .wrappedCurrency */ .pu)(currencyToAdd, chainId);
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Wrapper, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Section, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ConfirmedIcon, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.ArrowUpIcon, {
                        strokeWidth: 0.5,
                        width: "90px",
                        color: "primary"
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Layout_Column__WEBPACK_IMPORTED_MODULE_9__/* .AutoColumn */ .Tz, {
                    gap: "12px",
                    justify: "center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                            fontSize: "20px",
                            children: t('Transaction Submitted')
                        }),
                        chainId && hash && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Link, {
                            external: true,
                            small: true,
                            href: (0,_utils__WEBPACK_IMPORTED_MODULE_10__/* .getBscScanLink */ .s6)(hash, 'transaction', chainId),
                            children: t('View on BscScan')
                        }),
                        currencyToAdd && library?.provider?.isMetaMask && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Button, {
                            variant: "tertiary",
                            mt: "12px",
                            width: "fit-content",
                            onClick: ()=>(0,utils_wallet__WEBPACK_IMPORTED_MODULE_4__/* .registerToken */ .$)(token.address, token.symbol, token.decimals)
                            ,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Layout_Row__WEBPACK_IMPORTED_MODULE_8__/* .RowFixed */ .DA, {
                                children: [
                                    t('Add %asset% to Metamask', {
                                        asset: currencyToAdd.symbol
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.MetamaskIcon, {
                                        width: "16px",
                                        ml: "6px"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Button, {
                            onClick: onDismiss,
                            mt: "20px",
                            children: t('Close')
                        })
                    ]
                })
            ]
        })
    }));
}
function ConfirmationModalContent({ bottomContent , topContent  }) {
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Wrapper, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Box, {
                children: topContent()
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Box, {
                children: bottomContent()
            })
        ]
    }));
}
function TransactionErrorContent({ message , onDismiss  }) {
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_5__/* .useTranslation */ .$G)();
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Wrapper, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Layout_Column__WEBPACK_IMPORTED_MODULE_9__/* .AutoColumn */ .Tz, {
                justify: "center",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.ErrorIcon, {
                        color: "failure",
                        width: "64px"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                        color: "failure",
                        style: {
                            textAlign: 'center',
                            width: '85%'
                        },
                        children: message
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                justifyContent: "center",
                pt: "24px",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Button, {
                    onClick: onDismiss,
                    children: t('Dismiss')
                })
            })
        ]
    }));
}
const TransactionConfirmationModal = ({ title , onDismiss , customOnDismiss , attemptingTxn , hash , pendingText , content , currencyToAdd ,  })=>{
    const { chainId  } = (0,hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)();
    const handleDismiss = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        if (customOnDismiss) {
            customOnDismiss();
        }
        onDismiss();
    }, [
        customOnDismiss,
        onDismiss
    ]);
    if (!chainId) return null;
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_3__.Modal, {
        title: title,
        headerBackground: "gradients.cardHeader",
        onDismiss: handleDismiss,
        children: attemptingTxn ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ConfirmationPendingContent, {
            pendingText: pendingText
        }) : hash ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TransactionSubmittedContent, {
            chainId: chainId,
            hash: hash,
            onDismiss: onDismiss,
            currencyToAdd: currencyToAdd
        }) : content()
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TransactionConfirmationModal);


/***/ }),

/***/ 69398:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UK": () => (/* binding */ ApprovalState),
/* harmony export */   "qL": () => (/* binding */ useApproveCallback),
/* harmony export */   "re": () => (/* binding */ useApproveCallbackFromTrade)
/* harmony export */ });
/* harmony import */ var _ethersproject_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(26644);
/* harmony import */ var _ethersproject_constants__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_constants__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(42877);
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(64011);
/* harmony import */ var utils_sentry__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(17226);
/* harmony import */ var _config_constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3862);
/* harmony import */ var _useTokenAllowance__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(95527);
/* harmony import */ var _state_swap_actions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(70193);
/* harmony import */ var _state_transactions_hooks__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(55892);
/* harmony import */ var _utils_prices__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7879);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(38328);
/* harmony import */ var _useContract__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(46063);
/* harmony import */ var _useCallWithGasPrice__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(71228);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_useTokenAllowance__WEBPACK_IMPORTED_MODULE_6__, _useCallWithGasPrice__WEBPACK_IMPORTED_MODULE_12__]);
([_useTokenAllowance__WEBPACK_IMPORTED_MODULE_6__, _useCallWithGasPrice__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);













var ApprovalState;
(function(ApprovalState) {
    ApprovalState[ApprovalState["UNKNOWN"] = 0] = "UNKNOWN";
    ApprovalState[ApprovalState["NOT_APPROVED"] = 1] = "NOT_APPROVED";
    ApprovalState[ApprovalState["PENDING"] = 2] = "PENDING";
    ApprovalState[ApprovalState["APPROVED"] = 3] = "APPROVED";
})(ApprovalState || (ApprovalState = {}));
// returns a variable indicating the state of the approval and a function which approves if necessary or early returns
function useApproveCallback(amountToApprove, spender) {
    const { account  } = (0,hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)();
    const { callWithGasPrice  } = (0,_useCallWithGasPrice__WEBPACK_IMPORTED_MODULE_12__/* .useCallWithGasPrice */ .d)();
    const token = amountToApprove instanceof _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_1__.TokenAmount ? amountToApprove.token : undefined;
    const currentAllowance = (0,_useTokenAllowance__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)(token, account ?? undefined, spender);
    const pendingApproval = (0,_state_transactions_hooks__WEBPACK_IMPORTED_MODULE_8__/* .useHasPendingApproval */ .wB)(token?.address, spender);
    // check the current approval status
    const approvalState = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        if (!amountToApprove || !spender) return ApprovalState.UNKNOWN;
        if (amountToApprove.currency === _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_1__.ETHER) return ApprovalState.APPROVED;
        // we might not have enough data to know whether or not we need to approve
        if (!currentAllowance) return ApprovalState.UNKNOWN;
        // amountToApprove will be defined if currentAllowance is
        return currentAllowance.lessThan(amountToApprove) ? pendingApproval ? ApprovalState.PENDING : ApprovalState.NOT_APPROVED : ApprovalState.APPROVED;
    }, [
        amountToApprove,
        currentAllowance,
        pendingApproval,
        spender
    ]);
    const tokenContract = (0,_useContract__WEBPACK_IMPORTED_MODULE_11__/* .useTokenContract */ .Ib)(token?.address);
    const addTransaction = (0,_state_transactions_hooks__WEBPACK_IMPORTED_MODULE_8__/* .useTransactionAdder */ .h7)();
    const approve = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)(async ()=>{
        if (approvalState !== ApprovalState.NOT_APPROVED) {
            console.error('approve was called unnecessarily');
            return;
        }
        if (!token) {
            console.error('no token');
            return;
        }
        if (!tokenContract) {
            console.error('tokenContract is null');
            return;
        }
        if (!amountToApprove) {
            console.error('missing amount to approve');
            return;
        }
        if (!spender) {
            console.error('no spender');
            return;
        }
        let useExact = false;
        const estimatedGas = await tokenContract.estimateGas.approve(spender, _ethersproject_constants__WEBPACK_IMPORTED_MODULE_0__.MaxUint256).catch(()=>{
            // general fallback for tokens who restrict approval amounts
            useExact = true;
            return tokenContract.estimateGas.approve(spender, amountToApprove.raw.toString());
        });
        // eslint-disable-next-line consistent-return
        return callWithGasPrice(tokenContract, 'approve', [
            spender,
            useExact ? amountToApprove.raw.toString() : _ethersproject_constants__WEBPACK_IMPORTED_MODULE_0__.MaxUint256
        ], {
            gasLimit: (0,_utils__WEBPACK_IMPORTED_MODULE_10__/* .calculateGasMargin */ .yC)(estimatedGas)
        }).then((response)=>{
            addTransaction(response, {
                summary: `Approve ${amountToApprove.currency.symbol}`,
                approval: {
                    tokenAddress: token.address,
                    spender
                }
            });
        }).catch((error)=>{
            (0,utils_sentry__WEBPACK_IMPORTED_MODULE_4__/* .logError */ .H)(error);
            console.error('Failed to approve token', error);
            throw error;
        });
    }, [
        approvalState,
        token,
        tokenContract,
        amountToApprove,
        spender,
        addTransaction,
        callWithGasPrice
    ]);
    return [
        approvalState,
        approve
    ];
}
// wraps useApproveCallback in the context of a swap
function useApproveCallbackFromTrade(trade, allowedSlippage = 0) {
    const amountToApprove = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>trade ? (0,_utils_prices__WEBPACK_IMPORTED_MODULE_9__/* .computeSlippageAdjustedAmounts */ .b5)(trade, allowedSlippage)[_state_swap_actions__WEBPACK_IMPORTED_MODULE_7__/* .Field.INPUT */ .gN.INPUT] : undefined
    , [
        trade,
        allowedSlippage
    ]);
    return useApproveCallback(amountToApprove, _config_constants__WEBPACK_IMPORTED_MODULE_5__/* .ROUTER_ADDRESS */ .bR);
}

});

/***/ }),

/***/ 7694:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useCurrentBlockTimestamp)
/* harmony export */ });
/* harmony import */ var _state_multicall_hooks__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(91001);
/* harmony import */ var _useContract__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(46063);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_0__]);
_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];


// gets the current timestamp from the blockchain
function useCurrentBlockTimestamp() {
    const multicall = (0,_useContract__WEBPACK_IMPORTED_MODULE_1__/* .useMulticallContract */ .gq)();
    return (0,_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_0__/* .useSingleCallResult */ .Wk)(multicall, 'getCurrentBlockTimestamp')?.result?.[0];
};

});

/***/ }),

/***/ 95527:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(42877);
/* harmony import */ var _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _useContract__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(46063);
/* harmony import */ var _state_multicall_hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(91001);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_3__]);
_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];




function useTokenAllowance(token, owner, spender) {
    const contract = (0,_useContract__WEBPACK_IMPORTED_MODULE_2__/* .useTokenContract */ .Ib)(token?.address, false);
    const inputs = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>[
            owner,
            spender
        ]
    , [
        owner,
        spender
    ]);
    const allowance = (0,_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_3__/* .useSingleCallResult */ .Wk)(contract, 'allowance', inputs).result;
    return (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>token && allowance ? new _mdemouchy_sdk__WEBPACK_IMPORTED_MODULE_0__.TokenAmount(token, allowance.toString()) : undefined
    , [
        token,
        allowance
    ]);
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useTokenAllowance);

});

/***/ }),

/***/ 81748:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useTransactionDeadline)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _useCurrentBlockTimestamp__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7694);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_useCurrentBlockTimestamp__WEBPACK_IMPORTED_MODULE_2__]);
_useCurrentBlockTimestamp__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];



// combines the block timestamp with the user setting to give the deadline that should be used for any submitted transaction
function useTransactionDeadline() {
    const ttl = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.user.userDeadline
    );
    const blockTimestamp = (0,_useCurrentBlockTimestamp__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)();
    return (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        if (blockTimestamp && ttl) return blockTimestamp.add(ttl);
        return undefined;
    }, [
        blockTimestamp,
        ttl
    ]);
};

});

/***/ }),

/***/ 17226:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ isUserRejected),
/* harmony export */   "H": () => (/* binding */ logError)
/* harmony export */ });
/* harmony import */ var _sentry_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(15427);
/* harmony import */ var _sentry_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_sentry_react__WEBPACK_IMPORTED_MODULE_0__);

const assignError = (maybeError)=>{
    if (typeof maybeError === 'string') {
        return new Error(maybeError);
    }
    if (typeof maybeError === 'object') {
        const error = new Error(maybeError?.message ?? String(maybeError));
        if (maybeError?.stack) {
            error.stack = maybeError.stack;
        }
        if (maybeError?.code) {
            error.name = maybeError.code;
        }
        return error;
    }
    return maybeError;
};
const isUserRejected = (err)=>{
    // provider user rejected error code
    return typeof err === 'object' && 'code' in err && err.code === 4001;
};
const logError = (error)=>{
    if (error instanceof Error) {
        _sentry_react__WEBPACK_IMPORTED_MODULE_0__.captureException(error);
    } else {
        _sentry_react__WEBPACK_IMPORTED_MODULE_0__.captureException(assignError(error), error);
    }
    console.error(error);
};


/***/ })

};
;
//# sourceMappingURL=7904.js.map