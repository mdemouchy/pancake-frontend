"use strict";
exports.id = 7626;
exports.ids = [7626];
exports.modules = {

/***/ 40508:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "O": () => (/* binding */ FlexGap),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(57518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);


const FlexLayout = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
    componentId: "sc-b9235de4-0"
})`
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
  & > * {
    min-width: 280px;
    max-width: 31.5%;
    width: 100%;
    margin: 0 8px;
    margin-bottom: 32px;
  }
`;
const FlexGap = styled_components__WEBPACK_IMPORTED_MODULE_1___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_0__.Flex).withConfig({
    componentId: "sc-b9235de4-1"
})`
  gap: ${({ gap  })=>gap
};
`;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FlexLayout);


/***/ }),

/***/ 46414:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_RoiCalculatorModal)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(57518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: external "@pancakeswap/uikit"
var uikit_ = __webpack_require__(2829);
// EXTERNAL MODULE: ./src/contexts/Localization/index.tsx + 3 modules
var Localization = __webpack_require__(99150);
// EXTERNAL MODULE: ./src/utils/formatBalance.ts
var formatBalance = __webpack_require__(65044);
// EXTERNAL MODULE: ./src/hooks/useActiveWeb3React.ts
var useActiveWeb3React = __webpack_require__(64011);
// EXTERNAL MODULE: ./src/utils/compoundApyHelpers.ts
var compoundApyHelpers = __webpack_require__(16395);
;// CONCATENATED MODULE: ./src/components/RoiCalculatorModal/RoiCalculatorFooter.tsx






const Footer = external_styled_components_default()(uikit_.Flex).withConfig({
    componentId: "sc-e4d425e5-0"
})`
  width: 100%;
  background: ${({ theme  })=>theme.colors.dropdown
};
`;
const BulletList = external_styled_components_default().ul.withConfig({
    componentId: "sc-e4d425e5-1"
})`
  list-style-type: none;
  margin-top: 16px;
  padding: 0;
  li {
    margin: 0;
    padding: 0;
  }
  li::before {
    content: '•';
    margin-right: 4px;
    color: ${({ theme  })=>theme.colors.textSubtle
};
  }
  li::marker {
    font-size: 12px;
  }
`;
const RoiCalculatorFooter = ({ isFarm , apr , displayApr , autoCompoundFrequency , multiplier , linkLabel , linkHref , performanceFee ,  })=>{
    const { 0: isExpanded , 1: setIsExpanded  } = (0,external_react_.useState)(false);
    const { t  } = (0,Localization/* useTranslation */.$G)();
    const { targetRef: multiplierRef , tooltip: multiplierTooltip , tooltipVisible: multiplierTooltipVisible ,  } = (0,uikit_.useTooltip)(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Text, {
                children: t('The Multiplier represents the proportion of CAKE rewards each farm receives, as a proportion of the CAKE produced each block.')
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Text, {
                my: "24px",
                children: t('For example, if a 1x farm received 1 CAKE per block, a 40x farm would receive 40 CAKE per block.')
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Text, {
                children: t('This amount is already included in all APR calculations for the farm.')
            })
        ]
    }), {
        placement: 'top-end',
        tooltipOffset: [
            20,
            10
        ]
    });
    const gridRowCount = isFarm ? 4 : 2;
    const apy = ((0,compoundApyHelpers/* getApy */.g5)(apr, autoCompoundFrequency > 0 ? autoCompoundFrequency : 1, 365, performanceFee) * 100).toFixed(2);
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(Footer, {
        p: "16px",
        flexDirection: "column",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(uikit_.ExpandableLabel, {
                expanded: isExpanded,
                onClick: ()=>setIsExpanded((prev)=>!prev
                    )
                ,
                children: isExpanded ? t('Hide') : t('Details')
            }),
            isExpanded && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(uikit_.Box, {
                px: "8px",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(uikit_.Grid, {
                        gridTemplateColumns: "2.5fr 1fr",
                        gridRowGap: "8px",
                        gridTemplateRows: `repeat(${gridRowCount}, auto)`,
                        children: [
                            isFarm && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Text, {
                                        color: "textSubtle",
                                        small: true,
                                        children: t('APR (incl. LP rewards)')
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(uikit_.Text, {
                                        small: true,
                                        textAlign: "right",
                                        children: [
                                            displayApr,
                                            "%"
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Text, {
                                color: "textSubtle",
                                small: true,
                                children: isFarm ? t('Base APR (CAKE yield only)') : t('APR')
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(uikit_.Text, {
                                small: true,
                                textAlign: "right",
                                children: [
                                    apr.toFixed(2),
                                    "%"
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Text, {
                                color: "textSubtle",
                                small: true,
                                children: t('APY (%compoundTimes%x daily compound)', {
                                    compoundTimes: autoCompoundFrequency > 0 ? autoCompoundFrequency : 1
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(uikit_.Text, {
                                small: true,
                                textAlign: "right",
                                children: [
                                    apy,
                                    "%"
                                ]
                            }),
                            isFarm && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Text, {
                                        color: "textSubtle",
                                        small: true,
                                        children: t('Farm Multiplier')
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(uikit_.Flex, {
                                        justifyContent: "flex-end",
                                        alignItems: "flex-end",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Text, {
                                                small: true,
                                                textAlign: "right",
                                                mr: "4px",
                                                children: multiplier
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                ref: multiplierRef,
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(uikit_.HelpIcon, {
                                                    color: "textSubtle",
                                                    width: "16px",
                                                    height: "16px"
                                                })
                                            }),
                                            multiplierTooltipVisible && multiplierTooltip
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(BulletList, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Text, {
                                    fontSize: "12px",
                                    textAlign: "center",
                                    color: "textSubtle",
                                    display: "inline",
                                    children: t('Calculated based on current rates.')
                                })
                            }),
                            isFarm && /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Text, {
                                    fontSize: "12px",
                                    textAlign: "center",
                                    color: "textSubtle",
                                    display: "inline",
                                    children: t('LP rewards: 0.17% trading fees, distributed proportionally among LP token holders.')
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Text, {
                                    fontSize: "12px",
                                    textAlign: "center",
                                    color: "textSubtle",
                                    display: "inline",
                                    children: t('All figures are estimates provided for your convenience only, and by no means represent guaranteed returns.')
                                })
                            }),
                            performanceFee > 0 && /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Text, {
                                    mt: "14px",
                                    fontSize: "12px",
                                    textAlign: "center",
                                    color: "textSubtle",
                                    display: "inline",
                                    children: t('All estimated rates take into account this pool’s %fee%% performance fee', {
                                        fee: performanceFee
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Flex, {
                        justifyContent: "center",
                        mt: "24px",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(uikit_.LinkExternal, {
                            href: linkHref,
                            children: linkLabel
                        })
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const RoiCalculatorModal_RoiCalculatorFooter = (RoiCalculatorFooter);

// EXTERNAL MODULE: external "bignumber.js"
var external_bignumber_js_ = __webpack_require__(34215);
var external_bignumber_js_default = /*#__PURE__*/__webpack_require__.n(external_bignumber_js_);
;// CONCATENATED MODULE: ./src/components/RoiCalculatorModal/useRoiCalculatorReducer.ts



/**
 * This hook is handling all the calculator state and calculations.
 * UI connected to it is merely representation of the data and buttons to trigger actions
 */ // Mapping from the compounding frequency button index to actual compounding frequency
// in number of compounds per day
const compoundingIndexToFrequency = {
    0: 1,
    1: 0.142857142,
    2: 0.071428571,
    3: 0.033333333
};
const TOKEN_PRECISION = 10;
const USD_PRECISION = 2;
var EditingCurrency;
(function(EditingCurrency) {
    EditingCurrency[EditingCurrency["TOKEN"] = 0] = "TOKEN";
    EditingCurrency[EditingCurrency["USD"] = 1] = "USD";
})(EditingCurrency || (EditingCurrency = {}));
var CalculatorMode;
(function(CalculatorMode) {
    CalculatorMode[CalculatorMode["ROI_BASED_ON_PRINCIPAL"] = 0] = "ROI_BASED_ON_PRINCIPAL";
    CalculatorMode[CalculatorMode["PRINCIPAL_BASED_ON_ROI"] = 1] = "PRINCIPAL_BASED_ON_ROI";
})(CalculatorMode || (CalculatorMode = {}));
const initialState = {
    controls: {
        compounding: true,
        compoundingFrequency: 1,
        activeCompoundingIndex: 0,
        stakingDuration: 3,
        mode: CalculatorMode.ROI_BASED_ON_PRINCIPAL,
        editingCurrency: EditingCurrency.USD
    },
    data: {
        principalAsToken: '0.00',
        principalAsUSD: '',
        roiUSD: 0,
        roiTokens: 0,
        roiPercentage: 0
    }
};
const roiCalculatorReducer = (state, action)=>{
    switch(action.type){
        case 'setStakingDuration':
            {
                const controls = {
                    ...state.controls,
                    stakingDuration: action.payload
                };
                return {
                    ...state,
                    controls
                };
            }
        case 'toggleCompounding':
            {
                const toggledCompounding = !state.controls.compounding;
                const controls = {
                    ...state.controls,
                    compounding: toggledCompounding
                };
                return {
                    ...state,
                    controls
                };
            }
        case 'setCompoundingFrequency':
            {
                const { index , autoCompoundFrequency  } = action.payload;
                if (autoCompoundFrequency) {
                    return {
                        ...state,
                        controls: {
                            ...state.controls,
                            compoundingFrequency: autoCompoundFrequency
                        }
                    };
                }
                const compoundingFrequency = compoundingIndexToFrequency[index];
                const controls = {
                    ...state.controls,
                    compoundingFrequency,
                    activeCompoundingIndex: index
                };
                return {
                    ...state,
                    controls
                };
            }
        case 'setPrincipal':
            {
                const { principalAsUSD , principalAsToken  } = action.payload;
                const data = {
                    ...state.data,
                    principalAsUSD,
                    principalAsToken
                };
                const controls = {
                    ...state.controls,
                    mode: CalculatorMode.ROI_BASED_ON_PRINCIPAL
                };
                return {
                    controls,
                    data
                };
            }
        case 'setPrincipalForTargetRoi':
            {
                const { principalAsUSD , principalAsToken , roiPercentage  } = action.payload;
                const data = {
                    ...state.data,
                    principalAsUSD,
                    principalAsToken,
                    roiPercentage
                };
                return {
                    ...state,
                    data
                };
            }
        case 'setCalculatorMode':
            {
                const mode = action.payload;
                const controls = {
                    ...state.controls,
                    mode
                };
                if (mode === CalculatorMode.PRINCIPAL_BASED_ON_ROI) {
                    const roiUSD = parseFloat(state.data.roiUSD.toFixed(USD_PRECISION));
                    const data = {
                        ...state.data,
                        roiUSD
                    };
                    return {
                        controls,
                        data
                    };
                }
                return {
                    ...state,
                    controls
                };
            }
        case 'setRoi':
            {
                const data = {
                    ...state.data,
                    ...action.payload
                };
                return {
                    ...state,
                    data
                };
            }
        case 'setTargetRoi':
            {
                const { roiUSD , roiTokens  } = action.payload;
                const data = {
                    ...state.data,
                    roiUSD,
                    roiTokens
                };
                const controls = {
                    ...state.controls,
                    mode: CalculatorMode.PRINCIPAL_BASED_ON_ROI
                };
                return {
                    controls,
                    data
                };
            }
        case 'toggleEditingCurrency':
            {
                const currencyAfterChange = state.controls.editingCurrency === EditingCurrency.USD ? EditingCurrency.TOKEN : EditingCurrency.USD;
                const controls = {
                    ...state.controls,
                    editingCurrency: currencyAfterChange
                };
                return {
                    ...state,
                    controls
                };
            }
        default:
            return state;
    }
};
const useRoiCalculatorReducer = (stakingTokenPrice, earningTokenPrice, apr, autoCompoundFrequency, performanceFee)=>{
    const { 0: state , 1: dispatch  } = (0,external_react_.useReducer)(roiCalculatorReducer, initialState);
    const { principalAsUSD , roiUSD  } = state.data;
    const { compounding , compoundingFrequency , stakingDuration , mode  } = state.controls;
    // If pool is auto-compounding set state's compounding frequency to this pool's auto-compound frequency
    (0,external_react_.useEffect)(()=>{
        if (autoCompoundFrequency > 0) {
            dispatch({
                type: 'setCompoundingFrequency',
                payload: {
                    autoCompoundFrequency
                }
            });
        }
    }, [
        autoCompoundFrequency
    ]);
    // Calculates and sets ROI whenever related values change
    (0,external_react_.useEffect)(()=>{
        if (mode === CalculatorMode.ROI_BASED_ON_PRINCIPAL) {
            const principalInUSDAsNumber = parseFloat(principalAsUSD);
            const compoundFrequency = compounding ? compoundingFrequency : 0;
            const interestBreakdown = (0,compoundApyHelpers/* getInterestBreakdown */.A1)({
                principalInUSD: principalInUSDAsNumber,
                apr,
                earningTokenPrice,
                compoundFrequency,
                performanceFee
            });
            const hasInterest = !Number.isNaN(interestBreakdown[stakingDuration]);
            const roiTokens = hasInterest ? interestBreakdown[stakingDuration] : 0;
            const roiAsUSD = hasInterest ? roiTokens * earningTokenPrice : 0;
            const roiPercentage = hasInterest ? (0,compoundApyHelpers/* getRoi */.Lu)({
                amountEarned: roiAsUSD,
                amountInvested: principalInUSDAsNumber
            }) : 0;
            dispatch({
                type: 'setRoi',
                payload: {
                    roiUSD: roiAsUSD,
                    roiTokens,
                    roiPercentage
                }
            });
        }
    }, [
        principalAsUSD,
        apr,
        stakingDuration,
        earningTokenPrice,
        performanceFee,
        compounding,
        compoundingFrequency,
        mode
    ]);
    // Calculates and sets principal based on expected ROI value
    (0,external_react_.useEffect)(()=>{
        if (mode === CalculatorMode.PRINCIPAL_BASED_ON_ROI) {
            const principalForExpectedRoi = (0,compoundApyHelpers/* getPrincipalForInterest */._b)(roiUSD, apr, compounding ? compoundingFrequency : 0, performanceFee);
            const principalUSD = !Number.isNaN(principalForExpectedRoi[stakingDuration]) ? principalForExpectedRoi[stakingDuration] : 0;
            const principalToken = new (external_bignumber_js_default())(principalUSD).div(stakingTokenPrice);
            const roiPercentage = (0,compoundApyHelpers/* getRoi */.Lu)({
                amountEarned: roiUSD,
                amountInvested: principalUSD
            });
            dispatch({
                type: 'setPrincipalForTargetRoi',
                payload: {
                    principalAsUSD: principalUSD.toFixed(USD_PRECISION),
                    principalAsToken: principalToken.toFixed(TOKEN_PRECISION),
                    roiPercentage
                }
            });
        }
    }, [
        stakingDuration,
        apr,
        compounding,
        compoundingFrequency,
        mode,
        roiUSD,
        stakingTokenPrice,
        performanceFee
    ]);
    // Handler for compounding frequency buttons
    const setCompoundingFrequency = (index)=>{
        dispatch({
            type: 'setCompoundingFrequency',
            payload: {
                index
            }
        });
    };
    // Handler for principal input when in USD mode
    const setPrincipalFromUSDValue = (amount)=>{
        const principalAsTokenBN = new (external_bignumber_js_default())(amount).div(stakingTokenPrice);
        const principalAsToken = principalAsTokenBN.gt(0) ? principalAsTokenBN.toFixed(TOKEN_PRECISION) : '0.00';
        dispatch({
            type: 'setPrincipal',
            payload: {
                principalAsUSD: amount,
                principalAsToken
            }
        });
    };
    // Handler for principal input when in Token mode
    const setPrincipalFromTokenValue = (0,external_react_.useCallback)((amount)=>{
        const principalAsUsdBN = new (external_bignumber_js_default())(amount).times(stakingTokenPrice);
        const principalAsUsdString = principalAsUsdBN.gt(0) ? principalAsUsdBN.toFixed(USD_PRECISION) : '0.00';
        dispatch({
            type: 'setPrincipal',
            payload: {
                principalAsUSD: principalAsUsdString,
                principalAsToken: amount
            }
        });
    }, [
        stakingTokenPrice
    ]);
    // Handler for staking duration buttons
    const setStakingDuration = (stakingDurationIndex)=>{
        dispatch({
            type: 'setStakingDuration',
            payload: stakingDurationIndex
        });
    };
    // Handler for compounding checkbox
    const toggleCompounding = ()=>{
        dispatch({
            type: 'toggleCompounding'
        });
    };
    // Handler for principal input mode switch
    const toggleEditingCurrency = ()=>{
        dispatch({
            type: 'toggleEditingCurrency'
        });
    };
    const setCalculatorMode = (modeToSet)=>{
        dispatch({
            type: 'setCalculatorMode',
            payload: modeToSet
        });
    };
    // Handler for ROI input
    const setTargetRoi = (amount)=>{
        const targetRoiAsTokens = new (external_bignumber_js_default())(amount).div(earningTokenPrice);
        dispatch({
            type: 'setTargetRoi',
            payload: {
                roiUSD: +amount,
                roiTokens: targetRoiAsTokens.isNaN() ? 0 : targetRoiAsTokens.toNumber()
            }
        });
    };
    return {
        state,
        setPrincipalFromUSDValue,
        setPrincipalFromTokenValue,
        setStakingDuration,
        toggleCompounding,
        toggleEditingCurrency,
        setCompoundingFrequency,
        setCalculatorMode,
        setTargetRoi
    };
};
/* harmony default export */ const RoiCalculatorModal_useRoiCalculatorReducer = (useRoiCalculatorReducer);

;// CONCATENATED MODULE: ./src/components/RoiCalculatorModal/RoiCard.tsx






const MILLION = 1000000;
const TRILLION = 1000000000000;
const RoiCardWrapper = external_styled_components_default()(uikit_.Box).withConfig({
    componentId: "sc-701cda87-0"
})`
  background: linear-gradient(180deg, #53dee9, #7645d9);
  padding: 1px;
  width: 100%;
  border-radius: ${({ theme  })=>theme.radii.default
};
`;
const RoiCardInner = external_styled_components_default()(uikit_.Box).withConfig({
    componentId: "sc-701cda87-1"
})`
  height: 120px;
  padding: 24px;
  border-radius: ${({ theme  })=>theme.radii.default
};
  background: ${({ theme  })=>theme.colors.gradients.bubblegum
};
`;
const RoiInputContainer = external_styled_components_default()(uikit_.Box).withConfig({
    componentId: "sc-701cda87-2"
})`
  position: relative;
  & > input {
    padding-left: 28px;
    max-width: 70%;
  }
  &:before {
    position: absolute;
    content: '$';
    color: ${({ theme  })=>theme.colors.textSubtle
};
    left: 16px;
    top: 8px;
  }
`;
const RoiDisplayContainer = external_styled_components_default()(uikit_.Flex).withConfig({
    componentId: "sc-701cda87-3"
})`
  max-width: 82%;
  margin-right: 8px;
`;
const RoiDollarAmount = external_styled_components_default()(uikit_.Text).withConfig({
    componentId: "sc-701cda87-4"
})`
  position: relative;
  overflow-x: auto;
  &::-webkit-scrollbar {
    height: 0px;
  }

  ${({ fadeOut , theme  })=>fadeOut && `
      &:after {
        background: linear-gradient(
          to right,
          ${theme.colors.background}00,
          ${theme.colors.background}E6
        );
        content: '';
        height: 100%;
        pointer-events: none;
        position: absolute;
        right: 0;
        top: 0;
        width: 40px;
      }
  `
}
`;
const RoiCard = ({ earningTokenSymbol , calculatorState , setTargetRoi , setCalculatorMode  })=>{
    const { 0: expectedRoi , 1: setExpectedRoi  } = (0,external_react_.useState)('');
    const inputRef = (0,external_react_.useRef)(null);
    const { roiUSD , roiTokens , roiPercentage  } = calculatorState.data;
    const { mode  } = calculatorState.controls;
    const { t  } = (0,Localization/* useTranslation */.$G)();
    (0,external_react_.useEffect)(()=>{
        if (mode === CalculatorMode.PRINCIPAL_BASED_ON_ROI && inputRef.current) {
            inputRef.current.focus();
        }
    }, [
        mode
    ]);
    const onEnterEditing = ()=>{
        setCalculatorMode(CalculatorMode.PRINCIPAL_BASED_ON_ROI);
        setExpectedRoi(roiUSD.toLocaleString('en', {
            minimumFractionDigits: roiUSD > MILLION ? 0 : 2,
            maximumFractionDigits: roiUSD > MILLION ? 0 : 2
        }));
    };
    const onExitRoiEditing = ()=>{
        setCalculatorMode(CalculatorMode.ROI_BASED_ON_PRINCIPAL);
    };
    const handleExpectedRoiChange = (event)=>{
        if (event.currentTarget.validity.valid) {
            const roiAsString = event.target.value.replace(/,/g, '.');
            setTargetRoi(roiAsString);
            setExpectedRoi(roiAsString);
        }
    };
    return(/*#__PURE__*/ jsx_runtime_.jsx(RoiCardWrapper, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(RoiCardInner, {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Text, {
                    fontSize: "12px",
                    color: "secondary",
                    bold: true,
                    textTransform: "uppercase",
                    children: t('ROI at current rates')
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Flex, {
                    justifyContent: "space-between",
                    mt: "4px",
                    height: "36px",
                    children: mode === CalculatorMode.PRINCIPAL_BASED_ON_ROI ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(RoiInputContainer, {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Input, {
                                    ref: inputRef,
                                    type: "text",
                                    inputMode: "decimal",
                                    pattern: "^[0-9]+[.,]?[0-9]*$",
                                    scale: "sm",
                                    value: expectedRoi,
                                    placeholder: "0.0",
                                    onChange: handleExpectedRoiChange
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(uikit_.IconButton, {
                                scale: "sm",
                                variant: "text",
                                onClick: onExitRoiEditing,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(uikit_.CheckmarkIcon, {
                                    color: "primary"
                                })
                            })
                        ]
                    }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(RoiDisplayContainer, {
                                onClick: onEnterEditing,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Text, {
                                        fontSize: "24px",
                                        bold: true,
                                        children: "$"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(RoiDollarAmount, {
                                        fontSize: "24px",
                                        bold: true,
                                        fadeOut: roiUSD > TRILLION,
                                        children: roiUSD.toLocaleString('en', {
                                            minimumFractionDigits: roiUSD > MILLION ? 0 : 2,
                                            maximumFractionDigits: roiUSD > MILLION ? 0 : 2
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(uikit_.IconButton, {
                                scale: "sm",
                                variant: "text",
                                onClick: onEnterEditing,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(uikit_.PencilIcon, {
                                    color: "primary"
                                })
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(uikit_.Text, {
                    fontSize: "12px",
                    color: "textSubtle",
                    children: [
                        "~ ",
                        roiTokens,
                        " ",
                        earningTokenSymbol,
                        " (",
                        roiPercentage.toLocaleString('en', {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2
                        }),
                        "%)"
                    ]
                })
            ]
        })
    }));
};
/* harmony default export */ const RoiCalculatorModal_RoiCard = (RoiCard);

;// CONCATENATED MODULE: ./src/components/RoiCalculatorModal/AnimatedArrow.tsx





const rotate = external_styled_components_.keyframes`
  0% {
    transform: scale(1);
    stroke-width: 0;
  }
  50% {
    transform: scale(1.3);
    stroke-width: 2;
  }
  100% {
    transform: scale(1);
    stroke-width: 0;
  }
`;
const ArrowContainer = external_styled_components_default()(uikit_.Flex).withConfig({
    componentId: "sc-cb0e3a86-0"
})`
  & > svg {
    animation: 0.2s ${rotate} linear;
    stroke: ${({ theme  })=>`${theme.colors.primary}3D`
};
    stroke-width: 0;
  }
`;
const AnimatedArrow = ({ calculatorState  })=>{
    const { 0: key , 1: setKey  } = (0,external_react_.useState)('roiArrow-0');
    const { mode  } = calculatorState.controls;
    // Trigger animation on state change
    (0,external_react_.useEffect)(()=>{
        setKey((prevKey)=>{
            const prevId = parseInt(prevKey.split('-')[1], 10);
            return `roiArrow-${prevId + 1}`;
        });
    }, [
        calculatorState
    ]);
    return(/*#__PURE__*/ jsx_runtime_.jsx(ArrowContainer, {
        justifyContent: "center",
        my: "24px",
        children: mode === CalculatorMode.ROI_BASED_ON_PRINCIPAL ? /*#__PURE__*/ jsx_runtime_.jsx(uikit_.ArrowDownIcon, {
            width: "24px",
            height: "24px",
            color: "textSubtle"
        }) : /*#__PURE__*/ jsx_runtime_.jsx(uikit_.ArrowUpIcon, {
            width: "24px",
            height: "24px",
            color: "textSubtle"
        })
    }, key));
};
/* harmony default export */ const RoiCalculatorModal_AnimatedArrow = (AnimatedArrow);

;// CONCATENATED MODULE: ./src/components/RoiCalculatorModal/index.tsx











const StyledModal = external_styled_components_default()(uikit_.Modal).withConfig({
    componentId: "sc-399a1f79-0"
})`
  width: 345px;
  & > :nth-child(2) {
    padding: 0;
  }
`;
const ScrollableContainer = external_styled_components_default().div.withConfig({
    componentId: "sc-399a1f79-1"
})`
  padding: 24px;
  max-height: 500px;
  overflow-y: auto;
  ${({ theme  })=>theme.mediaQueries.sm
} {
    max-height: none;
  }
`;
const FullWidthButtonMenu = external_styled_components_default()(uikit_.ButtonMenu).withConfig({
    componentId: "sc-399a1f79-2"
})`
  width: 100%;

  & > button {
    width: 100%;
  }

  opacity: ${({ disabled  })=>disabled ? 0.5 : 1
};
`;
const RoiCalculatorModal = ({ onDismiss , onBack , earningTokenPrice , apr , displayApr , linkLabel , linkHref , stakingTokenBalance , stakingTokenSymbol , stakingTokenPrice , multiplier , initialValue , earningTokenSymbol ='CAKE' , autoCompoundFrequency =0 , performanceFee =0 , isFarm =false ,  })=>{
    const { t  } = (0,Localization/* useTranslation */.$G)();
    const { account  } = (0,useActiveWeb3React/* default */.Z)();
    const balanceInputRef = (0,external_react_.useRef)(null);
    const { state , setPrincipalFromUSDValue , setPrincipalFromTokenValue , setStakingDuration , toggleCompounding , toggleEditingCurrency , setCompoundingFrequency , setCalculatorMode , setTargetRoi ,  } = RoiCalculatorModal_useRoiCalculatorReducer(stakingTokenPrice, earningTokenPrice, apr, autoCompoundFrequency, performanceFee);
    const { compounding , activeCompoundingIndex , stakingDuration , editingCurrency  } = state.controls;
    const { principalAsUSD , principalAsToken  } = state.data;
    // Auto-focus input on opening modal
    (0,external_react_.useEffect)(()=>{
        if (balanceInputRef.current) {
            balanceInputRef.current.focus();
        }
    }, []);
    // If user comes to calculator from staking modal - initialize with whatever they put in there
    (0,external_react_.useEffect)(()=>{
        if (initialValue) {
            setPrincipalFromTokenValue(initialValue);
        }
    }, [
        initialValue,
        setPrincipalFromTokenValue
    ]);
    const { targetRef , tooltip , tooltipVisible  } = (0,uikit_.useTooltip)(isFarm ? t('“My Balance” here includes both LP Tokens in your wallet, and LP Tokens already staked in this farm.') : t('“My Balance” here includes both %assetSymbol% in your wallet, and %assetSymbol% already staked in this pool.', {
        assetSymbol: stakingTokenSymbol
    }), {
        placement: 'top-end',
        tooltipOffset: [
            20,
            10
        ]
    });
    const onBalanceFocus = ()=>{
        setCalculatorMode(CalculatorMode.ROI_BASED_ON_PRINCIPAL);
    };
    const editingUnit = editingCurrency === EditingCurrency.TOKEN ? stakingTokenSymbol : 'USD';
    const editingValue = editingCurrency === EditingCurrency.TOKEN ? principalAsToken : principalAsUSD;
    const conversionUnit = editingCurrency === EditingCurrency.TOKEN ? 'USD' : stakingTokenSymbol;
    const conversionValue = editingCurrency === EditingCurrency.TOKEN ? principalAsUSD : principalAsToken;
    const onUserInput = editingCurrency === EditingCurrency.TOKEN ? setPrincipalFromTokenValue : setPrincipalFromUSDValue;
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(StyledModal, {
        title: t('ROI Calculator'),
        onDismiss: onBack || onDismiss,
        onBack: onBack ?? null,
        headerBackground: "gradients.cardHeader",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ScrollableContainer, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(uikit_.Flex, {
                        flexDirection: "column",
                        mb: "8px",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Text, {
                                color: "secondary",
                                bold: true,
                                fontSize: "12px",
                                textTransform: "uppercase",
                                children: t('%asset% staked', {
                                    asset: stakingTokenSymbol
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(uikit_.BalanceInput, {
                                currencyValue: `${conversionValue} ${conversionUnit}`,
                                innerRef: balanceInputRef,
                                placeholder: "0.00",
                                value: editingValue,
                                unit: editingUnit,
                                onUserInput: onUserInput,
                                switchEditingUnits: toggleEditingCurrency,
                                onFocus: onBalanceFocus
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(uikit_.Flex, {
                                justifyContent: "space-between",
                                mt: "8px",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Button, {
                                        scale: "xs",
                                        p: "4px 16px",
                                        width: "68px",
                                        variant: "tertiary",
                                        onClick: ()=>setPrincipalFromUSDValue('100')
                                        ,
                                        children: "$100"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Button, {
                                        scale: "xs",
                                        p: "4px 16px",
                                        width: "68px",
                                        variant: "tertiary",
                                        onClick: ()=>setPrincipalFromUSDValue('1000')
                                        ,
                                        children: "$1000"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Button, {
                                        disabled: !stakingTokenBalance.isFinite() || stakingTokenBalance.lte(0) || !account,
                                        scale: "xs",
                                        p: "4px 16px",
                                        width: "128px",
                                        variant: "tertiary",
                                        onClick: ()=>setPrincipalFromUSDValue((0,formatBalance/* getBalanceNumber */.mW)(stakingTokenBalance.times(stakingTokenPrice)).toString())
                                        ,
                                        children: t('My Balance').toLocaleUpperCase()
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        ref: targetRef,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(uikit_.HelpIcon, {
                                            width: "16px",
                                            height: "16px",
                                            color: "textSubtle"
                                        })
                                    }),
                                    tooltipVisible && tooltip
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Text, {
                                mt: "24px",
                                color: "secondary",
                                bold: true,
                                fontSize: "12px",
                                textTransform: "uppercase",
                                children: t('Staked for')
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(FullWidthButtonMenu, {
                                activeIndex: stakingDuration,
                                onItemClick: setStakingDuration,
                                scale: "sm",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(uikit_.ButtonMenuItem, {
                                        variant: "tertiary",
                                        children: t('1D')
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(uikit_.ButtonMenuItem, {
                                        variant: "tertiary",
                                        children: t('7D')
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(uikit_.ButtonMenuItem, {
                                        variant: "tertiary",
                                        children: t('30D')
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(uikit_.ButtonMenuItem, {
                                        variant: "tertiary",
                                        children: t('1Y')
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(uikit_.ButtonMenuItem, {
                                        variant: "tertiary",
                                        children: t('5Y')
                                    })
                                ]
                            }),
                            autoCompoundFrequency === 0 && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Text, {
                                        mt: "24px",
                                        color: "secondary",
                                        bold: true,
                                        fontSize: "12px",
                                        textTransform: "uppercase",
                                        children: t('Compounding every')
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(uikit_.Flex, {
                                        alignItems: "center",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Flex, {
                                                flex: "1",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Checkbox, {
                                                    scale: "sm",
                                                    checked: compounding,
                                                    onChange: toggleCompounding
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Flex, {
                                                flex: "6",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(FullWidthButtonMenu, {
                                                    disabled: !compounding,
                                                    activeIndex: activeCompoundingIndex,
                                                    onItemClick: setCompoundingFrequency,
                                                    scale: "sm",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx(uikit_.ButtonMenuItem, {
                                                            children: t('1D')
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx(uikit_.ButtonMenuItem, {
                                                            children: t('7D')
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx(uikit_.ButtonMenuItem, {
                                                            children: t('14D')
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx(uikit_.ButtonMenuItem, {
                                                            children: t('30D')
                                                        })
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(RoiCalculatorModal_AnimatedArrow, {
                        calculatorState: state
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Flex, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(RoiCalculatorModal_RoiCard, {
                            earningTokenSymbol: earningTokenSymbol,
                            calculatorState: state,
                            setTargetRoi: setTargetRoi,
                            setCalculatorMode: setCalculatorMode
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(RoiCalculatorModal_RoiCalculatorFooter, {
                isFarm: isFarm,
                apr: apr,
                displayApr: displayApr,
                autoCompoundFrequency: autoCompoundFrequency,
                multiplier: multiplier,
                linkLabel: linkLabel,
                linkHref: linkHref,
                performanceFee: performanceFee
            })
        ]
    }));
};
/* harmony default export */ const components_RoiCalculatorModal = (RoiCalculatorModal);


/***/ }),

/***/ 95239:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "q": () => (/* binding */ TokenPairImage),
/* harmony export */   "O": () => (/* binding */ TokenImage)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var config_constants_tokens__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(29748);




const getImageUrlFromToken = (token)=>{
    const address = token.symbol === 'BNB' ? config_constants_tokens__WEBPACK_IMPORTED_MODULE_3__/* ["default"].wbnb.address */ .ZP.wbnb.address : token.address;
    return `/images/tokens/${address}.svg`;
};
const TokenPairImage = ({ primaryToken , secondaryToken , ...props })=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.TokenPairImage, {
        primarySrc: getImageUrlFromToken(primaryToken),
        secondarySrc: getImageUrlFromToken(secondaryToken),
        ...props
    }));
};
const TokenImage = ({ token , ...props })=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.TokenImage, {
        src: getImageUrlFromToken(token),
        ...props
    }));
};


/***/ })

};
;
//# sourceMappingURL=7626.js.map