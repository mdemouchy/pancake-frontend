"use strict";
exports.id = 838;
exports.ids = [838];
exports.modules = {

/***/ 6631:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "M4": () => (/* binding */ BarChartLoader),
  "fn": () => (/* binding */ LineChartLoader)
});

// UNUSED EXPORTS: CandleChartLoader

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(7518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: external "@pancakeswap/uikit"
var uikit_ = __webpack_require__(2829);
// EXTERNAL MODULE: ./src/contexts/Localization/index.tsx + 3 modules
var Localization = __webpack_require__(9150);
;// CONCATENATED MODULE: ./src/views/Info/components/ChartLoaders/LineChartLoaderSVG.tsx



const LineChartLoaderSVG = (props)=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(uikit_.Svg, {
        width: "100%",
        height: "100%",
        preserveAspectRatio: "none",
        viewBox: "0 0 100 50",
        ...props,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M 0 49 C 1 49 1 45 4 47 C 7 49 7 35 11 37 C 13 38 14 32 16 34 C 18 35.6667 20 40 22 39 C 24 38 24 34 26 34 C 27 34 29 39 32 36 C 33 35 34 32 35 32 C 37 32 37 35 39 34 C 40 33 39 29 43 31 C 46 32 45 28 47 30 C 50 32 49 22 51 24 Q 53 26 55 24 C 56 23 56 25 57 26 C 58 27 59 28 60 28 C 63 28 66 17 67 16 C 68 15 69 17 70 16 C 71 15 71 13 74 13 C 76 13 76 14 77 15 C 79 17 80 18 82 18 C 83 18 83 17 84 17 C 87 17 89 24 91 24 C 93 24 95 20 96 17 C 97.6667 13.3333 98 9 101 6",
                stroke: "#7645D9",
                strokeWidth: "0.2",
                strokeDasharray: "156",
                strokeDashoffset: "156",
                fill: "transparent",
                opacity: "0.5",
                filter: "url(#glow)",
                children: /*#__PURE__*/ jsx_runtime_.jsx("animate", {
                    id: "firstline",
                    attributeName: "stroke-dashoffset",
                    dur: "2s",
                    from: "156",
                    to: "-156",
                    begin: "0s;firstline.end+0.5s"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M 0 49 C 1 49 1 45 4 47 C 7 49 7 35 11 37 C 13 38 14 32 16 34 C 18 35.6667 20 40 22 39 C 24 38 24 34 26 34 C 27 34 29 39 32 36 C 33 35 34 32 35 32 C 37 32 37 35 39 34 C 40 33 39 29 43 31 C 46 32 45 28 47 30 C 50 32 49 22 51 24 Q 53 26 55 24 C 56 23 56 25 57 26 C 58 27 59 28 60 28 C 63 28 66 17 67 16 C 68 15 69 17 70 16 C 71 15 71 13 74 13 C 76 13 76 14 77 15 C 79 17 80 18 82 18 C 83 18 83 17 84 17 C 87 17 89 24 91 24 C 93 24 95 20 96 17 C 97.6667 13.3333 98 9 101 6",
                stroke: "#7645D9",
                strokeWidth: "0.2",
                strokeDasharray: "156",
                strokeDashoffset: "156",
                fill: "transparent",
                opacity: "0.5",
                filter: "url(#glow)",
                children: /*#__PURE__*/ jsx_runtime_.jsx("animate", {
                    id: "secondline",
                    attributeName: "stroke-dashoffset",
                    dur: "2s",
                    from: "156",
                    to: "-156",
                    begin: "1.3s;secondline.end+0.5s"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("filter", {
                    id: "glow",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("feGaussianBlur", {
                            className: "blur",
                            result: "coloredBlur",
                            stdDeviation: "4"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("feMerge", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("feMergeNode", {
                                    in: "coloredBlur"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("feMergeNode", {
                                    in: "coloredBlur"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("feMergeNode", {
                                    in: "coloredBlur"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("feMergeNode", {
                                    in: "SourceGraphic"
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    }));
};
/* harmony default export */ const ChartLoaders_LineChartLoaderSVG = (LineChartLoaderSVG);

;// CONCATENATED MODULE: ./src/views/Info/components/ChartLoaders/BarChartLoaderSVG.tsx



const BarChartLoaderSVG = (props)=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(uikit_.Svg, {
        width: "100%",
        height: "100%",
        viewBox: "0 0 50 25",
        preserveAspectRatio: "none",
        opacity: "0.1",
        ...props,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("rect", {
                width: "8%",
                fill: "#1FC7D4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("animate", {
                        attributeName: "height",
                        dur: "0.9s",
                        values: "15%; 90%; 15%",
                        keyTimes: "0; 0.55; 1",
                        repeatCount: "indefinite",
                        begin: "-0.9s"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("animate", {
                        attributeName: "y",
                        dur: "0.9s",
                        values: "85%; 10%; 85%",
                        keyTimes: "0; 0.55; 1",
                        repeatCount: "indefinite",
                        begin: "-0.9s"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("rect", {
                x: "10.222%",
                width: "8%",
                fill: "#1FC7D4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("animate", {
                        attributeName: "height",
                        dur: "0.9s",
                        values: "15%; 90%; 15%",
                        keyTimes: "0; 0.55; 1",
                        repeatCount: "indefinite",
                        begin: "-0.8s"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("animate", {
                        attributeName: "y",
                        dur: "0.9s",
                        values: "85%; 10%; 85%",
                        keyTimes: "0; 0.55; 1",
                        repeatCount: "indefinite",
                        begin: "-0.8s"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("rect", {
                x: "20.444%",
                width: "8%",
                fill: "#1FC7D4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("animate", {
                        attributeName: "height",
                        dur: "0.9s",
                        values: "15%; 90%; 15%",
                        keyTimes: "0; 0.55; 1",
                        repeatCount: "indefinite",
                        begin: "-0.7s"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("animate", {
                        attributeName: "y",
                        dur: "0.9s",
                        values: "85%; 10%; 85%",
                        keyTimes: "0; 0.55; 1",
                        repeatCount: "indefinite",
                        begin: "-0.7s"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("rect", {
                x: "30.666%",
                width: "8%",
                fill: "#1FC7D4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("animate", {
                        attributeName: "height",
                        dur: "0.9s",
                        values: "15%; 90%; 15%",
                        keyTimes: "0; 0.55; 1",
                        repeatCount: "indefinite",
                        begin: "-0.6s"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("animate", {
                        attributeName: "y",
                        dur: "0.9s",
                        values: "85%; 10%; 85%",
                        keyTimes: "0; 0.55; 1",
                        repeatCount: "indefinite",
                        begin: "-0.6s"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("rect", {
                x: "40.888%",
                width: "8%",
                fill: "#1FC7D4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("animate", {
                        attributeName: "height",
                        dur: "0.9s",
                        values: "15%; 90%; 15%",
                        keyTimes: "0; 0.55; 1",
                        repeatCount: "indefinite",
                        begin: "-0.5s"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("animate", {
                        attributeName: "y",
                        dur: "0.9s",
                        values: "85%; 10%; 85%",
                        keyTimes: "0; 0.55; 1",
                        repeatCount: "indefinite",
                        begin: "-0.5s"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("rect", {
                x: "51.11%",
                width: "8%",
                fill: "#1FC7D4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("animate", {
                        attributeName: "height",
                        dur: "0.9s",
                        values: "15%; 90%; 15%",
                        keyTimes: "0; 0.55; 1",
                        repeatCount: "indefinite",
                        begin: "-0.4s"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("animate", {
                        attributeName: "y",
                        dur: "0.9s",
                        values: "85%; 10%; 85%",
                        keyTimes: "0; 0.55; 1",
                        repeatCount: "indefinite",
                        begin: "-0.4s"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("rect", {
                x: "61.332%",
                width: "8%",
                fill: "#1FC7D4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("animate", {
                        attributeName: "height",
                        dur: "0.9s",
                        values: "15%; 90%; 15%",
                        keyTimes: "0; 0.55; 1",
                        repeatCount: "indefinite",
                        begin: "-0.3s"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("animate", {
                        attributeName: "y",
                        dur: "0.9s",
                        values: "85%; 10%; 85%",
                        keyTimes: "0; 0.55; 1",
                        repeatCount: "indefinite",
                        begin: "-0.3s"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("rect", {
                x: "71.554%",
                width: "8%",
                fill: "#1FC7D4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("animate", {
                        attributeName: "height",
                        dur: "0.9s",
                        values: "15%; 90%; 15%",
                        keyTimes: "0; 0.55; 1",
                        repeatCount: "indefinite",
                        begin: "-0.2s"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("animate", {
                        attributeName: "y",
                        dur: "0.9s",
                        values: "85%; 10%; 85%",
                        keyTimes: "0; 0.55; 1",
                        repeatCount: "indefinite",
                        begin: "-0.2s"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("rect", {
                x: "81.776%",
                width: "8%",
                fill: "#1FC7D4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("animate", {
                        attributeName: "height",
                        dur: "0.9s",
                        values: "15%; 90%; 15%",
                        keyTimes: "0; 0.55; 1",
                        repeatCount: "indefinite",
                        begin: "-0.1s"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("animate", {
                        attributeName: "y",
                        dur: "0.9s",
                        values: "85%; 10%; 85%",
                        keyTimes: "0; 0.55; 1",
                        repeatCount: "indefinite",
                        begin: "-0.1s"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("rect", {
                x: "91.998%",
                width: "8%",
                fill: "#1FC7D4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("animate", {
                        attributeName: "height",
                        dur: "0.9s",
                        values: "15%; 90%; 15%",
                        keyTimes: "0; 0.55; 1",
                        repeatCount: "indefinite"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("animate", {
                        attributeName: "y",
                        dur: "0.9s",
                        values: "85%; 10%; 85%",
                        keyTimes: "0; 0.55; 1",
                        repeatCount: "indefinite"
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const ChartLoaders_BarChartLoaderSVG = (BarChartLoaderSVG);

;// CONCATENATED MODULE: ./src/views/Info/components/ChartLoaders/CandleChartLoaderSVG.tsx



const CandleChartLoaderSVG_CandleChartLoaderSVG = (props)=>{
    return(/*#__PURE__*/ _jsxs(Svg, {
        width: "100%",
        height: "100%",
        viewBox: "0 0 100 50",
        opacity: "0.1",
        ...props,
        children: [
            /*#__PURE__*/ _jsxs("rect", {
                width: "5%",
                fill: "#31D0AA",
                children: [
                    /*#__PURE__*/ _jsx("animate", {
                        attributeName: "height",
                        dur: "2s",
                        values: "0%; 40%; 40%; 10%; 10%",
                        keyTimes: "0; 0.125; 0.5; 0.625; 1",
                        repeatCount: "indefinite"
                    }),
                    /*#__PURE__*/ _jsx("animate", {
                        attributeName: "y",
                        dur: "2s",
                        from: "50%",
                        to: "30%",
                        values: "30%; 10%; 10%; 25%; 25%",
                        keyTimes: "0; 0.125; 0.5; 0.625; 1",
                        repeatCount: "indefinite"
                    }),
                    /*#__PURE__*/ _jsx("animate", {
                        attributeName: "rx",
                        dur: "2s",
                        values: "0%; 0%; 100%; 100%;",
                        keyTimes: "0; 0.6; 0.625; 1",
                        repeatCount: "indefinite"
                    }),
                    /*#__PURE__*/ _jsx("animate", {
                        attributeName: "x",
                        dur: "2s",
                        values: "32.5%; 32.5%; 47.5%; 47.5%;",
                        keyTimes: "0; 0.7; 0.8; 1",
                        repeatCount: "indefinite"
                    }),
                    /*#__PURE__*/ _jsx("animate", {
                        attributeName: "opacity",
                        dur: "2s",
                        values: "1; 1; 0; 0;",
                        keyTimes: "0; 0.75; 0.9; 1",
                        repeatCount: "indefinite"
                    })
                ]
            }),
            /*#__PURE__*/ _jsxs("rect", {
                width: "5%",
                fill: "#31D0AA",
                children: [
                    /*#__PURE__*/ _jsx("animate", {
                        attributeName: "height",
                        dur: "2s",
                        values: "0%; 0%; 20%; 20%; 10%; 10%",
                        keyTimes: "0; 0.125; 0.25; 0.5; 0.625; 1",
                        repeatCount: "indefinite"
                    }),
                    /*#__PURE__*/ _jsx("animate", {
                        attributeName: "y",
                        dur: "2s",
                        values: "15%; 15%; 5%; 5%; 25%; 25%",
                        keyTimes: "0; 0.125; 0.25; 0.5; 0.625; 1",
                        repeatCount: "indefinite"
                    }),
                    /*#__PURE__*/ _jsx("animate", {
                        attributeName: "rx",
                        dur: "2s",
                        values: "0%; 0%; 100%; 100%;",
                        keyTimes: "0; 0.6; 0.625; 1",
                        repeatCount: "indefinite"
                    }),
                    /*#__PURE__*/ _jsx("animate", {
                        attributeName: "x",
                        dur: "2s",
                        values: "42.5%; 42.5%; 47.5%; 47.5%;",
                        keyTimes: "0; 0.7; 0.8; 1",
                        repeatCount: "indefinite"
                    }),
                    /*#__PURE__*/ _jsx("animate", {
                        attributeName: "opacity",
                        dur: "2s",
                        values: "1; 1; 0; 0;",
                        keyTimes: "0; 0.75; 0.9; 1",
                        repeatCount: "indefinite"
                    })
                ]
            }),
            /*#__PURE__*/ _jsxs("rect", {
                width: "5%",
                fill: "#ED4B9E",
                children: [
                    /*#__PURE__*/ _jsx("animate", {
                        attributeName: "height",
                        dur: "2s",
                        values: "0%; 0%; 35%; 35%; 10%; 10%",
                        keyTimes: "0; 0.25; 0.375; 0.5; 0.625; 1",
                        repeatCount: "indefinite"
                    }),
                    /*#__PURE__*/ _jsx("animate", {
                        attributeName: "y",
                        dur: "2s",
                        values: "25%; 25%; 10%; 10%; 25%; 25%",
                        keyTimes: "0; 0.25; 0.375; 0.5; 0.625; 1",
                        repeatCount: "indefinite"
                    }),
                    /*#__PURE__*/ _jsx("animate", {
                        attributeName: "rx",
                        dur: "2s",
                        values: "0%; 0%; 100%; 100%;",
                        keyTimes: "0; 0.6; 0.625; 1",
                        repeatCount: "indefinite"
                    }),
                    /*#__PURE__*/ _jsx("animate", {
                        attributeName: "x",
                        dur: "2s",
                        values: "52.5%; 52.5%; 47.5%; 47.5%;",
                        keyTimes: "0; 0.7; 0.8; 1",
                        repeatCount: "indefinite"
                    }),
                    /*#__PURE__*/ _jsx("animate", {
                        attributeName: "opacity",
                        dur: "2s",
                        values: "1; 1; 0; 0;",
                        keyTimes: "0; 0.75; 0.9; 1",
                        repeatCount: "indefinite"
                    })
                ]
            }),
            /*#__PURE__*/ _jsxs("rect", {
                width: "5%",
                fill: "#31D0AA",
                children: [
                    /*#__PURE__*/ _jsx("animate", {
                        attributeName: "height",
                        dur: "2s",
                        values: "0%; 0%; 35%; 35%; 10%; 10%",
                        keyTimes: "0; 0.375; 0.5; 0.5; 0.625; 1",
                        repeatCount: "indefinite"
                    }),
                    /*#__PURE__*/ _jsx("animate", {
                        attributeName: "y",
                        dur: "2s",
                        values: "15%; 15%; 0%; 0%; 25%; 25%",
                        keyTimes: "0; 0.375; 0.5; 0.5; 0.625; 1",
                        repeatCount: "indefinite"
                    }),
                    /*#__PURE__*/ _jsx("animate", {
                        attributeName: "rx",
                        dur: "2s",
                        values: "0%; 0%; 100%; 100%;",
                        keyTimes: "0; 0.6; 0.625; 1",
                        repeatCount: "indefinite"
                    }),
                    /*#__PURE__*/ _jsx("animate", {
                        attributeName: "x",
                        dur: "2s",
                        values: "62.5%; 62.5%; 47.5%; 47.5%;",
                        keyTimes: "0; 0.7; 0.8; 1",
                        repeatCount: "indefinite"
                    }),
                    /*#__PURE__*/ _jsx("animate", {
                        attributeName: "opacity",
                        dur: "2s",
                        values: "1; 1; 0; 0;",
                        keyTimes: "0; 0.75; 0.9; 1",
                        repeatCount: "indefinite"
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const ChartLoaders_CandleChartLoaderSVG = ((/* unused pure expression or super */ null && (CandleChartLoaderSVG_CandleChartLoaderSVG)));

;// CONCATENATED MODULE: ./src/views/Info/components/ChartLoaders/index.tsx








const LoadingText = external_styled_components_default()(uikit_.Box).withConfig({
    componentId: "sc-220ec09a-0"
})`
  position: absolute;
  margin-left: auto;
  margin-right: auto;
  top: 50%;
  left: 0;
  right: 0;
  text-align: center;
`;
const LoadingIndicator = external_styled_components_default()(uikit_.Box).withConfig({
    componentId: "sc-220ec09a-1"
})`
  height: 100%;
  position: relative;
`;
const BarChartLoader = ()=>{
    const { t  } = (0,Localization/* useTranslation */.$G)();
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(LoadingIndicator, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(ChartLoaders_BarChartLoaderSVG, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(LoadingText, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Text, {
                    color: "textSubtle",
                    fontSize: "20px",
                    children: t('Loading chart data...')
                })
            })
        ]
    }));
};
const LineChartLoader = ()=>{
    const { t  } = (0,Localization/* useTranslation */.$G)();
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(LoadingIndicator, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(ChartLoaders_LineChartLoaderSVG, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(LoadingText, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(uikit_.Text, {
                    color: "textSubtle",
                    fontSize: "20px",
                    children: t('Loading chart data...')
                })
            })
        ]
    }));
};
const CandleChartLoader = ()=>{
    const { t  } = useTranslation();
    return(/*#__PURE__*/ _jsxs(LoadingIndicator, {
        children: [
            /*#__PURE__*/ _jsx(CandleChartLoaderSVG, {}),
            /*#__PURE__*/ _jsx(LoadingText, {
                children: /*#__PURE__*/ _jsx(Text, {
                    color: "textSubtle",
                    fontSize: "20px",
                    children: t('Loading chart data...')
                })
            })
        ]
    }));
};


/***/ }),

/***/ 5224:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var recharts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3655);
/* harmony import */ var recharts__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(recharts__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var hooks_useTheme__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3917);
/* harmony import */ var views_Info_utils_formatInfoNumbers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3589);
/* harmony import */ var views_Info_components_ChartLoaders__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6631);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9150);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks_useTheme__WEBPACK_IMPORTED_MODULE_3__]);
hooks_useTheme__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];







const CustomBar = ({ x , y , width , height , fill  })=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
            x: x,
            y: y,
            fill: fill,
            width: width,
            height: height,
            rx: "2"
        })
    }));
};
// Calls setHoverValue and setHoverDate when part of chart is hovered
// Note: this NEEDs to be wrapped inside component and useEffect, if you plug it as is it will create big render problems (try and see console)
const HoverUpdater = ({ locale , payload , setHoverValue , setHoverDate  })=>{
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setHoverValue(payload.value);
        setHoverDate(payload.time.toLocaleString(locale, {
            year: 'numeric',
            day: 'numeric',
            month: 'short'
        }));
    }, [
        locale,
        payload.value,
        payload.time,
        setHoverValue,
        setHoverDate
    ]);
    return null;
};
const Chart = ({ data , setHoverValue , setHoverDate  })=>{
    const { currentLanguage: { locale  } ,  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_6__/* .useTranslation */ .$G)();
    const { theme  } = (0,hooks_useTheme__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)();
    if (!data || data.length === 0) {
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(views_Info_components_ChartLoaders__WEBPACK_IMPORTED_MODULE_5__/* .BarChartLoader */ .M4, {}));
    }
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(recharts__WEBPACK_IMPORTED_MODULE_2__.ResponsiveContainer, {
        width: "100%",
        height: "100%",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(recharts__WEBPACK_IMPORTED_MODULE_2__.BarChart, {
            data: data,
            margin: {
                top: 5,
                right: 15,
                left: 0,
                bottom: 5
            },
            onMouseLeave: ()=>{
                setHoverDate(undefined);
                setHoverValue(undefined);
            },
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(recharts__WEBPACK_IMPORTED_MODULE_2__.XAxis, {
                    dataKey: "time",
                    axisLine: false,
                    tickLine: false,
                    tickFormatter: (time)=>time.toLocaleDateString(undefined, {
                            day: '2-digit'
                        })
                    ,
                    minTickGap: 10
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(recharts__WEBPACK_IMPORTED_MODULE_2__.YAxis, {
                    dataKey: "value",
                    tickCount: 6,
                    scale: "linear",
                    axisLine: false,
                    tickLine: false,
                    color: theme.colors.textSubtle,
                    fontSize: "12px",
                    tickFormatter: (val)=>`$${(0,views_Info_utils_formatInfoNumbers__WEBPACK_IMPORTED_MODULE_4__/* .formatAmount */ .d)(val)}`
                    ,
                    orientation: "right",
                    tick: {
                        dx: 10,
                        fill: theme.colors.textSubtle
                    }
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(recharts__WEBPACK_IMPORTED_MODULE_2__.Tooltip, {
                    cursor: {
                        fill: theme.colors.backgroundDisabled
                    },
                    contentStyle: {
                        display: 'none'
                    },
                    formatter: (tooltipValue, name, props)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(HoverUpdater, {
                            locale: locale,
                            payload: props.payload,
                            setHoverValue: setHoverValue,
                            setHoverDate: setHoverDate
                        })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(recharts__WEBPACK_IMPORTED_MODULE_2__.Bar, {
                    dataKey: "value",
                    fill: theme.colors.primary,
                    shape: (props)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CustomBar, {
                            height: props.height,
                            width: props.width,
                            x: props.x,
                            y: props.y,
                            fill: theme.colors.primary
                        })
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Chart);

});

/***/ }),

/***/ 5091:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var recharts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3655);
/* harmony import */ var recharts__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(recharts__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var hooks_useTheme__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3917);
/* harmony import */ var views_Info_utils_formatInfoNumbers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3589);
/* harmony import */ var views_Info_components_ChartLoaders__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6631);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9150);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks_useTheme__WEBPACK_IMPORTED_MODULE_3__]);
hooks_useTheme__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];







// Calls setHoverValue and setHoverDate when part of chart is hovered
// Note: this NEEDs to be wrapped inside component and useEffect, if you plug it as is it will create big render problems (try and see console)
const HoverUpdater = ({ locale , payload , setHoverValue , setHoverDate  })=>{
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setHoverValue(payload.value);
        setHoverDate(payload.time.toLocaleString(locale, {
            year: 'numeric',
            day: 'numeric',
            month: 'short'
        }));
    }, [
        locale,
        payload.value,
        payload.time,
        setHoverValue,
        setHoverDate
    ]);
    return null;
};
/**
 * Note: remember that it needs to be mounted inside the container with fixed height
 */ const LineChart = ({ data , setHoverValue , setHoverDate  })=>{
    const { currentLanguage: { locale  } ,  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_6__/* .useTranslation */ .$G)();
    const { theme  } = (0,hooks_useTheme__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)();
    if (!data || data.length === 0) {
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(views_Info_components_ChartLoaders__WEBPACK_IMPORTED_MODULE_5__/* .LineChartLoader */ .fn, {}));
    }
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(recharts__WEBPACK_IMPORTED_MODULE_2__.ResponsiveContainer, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(recharts__WEBPACK_IMPORTED_MODULE_2__.AreaChart, {
            data: data,
            width: 300,
            height: 308,
            margin: {
                top: 5,
                right: 15,
                left: 0,
                bottom: 5
            },
            onMouseLeave: ()=>{
                if (setHoverDate) setHoverDate(undefined);
                if (setHoverValue) setHoverValue(undefined);
            },
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("defs", {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("linearGradient", {
                        id: "gradient",
                        x1: "0",
                        y1: "0",
                        x2: "0",
                        y2: "1",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                offset: "5%",
                                stopColor: theme.colors.inputSecondary,
                                stopOpacity: 0.5
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                offset: "100%",
                                stopColor: theme.colors.secondary,
                                stopOpacity: 0
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(recharts__WEBPACK_IMPORTED_MODULE_2__.XAxis, {
                    dataKey: "time",
                    axisLine: false,
                    tickLine: false,
                    tickFormatter: (time)=>time.toLocaleDateString(undefined, {
                            day: '2-digit'
                        })
                    ,
                    minTickGap: 10
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(recharts__WEBPACK_IMPORTED_MODULE_2__.YAxis, {
                    dataKey: "value",
                    tickCount: 6,
                    scale: "linear",
                    axisLine: false,
                    tickLine: false,
                    fontSize: "12px",
                    tickFormatter: (val)=>`$${(0,views_Info_utils_formatInfoNumbers__WEBPACK_IMPORTED_MODULE_4__/* .formatAmount */ .d)(val)}`
                    ,
                    orientation: "right",
                    tick: {
                        dx: 10,
                        fill: theme.colors.textSubtle
                    }
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(recharts__WEBPACK_IMPORTED_MODULE_2__.Tooltip, {
                    cursor: {
                        stroke: theme.colors.secondary
                    },
                    contentStyle: {
                        display: 'none'
                    },
                    formatter: (tooltipValue, name, props)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(HoverUpdater, {
                            locale: locale,
                            payload: props.payload,
                            setHoverValue: setHoverValue,
                            setHoverDate: setHoverDate
                        })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(recharts__WEBPACK_IMPORTED_MODULE_2__.Area, {
                    dataKey: "value",
                    type: "monotone",
                    stroke: theme.colors.secondary,
                    fill: "url(#gradient)",
                    strokeWidth: 2
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LineChart);

});

/***/ }),

/***/ 5943:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4146);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(date_fns__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var views_Info_utils_formatInfoNumbers__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3589);
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8328);
/* harmony import */ var utils_truncateHash__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3467);
/* harmony import */ var state_info_types__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2157);
/* harmony import */ var config_constants_info__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4003);
/* harmony import */ var contexts_Localization__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9150);
/* harmony import */ var _shared__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8910);

// TODO PCS refactor ternaries
/* eslint-disable no-nested-ternary */ 










const Wrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-20b335cd-0"
})`
  width: 100%;
`;
const ResponsiveGrid = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-20b335cd-1"
})`
  display: grid;
  grid-gap: 1em;
  align-items: center;
  grid-template-columns: 2fr 0.8fr repeat(4, 1fr);
  padding: 0 24px;
  @media screen and (max-width: 940px) {
    grid-template-columns: 2fr repeat(4, 1fr);
    & > *:nth-child(5) {
      display: none;
    }
  }
  @media screen and (max-width: 800px) {
    grid-template-columns: 2fr repeat(2, 1fr);
    & > *:nth-child(5) {
      display: none;
    }
    & > *:nth-child(3) {
      display: none;
    }
    & > *:nth-child(4) {
      display: none;
    }
  }
  @media screen and (max-width: 500px) {
    grid-template-columns: 2fr 1fr;
    & > *:nth-child(5) {
      display: none;
    }
    & > *:nth-child(3) {
      display: none;
    }
    & > *:nth-child(4) {
      display: none;
    }
    & > *:nth-child(2) {
      display: none;
    }
  }
`;
const RadioGroup = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Flex).withConfig({
    componentId: "sc-20b335cd-2"
})`
  align-items: center;
  margin-right: 16px;
  margin-top: 8px;
  cursor: pointer;
`;
const SORT_FIELD = {
    amountUSD: 'amountUSD',
    timestamp: 'timestamp',
    sender: 'sender',
    amountToken0: 'amountToken0',
    amountToken1: 'amountToken1'
};
const TableLoader = ()=>{
    const loadingRow = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ResponsiveGrid, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Skeleton, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Skeleton, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Skeleton, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Skeleton, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Skeleton, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Skeleton, {})
        ]
    });
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            loadingRow,
            loadingRow,
            loadingRow
        ]
    }));
};
const DataRow = ({ transaction  })=>{
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_8__/* .useTranslation */ .$G)();
    const abs0 = Math.abs(transaction.amountToken0);
    const abs1 = Math.abs(transaction.amountToken1);
    const outputTokenSymbol = transaction.amountToken0 < 0 ? transaction.token0Symbol : transaction.token1Symbol;
    const inputTokenSymbol = transaction.amountToken1 < 0 ? transaction.token0Symbol : transaction.token1Symbol;
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ResponsiveGrid, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.LinkExternal, {
                href: (0,utils__WEBPACK_IMPORTED_MODULE_6__/* .getBscScanLink */ .s6)(transaction.hash, 'transaction'),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                    children: transaction.type === state_info_types__WEBPACK_IMPORTED_MODULE_7__/* .TransactionType.MINT */ .i.MINT ? t('Add %token0% and %token1%', {
                        token0: transaction.token0Symbol,
                        token1: transaction.token1Symbol
                    }) : transaction.type === state_info_types__WEBPACK_IMPORTED_MODULE_7__/* .TransactionType.SWAP */ .i.SWAP ? t('Swap %token0% for %token1%', {
                        token0: inputTokenSymbol,
                        token1: outputTokenSymbol
                    }) : t('Remove %token0% and %token1%', {
                        token0: transaction.token0Symbol,
                        token1: transaction.token1Symbol
                    })
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                children: [
                    "$",
                    (0,views_Info_utils_formatInfoNumbers__WEBPACK_IMPORTED_MODULE_5__/* .formatAmount */ .d)(transaction.amountUSD)
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                    children: `${(0,views_Info_utils_formatInfoNumbers__WEBPACK_IMPORTED_MODULE_5__/* .formatAmount */ .d)(abs0)} ${transaction.token0Symbol}`
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                    children: `${(0,views_Info_utils_formatInfoNumbers__WEBPACK_IMPORTED_MODULE_5__/* .formatAmount */ .d)(abs1)} ${transaction.token1Symbol}`
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.LinkExternal, {
                href: (0,utils__WEBPACK_IMPORTED_MODULE_6__/* .getBscScanLink */ .s6)(transaction.sender, 'address'),
                children: (0,utils_truncateHash__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)(transaction.sender)
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                children: (0,date_fns__WEBPACK_IMPORTED_MODULE_3__.formatDistanceToNowStrict)(parseInt(transaction.timestamp, 10) * 1000)
            })
        ]
    }));
};
const TransactionTable = ({ transactions  })=>{
    const { 0: sortField , 1: setSortField  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(SORT_FIELD.timestamp);
    const { 0: sortDirection , 1: setSortDirection  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const { t  } = (0,contexts_Localization__WEBPACK_IMPORTED_MODULE_8__/* .useTranslation */ .$G)();
    const { 0: page , 1: setPage  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(1);
    const { 0: maxPage , 1: setMaxPage  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(1);
    const { 0: txFilter , 1: setTxFilter  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(undefined);
    const sortedTransactions = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        const toBeAbsList = [
            SORT_FIELD.amountToken0,
            SORT_FIELD.amountToken1
        ];
        return transactions ? transactions.slice().sort((a, b)=>{
            if (a && b) {
                const firstField = a[sortField];
                const secondField = b[sortField];
                const [first, second] = toBeAbsList.includes(sortField) ? [
                    Math.abs(firstField),
                    Math.abs(secondField)
                ] : [
                    firstField,
                    secondField
                ];
                return first > second ? (sortDirection ? -1 : 1) * 1 : (sortDirection ? -1 : 1) * -1;
            }
            return -1;
        }).filter((x)=>{
            return txFilter === undefined || x.type === txFilter;
        }).slice(config_constants_info__WEBPACK_IMPORTED_MODULE_11__/* .ITEMS_PER_INFO_TABLE_PAGE */ .si * (page - 1), page * config_constants_info__WEBPACK_IMPORTED_MODULE_11__/* .ITEMS_PER_INFO_TABLE_PAGE */ .si) : [];
    }, [
        transactions,
        page,
        sortField,
        sortDirection,
        txFilter
    ]);
    // Update maxPage based on amount of items & applied filtering
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (transactions) {
            const filteredTransactions = transactions.filter((tx)=>{
                return txFilter === undefined || tx.type === txFilter;
            });
            if (filteredTransactions.length % config_constants_info__WEBPACK_IMPORTED_MODULE_11__/* .ITEMS_PER_INFO_TABLE_PAGE */ .si === 0) {
                setMaxPage(Math.floor(filteredTransactions.length / config_constants_info__WEBPACK_IMPORTED_MODULE_11__/* .ITEMS_PER_INFO_TABLE_PAGE */ .si));
            } else {
                setMaxPage(Math.floor(filteredTransactions.length / config_constants_info__WEBPACK_IMPORTED_MODULE_11__/* .ITEMS_PER_INFO_TABLE_PAGE */ .si) + 1);
            }
        }
    }, [
        transactions,
        txFilter
    ]);
    const handleFilter = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((newFilter)=>{
        if (newFilter !== txFilter) {
            setTxFilter(newFilter);
            setPage(1);
        }
    }, [
        txFilter
    ]);
    const handleSort = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((newField)=>{
        setSortField(newField);
        setSortDirection(sortField !== newField ? true : !sortDirection);
    }, [
        sortDirection,
        sortField
    ]);
    const arrow = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((field)=>{
        const directionArrow = !sortDirection ? '↑' : '↓';
        return sortField === field ? directionArrow : '';
    }, [
        sortDirection,
        sortField
    ]);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Wrapper, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Flex, {
                mb: "16px",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Flex, {
                        flexDirection: [
                            'column',
                            'row'
                        ],
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(RadioGroup, {
                                onClick: ()=>handleFilter(undefined)
                                ,
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Radio, {
                                        onChange: ()=>null
                                        ,
                                        scale: "sm",
                                        checked: txFilter === undefined
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                                        ml: "8px",
                                        children: t('All')
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(RadioGroup, {
                                onClick: ()=>handleFilter(state_info_types__WEBPACK_IMPORTED_MODULE_7__/* .TransactionType.SWAP */ .i.SWAP)
                                ,
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Radio, {
                                        onChange: ()=>null
                                        ,
                                        scale: "sm",
                                        checked: txFilter === state_info_types__WEBPACK_IMPORTED_MODULE_7__/* .TransactionType.SWAP */ .i.SWAP
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                                        ml: "8px",
                                        children: t('Swaps')
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Flex, {
                        flexDirection: [
                            'column',
                            'row'
                        ],
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(RadioGroup, {
                                onClick: ()=>handleFilter(state_info_types__WEBPACK_IMPORTED_MODULE_7__/* .TransactionType.MINT */ .i.MINT)
                                ,
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Radio, {
                                        onChange: ()=>null
                                        ,
                                        scale: "sm",
                                        checked: txFilter === state_info_types__WEBPACK_IMPORTED_MODULE_7__/* .TransactionType.MINT */ .i.MINT
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                                        ml: "8px",
                                        children: t('Adds')
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(RadioGroup, {
                                onClick: ()=>handleFilter(state_info_types__WEBPACK_IMPORTED_MODULE_7__/* .TransactionType.BURN */ .i.BURN)
                                ,
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Radio, {
                                        onChange: ()=>null
                                        ,
                                        scale: "sm",
                                        checked: txFilter === state_info_types__WEBPACK_IMPORTED_MODULE_7__/* .TransactionType.BURN */ .i.BURN
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                                        ml: "8px",
                                        children: t('Removes')
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_shared__WEBPACK_IMPORTED_MODULE_9__/* .TableWrapper */ .y6, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ResponsiveGrid, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                                color: "secondary",
                                fontSize: "12px",
                                bold: true,
                                textTransform: "uppercase",
                                children: t('Action')
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_shared__WEBPACK_IMPORTED_MODULE_9__/* .ClickableColumnHeader */ ._J, {
                                color: "secondary",
                                fontSize: "12px",
                                bold: true,
                                onClick: ()=>handleSort(SORT_FIELD.amountUSD)
                                ,
                                textTransform: "uppercase",
                                children: [
                                    t('Total Value'),
                                    " ",
                                    arrow(SORT_FIELD.amountUSD)
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_shared__WEBPACK_IMPORTED_MODULE_9__/* .ClickableColumnHeader */ ._J, {
                                color: "secondary",
                                fontSize: "12px",
                                bold: true,
                                onClick: ()=>handleSort(SORT_FIELD.amountToken0)
                                ,
                                textTransform: "uppercase",
                                children: [
                                    t('Token Amount'),
                                    " ",
                                    arrow(SORT_FIELD.amountToken0)
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_shared__WEBPACK_IMPORTED_MODULE_9__/* .ClickableColumnHeader */ ._J, {
                                color: "secondary",
                                fontSize: "12px",
                                bold: true,
                                onClick: ()=>handleSort(SORT_FIELD.amountToken1)
                                ,
                                textTransform: "uppercase",
                                children: [
                                    t('Token Amount'),
                                    " ",
                                    arrow(SORT_FIELD.amountToken1)
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_shared__WEBPACK_IMPORTED_MODULE_9__/* .ClickableColumnHeader */ ._J, {
                                color: "secondary",
                                fontSize: "12px",
                                bold: true,
                                onClick: ()=>handleSort(SORT_FIELD.sender)
                                ,
                                textTransform: "uppercase",
                                children: [
                                    t('Account'),
                                    " ",
                                    arrow(SORT_FIELD.sender)
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_shared__WEBPACK_IMPORTED_MODULE_9__/* .ClickableColumnHeader */ ._J, {
                                color: "secondary",
                                fontSize: "12px",
                                bold: true,
                                onClick: ()=>handleSort(SORT_FIELD.timestamp)
                                ,
                                textTransform: "uppercase",
                                children: [
                                    t('Time'),
                                    " ",
                                    arrow(SORT_FIELD.timestamp)
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_shared__WEBPACK_IMPORTED_MODULE_9__/* .Break */ .SS, {}),
                    transactions ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            sortedTransactions.map((transaction, index)=>{
                                if (transaction) {
                                    return(// eslint-disable-next-line react/no-array-index-key
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(DataRow, {
                                                transaction: transaction
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_shared__WEBPACK_IMPORTED_MODULE_9__/* .Break */ .SS, {})
                                        ]
                                    }, index));
                                }
                                return null;
                            }),
                            sortedTransactions.length === 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Flex, {
                                justifyContent: "center",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                                    children: t('No Transactions')
                                })
                            }) : undefined,
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_shared__WEBPACK_IMPORTED_MODULE_9__/* .PageButtons */ .Ob, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_shared__WEBPACK_IMPORTED_MODULE_9__/* .Arrow */ .Eh, {
                                        onClick: ()=>{
                                            setPage(page === 1 ? page : page - 1);
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.ArrowBackIcon, {
                                            color: page === 1 ? 'textDisabled' : 'primary'
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                                        children: t('Page %page% of %maxPage%', {
                                            page,
                                            maxPage
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_shared__WEBPACK_IMPORTED_MODULE_9__/* .Arrow */ .Eh, {
                                        onClick: ()=>{
                                            setPage(page === maxPage ? page : page + 1);
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.ArrowForwardIcon, {
                                            color: page === maxPage ? 'textDisabled' : 'primary'
                                        })
                                    })
                                ]
                            })
                        ]
                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TableLoader, {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_4__.Box, {})
                        ]
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TransactionTable);


/***/ }),

/***/ 7795:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2829);
/* harmony import */ var _pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__);



const Percent = ({ value , ...rest })=>{
    if (!value || Number.isNaN(value)) {
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
            ...rest,
            children: "-"
        }));
    }
    const isNegative = value < 0;
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
        ...rest,
        color: isNegative ? 'failure' : 'success',
        children: [
            isNegative ? '↓' : '↑',
            Math.abs(value).toFixed(2),
            "%"
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Percent);


/***/ })

};
;
//# sourceMappingURL=838.js.map