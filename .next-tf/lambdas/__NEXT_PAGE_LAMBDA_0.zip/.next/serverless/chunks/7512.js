"use strict";
exports.id = 7512;
exports.ids = [7512];
exports.modules = {

/***/ 67512:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_PageSection)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(57518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: external "@pancakeswap/uikit"
var uikit_ = __webpack_require__(2829);
// EXTERNAL MODULE: ./src/components/Layout/Container.tsx
var Container = __webpack_require__(55027);
;// CONCATENATED MODULE: ./src/components/PageSection/svg/CurvedSvg.tsx




const sharedStyles = (theme, clipPath, clipFill)=>external_styled_components_.css`
  width: 100%;
  height: 20px;
  clip-path: url(${clipPath});

  background: ${()=>{
        if (theme.isDark) {
            return clipFill?.dark || clipFill?.light || theme.colors.background;
        }
        return clipFill?.light || theme.colors.background;
    }};

  & svg {
    display: block;
  }
`
;
const ConcaveContainer = external_styled_components_default()(uikit_.Box).withConfig({
    componentId: "sc-e8e7d569-0"
})`
  ${({ theme , clipPath , clipFill  })=>sharedStyles(theme, clipPath, clipFill)
}
  transform: ${({ clipPath  })=>clipPath === '#bottomConcaveCurve' ? 'translate(0, -13px)' : 'translate(0, 1px)'
};
`;
const ConvexContainer = external_styled_components_default()(uikit_.Box).withConfig({
    componentId: "sc-e8e7d569-1"
})`
  ${({ theme , clipPath , clipFill  })=>sharedStyles(theme, clipPath, clipFill)
}
  transform: ${({ clipPath  })=>clipPath === '#bottomConvexCurve' ? 'translate(0, -13px)' : 'translate(0, -1px)'
};
`;
const ConvexTop = ({ clipFill  })=>/*#__PURE__*/ jsx_runtime_.jsx(ConvexContainer, {
        clipFill: clipFill,
        clipPath: "#topConvexCurve",
        children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
            width: "0",
            height: "0",
            children: /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                    id: "topConvexCurve",
                    clipPathUnits: "objectBoundingBox",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        d: "M 0,1 L 0,0 L 1,0 L 1,1 C 0.75 0, .25 0, 0 1 Z"
                    })
                })
            })
        })
    })
;
const ConvexBottom = ({ clipFill  })=>/*#__PURE__*/ jsx_runtime_.jsx(ConvexContainer, {
        clipFill: clipFill,
        clipPath: "#bottomConvexCurve",
        children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
            width: "0",
            height: "0",
            children: /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                    id: "bottomConvexCurve",
                    clipPathUnits: "objectBoundingBox",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        d: "M 0,0 L 0,1 L 1,1 L 1,0 C .75 1, .25 1, 0 0 Z"
                    })
                })
            })
        })
    })
;
const ConcaveTop = ({ clipFill  })=>/*#__PURE__*/ jsx_runtime_.jsx(ConcaveContainer, {
        clipFill: clipFill,
        clipPath: "#topConcaveCurve",
        children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
            width: "0",
            height: "0",
            children: /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                    id: "topConcaveCurve",
                    clipPathUnits: "objectBoundingBox",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        d: "M 0,0 L 0,1 L 1,1 L 1,0 C .75 1, .25 1, 0 0 Z"
                    })
                })
            })
        })
    })
;
const ConcaveBottom = ({ clipFill  })=>/*#__PURE__*/ jsx_runtime_.jsx(ConcaveContainer, {
        clipFill: clipFill,
        clipPath: "#bottomConcaveCurve",
        children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
            width: "0",
            height: "0",
            children: /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                    id: "bottomConcaveCurve",
                    clipPathUnits: "objectBoundingBox",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        d: "M 0,1 L 0,0 L 1,0 L 1,1 C .75 0.1, .25 0.1, 0 1 Z"
                    })
                })
            })
        })
    })
;

;// CONCATENATED MODULE: ./src/components/PageSection/CurvedDivider.tsx




const Wrapper = external_styled_components_default().div.withConfig({
    componentId: "sc-b79bfb00-0"
})`
  background: ${({ theme , dividerFill  })=>{
    if (theme.isDark) {
        return dividerFill?.dark || dividerFill?.light || 'none';
    }
    return dividerFill?.light || dividerFill?.dark || 'none';
}};
  z-index: ${({ index  })=>index
};
  position: relative;
  display: flex;
  align-items: center;
  width: 100%;
`;
const ComponentWrapper = external_styled_components_default().div.withConfig({
    componentId: "sc-b79bfb00-1"
})`
  z-index: ${({ index  })=>index + 1
};
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
`;
const CurvedDivider = ({ index , dividerPosition , dividerComponent , concave , clipFill , dividerFill ,  })=>{
    const showConvexTop = dividerPosition === 'top' && !concave;
    const showConvexBottom = dividerPosition === 'bottom' && !concave;
    const showConcaveTop = dividerPosition === 'top' && concave;
    const showConcaveBottom = dividerPosition === 'bottom' && concave;
    const getConcaveDivider = ()=>{
        return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
            children: [
                showConcaveTop && /*#__PURE__*/ jsx_runtime_.jsx(ConcaveTop, {
                    clipFill: clipFill
                }),
                showConcaveBottom && /*#__PURE__*/ jsx_runtime_.jsx(ConcaveBottom, {
                    clipFill: clipFill
                })
            ]
        }));
    };
    const getConvexDivider = ()=>{
        return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
            children: [
                showConvexTop && /*#__PURE__*/ jsx_runtime_.jsx(ConvexTop, {
                    clipFill: clipFill
                }),
                showConvexBottom && /*#__PURE__*/ jsx_runtime_.jsx(ConvexBottom, {
                    clipFill: clipFill
                })
            ]
        }));
    };
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(Wrapper, {
        index: index,
        dividerFill: dividerFill,
        children: [
            dividerComponent && /*#__PURE__*/ jsx_runtime_.jsx(ComponentWrapper, {
                index: index,
                children: dividerComponent
            }),
            getConcaveDivider(),
            getConvexDivider()
        ]
    }));
};
/* harmony default export */ const PageSection_CurvedDivider = (CurvedDivider);

;// CONCATENATED MODULE: ./src/components/PageSection/index.tsx






const BackgroundColor = external_styled_components_default()(uikit_.Flex).withConfig({
    componentId: "sc-195451d6-0"
})`
  position: relative;
  flex-direction: column;
  align-items: center;
  z-index: ${({ index  })=>index - 1
};
  background: ${({ background , theme  })=>background || theme.colors.background
};
  padding: ${({ getPadding  })=>getPadding()
};
`;
const ChildrenWrapper = external_styled_components_default()(Container/* default */.Z).withConfig({
    componentId: "sc-195451d6-1"
})`
  min-height: auto;
  padding-top: 16px;
  padding-bottom: 16px;

  ${({ theme  })=>theme.mediaQueries.sm
} {
    padding-top: 32px;
    padding-bottom: 32px;
  }

  ${({ theme  })=>theme.mediaQueries.lg
} {
    padding-top: 48px;
    padding-bottom: 48px;
  }
`;
const PageSection = ({ children , background , svgFill , index =1 , dividerComponent , dividerPosition ='bottom' , hasCurvedDivider =true , concaveDivider =false , clipFill , dividerFill , containerProps , innerProps , ...props })=>{
    const getPadding = ()=>{
        // No curved divider
        if (!hasCurvedDivider) {
            return '48px 0';
        }
        // Bottom curved divider
        // Less bottom padding, as the divider is present there
        if (dividerPosition === 'bottom') {
            return '48px 0 14px';
        }
        // Top curved divider
        // Less top padding, as the divider is present there
        if (dividerPosition === 'top') {
            return '14px 0 48px';
        }
        return '48px 0';
    };
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(uikit_.Box, {
        ...containerProps,
        children: [
            hasCurvedDivider && dividerPosition === 'top' && /*#__PURE__*/ jsx_runtime_.jsx(PageSection_CurvedDivider, {
                svgFill: svgFill,
                index: index,
                concave: concaveDivider,
                dividerPosition: dividerPosition,
                dividerComponent: dividerComponent,
                clipFill: clipFill,
                dividerFill: dividerFill
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(BackgroundColor, {
                background: background,
                index: index,
                getPadding: getPadding,
                ...props,
                children: /*#__PURE__*/ jsx_runtime_.jsx(ChildrenWrapper, {
                    ...innerProps,
                    children: children
                })
            }),
            hasCurvedDivider && dividerPosition === 'bottom' && /*#__PURE__*/ jsx_runtime_.jsx(PageSection_CurvedDivider, {
                svgFill: svgFill,
                index: index,
                concave: concaveDivider,
                dividerPosition: dividerPosition,
                dividerComponent: dividerComponent,
                clipFill: clipFill,
                dividerFill: dividerFill
            })
        ]
    }));
};
/* harmony default export */ const components_PageSection = (PageSection);


/***/ })

};
;
//# sourceMappingURL=7512.js.map